# OPC OS

**OPC OS = the governance operating system for AI-native teams** — it manages your AI members'
roles, tasks, token spend, work records, and acceptance review, all from one self-hosted package.

[中文文档](README_CN.md) · [部署手册（中文）](deploy-guide.md) · [Delivery checklist](delivery-checklist.md) · [安装文档](docs/installation-guide.md) · [时钟服务](docs/clock-service.md)

> Applies to: v0.6.0 (customer form · **non-Docker native processes**, synced with
> installation-guide v0.6.0 on 2026-08-28). Full from-scratch manual:
> [docs/installation-guide.md](docs/installation-guide.md).

## What is OPC OS?

Most "AI ops" tools watch how **humans** consume AI — seat counts, token budgets per employee,
prompt logs. OPC OS starts from the opposite premise: **the AI agents are the team members**.
A one-person company (or any team) can run a whole org of AI workers — CEO, dev, ops, marketing,
support, finance, intel, QA, design — and OPC OS is the layer that governs them:

- **Who they are** — a roster of named members with roles and profiles
- **What they're doing** — a kanban-driven task lifecycle (dispatch → claim → work → review → done)
  with full event history
- **What they cost** — per-member token attribution and cost rollups
- **Whether the work passed** — acceptance/QA outcomes and pass rates per member
- **Where they "sit"** — a transparency office page that renders the team, its live activity
  stream, and its task board for anyone to watch

Fully self-hosted. All data lives in a host directory you own (the `<opc-init output dir>`),
with no Docker / images / external services involved.

## Quick start (three commands)

Dependencies: node ≥ 20 + python3.10+ (with uv). Detailed steps in installation-guide v0.5:

```bash
# ① Generate your customer team (parameterized, non-interactive)
python3 scripts/opc_init.py --template software --name "<customer company>" --gateway --out ~/opc-test

# ② Install the Hermes team runtime (pinned fork base + per-member profiles routed via gateway)
bash scripts/install-hermes-worker.sh \
  --source ~/hermes-agent-src \
  --hermes-home ~/opc-test/hermes-home \
  --gateway-url http://127.0.0.1:18080/v1

# ③ Bring up the stack (5 services under systemd; degrades to nohup without systemd)
scripts/install-services.sh install --out ~/opc-test
```

> Env injection: all 5 `opcos-*` units receive tokens via systemd `EnvironmentFile` (default
> `<out>/secrets.env`, overridable with `--env-file <path>`, e.g. production `~/.hermes/.env`) —
> bare node/python daemons do not load env themselves, and a missing injection surface means
> member chats return 401. Verification commands: installation-guide §8.8.

Then open:

- Transparency office (virtual office / activity stream / task board): <http://localhost:8081/opc/>
- Governance dashboard (per-member tokens / cost / tasks / pass rate): <http://localhost:8081/opc/governance.html>
- Health check: <http://localhost:8081/healthz>
- LLM gateway admin: <http://127.0.0.1:18080/admin> (localhost only, Bearer-token auth)

On first start you immediately see the team at work (opc-init seeds a desensitized member
skeleton + welcome tasks); the collector then refreshes data every 1 minute (incremental).

## Services

| Service | Process | Port | Guarded by |
|---|---|---|---|
| llm-gateway | `node server.js` | 18080 (localhost only) | systemd `opcos-gateway` |
| opc-api | `node index.cjs` | 3033 | systemd `opcos-api` |
| web | `node scripts/web-serve.js` | 8081 | systemd `opcos-web` |
| collector | `python3 opc-bus.py` + host crontab | — | systemd `opcos-collector` + crontab |
| dispatcher | `python3 -m kanban_dispatcher.cli` | — | systemd `opcos-dispatcher` |

- **Gateway**: single model name `hermes-opc-v1`; circuit breaker / monthly budget / multi-upstream
  routing happen inside the gateway; customer keys only ever live in `llm.env` (chmod 600).
- **collector**: `opc_collect.py` (status collection) + `token_stats.py` (token attribution) run
  from the host crontab every 1 minute; plus the **`opc-bus.py` data-bus daemon** (1s incremental
  polling of `kanban.db` `task_events`, refreshing the `kanban` segment of `status.json` at
  second level).
- **dispatcher**: 60s tick elastic scheduling (auto-derives concurrency from machine capacity;
  `--tier/--mem-mb/--cpus` override explicitly).

The web pages fetch only local `/opc/data/*` JSON — no outbound calls, no third-party
endpoints, nothing leaves your machine.

## Configuration (`config/config.json`)

Switching machines or teams means **editing config only, never scripts**:

| Key | Purpose |
|---|---|
| `collector.profiles` | Member profile list (the scan scope of data sources) |
| `collector.cron_member` | cron job → member / action / description mapping (drives activity-stream text) |
| `collector.name_id` / `name_en` / `roles` / `role_en` / `roster` | Member roster and roles (Chinese name / English name / function) |
| `collector.paths` | Data-source and output paths (`hermes_home` / `kanban_db` / `out_status` / `token_stats_out` …; the container-era `/data` prefix is rewritten to host absolute paths by install-services.sh → `config.native.json`) |
| `collector.running_since` | Start date for the "running N days" counter in the office page |
| `bus` | Data-bus daemon config: `poll_seconds` (default `1.0`), `kanban_db`, `status_out`, `bus_state_file` (default `<paths.opc_dir>/bus-state.json`), `skip_kinds` (default `["heartbeat"]`) |

## Data bus

`opc-bus.py` (systemd `opcos-collector` daemon) — a zero-dependency Python daemon that keeps the
task board fresh **between** the 1-minute full snapshots:

- Polls `kanban.db` `task_events` incrementally (watermark file `<out>/bus-state.json` —
  survives restarts, no replay, no missed events), skipping `heartbeat` events by default.
- On a state-change event it recomputes the `kanban` segment of `status.json` and stamps
  `sources.kanban` segment-level metadata (`ts` / `watermark` / `events`) — all other segments
  are left untouched.
- Writes are atomic (`tmp` + `os.replace`), so the frontend `fs.watch` / SSE stream never sees a
  half-written file. Segment-level write coordination with `opc_collect.py` is "last writer wins"
  (the bus owns `kanban` + `sources.kanban`; collect owns everything else and never clobbers a
  fresher bus segment).
- If the bus dies, systemd `Restart=on-failure` pulls it back up; `opc_collect.py`'s 1-minute
  full snapshot keeps working as a fallback either way (no degradation).

**Packaging boundary**: the bus needs only `kanban.db` readable + `status.json` writable —
the SSE push endpoint (`/api/opc/stream`) is existing infrastructure in the target deployment,
not bundled here.

## Monitoring, alerting & self-healing (v0.5.1)

Production-proven ops components (from the 2026-08-27 incident: proxy node flapping → delivery
timeouts → false "down" alarms), merged into the product package. All paths are env-overridable
(`OPC_*` / `WD_*` / `SCRIPT_DIR` …); the defaults are the OPC production home only as a fallback —
point them at your deployment home via env (see installation-guide §11.5).

| Component | Script | Role |
|---|---|---|
| Alert bus | `scripts/opc-alert-bus.py` | Unified alert line `alerts/bus.jsonl` (atomic O_APPEND, fixed 9-field schema); CLI `append/read_new/mark_routed/mark_resolved/count_new/list`; P2 writes resolve immediately (info trace); fingerprint `source:type:YYYY-MM-DD` dedup |
| Alert router monitor | `scripts/alerts_bus_monitor.py` | 5-min cron monitor: stable hash output wakes the router agent only on change → tiered kanban card creation; `[STALE>2h]` self-watch; 18:50 daily summary window |
| Delivery watchdog | `scripts/telegram_delivery_watchdog.py` | 24h/15min sliding-window error stats + `blocked_config` scan; no_agent cron contract: silent when healthy, output only on anomaly/recovery |
| Proxy watchdog | `scripts/singbox-watchdog.sh` | Ladder self-heal (SIGHUP → restart → 30-min fuse); v2.1 continuous-window guard (≥5min before touching gateway) + running-job protection |
| Proxy daemon | `systemd/sing-box.service.in` | systemd **user** unit template (`%h` portable); `Restart=always` + `StartLimitIntervalSec=0`; install: `cp … ~/.config/systemd/user/ && systemctl --user enable --now sing-box` |
| Bus self-test | `scripts/test_alert_bus.py` | 24 assertions (append atomicity / P2 / read_new / mark transitions / fingerprint / evidence truncation / CLI), temp-dir isolated |

System-level monitoring (system-monitor load-shedding perception/self-heal) follows once its P0
acceptance passes (delivery-checklist §2 point 21).

After editing, restart to apply: `scripts/install-services.sh restart --out <opc-init output dir>`.

## Data ownership

- Everything lives in the `<opc-init output dir>` (`<out>`): `kanban.db` / `status.json` /
  `token-stats.json` / `bus-state.json` / `llm-gateway.json` / `hermes-home/` / `llm.env`(600).
- Backup / export (`scripts/backup.sh`, keeps the most recent 14 daily copies in `backups/<date>/`):

```bash
scripts/backup.sh --data-dir <opc-init output dir>          # native form, recommended
scripts/backup.sh --data-dir <output dir> --keep 30 --out /mnt/ops   # custom retention / destination
```

- Backup contents: `kanban.db` (tasks + event history), `status.json`, `token-stats.json`,
  `state.json`; missing any one file aborts the run (no incomplete backups). Restore steps:
  installation-guide v0.5 §12.

### Switching from demo data to real data

1. Stop the stack: `scripts/install-services.sh stop --out <out>`
2. Put your real `kanban.db` / `state.json` / Hermes profile data into `<out>` (or point
   `config.native.json`'s `paths` at them)
3. Edit `config/config.json` for your team (`profiles` / `name_id` / `roster` / `cron_member`),
   then re-run `scripts/install-services.sh install --out <out>` (idempotent, rewrites
   `config.native.json`)
4. Bring it up and verify: `scripts/install-services.sh start --out <out>` +
   `scripts/smoke_test.sh <port>`

Full step-by-step instructions are in [docs/installation-guide.md](docs/installation-guide.md)
and [deploy-guide.md](deploy-guide.md) (Chinese).

## Versioning & upgrades

- The **single source of truth for the version** is the repo-root `VERSION` file (currently `0.6.0`);
  releases are `VERSION` + a `CHANGELOG.md` entry + a git tag, all aligned under semver.
- The governance layer runs on top of a **pinned fork of Hermes Agent**
  (`theBigGavin/hermes-agent-fork`, private, tag-locked at `v0.20.5-opc.1`); the fork base is
  merged from upstream **weekly**, and deployment-package releases are tagged in git.
- **Check for updates**: `python3 scripts/opc-os-check-update.py --json` — reads the local `VERSION`,
  probes the latest release, exits silently when offline; on a newer version it writes
  `~/.opc-os/update-available.json` and pushes an `upgrade-available` alert-bus notification.
  Scheduled daily by `install-services.sh`'s crontab block (`OPC_UPDATE_CHECK_INTERVAL` configurable).
- **One-step upgrade**: `bash scripts/opc-os-upgrade.sh [--to vX.Y.Z]` — backs up first, applies the
  incremental upgrade, smokes, and auto-rolls back on failure. `--dry-run` to preview,
  `--rollback` to return to the previous tag and restore data.
- **Manual/offline fallback** (installation-guide v0.6 §9.5): backup first → `git pull` (or check
  out a newer tag / rsync the package) → re-run `scripts/install-services.sh install --out <out>` →
  verify with smoke / doctor.
- **Full upgrade (major version change)**: the script refuses to auto-upgrade and prints a full
  reinstall guide; use `--force` only if you really mean it.
- Rollback: `bash scripts/opc-os-upgrade.sh --rollback`, or manually `git checkout <previous-tag>`
  and re-run install. Neither upgrades nor rollbacks touch your data directory.

## Smoke test

```bash
scripts/smoke_test.sh 8081
```

37 checks (38 with `WORKBENCH_API` set): the 5 service processes online, all pages/HTTP
endpoints 200, clean-URL semantics, real data flowing (members, tasks, token stats — nothing
hardcoded), the data bus (opc-bus alive, `sources.kanban` metadata, watermark file), and the
desensitization red line (no real identities anywhere).

## Self-diagnostics (doctor)

```bash
cd opc-os && python3 scripts/opc-os-doctor.py   # 10 check groups: deps/processes/units/ports/gateway/proxy/keys/dispatch/data-flow/red-line
python3 scripts/opc-os-doctor.py --json         # machine-readable {group,status,detail,fix}
echo $?                                         # 0=all green / 1=FAIL found / 2=tool error
```

> The doctor (`scripts/opc-os-doctor.py`) ships with the deployment package (P0-3 delivery);
> its spec is the one defined in installation-guide v0.5 §10.

## FAQ

**Does it need internet access at runtime?**
No. Dashboards read only local JSON from the output directory. (Only the install phase needs
package sources: node / python / uv; restricted networks: installation-guide §2.)

**Where is my data?**
In the `<opc-init output dir>` directory (`kanban.db` / `status.json` / `token-stats.json` etc.).
Nothing is sent anywhere.

**How do I reset to a clean demo?**
Re-run opc-init (point `--out` at a fresh directory, or empty the old one first), then
`install-services.sh install`. Deleting the data directory resets everything.

**Port 8081 is taken?**
`scripts/install-services.sh install --out <out> --web-port <new-port>` to change the port, and
pass the new port to `smoke_test.sh`.

**Is any of the demo data real?**
No. The demo team, tasks, and token numbers are entirely fictional and pre-desensitized.

**How do I manage the services?**
`scripts/install-services.sh status|restart|stop --out <out>` (equivalent under systemd:
`systemctl status opcos-*`); logs in `journalctl -u opcos-<service>` and `<out>/logs/*.log`.

## Boundaries (red lines)

- The bundled demo data is **fully fictional** — it contains no real business data.
- A deployed instance keeps all data internal; no external market/third-party data is mixed in.
- This package contains **no payment, billing, or pricing code**.
- Upstream LLM keys only ever live in `<out>/llm.env` (chmod 600); zero plaintext credentials
  in docs / code / logs.