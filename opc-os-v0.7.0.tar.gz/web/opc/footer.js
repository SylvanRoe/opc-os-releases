/* OPC OS — 页面底部「Powered by Gavin's Lab」链接 + 官网来源回传统计（0826-os-2 / os-2b）
 *
 * 职责：
 *   1. 客户部署的 OPC-OS 页面底部显示「Powered by Gavin's Lab」，点击 → https://hermes.cc.cd
 *      （target=_blank rel=noopener noreferrer，遵循 ui.js 既有外链规范）
 *   2. 点击时向官网统计接口回传匿名安装 ID + 产品版本 + 轻量设备指纹
 *      （GET /api/opc-install?src=opc-os&install_id=<id>&v=<ver>&fp=<16hex>）
 *   3. 隐私红线（Gavin 拍板，0826-os-2b 更新口径）：
 *      - 只回传匿名安装 ID + 轻量设备指纹，不采集个人可识别信息（姓名/邮箱/账号等）
 *      - 轻量指纹 = UA + 语言 + 屏幕分辨率 + 时区的单向哈希（FNV-1a 64bit，不可逆），
 *        仅用于官网统计「唯一安装数量」（跨重装去重），不做行为追踪
 *      - 无 install_id（异常态/self 形态）静默跳过不回传；回传失败静默（不报错、不阻断跳转）
 *
 * 数据源：<opc-init 输出>/install.json（web 容器 customer 形态挂载为 /opc/data/install.json）；
 * self 形态（OPC 官网线上）卷内无 install.json → fetch 404 → 静默跳过。
 * 页面加载时预读一次并缓存 {install_id, version}，点击回传全程同步（keepalive 更可靠）。
 *
 * 引入方式：index.html / governance.html 由 patch_static.py 在 </body> 前注入
 * <script src="/opc/footer.js"></script>；workbench.html 手动同步时同样注入（见 opc-os skill）。
 */
(function () {
  'use strict';

  var TRACK_URL = 'https://api.hermes.cc.cd/api/opc-install';
  var SRC = 'opc-os';
  // 读 install.json 失败时的兜底版本（与 scripts/opc_init.py 的 VERSION 对齐，发版同步）
  var FALLBACK_VERSION = '0.3.5';

  // 样式：复用页面主题变量（--fg/--muted/--border），明暗主题自适应；只注入一次
  var STYLE_ID = 'opc-powered-style';
  var STYLE_CSS =
    'footer.opc-powered{display:flex;justify-content:center;align-items:center;gap:6px;' +
    'flex-wrap:wrap;margin-top:34px;padding-top:16px;border-top:1px solid var(--border,#e5e7eb);' +
    'font-size:12px;color:var(--muted,#9ca3af);}' +
    'footer.opc-powered a{color:var(--muted,#9ca3af);text-decoration:none;font-weight:600;}' +
    'footer.opc-powered a:hover{color:var(--fg,#111827);text-decoration:underline;}' +
    'footer .opc-powered{display:inline-flex;align-items:center;gap:6px;}' +
    'footer .opc-powered a{color:var(--muted,#9ca3af);text-decoration:none;font-weight:600;}' +
    'footer .opc-powered a:hover{color:var(--fg,#111827);text-decoration:underline;}';

  // 轻量设备指纹：UA + 语言 + 屏幕分辨率 + 时区 拼接后 FNV-1a 64bit 哈希（16 位 hex，不可逆）。
  // 只取浏览器可复现的稳定特征，不含任何个人可识别信息；用于官网「唯一安装数量」去重口径。
  function computeFingerprint() {
    var parts = [];
    try { parts.push(navigator.userAgent || ''); } catch (e) { parts.push(''); }
    try { parts.push(navigator.language || ''); } catch (e) { parts.push(''); }
    try { parts.push((screen.width || 0) + 'x' + (screen.height || 0)); } catch (e) { parts.push('0x0'); }
    try {
      // IANA 时区名（如 Asia/Shanghai）跨 DST 稳定；旧浏览器兜底 getTimezoneOffset 分钟数
      var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      parts.push(tz || String(new Date().getTimezoneOffset()));
    } catch (e) { parts.push(String(new Date().getTimezoneOffset())); }
    var s = parts.join('|');
    var h = 0xcbf29ce484222325n;          // FNV-1a 64bit offset basis
    var PRIME = 0x100000001b3n;           // FNV-1a 64bit prime
    for (var i = 0; i < s.length; i++) {
      h ^= BigInt(s.charCodeAt(i));
      h = (h * PRIME) & 0xffffffffffffffffn;
    }
    return h.toString(16).padStart(16, '0');
  }

  function ensureStyle() {
    try {
      if (document.getElementById(STYLE_ID)) return;
      var st = document.createElement('style');
      st.id = STYLE_ID;
      st.textContent = STYLE_CSS;
      (document.head || document.documentElement).appendChild(st);
    } catch (e) { /* 样式失败不影响功能 */ }
  }

  function boot() {
    ensureStyle();
    var link = document.createElement('a');
    link.href = 'https://hermes.cc.cd/?src=' + encodeURIComponent(SRC);
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = "Gavin's Lab";

    var mark = document.createElement('span');
    mark.className = 'opc-powered';
    mark.appendChild(document.createTextNode('Powered by '));
    mark.appendChild(link);

    var existing = document.querySelector('footer');
    if (existing) {
      // governance / workbench 已有 footer：右侧追加 Powered by
      existing.appendChild(mark);
    } else {
      // index 无 footer：body 尾部新建
      var foot = document.createElement('footer');
      foot.className = 'opc-powered';
      foot.appendChild(document.createTextNode('Powered by '));
      foot.appendChild(link);
      document.body.appendChild(foot);
    }

    // 预读本地 install.json（customer 形态卷内），缓存 {install_id, version}。
    // 点击回传时全程同步发起（keepalive 可靠）；读取失败/self 形态 → 缓存 null → 点击静默。
    var installInfo = null;
    fetch('./data/install.json', { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        if (j && j.install_id) {
          installInfo = { id: j.install_id, ver: (j && j.version) || FALLBACK_VERSION };
        }
      })
      .catch(function () {});

    // 点击回传：匿名安装 ID + 版本 + 轻量设备指纹请求官网统计；
    // 无 ID / 读取失败 / 网络失败全部静默。不 preventDefault，链接正常新标签打开。
    link.addEventListener('click', function () {
      try {
        if (!installInfo) return;  // 异常态：仅带 src 的链接照常打开，不回传
        var fp = computeFingerprint();
        var u = TRACK_URL + '?src=' + encodeURIComponent(SRC) +
                '&install_id=' + encodeURIComponent(installInfo.id) +
                '&v=' + encodeURIComponent(installInfo.ver) +
                '&fp=' + encodeURIComponent(fp);
        // no-cors：客户部署 origin 不在官网 CORS 白名单，请求只需送达无需读响应
        fetch(u, { method: 'GET', mode: 'no-cors', cache: 'no-store',
                   referrerPolicy: 'no-referrer', keepalive: true })
          .catch(function () {});
      } catch (e) { /* 静默 */ }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
