# Changelog

本仓版本制度（资产版本制度 v1.0，2026-08-23 落地）：版本号 = git tag `vX.Y.Z` + 本文件条目；**仓根 `VERSION` 文件为版本单一来源**（v0.6.0 起；`opc_init.py --version` / check-update / upgrade 全部读取，与 git tag 对齐）。语义 semver（主.次.补丁）。

> 注：历史 tag v0.1.1/v0.2/v0.3/v0.3.1/v0.3.2 为版本制度落地前旧打标，非 semver 规范；以 VERSION='0.1.0' 为基线对齐打 tag v0.1.0。
> 注：v0.5 为**文档版本**（installation-guide v0.5 / delivery-checklist v0.3 / README_CN 同步，邵阳盘点 GAP-8），非 git tag；git tag 发布另议。v0.6.0 为升级机制版本（VERSION 文件 = `0.6.0`；G 卡 G-2026-08-27-002 拍板后已补 annotated tag v0.6.0，三源对齐）。

## 历史处置（2026-08-27）
> 按 asset-versioning.md v2.0 §7 方案 B 执行：保留不删，标注 deprecated。一次性治理记录，不参与版本判定。
- [v0.1] / [v0.1.1] / [v0.2] / [v0.3] / [v0.3.1] / [v0.3.2]：非规范旧打标（缺 PATCH 段）且无条目 → deprecated
- [v0.3.3]：有 tag 无条目，无法追溯 → deprecated
- [v0.5]（条目）：文档自版本轨产物，已并入代码版本体系，不再作为独立版本

## [v0.7.0] - 2026-08-28
### Feat（网关配置并发写保护 · 卡 t_d24edd9e / arch 评估 t_bf2cfddd · Gavin 0827 P0 事故根治：写锁 + 版本戳 CAS + 终态校验 + 单终态流程 SOP）
- **背景**：多会话并发写生产 `gateway.config.json` 互相覆盖 → unified 请求漂移到错误模型（eyuai 文本版非 vision）。根因 = 写路径缺失 + 拍板无唯一事实源，锁只是放大器。
- **W2 写锁（单写者判定红线）**：`llm-gateway/lib/admin.js` 新增受管写唯一入口 `writeConfigGuarded`，一切 `gateway.config.json` 写路径（setDirection / setDefaultProvider / thresholds / provider CRUD）统一经它：**O_EXCL 原子创建 `<config>.lock`（PID/时间戳）+ kill(pid,0) 存活检测 + TTL 60s 陈旧锁回收 + finally 释放**；冲突 = 拒绝 + 409 明确报错（绝不排队，5ms 级写争用是病理；零依赖约束禁原生 flock）。判定：`grep writeFileSync(gateway.config.json)` 只剩 admin.js 原子写。
- **W3 版本戳 CAS**：配置顶层新增 `version`（受管写 +1 单调）/ `updated_at` / `updated_by`（operator，永不写 token 值）；directive 扩展为 `{seq, direction:{provider,model}, declared_state, decided_at, decided_by, card_id}`。写前 CAS：磁盘 `version` ≠ 调用方 base version → 409「版本冲突」；`--decided-at`（拍板决策时刻，非写入时刻）CLI 必填，缺省拒绝。`declared_state` = 目标终态 `{default_provider, default_model, max_tokens, context_window}`（来自目标 provider + 拍板声明，禁硬编码供应商/模型名）。
- **W4 终态校验**：受管写后重读磁盘断言 `default_provider/default_model/max_tokens/context_window` == `declared_state`；不一致 → 从 `.bak` 回滚 + opc-alert-bus 告警（source=llm-gateway, type=config_terminal_check_failed, fingerprint=llm-gateway:config_terminal_check_failed:YYYY-MM-DD 幂等）+ `events.jsonl` 审计 `config_terminal_check_failed`。
- **CLI**：`llm-gateway/bin/opc-gw-config`（Node）`--decided-at` 改必填、`show` 增 `config_version`+`declared_state`、写前自动带 `base_version`；新增运维层薄客户端 `scripts/opc-gw-config`（Python，env `GATEWAY_BASE_URL`+`GATEWAY_ADMIN_TOKEN`，与 opc-alert-bus.py 同层，不碰文件）。`lib/config.js` 三处统一用 `validateDirective` 校验 directive/version（boot load + admin 写入 + reload）。
- **W5 reload 方向校验（纵深）**：手改文件改方向但无/旧/非法 directive → 拒 reload 保旧配置 + `config_reload_rejected` 审计 + last_error。
- **W6 清理**：生产目录 8 个即兴 `.bak_*`（绕过网关的写者尸体）归档到 `.backup-0827-gw-bak-archive/`。
- **文档**：`docs/gateway-config-change-sop.md`（单终态五步跑 book：一次性拍板 → 单会话执行 → 提交前检查 → 提交后验证 → 完成留痕；并发改向拒绝下沉写路径）。
- **测试**：llm-gateway `npm test` 75/75 + model-capabilities 15 + circuit-isolation 12 = **102/102 全绿**；新增 W2（活锁 409/陈锁回收）、W3（decided_at 必填/版本冲突 409/version 单调+1）、W4（终态失败 500+回滚+审计）用例。
- **版本**：llm-gateway 1.6.1 → **1.7.0**；opc-os 0.6.0 → **0.7.0**。（承接前 [Unreleased] 的 llm-gateway 扩展 / model_capabilities / system-monitor 一并随本版发布）

### Feat（llm-gateway 网关扩展合入 · 卡 t_e6b210b1 · Gavin 0827「公司即产品」：统一模型路由/上下文窗口为通用能力、客户受益）
- **per-model / per-provider context_window + max_tokens（config 新字段）**：`lib/config.js` normalize() 保留 `default_model` / `context_window` / `max_tokens`（非法值抛错必大声；未配置 → undefined，行为不变，向后兼容）
- **统一模型显式路由**：`lib/providers.js` selectModel() 支持 provider 级 `default_model`——健康时用指定模型（避开 models[0] 顺序依赖），default_model 熔断/不健康回落原逻辑（首个健康声明模型 → models[0] 兜底）
- **max_tokens 兜底（防推理型空回复）**：`lib/forward.js` 转发时客户端缺失 max_tokens 或所带 < provider.max_tokens → 注入配置值（推理型模型 reasoning tokens 占满输出上限→空回复，Gavin 红线；未配置 provider 不变）
- **/v1/models 暴露 context_window**：`server.js` 对统一模型名返回首选 provider 的 context_window（health-aware，candidates[0]；配置了才返回该字段）
- 示例 `llm-gateway/gateway.config.json` 补 `default_model`/`max_tokens`/`context_window`（deepseek-v4-flash-vision-exp 主用示例，演示显式路由不依赖数组顺序）
- 官网能力登记 source 留痕：deepseek-v4-flash-vision-exp context 1M=1,048,576 / max_output 384K=393,216 / 思考默认开（reasoning_effort=high|max，官方 2026-04-24；https://api-docs.deepseek.com/updates/ + /api/create-response/ + HF deepseek-ai/DeepSeek-V4-Flash）；max_tokens 运行时默认 800（Gavin 认可 300-800 常规），能力上限 384K 属 model_capabilities 注册范畴（子卡 t_d83d13e1）
- **进包状态：已合入 push（d97411c + 文档更正 e0fe42a）；蔡婉验收卡 t_bb9cce1b 验收 PASS 为最终确认，FAIL 则按结论修正回滚**（生产已实测 unified 落 deepseek/deepseek-v4-flash-vision-exp、reasoning_content 含、非空）

### Feat（llm-gateway model_capabilities 全模型官网能力注册表 · 卡 t_d83d13e1 · Gavin 0827「官网唯一事实源」铁律：全模型接入参数以官网为准 + source 留痕）
- **顶层 `model_capabilities` 注册表（gateway.config.json）**：按 model-id 索引的官网能力表，每条目 `context_length` / `max_output` / `reasoning` / `source`（官网 URL 留痕）/ `verified`（核验日期）/ `status`（verified|pending-官网核验）。已核 **10 个**（DeepSeek V4 三兄弟 1M=1,048,576 / 384K=393,216 / 思考默认开三档 low|high|max / OpenAI+Anthropic+Responses；MiniMax M2.7 + highspeed 204,800/196,608/思考不可关；M3 1,000,000/524,288/adaptive；Kimi K3 1M/1M/always-on、K2.7 Code + highspeed 262,144/262,144/always-on）；待核 **24 个**显式标 `pending-官网核验`（不伪造数值，仅登记已确认的 context：gpt-5.5/grok-4.3/grok-build-0.1、k3-256k、openrouter 17 个 :free 的 context 取自官方 catalog，其 max_output/思考官网未单独发布 → pending）。
- **`lib/config.js` normalize() 校验（可选，未配置行为不变）**：结构非法必大声报错不静默丢弃——context_length<=0 / max_output<=0 / reasoning 非枚举 / source 空 / status 非法 / api_format 或 reasoning_effort 非枚举 / model_capabilities 非对象，均抛错；`status=verified` 强制 context_length/max_output/reasoning 齐备，`pending` 允许只确认部分字段（不伪造）。
- **README「模型能力表（官网核验）」章节**：每模型 context/max_output/思考/source/verified 全列表（脚本从 config 生成，防 README↔config 漂移）+ 红线约束（provider 运行时默认值不得高于官方能力值）。
- **测试**：`test-model-capabilities.js` 新增 15 例（生产 config 通过 / 未配置向后兼容 / 各非法值抛错 / 覆盖 provider 声明模型）；生产 node --test **86/86 通过**（含真实 deepseek failover breaker 套件）。
- **官网值依据（source 留痕）**：DeepSeek V4（api-docs.deepseek.com/updates + /api/create-response/ + /quick_start/pricing/ + HF deepseek-ai/DeepSeek-V4-Flash）、MiniMax（platform.minimax.io api-overview + text-generation）、Kimi（platform.kimi.ai pricing/chat-k3 + kimi.com/code/docs）、xAI（docs.x.ai/developers/models）、OpenRouter 官方 catalog（openrouter.ai/api/v1/models）；核验日期 2026-08-27。
- **进包状态：已合入本提交；蔡婉验收卡 t_2616a553 验收 PASS 为最终确认**。

### Feat（system-monitor 降载感知/自愈合入 · 卡 t_eec83597 · Gavin 0827「公司即产品」：P0 复验 PASS 后合入）
- **`scripts/system-monitor.py`（统一系统监控：降载感知/自愈/留底/整点报）**：P0 复验 PASS（t_d1b7cc94）后合入部署包。run() 改 rc 语义（`RunResult` str 子类，`bool=rc==0`）——systemctl stop/start 静默成功不再被误判为失败，降载登记/P2 degrade 留痕/action 记录/heal_restore 恢复全链路闭环。**env 全参数化**（参照 opc-alert-bus.py `OPC_ALERT_DIR` 模式）：`OPC_HOME`/`OPC_SYSMON_DIR`/`OPC_SYSMON_LOG`/`OPC_KANBAN_DB`/`OPC_KANBAN_LOCK`/`OPC_GATEWAY_LOG`/`OPC_DISPATCHER_STATE`/`OPC_HERMES_CFG`/`OPC_PROFILES_DIR`/`OPC_XDG_RUNTIME_DIR`/`OPC_BUS_SCRIPT`，默认值=生产路径兜底（零行为变化）
- **自测进包**：`scripts/.system-health/test_degrade_perception.py`（19 项全绿；路径经 `__file__` 解析 + 设置 `OPC_BUS_SCRIPT`/`OPC_ALERT_DIR` 到临时目录，生产/产品包两处可跑、零污染生产）
- **文档同步**：delivery-checklist 验收点 21 转正（标注合入 commit）；installation-guide 新增 **§11.5.4 system-monitor 小节**（部署命令 + env 参数化 + 自测）；§14 红线 7 组件清单补 system-monitor.py
- 版本号维持 v0.6.0（升级机制版本；tag 发布规则待 G 卡 G-2026-08-27-002 拍板，本卡只合入不升版）

### Fixed（0826-osv-2c：web-serve.js clean-URL 重写，Gavin sandbox1 实测第 5 条）
- scripts/web-serve.js 新增无扩展名 clean-URL 白名单（`/opc/workbench` → workbench.html、
  `/opc/governance` → governance.html，web/opc/ 实页盘点仅此两页；目录 /opc/ 走既有 index.html
  逻辑不重复处理），处理位在 /opc/data 数据路由之后、静态映射之前：命中直接 serveFile 目标
  html（200，与 CF Pages 生产路由语义一致），未命中走原静态映射/404（禁 SPA 兜底，未知路径
  保持 404 不误伤 /opc/data、/healthz、静态资源）；/healthz、/ 301、数据路由零改动
- scripts/smoke_test.sh 新增 [clean-url] 段 5 用例：/opc/workbench 200+text/html、/opc/governance
  200、/opc/workbench.html 200（兼容原直映）、/opc/data/status.json 200（数据路由未破坏）、
  /opc/no-such-page 404（禁 SPA 兜底）。实测：修复前 404/404，修复后 200/200，数据路由与
  404 语义两边一致（git stash 对照）；smoke_test clean-url 段 5/5 + HTTP 段全绿
### Changed（0825-retro-6 三模板字段升级，govern 模板）
- opc-govern R1 修复/复验卡 body 自动含「初验卡 id + 原 FAIL 项清单」（gov-8）：
  `_extract_fail_items` 从失败卡（一轮=验收卡；二轮=复验卡）body + 验收人评论提取
  （`**P1-1 标题**` 严重度行 / ❌✗FAIL 标记行 / 「原 FAIL 项清单」段条目），当前轮
  block reason 原文恒追加兜底；复验时不用回翻历史（治「文档与脚本一致性」类 FAIL 返工）
- 新增 `docs/kanban-card-templates.md`（庄子派活模板文档 v1.0）：完成卡【自测点清单】
  （对齐验收脚本关键断言：exit code / HTTP 200 / 几何值 / 数据值）、验收卡【验收清单】
  +【视口矩阵】（桌面 ≥1024px / 平板 768px / 移动 375·390px 三档）、修复/复验卡模板
- 测试：test_govern.py 新增场景 1c（FAIL 清单提取 mock）+ 场景 6 二轮断言 + 场景 1 断言
  升级，59/59；test_govern_taskkind.py 修 gov-7c 缓存失效（reset/make_card 后
  `_invalidate_tk_cache`），23/23
- 同步：opc-govern.py 生产副本（~/.hermes/scripts/）与仓库版对齐（补 gov-7c/R5/R6
  未提交漂移），守护已重启；opc-team skill 三 profile（庄子/马克/蔡婉）补三模板字段约定

## [v0.6.0] - 2026-08-28
### Feat（Gavin 0827「建立升级机制」指令：已部署客户及时收到更新通知 + 安全升级 · 庄子拍板设计）
- **版本单一来源（D1）**：新增仓根 `VERSION` 文件（=`0.6.0`）；`scripts/opc_init.py --version` 改读 VERSION 文件（缺失时 fallback 硬编码常量，兼容旧部署包）；check-update / upgrade 脚本全部读 VERSION 文件，不解析 Python 源码
- **版本检查/通知（D2+D3）**：新增 `scripts/opc-os-check-update.py`——读本地 VERSION vs 远端最新（GitHub Releases API → `git ls-remote --tags origin` fallback，全失败离线静默退出 0 + 记 last-check）；semver 比较；有新版 **双落点通知**：alert-bus `append` type=upgrade-available（severity=P2 信息留痕）+ `~/.opc-os/update-available.json` `{current, latest, changelog_summary, detected_at}`（透明办公室角标数据源）；`--json` / `--force`；install-services.sh crontab 块新增每日版本检查行（`OPC_UPDATE_CHECK_INTERVAL` 可配 daily/hourly/Nh/Nd/raw cron，幂等安装）；env 全参数化（OPC_OS_REPO/OPC_OS_STATE_DIR/OPC_ALERT_DIR/OPC_UPDATE_CHECK_URL/OPC_UPDATE_CHECK_INTERVAL_H）
- **安全升级（D4+D6）**：新增 `scripts/opc-os-upgrade.sh`——阶段化流程（1 前置检查：部署形态 git/rsync 判定 + git 状态干净（`--force` 跳过）+ 磁盘 ≥1G + 当前版本 → 2 自动备份（调 backup.sh 7 文件集，失败中止）→ 3 目标版本解析（`--to` / update-available.json / git tag）→ 4 增量/全量判定（主版本不同拒绝自动升级输出全量重装指引，`--force` 可强制）→ 5 冒烟（smoke_test.sh + systemctl is-active opcos-*）→ 6 失败自动回滚（checkout 旧 tag + install 重跑 + 备份恢复数据）→ 7 成功留痕 `~/.opc-os/upgrade.log` `{ts, from, to, result}` + 清 update-available.json）；`--to vX.Y.Z` / `--dry-run` / `--rollback` / `--force`；env 全参数化（OPC_OS_REPO/OPC_OS_STATE_DIR/OPC_DATA_DIR/OPC_GATEWAY_CONFIG/OPC_SMOKE_PORT/OPC_UPGRADE_CHECK_DRY/OPC_SMOKE_SKIP_SYSTEMCTL）
- **备份扩展（D5，GAP-6 P1-1 代码部分）**：`scripts/backup.sh` 备份集 4 → **7 文件**（+gateway.config.json / bus-state.json / govern-state.json）；核心 4 文件（kanban.db/status.json/token-stats.json/state.json）缺一 = 中止并清理本次部分复制，配置类 3 文件缺 = 警告继续（新部署可能尚无）；`--keep/--out/--data-dir` + env `OPC_DATA_DIR`/`OPC_GATEWAY_CONFIG` 参数化
- **自测进包（D7）**：新增 `scripts/test_upgrade_mechanism.py`（46 项全绿，mock 远端零污染：check-update 间隔跳过/离线静默/双落点/无新版清残留、upgrade 主版本拒绝/`--dry-run`、backup 7 文件集）
- **文档同步（卡 B）**：installation-guide v0.5 → **v0.6**（§9 重写为「升级机制」章节：check-update + upgrade.sh + 版本制度 + 增量/全量判定 + 手工 SOP 兜底 + fork 底座升级 + 双路径回退；§12 备份同步 7 文件集）；delivery-checklist v0.3.2 → **v0.4**（新增验收点 22-25）；README.md + README_CN.md 升级段落同步一步升级/回退
- G 卡 G-2026-08-27-002（版本基线 tag + 发布规则）待 Gavin 拍板；v0.6.0 git tag 待 G 卡发布规则确认后补齐

## [v0.5.2] - 2026-08-27
### Feat（Gavin 0827 拍板：OPC llm-gateway 统一模型显式路由 + 推理型模型 max_tokens 红线注入 · 公司即产品）
> 更正说明（庄 · 修正 commit）：**d97411c 曾按旧指令「切主用 eyuai」合入（方向错误，被 Gavin 否决）**；本修正 commit 已把代码对齐 Gavin 最终拍板（23:29）**deepseek 主用 + vision-exp**，以下为最终事实内容，生产/产品包/网关三者一致。
- **主用切换（Gavin 最终拍板 23:29，权威以此为准）**：`default_provider=deepseek`（官方 api.deepseek.com，priority 1），统一模型显式路由 `default_model=deepseek-v4-flash-vision-exp`（带图识图实测可用）；eyuai 降 priority 2 兜底（同源 `deepseek-v4-flash` 文本版）；openrouter 4 / kimi 10。早期「切主用 eyuai」方案被 Gavin 否决，勿复辟。
- **官网能力登记（vision-exp，2026-04-24）**：context 1M=1,048,576 / max_output 384K=393,216 / 思考默认开（reasoning_effort=high|max）；来源 api-docs.deepseek.com/updates + /api/create-response/ + HF deepseek-ai/DeepSeek-V4-Flash。
- **推理型模型 max_tokens 红线（Gavin：max_tokens 必须给足，否则 reasoning 占满→空回复）**：
  - provider 级新增 `max_tokens` 配置（deepseek/eyuai=800，Gavin 认可 300-800 常规；**运行时默认，非能力上限**，能力上限 384K 属 model_capabilities 注册范畴 t_d83d13e1）；
  - `lib/forward.js`：对 unified 请求当客户端缺失或 `< provider.max_tokens` 时注入配置值（未配置 provider 行为不变=向后兼容）；
  - `lib/config.js`：透传 `max_tokens` / `context_window` / `default_model` 并校验（非法值抛错）；
  - `lib/providers.js`：`selectModel` 优先用 `default_model`（健康时避开 models[0] 顺序依赖，熔断回落原逻辑）；
  - `server.js`：/v1/models 对统一模型名暴露首选 provider 的 `context_window`（health-aware，candidates[0]；配置了才返回，向后兼容）。
  - 冒烟实测：max_tokens 缺失 / =20 / =300 均 200 非空（=20 曾空回复，现注入后修复）；=8000 原样透传不覆盖；reasoning_effort=high 请求返回 reasoning_content（思考透传回归）。
- **测试**：`test-unified-model.js` max_tokens 注入用例（缺失→800 / 20→800 / 300→800 / 8000→透传）；`fake-provider` 记录 `lastMaxTokens`；`gateway.unified.test.json` fake-b 加 `max_tokens=800`；生产 node --test **71/71 通过**（含 breaker 套件）。
- 注：产品包 `gateway.env` 不提交（含 key secrets，gitignore §10）；breaker 套件中依赖真实 deepseek 的 failover 用例需本机 DEEPSEEK_API_KEY（测试进程 env 或 GATEWAY_ENV_FILE 指向含 key 的机密文件），无 key 时该 3 用例 502 属环境依赖，非代码缺陷（生产有 gateway.env，71/71 全过为有效验证）。
- **进包状态：代码已合入本提交；蔡婉验收卡 t_bb9cce1b 验收 PASS 为最终确认，验收 FAIL 需按结论修正回滚**。

## [v0.5.1] - 2026-08-27
### Feat（Gavin 0827「公司即产品」拍板：生产变更必须评估合入产品包 · 首批合入）
- 监控/告警/守护组件合入部署包（生产 08-27 事故实战验证，全部 env 参数化，路径默认值仅生产兜底）：
  - `scripts/opc-alert-bus.py` 统一告警总线（bus.jsonl O_APPEND 原子写，schema 定稿 9 字段；append/read_new/mark_routed/mark_resolved/count_new/list；P2 直接 resolved 留痕；`OPC_ALERT_DIR` 可覆盖）
  - `scripts/alerts_bus_monitor.py` 告警路由 monitor（5min tick 稳定摘要 → 路由 agent 分级建卡；STALE>2h 自监控；18:50 汇总窗口）
  - `scripts/telegram_delivery_watchdog.py` 投递看门狗（日志滑动窗口 + blocked_config 扫描；no_agent 静默契约；`WD_*` 可覆盖；恢复输出留痕）
  - `scripts/singbox-watchdog.sh` 代理自愈看门狗（L1 SIGHUP→L2 restart→L3 熔断；v2.1 持续窗口防瞬态误杀 + 运行中任务保护）
  - `scripts/test_alert_bus.py` 总线单元自测（24 断言，临时目录零污染；路径经 `__file__` 解析，生产/产品包两处可跑）
  - `systemd/sing-box.service.in` 代理守护 user unit 模板（`%h` 相对路径天然可移植；Restart=always + StartLimitIntervalSec=0；生产 active 验证）
- 文档同步：delivery-checklist v0.3.1 → **v0.3.2**（§1.1b 可选守护 + §1.3 补 5 组件 + 验收点 18-21 + 交接核对项）；
  installation-guide 新增 **§11.5 监控/告警/自愈组件**（总线/看门狗/代理守护部署命令 + env 参数化约定），原 §11.5 → §11.6；§14 红线新增第 7 条（组件路径参数化，禁止客户化改硬编码）
- 合入评估留档：opc_sched_health.sh **不合入**（本机特例：OPC 9 人名册硬编码，客户 profile 名不同；dispatcher stuck 检查价值已由 doctor G11 覆盖）；
  system-monitor.py（降载感知）**已于 [Unreleased] 合入**（ada 验收 FAIL 修复链 t_f9843ec9 → 复验 t_d1b7cc94 PASS 后合入，验收点 21 转正）

## [v0.5] - 2026-08-27
### Docs（邵阳架构盘点 GAP-8 · P0-4，安装/运维文档补齐）
- docs/installation-guide.md v0.4 → v0.5，新增四章：
  - **§9 增量升级 SOP**：备份先行 → git pull / checkout tag / rsync 部署包 → install-services install 重跑（幂等，start=enable+restart 语义）→ smoke 验证；fork 底座 `install-hermes-worker.sh --tag` 升级；回退（checkout 旧 tag + install 重跑，数据不动）；覆盖「生产已有部署」场景
  - **§10 故障诊断**：opc-os-doctor 用法（`--json` / 退出码 0-1-2 / 10 组检查含义表）+ 常见故障定位表（现象 → doctor 组 → 修复命令，全部实测）；doctor 脚本随 P0-3 交付合入，未合入前按 P0-3 定稿规格描述并标注
  - **§11 日常监控**：systemctl status/is-active opcos-*、journalctl 日志、关键状态文件位置索引表（status/token-stats/bus-state/kanban.db/gateway.config.json/llm.env 等）、数据新鲜度快检（mtime < 2min）
  - **§12 备份与恢复**：backup.sh 实际行为（--data-dir 备份集 4 文件、默认 14 份、缺一失败中止、docker 分支仅 v0.2 旧形态兼容）+ 恢复步骤（停栈→保护现场→复制回→起栈→smoke）+ P1-1 备份集扩展标注
  - 原 §9 常见坑 → §13、§10 红线 → §14（交叉引用同步更新）
  - smoke 项数同步：32/32 → **37/37**（配 WORKBENCH_API 38/38，与 smoke_test.sh 实际一致）
- delivery-checklist.md v0.2 → **v0.3 重写**：去 docker 形态（compose/Dockerfile/镜像/卷引用清零），对齐部署包实际（5 服务 systemd unit + install 三件套 + smoke_test 37 项 + doctor（P0-3 交付）+ backup）；验收标准逐条可勾验（每条 = 一个可执行验证动作）
- README_CN.md 同步 v0.5：docker 操作段落清零（快速开始改三步原生安装、服务组成改 5 服务表、数据自持改宿主机目录、升级改 install-services SOP），新增 doctor / 监控 / 冒烟 37 项条目

## [v0.3.5] - 2026-08-25
### Fixed（0825-init-a 验收 FAIL 修复，R1 自动派修）
- install-hermes-worker.sh 首装校验段 SIGPIPE 竞态修复：`V=$(hermes --version | head -1)`
  在 `set -euo pipefail` 下冷启动多行输出被 head 提前关管道 → 非零管线 → exit 1 中止
  （安装实际成功但误导失败）；校验行与 profiles 列表行均加 `|| true` 防竞态，首装
  必达「== 完成 ==」且 exit 0（实测：全新首装 --source 校验全通 + 幂等重跑全通）
- deploy-guide §2.6 + 脚本完成提示补「启动客户端前导出 key」步骤：`set -a; source
  <out>/llm.env; set +a`（Hermes 客户端发请求前做自身凭据校验，未设置即报
  No usable credentials；值可为占位，网关用自身池 key 覆盖 Authorization）；
  验证清单新增第 8 项「客户端可启动」
- 脱敏：客户镜像内 OPC 真实身份清零——llm-gateway/lib/admin.js（庄子×2）/
  monitor/monitor.js（Gavin）/admin/index.html（OPC 规范）/admin/ui.css（Gavin）/
  web/opc/workbench.html（Gavin/庄子/蔡婉）注释全部中性化；进镜像代码文件 grep
  团队名零命中（*.md 由 .dockerignore 排除不进镜像；gavinlab-theme-v2 为功能 key 保留）
- VERSION → 0.3.5

## [v0.3.4] - 2026-08-25
### Added（0825-init 客户形态 v0.3）
- opc-init 网关模式（--llm gateway / --gateway / --gateway-url）：profile config.yaml
  base_url 指向 llm-gateway（默认 http://127.0.0.1:18080/v1），fallback_providers 保持空
  （熔断由网关负责）；交互选项新增 [gateway]（推荐）；llm.env 额外写网关 provider key
  变量（DEEPSEEK_API_KEY，chmod 600）；报告注明网关模式 + 网关地址；VERSION → 0.2.0
- scripts/install-hermes-worker.sh（新建）：客户 Hermes 运行时安装——安装 hermes-agent-fork
  （锁 tag v0.20.5-opc.1，GITHUB_TOKEN 拉私有仓或 --source 本地源码包）+ HERMES_HOME 指向
  opc-init 输出 hermes-home + 每 profile 官方 `hermes config set` 写网关配置（不手写
  config.yaml）+ key 只进 llm.env（600）+ 幂等（同 tag 跳过安装/换 tag 升级）+ 完成校验
  （hermes --version / profiles 列表 / 网关 /v1/models）
- llm-gateway 容器化（customer 形态部署包内置）：Dockerfile（node:24-alpine，零运行时
  依赖）+ docker-entrypoint.sh（首启默认配置拷入数据卷）+ GATEWAY_HOST env 覆盖 host
  （默认 127.0.0.1 不变，OPC 本机生产零变化）+ test-host-env.js 测试（npm test 18 项）
- docker-compose：base 新增 llm-gateway 服务（profiles: ["customer"]，self 形态 up 零
  变化；端口 127.0.0.1:18080 仅宿主回环；GATEWAY_ENV_FILE=/data/llm.env）+ llm_gateway_data 卷；
  customer.yml v0.3：数据源 = 宿主机 ${OPC_INIT_OUT} 目录（collector/init/web/opc-api 全
  bind），llm-gateway 激活（profiles !override []），欢迎态不回退
- deploy-guide.md §2.6「安装 Hermes 运行时（客户团队 Agent 底座）」：install-hermes-worker.sh
  用法 + HERMES_HOME 说明 + 网关模式配置 + llm.env 注入 + 客户形态验证清单
- docs/hermes-worker-containerization.md（A1 方案草案，只出方案不动代码）：Dockerfile
  思路/多 profile 编排（倾向每 profile 一容器）/gateway 网络别名/成本风险/暂缓立项建议

### Changed
- gateway.config.json / monitor.config.json：字段格式与生产侧管理 UI 原子写对齐（语义不变）

## [v0.1.0] - 2026-08-23
### Changed
- 版本制度落地（0823-ver-1）：根目录新增本 CHANGELOG.md；VERSION 常量（scripts/opc_init.py:37）确认 ='0.1.0'，git tag v0.1.0 对齐

### 基线现状（2026-08-23 快照，主要能力）
- OPC OS — governance operating system for AI-native teams（self-hosted, Docker）
- opc-govern 守护：R1 验收卡判定 / R2 复验路由 / R4 高风险动作审批校验（task_kind 字段优先 + 文本兜底）
- status.json members[] agent 状态机（working/searching/writing/awaiting/blocked/idle 6 态 + state_detail）
- visitor 旁观模式（?view=visitor 只读+隐私白名单）
