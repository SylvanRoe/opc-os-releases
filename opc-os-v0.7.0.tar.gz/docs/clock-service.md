# OPC 时钟服务（Clock Service）

> 0825-f（2026-08-25，Gavin P2 需求）：OPC 作为商用产品对时间极度敏感。本文档说明
> **权威时间端点怎么用**、**为什么不信会话头时间戳**、**容器/远程主机怎么对齐**、
> **全 profile TZ 统一方案**，以及**验证方法**。

## 一、为什么需要权威时间

现状（改造前）：

- 系统时钟本身很准（chrony 同步，`timedatectl` 显示 `System clock synchronized: yes`）
- 但**应用层 TZ 环境变量为空**（`echo $TZ` 无输出），容器形态（alpine/node:22-slim）
  未注入时区时 `date` 返回 UTC
- Hermes 会话头时间戳是**固定/可过期**的（内核在会话创建时固化日期，不随真实时间推进）——
  agent 若依赖会话头判断「现在几点」，会得到过期或错误的时间

统一方案：**统一时区 Asia/Shanghai（UTC+8，无夏令时）+ 实时时间注入**。
权威来源是 opc-api 的 `/api/time` 与 status.json 的 `server_time` 字段（两者同构），
**不依赖会话头**。

## 二、权威时间端点：GET /api/time

`opc-api`（默认 `:3033`，生产经 systemd `opcos-api` 常驻——2026-08-27 已从 pm2 迁移）：

```bash
curl -s https://opc.hermes.cc.cd/api/time
```

响应（统一包装 `{ok, data, ts}` 契约，时间载荷在 `data`）：

```json
{
  "ok": true,
  "data": {
    "iso": "2026-08-25T13:21:24+08:00",
    "unix": 1787635284,
    "tz": "Asia/Shanghai",
    "offset": 480
  },
  "ts": 1787635284298
}
```

| 字段 | 含义 |
|---|---|
| `iso` | Asia/Shanghai 墙钟 ISO 8601（带 `+08:00` 偏移，无 DST） |
| `unix` | epoch 秒（UTC 语义，跨时区可比） |
| `tz` | IANA 时区名，恒为 `Asia/Shanghai` |
| `offset` | UTC 偏移（分钟），恒为 `480`（= +08:00） |

要点：

- **不缓存**：每次请求实时生成（`lib/time.cjs` 的 `timePayload()`）
- 实现：`opc-api/lib/time.cjs`，注册于路由表 `"/api/time"`；测试 `opc-api/time.test.cjs`
  （`cd opc-api && node --test *.test.cjs`）
- CORS 白名单已含 `/api/time`（`OPC_WHITELISTED`），跨域预检放行
- 校准动作：agent/脚本拿到 `unix` 后与本地时钟比较即可得到偏差，需要精确时刻时
  **以 `iso`/`unix` 为准**，不要依赖会话头

### status.json 的 server_time 字段（同构）

透明办公室数据源 `status.json` 顶层带 `server_time`（opc_collect.py 每次全量写入注入，
与 `/api/time` 同构、同口径）：

```json
"server_time": { "iso": "2026-08-25T13:22:38+08:00", "unix": 1787635358, "tz": "Asia/Shanghai", "offset": 480 }
```

- 写入方：`opc_collect.py`（运行版 `~/.hermes/scripts/opc_collect.py` + 容器版
  `opc-os/scripts/opc_collect.py` 双份）、`gen_welcome_state.py`（欢迎态）与
  `opc-bus.py`（1s 高频段级写，0825-f 修复后同源刷新 `server_time`，保证校准源恒新鲜）
- `opc-bus.py`（1s 高频）写 kanban/members/activities/sources 段，同时刷新 `server_time`
  （与 collect 同源同口径）；其余顶层字段原样保留
- 前端透明办公室 header 中央的服务器时钟即由此字段驱动（秒级本地推进，
  **只在 server_time 比上次校准值更新时重新校准**——单调防回退，避免陈旧校准源
  把时钟钉在「最近一次 collect 写入时刻」，见 `company-site/opc/index.html` 的
  `updateServerClock()`；校准源明显落后于本地时钟 >5s 时以本地时钟兜底）

## 三、为什么不信会话头（红线说明）

Hermes 系统提示中的会话头时间戳是会话创建时固化的（为保证前缀缓存字节稳定，
日期按天粒度更新），**不是**「当前真实时间」；长时间运行的会话/网关重启后，
会话头时间会明显过期。本任务**不做**会话头 hack（fork 层会话头注入列为二期，
见 gov 卡备注）。正确姿势：

1. agent 需要当前时间 → 调 `/api/time`（或读 status.json `server_time`），
   或跑 `date`（终端子进程，实时）
2. 前端需要显示时间 → 读 `server_time` 并本地秒级推进

## 四、TZ 统一：全 profile / 容器 / 主机

### 1. Hermes 全 profile（default + 9 成员）

10 个 profile 的 `config.yaml` 均已用**官方命令**设置时区（红线：config.yaml 只允许
`hermes config set`，绝不手改）：

```bash
hermes -p <profile> config set timezone Asia/Shanghai
# default profile: HERMES_HOME=/home/gavin/.hermes hermes config set timezone Asia/Shanghai
```

生效范围：`hermes_time.now()`（cron 调度/报告时间戳/系统提示时区行）全部按
Asia/Shanghai 输出。已验证：10 profile 的 `hermes_time.now()` 均返回 `+08:00`、
`tzinfo: Asia/Shanghai`。

### 2. 运行环境注入 TZ=Asia/Shanghai（date 等子进程）

| 注入点 | 文件 | 生效时机 |
|---|---|---|
| 登录会话基线 | `/etc/environment`（已追加 `TZ=Asia/Shanghai`） | 新登录会话 |
| Hermes gateway | `~/.config/systemd/user/hermes-gateway.service.d/60-tz.conf`（`Environment="TZ=Asia/Shanghai"`） | 下次 `systemctl --user restart hermes-gateway` |
| opcos-* 服务（10 个） | unit 内 `Environment=TZ=Asia/Shanghai`（归档 ~/.hermes/opc/systemd-host/） | daemon-reload 后重启对应 unit |

说明：即使 TZ 环境变量缺失，`date` 输出仍为 CST（`/etc/localtime` 已是
Asia/Shanghai 符号链接）——TZ 注入是**防漂移加固**，保证任何被注入进程的
`TZ` 显式可查。gateway/opcos-* 的重启会中断运行中的会话/服务，因此本任务只部署
配置**不重启**，由运维择机重启生效。

### 3. 容器形态（opc-os docker-compose）

- `docker-compose.yml` 四个服务（collector / init / web / opc-api）均已注入
  `TZ=Asia/Shanghai` 环境变量；customer 形态（`-f docker-compose.customer.yml`）
  继承 base 的 TZ（compose list merge 保留）
- `Dockerfile.web`：`apk add tzdata` + 复制 `/etc/localtime` + `/etc/timezone`
  （alpine 基础镜像无 zoneinfo，不装 tzdata 则 TZ env 不生效）
- `Dockerfile.opc-api`：双兼容安装 tzdata（官方 node:22-slim=Debian apt-get /
  本地离线替换版=Alpine apk）+ localtime 对齐
- `Dockerfile.collector`：原本已 `apk add tzdata` + localtime 对齐（无改动）

验证：`docker compose up` 后容器内 `date` 输出 `CST +0800`（非 UTC）。

### 4. opc-init 客户环境

`opc_init.py` 生成的客户 profile 骨架 `config.yaml` 默认带 `timezone: Asia/Shanghai`
（`gen_profile_config_yaml()`）；opc-init 容器本身继承 compose 的 `TZ`。
新客户环境开箱即 Asia/Shanghai。

## 五、验证方法

```bash
# 1. /api/time 与系统 date 偏差 <2s
curl -s http://127.0.0.1:3033/api/time
# 2. profile 时区
python3 /tmp/verify_tz_profiles.py        # 10 profile date=CST + hermes_time +08:00
# 3. 容器
docker compose up -d --build && docker compose exec web date        # CST +0800
docker compose exec opc-api date
# 4. 透明办公室页面
# 打开 /opc/ 页面，header 中央显示 YYYY-MM-DD HH:MM:SS CST（秒级跳动）
# 5. 回归：cron 调度时刻显示仍 +08:00（config timezone=Asia/Shanghai 与原 server-local 同为 UTC+8）
```

## 六、相关文件清单

| 文件 | 变更 |
|---|---|
| `opc-api/lib/time.cjs` | 新增：时间载荷（iso/unix/tz/offset） |
| `opc-api/time.test.cjs` | 新增：6 例单测 |
| `opc-api/index.cjs` | 路由 `/api/time` + 白名单 + 头部注释 |
| `scripts/opc_collect.py`（运行版+容器版） | 顶层 `server_time` 注入 |
| `scripts/gen_welcome_state.py` | 欢迎态 `server_time` |
| `scripts/opc_init.py` | 客户 profile 骨架 `timezone: Asia/Shanghai` |
| `docker-compose.yml` | 4 服务 `TZ=Asia/Shanghai` |
| `Dockerfile.web` / `Dockerfile.opc-api` | tzdata + localtime 对齐 |
| `company-site/opc/index.html` | header 服务器时钟（server_time 驱动） |
| 系统层 | `/etc/environment` + gateway systemd drop-in + opcos-* unit 内 TZ |
| 10 × `config.yaml` | `timezone: Asia/Shanghai`（官方 hermes config set） |
