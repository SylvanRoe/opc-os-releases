# hermes-worker 容器化方案草案（A1，0825-init 交付）

> 状态：**方案草案，未实施**。CEO 拍板 A1 本期只出方案（2026-08-25），供创始人决策
> 是否立项。客户 Hermes 运行时当前交付形态 = A2 随包安装脚本（`scripts/install-hermes-worker.sh`，
> 本期已交付）；本草案是 A1 容器化的前置评估，其结论直接决定 A2 是否升级为容器化。

---

## 1. 背景与目标

客户团队成员 agent = 独立 Hermes 实例（多 profile）。当前 A2 形态：fork 装宿主机、
HERMES_HOME 指向 opc-init 输出的 `hermes-home/`（profiles 骨架），compose 只负责
治理栈（collector/web/opc-api/llm-gateway）。容器化目标：

1. 客户环境零依赖：不要求宿主机有 Node/Python/git（当前 A2 要求 python3 + git）；
2. 版本锁定 + 可复现：镜像 = 验证过的 fork tag，构建产物即交付物；
3. 与 compose 网络衔接：hermes-worker 容器走 compose 内部网络，直连
   `gateway:18080`（网关容器别名），不再依赖宿主机回环 127.0.0.1；
4. 多 profile 编排：一个容器跑多个 profile（每个 profile 一个进程）还是
   每 profile 一容器——本草案评估两种。

## 2. Dockerfile 思路

```dockerfile
# 方案基线：node 运行时 + fork 源码（Python 依赖由 venv 承载）
FROM node:24-alpine                 # 与 llm-gateway 同基座，本地已缓存
# 装 python3 + uv（fork 是 Python 项目，依赖极多：pyproject 精确 pin ≈ 60 包）
RUN apk add --no-cache python3 git uv tzdata
WORKDIR /opt/hermes-agent
# 构建期：拉取 fork（锁 tag v0.20.5-opc.1）+ 安装依赖到 venv
RUN git clone -q https://github.com/theBigGavin/hermes-agent-fork.git . \
 && git checkout -q v0.20.5-opc.1 \
 && uv venv /opt/venv && uv pip install --python /opt/venv/bin/python -e .
# 构建产物：/opt/venv/bin/hermes（可执行）+ 源码树
ENTRYPOINT ["/opt/venv/bin/hermes"]
```

要点：
- **Node 版本**：fork 依赖 Python 运行时（agent core），Node 仅 llm-gateway 需要；
  hermes-worker 容器实为 Python 容器，Node 非必需（除非跑 gateway 子进程）——两容器
  基座不必相同；
- **依赖安装**：`pip install -e .`（核心依赖，无 extras）≈ 30-60 包；构建期联网
  （PyPI），运行期零外连（LLM 请求走网关容器）——与现有「构建期联网、运行期零外连」红线一致；
- **构建产物**：镜像内 `venv + 源码 + profiles 挂载`；profiles 不 COPY 进镜像
  （客户数据，运行时 bind）。

## 3. 多 profile 进程编排（两种方案）

**方案甲：一容器多 profile（推荐候选）**

```yaml
services:
  hermes-worker:
    image: opc-os-hermes-worker:<tag>
    command: ["--multi", "--profiles", "ceo,ops,finance"]   # 内置编排器
    volumes:
      - ${OPC_INIT_OUT:-./opc-init-out}/hermes-home:/data/hermes-home
    networks: [default]        # 与 gateway 同网 → http://gateway:18080
```

- 内置一个薄编排器：N 个 profile = N 个 `hermes --profile <id> serve` 子进程，
  supervisor 守护（类似 opc-bus 的容器内守护模式：任一退出容器退出 → docker restart）；
- 优点：单容器管理、资源共享、与 collector 的守护模式一致（已验证模式）；
- 缺点：编排器本身是新增代码（薄，~100 行）；profile 间资源隔离弱。

**方案乙：每 profile 一容器**

```yaml
services:
  hermes-worker-ceo:  { image: ..., command: ["--profile", "ceo"],  volumes: [...] }
  hermes-worker-ops:  { image: ..., command: ["--profile", "ops"],  volumes: [...] }
```

- 优点：零编排器代码（官方 CLI 原生入口）、资源隔离好、独立重启；
- 缺点：compose 文件按客户团队规模静态展开（客户 5 人 / 20 人形态不同），
  需要模板生成 compose（opc-init 生成）；容器数量 = 团队规模。

**倾向**：方案乙（复用官方 CLI、零新增代码），compose 片段由 opc-init 按模板生成
（opc-init 已有成员清单，输出 compose 覆盖文件成本低）。

## 4. 与 compose 网络衔接（gateway 别名）

```yaml
# llm-gateway 已是 compose 服务（本期交付）→ 默认网络别名 = 服务名
# hermes-worker 容器内 config.yaml：
#   model.base_url: http://gateway:18080/v1     （容器内网络，非 127.0.0.1）
# 宿主形态（A2）仍是 http://127.0.0.1:18080/v1 —— install-hermes-worker.sh 的
# --gateway-url 参数已支持，容器化时传 http://gateway:18080/v1 即可，零代码改动。
```

前提：llm-gateway 容器 `GATEWAY_HOST=0.0.0.0`（本期已实现）+ 端口映射
`127.0.0.1:18080:18080` 保持（宿主 A2 形态仍走回环）；容器内直连走网络别名
`gateway:18080` 不经端口映射（compose 内部网络直通）。

## 5. 成本与风险

| 项 | 评估 |
|---|---|
| 构建成本 | 单镜像构建 ≈ 2-5 分钟（pip 依赖安装）；与现有 collector/web 镜像同量级 |
| 运行成本 | 每 profile 一容器 ≈ +100-300MB 内存（Hermes 常驻）；10 人团队 ≈ +2-3GB，可接受 |
| 升级成本 | 换 fork tag 重建镜像 + 滚动重启；比 A2（宿主机 git pull + pip）更干净 |
| 风险 1：profiles 挂载 | hermes-home bind 只读/读写？运行期 Hermes 写 profiles（技能/记忆）→ 需读写 bind，与 collector 只读共享冲突 → 需拆卷（运行时数据 vs 归因只读） |
| 风险 2：cron 调度 | 客户 profile cron 由 Hermes 进程内调度，容器重启丢任务窗口 → 需 restart 策略 + 幂等 cron |
| 风险 3：网关鉴权 | 容器内 profile 直连 gateway 无宿主 NAT，GATEWAY_ADMIN_TOKEN 不进容器（仅环境变量注入 llm-gateway），数据面无鉴权——与 A2 同风险面 |
| 风险 4：多平台 | 镜像需 linux/amd64 + arm64（客户机器异构）；CI 构建成本 |

## 6. 是否立项建议

**建议：暂缓立项（本期不实施）**，理由：

1. A2（随包安装脚本）已交付且验证——客户首单场景（单机自部署）够用；
2. 容器化收益主要在「零宿主机依赖 + 多机编排」，触发条件是阶段 3 对外试点
   （创始人拍板「不急，不排期」）；
3. 8/28 轨 A 窗口已排满（0825-init 本体 + 0825-j 网关面板 + 验收），硬塞有风险；
4. 本草案已把关键决策点（编排方案/网关别名/拆卷）钉死，立项时直接照做。

**立项触发条件**（任一满足即评估）：① 对外试点排期；② 客户环境出现
「宿主机无 Python/git」硬性要求；③ 单客户团队规模 > 15 人（容器资源隔离收益显性化）。

---

*本文档为方案草案，不含实施代码；实施时按 §2-4 决策点执行，交付物 = 镜像 + opc-init compose 生成器扩展。*
