# 网关配置变更 SOP（gateway-config-change-sop）

适用版本：llm-gateway ≥ 1.7.0 / opc-os ≥ 0.7.0
定稿依据：`2026-08-27-llm-gateway-concurrent-write-protection.md`（arch 评估，W1-W6 红线）
对象：模型接入 / 网关方向（default_provider / 主用模型 / priority）等**有明确终态**的配置变更。

---

## 0. 一句话原则

> **模型接入 / 网关配置变更 = 一次性拍板（单终态描述）→ 单会话执行 → 提交前检查 → 提交后验证 → 完成留痕。** 任何会话/人不得直接改 `gateway.config.json`；一切写只能经 `opc-gw-config` CLI → admin API → 网关单进程（唯一文件写者）。

---

## 1. 为什么必须有这道工序（事故复盘）

- **事故**：多条模型切换指令被并发 spawn 成多个会话，基于不同版本指令执行，并发写生产
  `gateway.config.json` 互相覆盖。最严重一次：一个执行「更早被否的切 eyuai」的会话把配置
  覆盖成 eyuai 主用 → unified 请求（`hermes-opc-v1`，所有 OPC agent 走此入口）漂移落到
  eyuai 通道的 deepseek-v4-flash **文本版（非 vision）**。
- **根因**：写路径缺失（绕过网关的即兴写者直改文件）+ 拍板无唯一事实源（无 machine-readable
  拍板戳）。锁缺失只是放大器，不是根因。
- **对策（W1-W6 判定红线）**：唯一写路径（CLI→admin API→单进程）+ 写锁（O_EXCL lockfile）
  + 版本戳 CAS + 写后终态校验 + reload 方向校验 + 清理即兴 `.bak_*`。

---

## 2. 写保护机制（1.7.0 起内嵌网关）

| 红线 | 机制 | 触发 |
|---|---|---|
| W1 唯一写路径 | 一切变更经 `opc-gw-config` → `PUT /admin/direction` 等 admin API | 直写 `gateway.config.json` = 违规 |
| W2 写锁 | `writeConfigGuarded`：O_EXCL 新建 `<config>.lock` + PID/ts + 陈旧回收；冲突 → 409 | 受管写并发争用 → 一成一拒 |
| W3 版本戳 CAS | 顶层 `version`（+1 单调）/ `updated_at` / `updated_by`；`directive.declared_state` | 写前磁盘 version ≠ base version → 409 |
| W4 终态校验 | 写后重读磁盘断言 `default_provider/default_model/max_tokens/context_window` == `declared_state` | 不一致 → 回滚 + opc-alert-bus 告警 + 审计 |
| W5 reload 方向校验 | 手改文件改方向但无/旧/非法 directive → 拒 reload 保旧配置 | 绕过 CLI 的即兴改向 |
| W6 清理 | 即兴 `.bak_*` 归档，不留现场 | 上线时执行 |

---

## 3. 单终态流程（五步，全程单会话）

### Step 1 — 一次性拍板（单终态描述）
在拍板（G 卡或用户指令）中**完整描述目标终态**，至少含：
- `default_provider`（主用供应商，如 `deepseek`）
- `default_model`（主用模型，如 `deepseek-v4-flash-vision-exp`）
- `max_tokens` / `context_window`（运行时上下限，二选一或全给）
- 拍板人 `decided_by`、拍板卡 `card_id`、**拍板决策时刻 `decided-at`**（非写入时刻）

> `decided-at` 是事故根因的解药：两个会话拿「写文件时刻」排序会被反转，所以必须用
> **拍板决策时刻**。CLI 缺省拒绝不带 `--decided-at` 的写入。

### Step 2 — 单会话执行
一个会话（严格单写者）执行以下**一条** CLI，不再并发 spaw n 其它改向会话：
```bash
cd opc-os/scripts   # 运维层 CLI；或 llm-gateway/bin/opc-gw-config
export GATEWAY_BASE_URL="http://127.0.0.1:18080"
export GATEWAY_ADMIN_TOKEN="<只从 env 文件读，不落库>"

opc-gw-config show   # 先读当前生效方向 + directive + config_version，作为基线

opc-gw-config set-direction \
  --provider deepseek --model deepseek-v4-flash-vision-exp \
  --decided-by zhuangzi --card-id G-2026-08-27-00N \
  --decided-at 2026-08-27T15:30:00.000Z
```

### Step 3 — 提交前检查（写锁 + CAS + normalize）
网关侧在写入前已自动完成：取锁（O_EXCL）→ CAS（`version` / `seq`）→ normalize 校验
（含 `directive`/`declared_state` 结构）。若并发会话更早已改方向：
- `seq` 旧 → 409「旧指令，已拒」
- `version` 旧 → 409「版本冲突」
此时**重读 `opc-gw-config show` 拿最新基线再重试**，绝不静默覆盖。

### Step 4 — 提交后验证（重读 + 终态断言 + 真实冒烟）
```bash
# ① 终态断言（网关自动：重读磁盘 == declared_state；失败 → 回滚 + 告警）
opc-gw-config show          # 确认 default_provider / active_direction / directive / config_version / config_sync
opc-gw-config verify --provider deepseek

# ② 真实 unified 冒烟请求（确认落点 = 目标 vision 模型，而非兜底文本版）
python3 - <<'PY'   # 或用 curl；见下
import os, json, urllib.request
tok = os.environ["GATEWAY_ADMIN_TOKEN"]  # 或 GATEWAY_CLIENT_TOKEN
req = urllib.request.Request("http://127.0.0.1:18080/v1/chat/completions",
    data=json.dumps({"model":"hermes-opc-v1","messages":[{"role":"user","content":"ping"}]}).encode(),
    headers={"Authorization":"Bearer "+tok,"Content-Type":"application/json"})
r = json.load(urllib.request.urlopen(req, timeout=60))
print("model落点/内容:", r["choices"][0]["message"]["content"][:80])
PY

# ③ /status 健康核对
curl -s http://127.0.0.1:18080/status | grep -E 'default_provider|current_provider'
```
验证要点：`/v1/models` 暴露 `context_window`（首选 provider）；unified 请求必须有内容且
`reasoning_content` 存在（vision/思考型模型特征）；`/status` `current_provider` 指向目标。

### Step 5 — 完成留痕
CLI 已自动落 `events.jsonl`（`admin_set_direction`）+ 版本戳。在拍板卡上留痕：
- 实际落点（provider/model/seq/config_version）
- 验证输出（冒烟请求内容）
- commit hash（若涉及产品包）

---

## 4. 并发改向指令的识别与拒绝

- **机制**：并发改向的检测/拒绝**下沉到写路径**（CLI + CAS + 版本戳），**不依赖消息入口串行**。
  即使多个会话照旧被 spawn，任何旧指令会话走到 CLI 时：旧 `seq` / 旧 `decided-at` / 旧
  `base-version` → 被 409 拒绝，**本次事故不可复现**。
- **识别特征**：CLI 报「旧指令，已拒」或「版本冲突」。
- **处置**：停止该会话执行，回到 Step 1 用最新拍板重做，不再并发覆盖。

---

## 5. 回滚 / 异常

- 全部机制挂在既有原子写（备份 + tmp + rename + 失败从 `.bak` 回滚）之上。
- 若后台方向错误：`opc-gw-config show` 读当前生效方向 + directive；**回退 = 再走一次 CLI
  写回旧方向**（seq 递增），无需手改文件。
- 若终态校验失败：网关已自动回滚到 `.bak` 并 opc-alert-bus 告警
  （`llm-gateway:config_terminal_check_failed:YYYY-MM-DD`），确认 `/status`
  `default_provider` 未漂移即可。

---

## 6. 红线（可判定不变式）

1. 库里 `grep writeFileSync(gateway.config.json)` 必须只剩 `lib/admin.js` 的原子写；
   任何脚本/会话直写配置 = 违规。
2. 任何写必须先取锁（`.lock` 存在且活）——无锁写 = 违规。
3. 任何受管写必须带 `--decided-at`（拍板决策时刻）缺省拒绝。
4. 写后磁盘与 `decided_state` 不一致 → 必须回滚 + 告警 + 审计，不可带病生效。
5. 手改文件改方向（绕过 CLI）→ reload 被拒，方向不可静默翻转。
