# OPC OS 部署手册

> 适用版本：v0.2（git tag）。产品名：**OPC OS** = AI 原生团队的治理操作系统。
> 本手册面向在一台全新机器上自部署 OPC OS 的运维 / 技术负责人。

---

## 1. 前置要求

| 项 | 要求 | 检查命令 |
|---|---|---|
| Docker | 20.10+（含 compose v2 插件） | `docker --version && docker compose version` |
| 磁盘 | ≥ 2 GB 可用（镜像 + 数据卷） | `df -h` |
| 端口 | 8081 空闲（或自行改映射） | `ss -tlnp \| grep 8081`（无输出即空闲） |
| 网络（仅构建期） | 能访问 apk 包源 | 见下方「受限网络」 |

> 📌 **形态区分**：§1-§2.5 为 **self 形态**（OPC 本机线上，systemd `opcos-*.service` 守护——2026-08-27 已从 pm2 迁移，pm2 弃用）。
> **customer 形态（交付客户团队）已去 docker 化（v0.4，Gavin 拍板 run 1350）**：
> 不需要 Docker，只依赖 node ≥ 20 + python3.10+，安装走
> `scripts/install-services.sh install --out <opc-init 输出目录>`（systemd 守护，LXC 也可跑）。
> customer 形态完整手册见 **docs/installation-guide.md（v0.4）**，本节 docker 说明仅 self 形态适用。

**受限网络说明**：三个 Dockerfile 默认把 apk 源替换为阿里云镜像
（`mirrors.aliyun.com`），dispatcher 的 pip 依赖也走阿里云 pypi 镜像
（`https://mirrors.aliyun.com/pypi/simple/`），大陆受限网络可直接构建；基础镜像
`alpine:latest` 需已在本地（`docker images | grep alpine`）。kanban-dispatcher
用 `vendor/kanban-dispatcher/` 源码（锁 commit SHA 0a93f43 = tag v0.1.0）构建，
不依赖 GitHub。若你的环境能直连 Docker Hub，按常规拉取即可。

**运行时零外连**：构建完成后，整套系统运行不需要任何外部网络——页面只读本地数据卷
里的 JSON 文件。唯一例外：`/opc/workbench.html`（人在 loop 工作台）默认读取
官方预设的任务接口，可经 `WORKBENCH_API` 指到自己的后端（见 §2.4）。

---

## 2. 分步部署

### 2.1 获取部署包

```bash
git clone <部署包仓库地址> opc-os    # 或解压交付的源码包
cd opc-os
git checkout v0.1.1                   # 锁定发布版本
```

### 2.2 一条命令启动

```bash
docker compose up -d --build
```

首次启动会发生两件事（均为自动）：

1. `web` 容器：数据卷为空 → 把镜像内置的 demo 种子（`status.json` / `token-stats.json`）
   复制进共享卷，页面立即可见；
2. `collector` 容器：数据卷为空 → 运行 `gen_demo_data.py` 生成**脱敏演示数据**
   （虚构 9 人团队 + 示例 kanban 任务 + 事件留痕 + 示例 token 统计），然后首跑采集，
   之后由 `crond` 每 10 分钟增量刷新。

### 2.3 改配置（可选）

换团队 / 换数据源只改 `config/config.json`（键位说明见 README_CN.md「配置」一节），
改完重建：

```bash
docker compose up -d --build
```

### 2.3.1 数据总线（opc-bus，v0.2 起内置，无需单独操作）

`collector` 容器内自动运行 `opc-bus.py` 数据总线守护（Gavin 拍板：bus 并入 collector 容器，
不新增服务）：1s 增量轮询 `kanban.db` 的 `task_events`（水位线文件 `/data/bus-state.json`），
发现状态迁移事件 → 秒级刷新 `status.json` 的 kanban 段 + `sources.kanban` 段级元数据。
这是「透明办公室任务看板 / 气泡秒级新鲜」的机制，也是演示数据之外的**唯一常驻守护**，
随 `crond` 一起由容器保活（任一守护退出 → 容器退出 → docker restart 自动拉起）。

如需调整（一般不需要）：改 `config/config.json` 的 `bus` 段后重建，例如轮询间隔改 0.5 秒：

```json
"bus": { "poll_seconds": 0.5, ... }
```

打包边界：bus 只依赖共享卷内 `kanban.db` 可读 + `status.json` 可写；秒级推送所依赖的
SSE 端点（`/api/opc/stream`）是目标部署（Hermes 内核 + mrd 服务）的既有设施，本包不含。

### 2.4 工作台连自己的后端（可选）

`/opc/workbench.html`（人在 loop 工作台）默认读取官方预设的任务接口。自部署且想连
自己的 kanban 后端时，启动前注入 `WORKBENCH_API`：

```bash
WORKBENCH_API=http://<你的后端>:3000 docker compose up -d --build
```

- 不设置则保持默认值，行为零变化；
- 后端须对部署机页面 origin 放行 CORS（mrd 侧 `OPC_CORS_ORIGINS` 环境变量逗号分隔追加）；
- 该值在 `web` 容器每次启动时注入 `workbench.html`（幂等，改值重启即生效）。

### 2.5 停止 / 重启 / 重置

```bash
docker compose stop                 # 停止（保留数据）
docker compose start                # 再起
docker compose down                 # 停栈（保留数据卷）
docker compose down -v              # 停栈并清空数据卷（下次启动重新生成 demo）
```

### 2.6 安装 Hermes 运行时（客户团队 Agent 底座）【0825-init 新增 · v0.4 去 docker 化】

> 客户形态（非 docker 原生进程，v0.4）：opc-init 输出目录 = 宿主机单一数据源。
> 团队成员 agent 由**宿主机上独立的 Hermes 实例**运行（`install-hermes-worker.sh` 安装），
> 通过 llm-gateway 网关访问 LLM（熔断自动切换 + 月度预算保护），客户 key 只进 llm.env。

**统一模型名 `hermes-opc-v1`（0825-init-2）：** 网关的唯一模型入口。`/v1/models`
静态清单只暴露 `hermes-opc-v1`（不透传上游模型列表）；对该模型名的请求在网关
内部按 priority 路由到 eyuai → kimi → deepseek → openrouter（熔断/健康/冷却
照旧，切换全在网关内部；`default_provider` 健康时置 healthy 组首位——0826-gw-2
自愈核心，熔断/未设时按 priority 兜底）。客户端 config.yaml
一律写 `model.default=hermes-opc-v1 / model.provider=custom:hermes-opc /
model.base_url=网关地址 / model.api_key=${GATEWAY_CLIENT_TOKEN}`（0826-fix：
provider 必须带 `custom:` 前缀且配 `custom_providers[].name=hermes-opc` 块，
缺任一即 Unknown provider），由 `install-hermes-worker.sh` 用官方
`hermes config set` 写入。

**安装步骤（宿主机）：**

```bash
# 0) 前置：已生成 opc-init 产物（profiles 骨架 + llm.env）
python3 scripts/opc_init.py --template software --name "客户公司" --gateway --out <opc-init 输出目录>

# 1) 安装 Hermes fork（锁 tag v0.20.5-opc.1）+ 为每个 profile 写网关配置
#    私有仓拉取（推荐）：
GITHUB_TOKEN=<pat> scripts/install-hermes-worker.sh \
    --hermes-home <opc-init 输出目录>/hermes-home \
    --gateway-url http://127.0.0.1:18080/v1
#    或本地源码包（离线）：
scripts/install-hermes-worker.sh --source /path/to/hermes-agent-fork \
    --hermes-home <opc-init 输出目录>/hermes-home

# 2) 起客户栈（原生进程，systemd 守护；无 systemd 自动退化 nohup）
scripts/install-services.sh install --out <opc-init 输出目录>
```

**脚本做了什么（红线：一律官方命令，不手写 config.yaml）：**

1. 安装 hermes-agent fork（`theBigGavin/hermes-agent-fork`，锁 tag `v0.20.5-opc.1`；
   换 tag 重跑 = 升级；幂等：同 tag 重跑跳过安装、仅校正配置）；
2. `HERMES_HOME` 指向 `<opc-init 输出目录>/hermes-home/`（opc-init 生成的 profiles 骨架）；
3. 为每个 profile 用**官方 `hermes --profile <id> config set`** 写入
   `model.default`（= 统一模型名 `hermes-opc-v1`）/ `model.provider`（= `custom:hermes-opc`，
   0826-fix：必须带 `custom:` 前缀）/ `model.base_url`（= 网关地址）/
   `model.api_key`（= `${GATEWAY_CLIENT_TOKEN}` 引用，token 由 llm.env 注入环境）/
   `custom_providers`（= `[{"name":"hermes-opc","base_url":<网关>,"key_env":"GATEWAY_CLIENT_TOKEN"}]`，
   0826-fix：缺此块即 Unknown provider）/ `fallback_providers=[]` / `timezone`；
   `fallback_providers` 保持空——熔断/降级由网关负责，不依赖 Hermes 单点 fallback；
4. **上游 provider key 只进 `<opc-init 输出目录>/llm.env`**（chmod 600）：网关进程
   `GATEWAY_ENV_FILE=<输出目录>/llm.env` 引用，不落盘 config.yaml / profiles；
   网关 client token（随机值）同时存在于 llm.env 与各 profile 的 `model.api_key`
   （`/v1/*` Bearer 鉴权，两处同值自洽）；
5. 完成校验：`hermes --version` + profiles 列表可读 + `curl <网关>/v1/models`（带 client token）；
6. **启动客户端前必须导出 key（0826 实测坑，v0.4 修复）：** profile 的
   `model.api_key=${GATEWAY_CLIENT_TOKEN}` 是 **env 引用**，shell 未导出时为字面量 →
   成员对话/kanban worker 全部 401。install-services.sh 已自动生成
   `<输出目录>/env.sh`（chmod 600，含 HERMES_HOME + KANBAN env + GATEWAY_CLIENT_TOKEN 导出），
   dispatcher 侧由 `secrets.env` 经 systemd EnvironmentFile 注入（worker spawn 继承）：

   ```bash
   source <opc-init 输出目录>/env.sh
   HERMES_HOME=<opc-init 输出目录>/hermes-home hermes --profile <成员id>
   ```

**HERMES_HOME 说明：** 客户 Hermes 实例的 HOME 目录 = opc-init 输出目录下的
`hermes-home/`（含 `profiles/<id>/SOUL.md、role.md、config.yaml、cron/` 骨架）。
collector 进程按 `config.native.json paths.hermes_home=<输出目录>/hermes-home` 读取同一份 profiles
做 token 归因——宿主机 Hermes 与 collector 共享同一数据源（v0.4：install-services.sh
把容器视角 `/data` 映射为宿主机绝对路径）。

**客户形态验证清单（v0.4，0826 去 docker 实测更新）：**

| # | 验证项 | 命令 | 通过标准 |
|---|---|---|---|
| 1 | 网关进程 | `systemctl is-active opcos-gateway` | active；`pgrep -f "node server.js"` 有 pid |
| 2 | 网关可达（宿主） | `TOKEN=$(grep '^GATEWAY_CLIENT_TOKEN=' <opc-init 输出目录>/llm.env \| cut -d= -f2-); curl --oauth2-bearer "$TOKEN" -o /dev/null -w '%{http_code}' http://127.0.0.1:18080/v1/models` | 200 |
| 2b | 统一模型名清单 | 同上 + `curl .../v1/models` 响应体 | 仅 `hermes-opc-v1` 一个模型（无上游模型透传） |
| 3 | 网关仅宿主回环 | `ss -tlnp \| grep 18080` | 仅 `127.0.0.1:18080`，无 `0.0.0.0` 公网监听 |
| 4 | profile 配置走网关 | `grep -E 'default\|provider\|base_url' <hermes-home>/profiles/<id>/config.yaml` | `hermes-opc-v1` / `custom:hermes-opc` / `http://127.0.0.1:18080/v1`；`grep -A2 custom_providers` 含 `name: hermes-opc` + `key_env: GATEWAY_CLIENT_TOKEN` |
| 5 | 上游 key 不进 config | `grep -r sk- <hermes-home>/profiles/` | 无输出（上游 key 只在 llm.env；config.yaml 的 model.api_key 仅 `${GATEWAY_CLIENT_TOKEN}` 引用，无明文 token） |
| 6 | Hermes 读 profiles | `source <输出目录>/env.sh && hermes profile list` | 成员列表齐全 |
| 7 | 欢迎态不回退 | 空输出目录起栈 | 透明办公室显示引导页（非 demo） |
| 8 | 客户端可启动 | `source <输出目录>/env.sh && hermes --profile <成员id> chat -q "hi"` | 正常启动（model.api_key=网关 client token，经网关对话成功；缺 env.sh 导出必 401） |

### 2.7 弹性调度（dispatcher 原生进程）【0826-elastic-P1 新增 · v0.4 去 docker 化】

> 弹性 = 调度运行时的自适应性：dispatcher 进程每 tick 探测本机（cgroup 优先）
> 推导并发上限 `max_in_progress`——4G/4 核小机推 4、强机推到 ceiling 8，零配置换机器。
> 显式覆盖链（R1，覆盖写日志）：`--mem-mb/--cpus`（KANBAN_DISPATCHER_CAPACITY_*）
> > `--tier`（KANBAN_DISPATCHER_TIER）> cgroup 探测 > 裸机探测 > fail-open
> （floor 1 + degraded 日志）。

> 单机语义：worker 与调度同主机（worker 是宿主机 Hermes 实例的进程）。
> 容器形态的 worker 执行层（远程 spawn 桥）属 P3 分布式前置，本版不做。

**默认档位（最低配置可跑，install 即随栈启动）：**

```bash
scripts/install-services.sh install --out <opc-init 输出目录>
```

| 参数 | 默认 | 说明 |
|---|---|---|
| `--mem-mb N` / `--cpus N` | 空 | 精确覆盖（最高优先级）→ 透传 `KANBAN_DISPATCHER_CAPACITY_*`（render 时空值行自动删除，避免 tick 日志 WARNING 噪音） |
| `--tier small\|medium\|large` | auto | 档位语法糖 → 透传 `KANBAN_DISPATCHER_TIER`（覆盖推导输入并写日志） |
| `--gateway-port N` | 18080 | 网关端口（dispatcher 环境无直接依赖，仅网关进程用） |

> v0.3 容器形态的 `OPCOS_MEM_LIMIT/OPCOS_CPUS_LIMIT` 双声明红线已随去 docker 化消失——
> 原生进程无容器配额，推导走裸机探测（meminfo + 核数），LXC 无 cgroup 也正常（实测
> `cgroup_detected=False -> effective_mem=8000MB ... max_in_progress=4`）。

**验证推导（journalctl 看 capacity derived）：**

```bash
sudo journalctl -u opcos-dispatcher --no-pager -n 30 | grep capacity
# 期望：capacity derived: meminfo=8000MB cgroup=NoneMB cpu_quota=None cores=4
#       cgroup_detected=False -> effective_mem=8000MB mem_workers=8 cpu_workers=4
#       max_in_progress=4 per_profile=2 (source=derived)
```

**worker spawn 关键环境（v0.4 实测修复，缺一即不派活/401）：**

| 环境 | 值 | 缺失后果 |
|---|---|---|
| `HERMES_HOME` | `<输出目录>/hermes-home` | dispatch_once 校验 assignee profile 解析到 ~/.hermes → `skipped_nonspawnable=N`，卡一直 ready 不派活 |
| `GATEWAY_CLIENT_TOKEN` | 从 secrets.env（EnvironmentFile）注入 | worker 继承后 profile `api_key=${GATEWAY_CLIENT_TOKEN}` 才非字面量 → 否则 worker 全程 401 |
| `HERMES_BIN` | `<fork>/venv/bin/hermes` | spawn 走 PATH 查找，可能撞到别的 hermes；显式 pin 最稳 |

**self 形态（OPC 本机线上）**：dispatcher 是宿主机 systemd 进程（`opcos-dispatcher.service` → `opc-dispatcher.py`，staging 隔离实例），
install-services.sh 不触碰 self 形态，零变化。

**已知边界（如实声明）**：customer 形态 v1 中 dispatcher 进程负责调度状态机
（claim/promote/reclaim/崩溃自愈），worker 执行由宿主机 Hermes 实例承担；
dispatcher spawn 的 worker 与手工 CLI 共享同一 kanban.db 与 `.dispatcher.lock`
（`<输出目录>/hermes-home/kanban/.dispatcher.lock`），单机语义下互斥调度，无双调度器竞争。

---

## 3. 验证清单（部署后逐项过）

| # | 验证项 | 命令 / 操作 | 通过标准 |
|---|---|---|---|
| 1 | 服务在线 | `systemctl is-active opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher` | 全部 active（无 systemd 时 `install-services.sh status` 全部运行中） |
| 2 | 首页跳转 | `curl -o /dev/null -w '%{http_code}' http://127.0.0.1:8081/` | 301 |
| 3 | 透明办公室 | `curl -sf -o /dev/null -w '%{http_code}' http://127.0.0.1:8081/opc/` | 200 |
| 4 | 治理仪表盘 | `curl -sf -o /dev/null -w '%{http_code}' http://127.0.0.1:8081/opc/governance.html` | 200 |
| 4b | 工作台 | `curl -sf -o /dev/null -w '%{http_code}' http://127.0.0.1:8081/opc/workbench.html` | 200；页面含 `window.OPC_WORKBENCH_API` 注入点 |
| 5 | 数据出现 | 浏览器打开治理仪表盘 | 成员行按 token / 成本 / 任务数 / 通过率展示（demo 9 行） |
| 6 | 健康检查 | `curl http://127.0.0.1:8081/healthz` | 返回 `ok` |
| 7 | 数据非写死 | `curl -s http://127.0.0.1:8081/opc/data/token-stats.json` | JSON 内含真实字段（`tokens` / `cost_usd` / `pass_rate` / `tasks_done`） |
| 8 | 脱敏红线 | 页面与 JSON 全文搜索 | 无任何真实团队身份 / 真实业务数据 |
| 8b | 数据总线存活 | `pgrep -af opc-bus.py` | 有 pid；`journalctl -u opcos-collector` 见 `opc-bus start (poll=1.0s...)` |
| 8c | 总线段级元数据 | `curl -s http://127.0.0.1:8081/opc/data/status.json` | JSON 含 `sources.kanban`（`ts` / `watermark` / `events`） |
| 8d | crontab 采集 | `crontab -l \| grep "OPC-OS collector"` | `*/1` opc_collect + token_stats、`*/5` llm_gateway_sync 两条 |
| 9 | 一键冒烟 | `scripts/smoke_test.sh 8081` | 37/37 ALL GREEN（配了 `WORKBENCH_API` 时为 38/38） |

---

## 4. 升级与回退

### 升级

```bash
cd opc-os
git fetch --tags
git checkout <新 tag>        # 或 git pull
rsync -a --exclude .git ./ sandbox1:~/opc-os/   # 或部署机上直接 pull
scripts/install-services.sh install --out <opc-init 输出目录>   # 幂等重跑：渲染新 unit + restart 服务
```

升级**不动数据目录**：`<opc-init 输出目录>` 里的 kanban.db / JSON / profiles 全部保留。

底座政策：治理层运行在 Hermes Agent 的锁定 fork 之上，fork 每周 merge upstream；
部署包按 tag 发布，建议跟随 tag 升级而不是追 main。

### 回退

```bash
git checkout v0.1.1          # 回到上一个可用 tag
scripts/install-services.sh install --out <opc-init 输出目录>
```

如需连数据一起回退：先用 `scripts/backup.sh --data-dir <opc-init 输出目录>` 恢复对应日期的备份文件进数据目录，再重跑 install。

### 备份（建议纳入日常 cron）

```bash
scripts/backup.sh --data-dir <opc-init 输出目录>   # 默认保留最近 14 份到 backups/<日期>/
# crontab 示例：每天 03:30 备份
# 30 3 * * * cd /path/to/opc-os && scripts/backup.sh --data-dir <opc-init 输出目录> >> backups/backup.log 2>&1
```

---

## 5. 故障排查

| 症状 | 排查路径 |
|---|---|
| `install-services.sh install` 报「opc-init 产物不完整」 | 确认 `<out>` 下有 llm.env / config/config.json / kanban.db / init-state.json / hermes-home/profiles；先跑 opc-init（§2.6 步骤 0） |
| 成员对话 401（AuthenticationError，重试后像卡死）★ v0.4 实测坑 | profile 的 `model.api_key=${GATEWAY_CLIENT_TOKEN}` 是 env 引用，shell 未导出时为字面量。`source <输出目录>/env.sh` 后再跑；dispatcher worker 由 secrets.env EnvironmentFile 自动注入，重跑 install 生效 |
| kanban 卡一直 ready 不派活（dispatcher 日志 `skipped_nonspawnable=N`）★ v0.4 实测坑 | dispatcher 进程缺 `HERMES_HOME` env → assignee profile 校验解析到 ~/.hermes 判为无效。确认 unit 有 `Environment=HERMES_HOME=<输出目录>/hermes-home`；改配置后须 `install` 重跑（start=enable+restart，enable --now 对已 active 服务不重启） |
| 服务在跑但端口不通 | `systemctl status opcos-*` / `install-services.sh status` 看进程；`ss -tlnp \| grep <port>` 确认监听；`journalctl -u opcos-web --no-pager -n 30` 看启动报错 |
| 页面 200 但数据空白 | `journalctl -u opcos-collector` 看首跑是否报错；`ls -la <输出目录>/status.json` 确认 JSON 已生成；等下一个 1 分钟采集周期；`pgrep -af opc-bus.py` 确认总线存活 |
| 管理后台 `/admin` 打不开或 admin API 401 | 网关没跑：`curl -s http://127.0.0.1:18080/healthz`（应 ok）；token 未配：`grep -q '^GATEWAY_ADMIN_TOKEN=.' <输出目录>/llm.env`（§6.1 合并进 llm.env，经 `GATEWAY_ENV_FILE` 注入）；监听核对 `ss -tlnp \| grep 18080`；默认仅 127.0.0.1 回环，勿裸公网，远程走 SSH 隧道 |
| 治理仪表盘成员数不对 | 检查 `config/config.native.json` 的 `profiles` / `roster` 是否改成你的团队；改后 `install-services.sh restart --out <输出目录>` |
| 8081 被占 | 改 `install-services.sh install --web-port <新端口>`，冒烟测试同步传新端口（`scripts/smoke_test.sh <新端口>`） |
| 想看采集日志 | `tail -f <输出目录>/logs/collect.log`（token 归因：`tokenstats.log`） |
| 想看总线日志 | `journalctl -u opcos-collector --no-pager -n 50`（启动行含 `poll=1.0s`；事件刷新行含 `-> kanban refreshed`） |
| 总线挂了 / 一直不刷新 | `journalctl -u opcos-collector` 看 opc-bus 启动是否报错；`ls -la <输出目录>/bus-state.json` 确认水位线文件存在；bus 挂不影响 1 分钟快照兜底（页面数据不会丢，只影响秒级刷新） |
| cron 没在跑 | `crontab -l \| grep "OPC-OS collector"` 应有 `*/1` + `*/5` 两条；`<输出目录>/logs/collect.log` 看执行记录；`crontab -e` 手动补跑 `OPC_OS_CONFIG=<输出目录>/config/config.native.json python3 opc_collect.py` |
| dispatcher 日志 WARNING「capacity override: invalid ... ''」 | 未设 `--mem-mb/--cpus` 时空 env 传入的旧 unit；重跑 install（render 已删空值行） |
| 无 systemd 环境起不了服务 | LXC 精简版没有 /run/systemd/system：install 自动退化 nohup+pidfile；或 `--no-systemd` 强制；管理用 `install-services.sh start/stop/status` |
| 网关 /v1/models 401 | 确认用的是 `GATEWAY_CLIENT_TOKEN`（llm.env），不是上游 key；`source <输出目录>/env.sh` 后 `$GATEWAY_CLIENT_TOKEN` 有值 |
| 误删数据目录 | 从 `backups/` 恢复（`backup.sh --data-dir` 保留最近 14 份）后重跑 install |
| 磁盘告警 | 旧备份按 `--keep` 自动裁剪；`<输出目录>/logs/` 定期清理（cron 日志无轮转，量大时手动清） |
| 沙箱/内网部署的翻墙代理不通（curl 000） | 勿用宿主侧地址 `10.0.2.2:7890`（沙箱网络后不通）；正确地址 `http://10.77.0.1:7890`（已实测：单次 `curl -x http://10.77.0.1:7890 <url>`，持久 `export http_proxy=https_proxy=http://10.77.0.1:7890`，sudo 场景加 `-E`）；搜索后端 `http://10.77.0.1:11234/`（SearXNG，JSON API `/search?q=xx&format=json`） |

---

## 6. 安全与边界提示

- 默认无鉴权，仪表盘对内网 / 本机开放；要暴露到公网请自行加反向代理与访问控制。
- 演示数据全部为虚构脱敏数据；接入真实数据前请确认你的团队授权范围。
- 本包不含任何收款 / 计费代码，也不采集任何外部第三方数据。
