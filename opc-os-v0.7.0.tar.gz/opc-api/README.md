# opc-api — OPC 透明办公室 / 工作台 / 治理 独立后端

OPC OS 的 API 层服务（P0-1 架构拆分，2026-08-21）。接管原混在 mrd server 里的
OPC 透明办公室 / 人在 loop 工作台 / 治理 后端，独立进程 :3033 运行。

## 服务端点（与 mrd 旧路径一致，供 mrd 反代过渡 + opc.hermes.cc.cd 直连）

| 端点 | 用途 | 数据落点 |
|---|---|---|
| GET /api/token-stats | 治理: token 用量 | `$OPC_OS_DATA_DIR/token-stats.json` |
| GET /api/acquisition | 治理: 引流四源聚合 | knock.db + 短链 + v2ex + status.json |
| GET /api/trends | 治理: 访问趋势 4 指标按日序列（`?days=N` 默认 7 上限 30；`days` 正序=最早在前；采集前日=null 不造假；降级带 `degraded_sources`+`__ttl`） | knock.db(utm_visits/feedback_events) + CF KV 短链 + demo/status.json + assistant-leads.jsonl/feedback-messages.jsonl（跨仓路径参数化 `ASSISTANT_LEADS_PATH`/`FEEDBACK_MESSAGES_PATH`） |
| GET /api/trends/messages | 治理: 留言/咨询明细读取（`?type=feedback|consultation&limit=N&offset=M`；`Authorization: Bearer <token>` 管理员鉴权，401 零泄露；IP 后端脱敏 `ip_masked`；倒序=最新在前；limit 默认 50 上限 200） | feedback-messages.jsonl / assistant-leads.jsonl（只读，跨仓路径参数化同上） |
| GET /api/kanban/tasks | 工作台: kanban 公开读；`?task_id=X` 按 id 直查任意成员名下卡详情（忽略 assignee 过滤，未命中 404 语义）；无参数保持 assignee 列表（默认 gavin） | node:sqlite 只读 `kanban.db` |
| POST /api/kanban/feedback | 工作台: Gavin 反馈写回 | spawn hermes CLI（WORKBENCH_TOKEN） |
| POST /api/opc/demo | 透明办公室: 访客 demo 派活 | `$OPC_OS_DATA_DIR/demo/` |
| GET /api/opc/demo/status | 透明办公室: demo 状态 | 同上 |
| GET /api/opc/demo/history | 透明办公室: demo 历史 | 同上 |
| GET /api/opc/demo/weather/gz | 透明办公室: 广州天气代理 | 中国天气网/气象局（免 key） |
| GET /api/opc/stream | 透明办公室: 全局状态 SSE | status.json 变更秒级广播 |
| GET /api/opc/demo/{id}/stream | 透明办公室: demo 进展 SSE | demo/status.json |

## 运行（本机 systemd）

```bash
cd opc-api
cp .env.example .env   # 填入 WORKBENCH_TOKEN（从 mrd server/.env 迁入, 换位置不换值）
sudo systemctl start opcos-api.service    # 本机已部署（unit 归档 ~/.hermes/opc/systemd-host/）
systemctl status opcos-api.service        # active + listening :3033
```

## 配置

| 变量 | 默认 | 说明 |
|---|---|---|
| PORT | 3033 | 监听端口（opc.hermes.cc.cd 经 cloudflared → :3033） |
| OPC_OS_DATA_DIR | /home/gavin/.hermes/opc | 数据根目录（容器部署注入 /data） |
| WORKBENCH_TOKEN | — | 工作台写回令牌（.env, gitignore） |
| OPC_CORS_ORIGINS | https://www.hermes.cc.cd | 跨源白名单（逗号分隔） |
| DEMO_DISPATCH_SCRIPT | /home/gavin/.hermes/scripts/opc_demo_dispatch.py | demo 派活脚本（同机 spawn） |
| KANBAN_DB_PATH | `$OPC_OS_DATA_DIR/kanban.db` 或本机 boards/opc/kanban.db | kanban 只读库 |

## 测试

```bash
node --test *.test.cjs   # 62 用例: workbench(逻辑) + demo-stream(帧) + acquisition(聚合) + trends(趋势 4 指标) + trends-messages(明细读取: 鉴权/脱敏/分页)
```

## 部署（OPC OS 容器）

`docker-compose.yml` 第三服务 `opc-api`（Dockerfile.opc-api）：`opc_data` 卷挂载到 `/data`，
compose env `WORKBENCH_TOKEN` 注入写回令牌（不入 git）。

## git 溯源（P0-1 拆分，2026-08-21）

本目录代码为迁移时刻快照，源仓 **theBigGavin/marketingdashboard**，源文件与源 commit：

| 本目录 | 源路径 | 迁移方式 |
|---|---|---|
| index.cjs | `server/index.cjs`（OPC 路由段） | 混合文件无法按函数拆历史 → 快照 + 本 README 溯源（`git log --follow` 可追溯演进） |
| lib/workbench.cjs | `server/lib/workbench.cjs` | 原样复制 |
| lib/demo-stream.cjs | `server/lib/demo-stream.cjs` | 原样复制 |
| lib/fetch-any.cjs | `server/lib/fetch-any.cjs` | 精简（去 iconv-lite 依赖，上游均 UTF-8） |
| lib/cache.cjs | `server/lib/cache.cjs` | 精简（只留 cached/退避） |
| sources/acquisition.cjs | `server/sources/acquisition.cjs` | 路径参数化（默认指向 OPC 目录） |
| workbench.test.cjs | `server/workbench.test.cjs` | 原样复制 |
| demo-stream.test.cjs | `server/demo-stream.test.cjs` | 原样复制 |
| acquisition.test.cjs | `server/acquisition.test.cjs` | STATUS_JSON 指向 OPC 目录 |

源 commit 可在 mrd 仓通过 `git log --follow -- server/lib/workbench.cjs` 等追溯。

## 红线

- 不新增混入路由（端点即上方清单）
- WORKBENCH_TOKEN 只存在于本仓 `.env`（gitignore），绝不进 git / kanban / 评论
- opc-server 不依赖 mrd 进程存活性（数据全在 OPC 目录）
