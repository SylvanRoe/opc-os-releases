/**
 * opc-server — OPC 透明办公室 / 工作台 / 治理 独立后端（P0-1 架构拆分，2026-08-21）
 * 自 mrd server/index.cjs 提取 OPC 专属路由，零依赖 node http server（同 mrd 风格）。
 *
 * 迁移来源: theBigGavin/marketingdashboard（server/index.cjs 内 OPC 路由段，
 *   2026-08-21 拆分时刻快照; git log --follow 可在 mrd 仓追溯原实现演进）。
 *
 * 端点（与 mrd 旧路径一致，供 mrd 反代 + cloudflared 直连 opc.hermes.cc.cd）:
 *   GET  /api/time                   时钟: 权威时间 {iso, unix, tz: Asia/Shanghai, offset}（agent 校准用）
 *   GET  /api/token-stats            治理: token 用量（读 OPC 目录 token-stats.json）
 *   GET  /api/acquisition            治理: 引流四源聚合
 *   GET  /api/trends                 治理: 访问趋势 4 指标按日序列（?days=N 默认 7 上限 30; 采集前日=null）
 *   GET  /api/trends/messages        治理: 留言/咨询明细读取（管理员 Bearer 鉴权 + IP 脱敏 + 分页）
 *   GET  /api/kanban/tasks           工作台: kanban 公开读（node:sqlite 只读聚合）
 *   POST /api/kanban/feedback        工作台: Gavin 反馈写回（WORKBENCH_TOKEN + spawn hermes CLI）
 *   POST /api/kanban/reopen          工作台: done 卡打回重做（0824b: OPC 侧 reopen 语义,
 *                                       WORKBENCH_TOKEN + spawn opc_kanban_reopen.py runner,
 *                                       官方 kanban_db 公开函数组合实现 done→ready/todo + 子树失效)
 *   POST /api/opc/demo               透明办公室: 访客 demo 体验派活（白名单 + 限流 + dispatch spawn）
 *   GET  /api/opc/demo/status        透明办公室: demo 状态轮询
 *   GET  /api/opc/demo/history       透明办公室: demo 历史回看
 *   GET  /api/opc/demo/weather/gz    透明办公室: 广州天气代理（中国天气网/气象局）
 *   GET  /api/opc/stream             透明办公室: 全局状态 SSE（status.json 变更秒级广播）
 *   GET  /api/opc/demo/{id}/stream   透明办公室: demo 进展 SSE
 *
 * 配置（.env 或进程 env; 全部可覆盖, 见文件尾 loadEnv）:
 *   PORT                 默认 3033
 *   OPC_OS_DATA_DIR      数据根（默认 /home/gavin/.hermes/opc; 容器部署注入 /data）
 *   TOKEN_STATS_PATH     默认 <OPC_OS_DATA_DIR>/token-stats.json
 *   OPC_STATUS_FILE      默认 <OPC_OS_DATA_DIR>/status.json
 *   DEMO_DIR             默认 <OPC_OS_DATA_DIR>/demo
 *   DEMO_DISPATCH_SCRIPT 默认 /home/gavin/.hermes/scripts/opc_demo_dispatch.py
 *   KANBAN_DB_PATH       默认 <OPC_OS_DATA_DIR>/kanban.db（容器）或本机 boards/opc/kanban.db
 *   KANBAN_HERMES_BIN    默认 /home/gavin/.hermes/hermes-agent/venv/bin/hermes
 *   KANBAN_PYTHON_BIN    默认 <KANBAN_HERMES_BIN 同目录>/python（runner 解释器）
 *   OPC_REOPEN_RUNNER    默认 /home/gavin/.hermes/scripts/opc_kanban_reopen.py
 *   WORKBENCH_TOKEN      工作台写回令牌（.env, gitignore）
 *   OPC_CORS_ORIGINS     逗号分隔跨源白名单, 默认 https://www.hermes.cc.cd
 */
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");
const { DatabaseSync } = require("node:sqlite"); // kanban 只读聚合(node 22+ 原生, 零依赖)

/* ---------------- 配置（.env 加载须在模块读取 process.env 之前） ---------------- */
function loadEnv() {
  try {
    const envPath = path.join(__dirname, ".env");
    if (fs.existsSync(envPath)) {
      for (const line of fs.readFileSync(envPath, "utf-8").split("\n")) {
        const m = line.trim().match(/^([A-Z_][A-Z0-9_]*)=(.*)$/);
        if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
      }
      console.log("[env] loaded", envPath);
    }
  } catch (e) { console.error("[env] load error:", e.message); }
}
loadEnv();

const PORT = parseInt(process.env.PORT || "3033", 10);
const OPC_DATA = process.env.OPC_OS_DATA_DIR || "/home/gavin/.hermes/opc";
const TOKEN_STATS_PATH = process.env.TOKEN_STATS_PATH || path.join(OPC_DATA, "token-stats.json");
const OPC_STATUS_FILE = process.env.OPC_STATUS_FILE || path.join(OPC_DATA, "status.json");
const DEMO_DIR = process.env.DEMO_DIR || path.join(OPC_DATA, "demo");
const DEMO_REQ_DIR = path.join(DEMO_DIR, "requests");
const DEMO_RES_DIR = path.join(DEMO_DIR, "results");
const DEMO_STATUS_FILE = path.join(DEMO_DIR, "status.json");
const DEMO_DISPATCH_SCRIPT = process.env.DEMO_DISPATCH_SCRIPT || "/home/gavin/.hermes/scripts/opc_demo_dispatch.py";
const KANBAN_DB_PATH = process.env.KANBAN_DB_PATH
  || (process.env.OPC_OS_DATA_DIR ? path.join(OPC_DATA, "kanban.db") : "/home/gavin/.hermes/kanban/boards/opc/kanban.db");
const KANBAN_HERMES_BIN = process.env.KANBAN_HERMES_BIN || "/home/gavin/.hermes/hermes-agent/venv/bin/hermes";
// 0824b: reopen runner 解释器（默认与 hermes CLI 同 venv 的 python）；runner 组合官方
// kanban_db 公开函数实现 done→ready/todo + 子树失效（官方 main 无 done-reopen verb）。
const KANBAN_PYTHON_BIN = process.env.KANBAN_PYTHON_BIN || path.join(path.dirname(KANBAN_HERMES_BIN), "python");
const OPC_REOPEN_RUNNER = process.env.OPC_REOPEN_RUNNER || "/home/gavin/.hermes/scripts/opc_kanban_reopen.py";
const WORKBENCH_TOKEN = process.env.WORKBENCH_TOKEN || "";
const OPC_CORS_ORIGINS = new Set(
  (process.env.OPC_CORS_ORIGINS || "https://www.hermes.cc.cd")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
);

/* ---------------- 统一 fetch 通道 + 内存缓存（零依赖） ---------------- */
const { fetchText, fetchWithFallback, UA } = require("./lib/fetch-any.cjs")();
const { createCache } = require("./lib/cache.cjs");
const { cache: _, cached } = createCache();

/* ---------------- 纯逻辑模块（原样迁移, 单测覆盖） ---------------- */
const bjToday = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);
const { tokenOk, validateFeedback, buildPlan, taskOperable } = require("./lib/workbench.cjs");
const { makeFrame, demoStreamDiff: demoStreamDiffRaw } = require("./lib/demo-stream.cjs");
const srcAcquisition = require("./sources/acquisition.cjs")({ fetchText, fs, bjToday });
const { handleAcquisition } = srcAcquisition;
// 0822-t1a: 访问趋势聚合（4 指标按日序列, 跨仓读路径参数化见 sources/trends.cjs）
const srcTrends = require("./sources/trends.cjs")({ fetchText, fs, bjToday });
const { handleTrends } = srcTrends;
// 0822-t1d: 留言/咨询明细读取（管理员鉴权 + IP 脱敏 + 分页, 见 sources/trends-messages.cjs）
const srcTrendsMessages = require("./sources/trends-messages.cjs")({ fs, WORKBENCH_TOKEN });
const { handleMessages: handleTrendsMessages } = srcTrendsMessages;

// 0825-f: 时钟服务 — 权威时间端点（Asia/Shanghai 墙钟 + unix + 固定偏移, 不缓存, 不依赖会话头）
const { timePayload } = require("./lib/time.cjs");

/* ---------------- 响应与限流设施（与 mrd 逐字节同契约） ---------------- */
function send(res, code, obj, extra = {}) {
  const body = typeof obj === "string" ? obj : JSON.stringify(obj);
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...extra,
  };
  for (const k of Object.keys(headers)) if (headers[k] == null) delete headers[k];
  res.writeHead(code, headers);
  res.end(body);
}

function readBodyWithLimit(req, limit) {
  return new Promise((resolve) => {
    const chunks = [];
    let size = 0;
    let settled = false;
    const done = (r) => { if (!settled) { settled = true; resolve(r); } };
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > limit) {
        req.removeAllListeners("data");
        req.resume();
        done({ tooBig: true });
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => done({ buf: Buffer.concat(chunks) }));
    req.on("error", () => done({ buf: Buffer.concat(chunks) }));
    req.on("close", () => done({ buf: Buffer.concat(chunks) }));
  });
}

// 按客户端 IP 限流（CF Tunnel 后取 CF-Connecting-IP 头; 仅可信代理/环回采信）
const CF_EDGE_RANGES = [
  "173.245.48.0/20", "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22",
  "141.101.64.0/18", "108.162.192.0/18", "190.93.240.0/20", "188.114.96.0/20",
  "197.234.240.0/22", "198.41.128.0/17", "162.158.0.0/15", "104.16.0.0/13",
  "104.24.0.0/14", "172.64.0.0/13", "131.0.72.0/22",
];
function ipInRanges(ip, ranges) {
  if (!ip || ip.includes(":")) return false;
  const n = (s) => s.split(".").reduce((a, b) => (a << 8) + +b, 0) >>> 0;
  const addr = n(ip);
  return ranges.some((r) => {
    const [base, bits] = r.split("/");
    const mask = bits === "0" ? 0 : (~0 << (32 - +bits)) >>> 0;
    return (addr & mask) === (n(base) & mask);
  });
}
function clientIp(req) {
  const peer = req.socket.remoteAddress || "unknown";
  const trusted = peer === "127.0.0.1" || peer === "::1" || peer === "::ffff:127.0.0.1" || ipInRanges(peer, CF_EDGE_RANGES);
  if (trusted) {
    const cf = req.headers["cf-connecting-ip"];
    if (typeof cf === "string" && cf.trim()) return cf.trim();
    const xff = req.headers["x-forwarded-for"];
    if (typeof xff === "string" && xff.trim()) return xff.split(",")[0].trim();
  }
  return peer;
}

function makeLimiter(windowMs, max) {
  const hits = new Map();
  const sweeper = setInterval(() => {
    const cutoff = Date.now() - windowMs;
    for (const [ip, ts] of hits) {
      const idx = ts.findIndex((t) => t >= cutoff);
      if (idx > 0) hits.set(ip, ts.slice(idx));
      else if (idx === -1) hits.delete(ip);
    }
  }, Math.min(windowMs, 30000));
  sweeper.unref();
  return (ip) => {
    const now = Date.now();
    const cutoff = now - windowMs;
    let ts = hits.get(ip);
    if (!ts) { hits.set(ip, [now]); return true; }
    const idx = ts.findIndex((t) => t >= cutoff);
    if (idx > 0) ts = ts.slice(idx);
    else if (idx === -1) { hits.set(ip, [now]); return true; }
    ts.push(now);
    hits.set(ip, ts);
    return ts.length <= max;
  };
}
const apiLimiter = makeLimiter(60 * 1000, 2400);
const workbenchLimiter = makeLimiter(60 * 1000, 30);
const DEMO_RATE_WINDOW_MS = 60 * 1000;
const DEMO_RATE_MAX = 1;
const demoLimiter = makeLimiter(DEMO_RATE_WINDOW_MS, DEMO_RATE_MAX);

/* ---------------- CORS（OPC 白名单, 与 mrd OPC_CORS_ORIGINS 同语义） ---------------- */
const isLoopbackHost = (h) => /^(localhost|127\.\d{1,3}\.\d{1,3}\.\d{1,3}|\[::1\])(:\d+)?$/.test(h);
function isSameOrigin(req) {
  const host = req.headers.host;
  if (!host) return true;
  for (const h of [req.headers.origin, req.headers.referer]) {
    if (!h) continue;
    try {
      const oh = new URL(h).host;
      if (oh !== host && !(isLoopbackHost(oh) && isLoopbackHost(host))) return false;
    } catch { return false; }
  }
  return true;
}
function opcCorsHeaders(req) {
  const origin = req.headers.origin;
  if (!origin) return { "Access-Control-Allow-Origin": null };
  if (isSameOrigin(req) || OPC_CORS_ORIGINS.has(origin)) {
    return { "Access-Control-Allow-Origin": origin, Vary: "Origin" };
  }
  return { "Access-Control-Allow-Origin": null };
}

/* ---------------- SSE 公共设施（与 mrd 逐字节一致: event: status / event: demo 同流） ---------------- */
function setSSEHeaders(res, extra = {}) {
  const headers = {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
    ...extra,
  };
  res.writeHead(200, headers);
}
// 0826-P0: 返回 write 结果——背压(write=false)/异常(false) 供 SSE 客户端健康判定（僵尸踢出）
function sendEvent(res, event, data) {
  try { return res.write(`event: ${event}\ndata: ${typeof data === "string" ? data : JSON.stringify(data)}\n\n`); } catch { return false; }
}

/* ---------------- 治理: /api/token-stats（OPC 目录, 60s 缓存, 缺失抛 503） ---------------- */
const tokenStatsRoute = () =>
  cached("token-stats", 60000, async () => {
    let raw;
    try { raw = fs.readFileSync(TOKEN_STATS_PATH, "utf8"); }
    catch { const e = new Error("token-stats 数据未就绪"); e.status = 503; throw e; }
    try { return JSON.parse(raw); }
    catch { const e = new Error("token-stats 数据未就绪"); e.status = 503; throw e; }
  });

/* ---------------- 工作台: kanban 只读聚合 + Gavin 反馈写回（原样迁移） ---------------- */
function openKanbanDb() {
  try {
    if (!fs.existsSync(KANBAN_DB_PATH)) return null;
    const db = new DatabaseSync(KANBAN_DB_PATH, { readOnly: true });
    try { db.exec("PRAGMA busy_timeout = 5000;"); } catch {}
    return db;
  } catch (e) {
    console.error("[workbench] kanban db open failed:", e.message);
    return null;
  }
}
function kanbanTaskView(db, row) {
  let comments = [];
  let events = [];
  try {
    comments = db.prepare("SELECT id, author, body, created_at FROM task_comments WHERE task_id = ? ORDER BY created_at ASC, id ASC").all(row.id);
  } catch {}
  try {
    events = db.prepare("SELECT id, run_id, kind, payload, created_at FROM task_events WHERE task_id = ? ORDER BY created_at ASC, id ASC").all(row.id)
      .map((e) => {
        let p = e.payload;
        try { p = JSON.parse(p); } catch {}
        return { id: e.id, run_id: e.run_id, kind: e.kind, payload: p, created_at: e.created_at };
      });
  } catch {}
  return { ...row, comments, events };
}
function handleKanbanTasks(q, req) {
  const db = openKanbanDb();
  if (!db) { const e = new Error("kanban 数据未就绪"); e.status = 503; throw e; }
  try {
    const tasks = [];
    // 详情模式（31b）：?task_id=X 按 id 直查（忽略 assignee 过滤，支持任意成员名下卡）；
    // 未命中返回 404 语义（明确错误 JSON），不回退 assignee 列表。
    const taskId = String(q.get("task_id") || "").trim().slice(0, 64);
    if (taskId) {
      const row = db.prepare("SELECT * FROM tasks WHERE id = ? AND status != 'archived'").get(taskId);
      if (!row) { const e = new Error("任务卡不存在"); e.status = 404; throw e; }
      tasks.push(kanbanTaskView(db, row));
    } else {
      // 列表模式：保持既有行为（assignee 过滤，默认 gavin），兼容 workbench/现有调用方
      const assignee = String(q.get("assignee") || "gavin").trim().slice(0, 64);
      const seen = new Set();
      const rows = [];
      if (assignee) {
        for (const r of db.prepare("SELECT * FROM tasks WHERE assignee = ? AND status != 'archived' ORDER BY created_at DESC LIMIT 200").all(assignee)) rows.push(r);
      }
      for (const r of rows) {
        if (seen.has(r.id)) continue;
        seen.add(r.id);
        tasks.push(kanbanTaskView(db, r));
      }
      tasks.sort((a, b) => {
        const pa = a.status === "blocked" ? 0 : 1;
        const pb = b.status === "blocked" ? 0 : 1;
        if (pa !== pb) return pa - pb;
        return (b.created_at || 0) - (a.created_at || 0);
      });
    }
    let session_ok = null;
    const tok = req && req.headers && req.headers["x-workbench-token"];
    if (typeof tok === "string" && tok.length > 0) session_ok = tokenOk(tok, WORKBENCH_TOKEN);
    return { tasks, session_ok };
  } catch (e) {
    if (e && e.status) throw e; // 已带状态码的错误（如 404 任务卡不存在）原样上抛
    console.error("[workbench] kanban read error:", e?.message || e);
    const err = new Error("kanban 数据读取失败"); err.status = 502; throw err;
  } finally {
    try { db.close(); } catch {}
  }
}
function spawnHermesKanban(args, timeoutMs = 30000) {
  return new Promise((resolve) => {
    let env;
    try {
      env = { ...process.env };
      delete env.HERMES_KANBAN_DB;
      delete env.HERMES_KANBAN_BOARD;
      delete env.HERMES_DELEGATED_CHILD_CONTEXT;
      env.HERMES_KANBAN_DB = KANBAN_DB_PATH;
      env.HOME = "/home/gavin";
    } catch (e) { resolve({ ok: false, err: "env prepare failed: " + e.message }); return; }
    const child = spawn(KANBAN_HERMES_BIN, ["kanban", "--board", "opc", ...args], { env, stdio: ["ignore", "pipe", "pipe"] });
    let out = "", err = "";
    child.stdout.on("data", (d) => { out += d.toString(); });
    child.stderr.on("data", (d) => { err += d.toString(); });
    const timer = setTimeout(() => { try { child.kill(); } catch {} resolve({ ok: false, err: "CLI 执行超时" }); }, timeoutMs);
    child.on("error", (e) => { clearTimeout(timer); resolve({ ok: false, err: e.message }); });
    child.on("close", (code) => {
      clearTimeout(timer);
      if (code === 0) resolve({ ok: true, out, err });
      else resolve({ ok: false, err: (err || out || `exit ${code}`).trim().slice(0, 300) });
    });
  });
}
async function handleKanbanFeedback(body, req) {
  if (!WORKBENCH_TOKEN) { const e = new Error("工作台未配置（WORKBENCH_TOKEN 缺失）"); e.status = 503; throw e; }
  if (!workbenchLimiter(clientIp(req))) { const e = new Error("操作太频繁，请稍后再试"); e.status = 429; throw e; }
  const v = validateFeedback(body);
  if (!v.ok) { const e = new Error(v.error); e.status = v.status; throw e; }
  if (!tokenOk(body && body.token, WORKBENCH_TOKEN)) { const e = new Error("密码不正确"); e.status = 401; throw e; }
  const { taskId, action, text } = v.value;
  const db = openKanbanDb();
  if (!db) { const e = new Error("kanban 数据未就绪"); e.status = 503; throw e; }
  let task;
  try { task = db.prepare("SELECT id, assignee, status, block_kind, block_recurrences FROM tasks WHERE id = ?").get(taskId); }
  catch (e) { console.error("[workbench] task lookup error:", e?.message || e); }
  finally { try { db.close(); } catch {} }
  if (!task) { const e = new Error("任务卡不存在"); e.status = 404; throw e; }
  if (!taskOperable(task)) { const e = new Error("无权操作该任务卡"); e.status = 403; throw e; }
  // 0824b: reopen 动作改走 OPC runner（官方 main 无 done-reopen CLI verb）；
  // 保留 feedback 通道兼容（workbench 已直连 /api/kanban/reopen）。
  if (action === "reopen") {
    return runReopen(taskId, text);
  }
  const steps = [];
  for (const args of buildPlan(action, task, text)) {
    const r = await spawnHermesKanban(args);
    steps.push({ cmd: args[0], ok: r.ok });
    if (!r.ok) {
      console.error("[workbench] CLI failed:", args[0], taskId, r.err);
      const FRIENDLY = [
        [/cannot complete/, "该卡存在未完成的父卡或已处于终态，无法标记完成"],
        [/cannot block/, "该卡当前状态不允许执行驳回阻塞操作"],
        [/cannot unblock/, "该卡当前未处于阻塞状态，无法批准"],
        [/cannot reopen/, "该卡不可打回（仅 done/archived 卡可打回）"],
      ];
      let msg = r.err;
      for (const [re, friendly] of FRIENDLY) if (re.test(r.err)) { msg = friendly; break; }
      const e = new Error(`写回失败（${args[0]}）: ${msg}`); e.status = 502; throw e;
    }
  }
  return { action, task_id: taskId, steps };
}

/* ---------------- 0824b: done 卡打回（reopen 语义）OPC 侧实现 ----------------
 * 官方 main 无 done/archived → ready/todo 的完整 reopen（仅 reopen-review）。
 * OPC 侧 runner（~/.hermes/scripts/opc_kanban_reopen.py）组合官方 kanban_db 公开函数
 * 在同一写事务内完成：状态翻转 + reopened/status 事件 + REOPENED 评论 + 子树失效
 * （ready/review/running/done 后代 → todo，running worker 提交后终止）。
 * 端点与 /api/kanban/feedback 同模式：WORKBENCH_TOKEN + 限流 + taskOperable。
 */
function spawnKanbanRunner(args, timeoutMs = 60000) {
  return new Promise((resolve) => {
    let env;
    try {
      env = { ...process.env };
      delete env.HERMES_KANBAN_DB;
      delete env.HERMES_KANBAN_BOARD;
      delete env.HERMES_DELEGATED_CHILD_CONTEXT;
      env.HERMES_KANBAN_DB = KANBAN_DB_PATH;
      env.HOME = "/home/gavin";
    } catch (e) { resolve({ ok: false, err: "env prepare failed: " + e.message }); return; }
    const child = spawn(KANBAN_PYTHON_BIN, args, { env, stdio: ["ignore", "pipe", "pipe"] });
    let out = "", err = "";
    child.stdout.on("data", (d) => { out += d.toString(); });
    child.stderr.on("data", (d) => { err += d.toString(); });
    const timer = setTimeout(() => { try { child.kill(); } catch {} resolve({ ok: false, err: "runner 执行超时" }); }, timeoutMs);
    child.on("error", (e) => { clearTimeout(timer); resolve({ ok: false, err: e.message }); });
    child.on("close", (code) => {
      clearTimeout(timer);
      if (code === 0) resolve({ ok: true, out, err });
      else resolve({ ok: false, err: (err || out || `exit ${code}`).trim().slice(0, 300) });
    });
  });
}
async function runReopen(taskId, text) {
  const r = await spawnKanbanRunner([
    OPC_REOPEN_RUNNER, taskId, "--reason", text,
    "--db", KANBAN_DB_PATH, "--author", "gavin",
  ]);
  if (!r.ok) {
    console.error("[workbench] reopen runner failed:", taskId, r.err);
    let msg = r.err;
    if (/not done\/archived/.test(r.err)) msg = "该卡不可打回（仅 done/archived 卡可打回）";
    else if (/任务卡不存在/.test(r.err)) msg = "任务卡不存在";
    const e = new Error(`打回失败: ${msg}`); e.status = 502; throw e;
  }
  let j = null;
  try { j = JSON.parse(r.out.trim()); } catch { j = null; }
  if (!j || j.ok !== true) {
    const e = new Error(`打回失败: ${(j && j.error) || "runner 输出异常"}`); e.status = 502; throw e;
  }
  return {
    reopened: true,
    task_id: j.task_id,
    new_status: j.new_status,
    previous_status: j.previous_status,
    invalidated: j.invalidated || [],
    reason: j.reason || text,
  };
}
async function handleKanbanReopen(body, req) {
  if (!WORKBENCH_TOKEN) { const e = new Error("工作台未配置（WORKBENCH_TOKEN 缺失）"); e.status = 503; throw e; }
  if (!workbenchLimiter(clientIp(req))) { const e = new Error("操作太频繁，请稍后再试"); e.status = 429; throw e; }
  const v = validateFeedback({ ...(body || {}), action: "reopen" });
  if (!v.ok) { const e = new Error(v.error); e.status = v.status; throw e; }
  if (!tokenOk(body && body.token, WORKBENCH_TOKEN)) { const e = new Error("密码不正确"); e.status = 401; throw e; }
  const { taskId, text } = v.value;
  const db = openKanbanDb();
  if (!db) { const e = new Error("kanban 数据未就绪"); e.status = 503; throw e; }
  let task;
  try {
    task = db.prepare("SELECT id, assignee, status, block_kind, block_recurrences FROM tasks WHERE id = ?").get(taskId);
    if (task && !["done", "archived"].includes(task.status)) {
      const e = new Error("该卡不可打回（仅 done/archived 卡可打回）"); e.status = 409; throw e;
    }
  } catch (e2) {
    if (e2 && e2.status) throw e2;
    console.error("[workbench] reopen task lookup error:", e2?.message || e2);
    const e = new Error("任务卡不存在"); e.status = 404; throw e;
  } finally { try { db.close(); } catch {} }
  if (!task) { const e = new Error("任务卡不存在"); e.status = 404; throw e; }
  if (!taskOperable(task)) { const e = new Error("无权操作该任务卡"); e.status = 403; throw e; }
  return runReopen(taskId, text);
}

/* ---------------- demo 体验引擎（原样迁移; 数据在 OPC 目录） ---------------- */
const DEMO_TASKS = {
  v2ex_hot:         { name: "V2EX 热帖",   prompt: "帮我收集一下 v2ex 十个热帖（标题+链接+热度）" },
  gz_weather:       { name: "广州天气",     prompt: "帮我查一下广州未来 15 天的天气。请使用国内天气数据源（中国天气网/中国气象局数据）：通过服务端天气代理接口获取数据（GET http://localhost:3033/api/opc/demo/weather/gz，本机服务；如不可用可尝试公网 https://opc.hermes.cc.cd/api/opc/demo/weather/gz），该接口返回广州未来 15 天预报 JSON（含 data_source/fetched_at/days）。报告中必须标注「数据来源：中国天气网（中国气象局）」和抓取时间。" },
  gz_trip:          { name: "广州周边旅行", prompt: "给我一个广州周边旅行的计划（2-3 天行程）。行程涉及天气，请使用国内天气数据源（中国天气网/中国气象局数据）：通过服务端天气代理接口获取数据（GET http://localhost:3033/api/opc/demo/weather/gz，本机服务；如不可用可尝试公网 https://opc.hermes.cc.cd/api/opc/demo/weather/gz），报告中必须标注「数据来源：中国天气网（中国气象局）」和抓取时间。" },
  niulai_boxoffice: { name: "牛来票房",     prompt: "帮我看看《牛来》这个电影的实时票房" },
};
const DEMO_MAX_INFLIGHT = 2;
const DEMO_HISTORY_MAX = 30;
const DEMO_SSE_POLL_MS = 2000;
const DEMO_SSE_MAX_MS = 15 * 60 * 1000;
const DEMO_MEMBER = "潘明";

// 启动时把预设表同步成 presets.json（供 opc_demo_dispatch.py 读取, 单一事实源）
try {
  fs.mkdirSync(DEMO_DIR, { recursive: true });
  fs.writeFileSync(path.join(DEMO_DIR, "presets.json"), JSON.stringify(DEMO_TASKS, null, 2));
} catch (e) { console.error("[demo] presets.json sync error:", e.message); }

function demoReadStatus() {
  try { return JSON.parse(fs.readFileSync(DEMO_STATUS_FILE, "utf-8")); } catch { return { tasks: {}, history: [] }; }
}
function demoWriteStatus(s) {
  fs.mkdirSync(DEMO_DIR, { recursive: true });
  fs.writeFileSync(DEMO_STATUS_FILE, JSON.stringify(s, null, 2));
}
function demoTaskCreatedAt(t) {
  return t.created_at || t.started_at || t.finished_at || null;
}
function demoTaskView(s, id) {
  const t = s.tasks[id];
  if (!t) return null;
  const v = {
    demo_id: id, task_id: t.task_id, status: t.status,
    kanban_task_id: t.kanban_task_id || null,
    created_at: t.created_at, started_at: t.started_at || null, finished_at: t.finished_at || null,
  };
  if (t.status === "completed") {
    v.report_md = "";
    try { v.report_md = fs.readFileSync(path.join(DEMO_RES_DIR, `${id}.md`), "utf-8"); } catch {}
  }
  return v;
}
function spawnDispatchScript() {
  try {
    const env = { ...process.env };
    delete env.HERMES_DELEGATED_CHILD_CONTEXT;
    // P0-1 修复: dispatch 脚本用 expanduser('~') 解析 OPC 目录, 必须显式 HOME=/home/gavin
    // （否则 pm2 从 profile 会话启动时 HOME 被污染为 profile 家目录, 扫描不到请求文件）
    env.HOME = "/home/gavin";
    const child = spawn("python3", [DEMO_DISPATCH_SCRIPT], { stdio: ["ignore", "ignore", "pipe"], env });
    let cerr = "";
    child.stderr.on("data", (d) => { cerr += d.toString(); });
    child.on("error", (e) => console.error("[demo] dispatch spawn error:", e.message));
    child.on("close", (code) => {
      if (code !== 0 || cerr.trim()) console.error(`[demo] dispatch exit=${code} stderr: ${cerr.trim().slice(0, 400)}`);
    });
    child.unref();
  } catch (e) {
    console.error("[demo] dispatch spawn failed:", e?.message || e);
  }
}
const demoRoute = async (_q, body, req) => {
  const taskId = String(body?.task_id || "").trim();
  if (!DEMO_TASKS[taskId]) { const e = new Error("unknown demo task"); e.status = 400; throw e; }
  const ip = clientIp(req);
  if (!demoLimiter(ip)) { const e = new Error("demo rate limited"); e.status = 429; throw e; }
  const s = demoReadStatus();
  // 缓存命中收窄为「进行中(inflight)」：同 IP + 同 task_id + status ∈ {queued, dispatched, running}
  // （P0 bug: 原条件 status !== "failed" 把 completed 也命中 → 永远返回旧任务不建新任务）
  // completed / failed 不再命中 → 正常走下方创建新任务流程
  const existing = Object.entries(s.tasks).find(
    ([, t]) => t.ip === ip && t.task_id === taskId && ["queued", "dispatched", "running"].includes(t.status)
  );
  if (existing) {
    return { demo_id: existing[0], status: existing[1].status, task_id: existing[1].task_id, cached: true, inflight: true };
  }
  const inflight = Object.values(s.tasks)
    .filter((t) => ["queued", "dispatched", "running"].includes(t.status)).length;
  if (inflight >= DEMO_MAX_INFLIGHT) { const e = new Error("demo busy"); e.status = 429; throw e; }
  const demoId = "d" + Date.now().toString(36) + "_" + crypto.randomBytes(4).toString("hex");
  const now = new Date().toISOString();
  fs.mkdirSync(DEMO_REQ_DIR, { recursive: true });
  fs.writeFileSync(path.join(DEMO_REQ_DIR, `${demoId}.json`),
    JSON.stringify({ demo_id: demoId, task_id: taskId, ip, ts: now }, null, 2));
  s.tasks[demoId] = {
    task_id: taskId, ip, status: "queued",
    created_at: now, started_at: null, finished_at: null, kanban_task_id: null,
  };
  demoWriteStatus(s);
  spawnDispatchScript();
  return { demo_id: demoId, status: "queued", task_id: taskId };
};
const demoStatusRoute = (q) => {
  const id = String(q.get("demo_id") || "").trim();
  if (!id) { const e = new Error("demo_id required"); e.status = 400; throw e; }
  const v = demoTaskView(demoReadStatus(), id);
  if (!v) { const e = new Error("demo not found"); e.status = 404; throw e; }
  return v;
};
const demoHistoryRoute = () => {
  const s = demoReadStatus();
  let items = (s.history || []).slice(0, DEMO_HISTORY_MAX);
  if (!items.length) {
    items = Object.entries(s.tasks)
      .filter(([, t]) => ["completed", "failed"].includes(t.status))
      .map(([id, t]) => ({
        demo_id: id, task_id: t.task_id, status: t.status,
        created_at: demoTaskCreatedAt(t), finished_at: t.finished_at || null,
      }))
      .sort((a, b) => String(b.created_at || "").localeCompare(String(a.created_at || "")))
      .slice(0, DEMO_HISTORY_MAX);
  }
  return { items, count: items.length };
};

/* ---------------- gz_weather 天气代理（中国天气网/气象局, 免 key, 服务端取数） ---------------- */
const GZ_WEATHER_CITY = "101280101";
const GZ_WEATHER_STATION = "59287";
const GZ_WEATHER_7D_URL = `https://www.weather.com.cn/weather/${GZ_WEATHER_CITY}.shtml`;
const GZ_WEATHER_15D_URL = `https://www.weather.com.cn/weather15d/${GZ_WEATHER_CITY}.shtml`;
const GZ_WEATHER_CMA_URL = `https://weather.cma.cn/api/weather/${GZ_WEATHER_STATION}`;
const GZ_WEATHER_REFERER = "https://www.weather.com.cn/";
const GZ_WEATHER_TTL_MS = 30 * 60 * 1000;
const GZ_WEATHER_DEGRADE_TTL_MS = 5 * 60 * 1000;
const gzWeatherDate = (offsetDays) => new Date(Date.now() + 8 * 3600e3 + offsetDays * 86400e3).toISOString().slice(0, 10);
const gzWeatherNow = () => `${new Date(Date.now() + 8 * 3600e3).toISOString().replace("T", " ").slice(0, 16)} (UTC+8)`;
function parseWeather7dHtml(html, start) {
  const rows = [];
  const liRe = /<li\s+class="sky[^"]*"[^>]*>([\s\S]*?)<\/li>/g;
  let m;
  while ((m = liRe.exec(html))) {
    const b = m[1];
    if (!/<h1>\s*\d{1,2}日（(?:今天|明天|后天|周.)）\s*<\/h1>/.test(b)) continue;
    const tem = b.match(/<p\s+class="tem">\s*<span>([^<]+)<\/span>\s*\/\s*<i>([^<]+)<\/i>/);
    const win = b.match(/<p\s+class="win">([\s\S]*?)<\/p>/);
    const winDir = win && (win[1].match(/<span\s+title="([^"]*)"\s+class="[^"]*"><\/span>/) || [])[1];
    const winScale = win && (win[1].match(/<i>([\s\S]*?)<\/i>/) || [])[1];
    rows.push({
      date: gzWeatherDate(start + rows.length),
      dayText: ((b.match(/<p\s+title="([^"]*)"\s+class="wea">/) || [])[1] || "").trim(),
      high: tem ? parseInt(tem[1], 10) : null,
      low: tem ? parseInt(tem[2].replace("℃", ""), 10) : null,
      windDir: winDir ? winDir.trim() : "",
      windScale: winScale ? winScale.trim() : "",
    });
  }
  return rows;
}
function parseWeather15dHtml(html, start) {
  const rows = [];
  const ulM = html.match(/<ul\s+class="t clearfix">([\s\S]*?)<\/ul>/);
  if (!ulM) return rows;
  const liRe = /<li[^>]*>([\s\S]*?)<\/li>/g;
  let m;
  while ((m = liRe.exec(ulM[1]))) {
    const b = m[1];
    if (!/<span\s+class="time">周.（(\d{1,2})日）<\/span>/.test(b)) continue;
    const tem = b.match(/<span\s+class="tem"><em>(\d+)℃<\/em>\s*\/\s*(\d+)℃<\/span>/);
    rows.push({
      date: gzWeatherDate(start + rows.length),
      dayText: ((b.match(/<span\s+class="wea">([\s\S]*?)<\/span>/) || [])[1] || "").trim(),
      high: tem ? parseInt(tem[1], 10) : null,
      low: tem ? parseInt(tem[2], 10) : null,
      windDir: ((b.match(/<span\s+class="wind">([\s\S]*?)<\/span>/) || [])[1] || "").trim(),
      windScale: ((b.match(/<span\s+class="wind1">([\s\S]*?)<\/span>/) || [])[1] || "").trim(),
    });
  }
  return rows;
}
function parseWeatherCmaDaily(txt) {
  const d = JSON.parse(txt);
  const daily = d?.data?.daily;
  if (!Array.isArray(daily)) return [];
  return daily.map((x, i) => ({
    date: String(x.date || "").replace(/\//g, "-") || gzWeatherDate(i),
    dayText: x.dayText || x.nightText || "",
    high: x.high != null ? Math.round(x.high) : null,
    low: x.low != null ? Math.round(x.low) : null,
    windDir: x.dayWindDirection || "",
    windScale: x.dayWindScale || "",
  }));
}
async function handleGzWeather() {
  let days = [];
  let updateTime = null;
  let note = null;
  try {
    const h7 = await fetchWithFallback(GZ_WEATHER_7D_URL, { referer: GZ_WEATHER_REFERER, retries: 1 });
    days = parseWeather7dHtml(h7, 0);
    const um = h7.match(/id="hidden_title"[^>]*value="([^"]*)"/);
    if (um) updateTime = um[1].trim();
  } catch {}
  if (!days.length) {
    try {
      const cma = await fetchWithFallback(GZ_WEATHER_CMA_URL, { retries: 1 });
      days = parseWeatherCmaDaily(cma);
      try { const du = JSON.parse(cma)?.data?.lastUpdate; if (du) updateTime = du; } catch {}
    } catch {}
  }
  if (!days.length) { const e = new Error("weather upstream unavailable"); e.status = 502; throw e; }
  try {
    const h15 = await fetchWithFallback(GZ_WEATHER_15D_URL, { referer: GZ_WEATHER_REFERER, retries: 1 });
    const tail = parseWeather15dHtml(h15, days.length);
    if (tail.length) days = days.concat(tail);
    else note = "15 天预报页未取到第 8-15 天数据，仅含第 1-7 天";
  } catch { note = "15 天预报上游暂不可用，仅含第 1-7 天"; }
  const out = {
    city: "广州",
    data_source: "中国天气网（中国气象局）",
    fetched_at: gzWeatherNow(),
    update_time: updateTime,
    day_count: days.length,
    days,
  };
  if (note) out.note = note;
  return days.length >= 15 ? out : { ...out, __ttl: GZ_WEATHER_DEGRADE_TTL_MS };
}

/* ---------------- 全局状态流 SSE（status.json 变更秒级广播, 持续不关闭） ---------------- */
const OPC_STATUS_DIR = path.dirname(OPC_STATUS_FILE);   // 27d-fix: watch 目录而非文件(原子替换换 inode)
const OPC_STREAM_MAX_CLIENTS = 50;
const OPC_STREAM_DEBOUNCE_MS = 200;
const OPC_STREAM_FALLBACK_POLL_MS = 30 * 1000;
const OPC_STREAM_HEARTBEAT_MS = 27 * 1000;
// 0826-P0 SSE 风暴修复: 广播瘦身 + 合并节流 + 僵尸踢出（详见 opcStreamBroadcast / opcStreamSweep）
const OPC_STREAM_MIN_INTERVAL_MS = 5 * 1000;   // 合并节流: 最短广播间隔 ≥5s（opc-bus ~3s 原子写 → 高频变化合并）
const OPC_STREAM_ZOMBIE_MS = 90 * 1000;        // 90s 无成功写(含心跳) → 僵尸, 踢出
const OPC_STREAM_SWEEP_MS = 30 * 1000;         // 僵尸清扫周期
const OPC_STREAM_SLOW_LIMIT = 5;               // 连续 N 次广播背压(write=false) → 慢客户端, 踢出

const opcStreamClients = new Set();
let opcStreamWatcher = null;
let opcStreamFallbackTimer = null;
let opcStreamDebounceTimer = null;
let opcStreamSweepTimer = null;
let opcStreamThrottleTimer = null;
let opcStreamLastMtime = 0;
let opcStreamLastSignal = null;    // 上次广播信号(JSON 字符串): 内容相同跳过, 防无变化写入重复推送
let opcStreamLastBroadcastAt = 0;  // 上次实际广播时刻(节流用)

function opcStreamReadSnapshot() {
  try { return JSON.parse(fs.readFileSync(OPC_STATUS_FILE, "utf-8")); } catch { return null; }
}
// 连接建立/广播共用: 构建当前轻量信号（KB 级; 零全量 JSON.parse）。
// 0826-P0 A3: 原始实现 readFileSync(755KB)+JSON.parse 逐连接执行——旧前端无退避重连风暴下
// 每秒 N 次全量解析是放大器之三（实测 14 连接 API 3s→15s 持续劣化）。现在:
//   - mtime 未变 → 直接复用缓存信号(零文件读取, 连接风暴 O(1))
//   - mtime 已变 → 正则提取顶层 ts 字段(比 JSON.parse 快一个量级, 无大对象分配)
// 0826-P1 修复(P1, 蔡婉验收): 信号字段只留 {ver,mtime,ts}, 删除 updated_at。
//   旧逻辑 /"updated_at".../ 正则未锚定行首 → 匹配到嵌套 metrics/kanban 的陈旧值
//   ("2026-08-26T18:17:14") → 信号携带陈旧 updated_at → 前端 d.updated_at||d.ts||d.ver
//   优先取陈旧值 → 与 lastStatusVer(顶层 ts) 永不相等 → 每 5s 拉全量 760KB。
//   现在 ver 锚定 status.json 顶层 ts(indent=2 格式化 JSON, 顶层字段行首恰为两空格,
//   ^ 锚定 + m 标志精确匹配行首; 提取失败 → ver=null → 前端不跳过拉全量, 安全降级)。
let opcStreamSigMtime = 0;   // 构建/缓存 signal 时的 status.json mtime
let opcStatusJsonCache = null;   // 0826-P0 A4: /api/opc/status.json 全量响应缓存 {mtime, raw}
function opcStreamBuildSignal() {
  let mtime = 0;
  try { mtime = fs.statSync(OPC_STATUS_FILE).mtimeMs; } catch { return null; }
  if (opcStreamLastSignal != null && mtime === opcStreamSigMtime) return opcStreamLastSignal;
  let raw = null;
  try { raw = fs.readFileSync(OPC_STATUS_FILE, "utf-8"); } catch { return null; }
  const m2 = raw.match(/^  "ts"\s*:\s*"([^"]+)"/m);
  const ts = m2 ? m2[1] : null;
  opcStreamSigMtime = mtime;
  opcStreamLastSignal = JSON.stringify({
    ver: ts,
    mtime,
    ts: new Date().toISOString(),
  });
  return opcStreamLastSignal;
}
// 0826-P0 风暴修复(A): 全量 755KB 快照广播 → 轻量信号广播（{ver, mtime, updated_at, ts}, KB 级）。
//   前端收到 event:status 信号后按需 fetch /api/opc/status.json 拿全量; 连接建立首帧同样只发
//   轻量信号（见 SSE handler）——连接风暴下 N×755KB 首帧写放大是风暴放大器之一, 一并消除;
//   新前端收到信号即按需拉全量, 旧前端 30s 兜底轮询不白屏。另加合并节流: 最短广播间隔 ≥5s——
//   opc-bus ~3s 原子写 status.json, 节流把高频变化合并为一次广播; 节流窗口内的最新信号在窗口
//   结束时补发一次, 保证不丢最终态。
function opcStreamBroadcast() {
  let mtime = 0;
  try { mtime = fs.statSync(OPC_STATUS_FILE).mtimeMs; } catch { return; }
  if (mtime === opcStreamSigMtime && opcStreamLastSignal != null) return;   // 内容未变跳过(去重)
  const signal = opcStreamBuildSignal();
  if (signal == null) return;
  const now = Date.now();
  const wait = OPC_STREAM_MIN_INTERVAL_MS - (now - opcStreamLastBroadcastAt);
  if (wait > 0) {
    if (opcStreamThrottleTimer) return;         // 已在节流补发队列, signal 已是最新
    opcStreamThrottleTimer = setTimeout(() => {
      opcStreamThrottleTimer = null;
      opcStreamLastBroadcastAt = Date.now();
      opcStreamEmitSignal(opcStreamLastSignal);
    }, wait);
    return;
  }
  opcStreamLastBroadcastAt = now;
  opcStreamEmitSignal(signal);
}
function opcStreamEmitSignal(signal) {
  for (const c of opcStreamClients) opcStreamWrite(c, "status", signal);
}
// 写事件到单个 SSE 客户端; 成功写更新 lastActive(心跳/数据皆可), 背压(write=false)累计 slow 供清扫踢出
function opcStreamWrite(c, event, data) {
  if (sendEvent(c.res, event, data)) {
    c.lastActive = Date.now();
    c.slow = 0;
  } else {
    c.slow = (c.slow || 0) + 1;
  }
}
// 0826-P0 风暴修复(B): 僵尸/半开连接踢出——90s 无成功写(心跳失败/异常)或连续背压 → destroy。
//   destroy 触发 socket error/close → req 'close' 清理路径（delete + clearInterval），此处兜底幂等。
//   TCP keepalive(socket.setKeepAlive) 由 SSE handler 设置, 辅助内核探测半开连接。
function opcStreamSweep() {
  const now = Date.now();
  for (const c of opcStreamClients) {
    if (now - c.lastActive > OPC_STREAM_ZOMBIE_MS || (c.slow || 0) >= OPC_STREAM_SLOW_LIMIT) {
      try { c.res.destroy(); } catch {}
      opcStreamClients.delete(c);
      clearInterval(c.hb);
    }
  }
}
// 27d-fix(蔡婉双写实验复现): opc-bus.py / opc_collect.py 均 tmp+os.replace 原子写(换 inode),
// 文件级 fs.watch 首次替换后 inotify 失效, 之后写入零事件 → SSE 只剩 30s 兜底轮询(气泡 P95 24.5s)。
// 方案①(庄子拍板): watch status.json 所在目录, 捕获 rename 事件按文件名过滤定位 status.json,
// 写入方原子性零改动(tmp+os.replace 保留); 30s mtime 轮询仅作保险。
function opcStreamStartWatcher() {
  if (opcStreamWatcher || opcStreamFallbackTimer) return;
  try { opcStreamLastMtime = fs.statSync(OPC_STATUS_FILE).mtimeMs; } catch { opcStreamLastMtime = 0; }
  try {
    opcStreamWatcher = fs.watch(OPC_STATUS_DIR, { persistent: false }, (eventType, filename) => {
      // 目录级 watch 收到目录内所有文件事件(tmp 中间文件/其他文件): 只认 status.json。
      // Linux inotify 下 os.replace(tmp, status.json) → IN_MOVED_TO, eventType='rename', filename='status.json'。
      const name = Buffer.isBuffer(filename) ? filename.toString("utf8") : filename;
      if (name !== null && name !== path.basename(OPC_STATUS_FILE)) return;
      if (opcStreamDebounceTimer) clearTimeout(opcStreamDebounceTimer);
      opcStreamDebounceTimer = setTimeout(() => { opcStreamDebounceTimer = null; opcStreamBroadcast(); }, OPC_STREAM_DEBOUNCE_MS);
    });
  } catch (e) {
    console.error("[opc-stream] fs.watch unavailable, falling back to 30s poll:", e.message);
    opcStreamWatcher = null;
  }
  opcStreamFallbackTimer = setInterval(() => {
    let mtime = 0;
    try { mtime = fs.statSync(OPC_STATUS_FILE).mtimeMs; } catch { return; }
    if (mtime !== opcStreamLastMtime) { opcStreamLastMtime = mtime; opcStreamBroadcast(); }
  }, OPC_STREAM_FALLBACK_POLL_MS);
  opcStreamFallbackTimer.unref();
  // 0826-P0: 僵尸清扫随首个连接启动, 最后一个连接断开时随 watcher 一起停
  opcStreamSweepTimer = setInterval(opcStreamSweep, OPC_STREAM_SWEEP_MS);
  opcStreamSweepTimer.unref();
  demoStreamStartWatcher();
}
function opcStreamStopWatcher() {
  if (opcStreamWatcher) { try { opcStreamWatcher.close(); } catch {} opcStreamWatcher = null; }
  if (opcStreamFallbackTimer) { clearInterval(opcStreamFallbackTimer); opcStreamFallbackTimer = null; }
  if (opcStreamDebounceTimer) { clearTimeout(opcStreamDebounceTimer); opcStreamDebounceTimer = null; }
  if (opcStreamSweepTimer) { clearInterval(opcStreamSweepTimer); opcStreamSweepTimer = null; }
  if (opcStreamThrottleTimer) { clearTimeout(opcStreamThrottleTimer); opcStreamThrottleTimer = null; }
  demoStreamStopWatcher();
}

/* ---------------- demo 事件管道（与全局流同 SSE, event: demo） ---------------- */
const demoStreamFrame = makeFrame({ tasks: DEMO_TASKS, member: DEMO_MEMBER });
function demoStreamDiff(prev, cur, nowIso) {
  return demoStreamDiffRaw(prev, cur, nowIso, demoStreamFrame);
}
let demoStreamWatcher = null;
let demoStreamDebounceTimer = null;
let demoStreamFallbackTimer = null;
let demoStreamLastMtime = 0;
let demoStreamPrevTasks = null;
const demoStreamSentSigs = new Set();

function demoStreamReadStatus() {
  try { return JSON.parse(fs.readFileSync(DEMO_STATUS_FILE, "utf-8")); } catch { return null; }
}
function demoStreamSig(id, status) { return `${id}|${status}`; }
function demoStreamMarkSent(id, status) {
  const sig = demoStreamSig(id, status);
  if (demoStreamSentSigs.has(sig)) return false;
  demoStreamSentSigs.add(sig);
  if (demoStreamSentSigs.size > 1000) demoStreamSentSigs.clear();
  return true;
}
function demoStreamBroadcast() {
  const snap = demoStreamReadStatus();
  if (!snap || !snap.tasks) return;
  const nowIso = new Date().toISOString();
  if (demoStreamPrevTasks == null) { demoStreamPrevTasks = snap.tasks; return; }
  const frames = demoStreamDiff(demoStreamPrevTasks, snap.tasks, nowIso);
  demoStreamPrevTasks = snap.tasks;
  if (!frames.length) return;
  const fresh = frames.filter((f) => demoStreamMarkSent(f.demo_id, f.status));
  if (!fresh.length) return;
  for (const c of opcStreamClients) for (const f of fresh) opcStreamWrite(c, "demo", f);
}
function demoStreamStartWatcher() {
  if (demoStreamWatcher || demoStreamFallbackTimer) return;
  try { demoStreamLastMtime = fs.statSync(DEMO_STATUS_FILE).mtimeMs; } catch { demoStreamLastMtime = 0; }
  try {
    demoStreamWatcher = fs.watch(DEMO_STATUS_FILE, { persistent: false }, () => {
      if (demoStreamDebounceTimer) clearTimeout(demoStreamDebounceTimer);
      demoStreamDebounceTimer = setTimeout(() => { demoStreamDebounceTimer = null; demoStreamBroadcast(); }, OPC_STREAM_DEBOUNCE_MS);
    });
  } catch (e) {
    console.error("[demo-stream] fs.watch unavailable for demo status:", e.message);
    demoStreamWatcher = null;
  }
  demoStreamFallbackTimer = setInterval(() => {
    let mtime = 0;
    try { mtime = fs.statSync(DEMO_STATUS_FILE).mtimeMs; } catch { return; }
    if (mtime !== demoStreamLastMtime) { demoStreamLastMtime = mtime; demoStreamBroadcast(); }
  }, 5000);
  demoStreamFallbackTimer.unref();
}
function demoStreamStopWatcher() {
  if (demoStreamWatcher) { try { demoStreamWatcher.close(); } catch {} demoStreamWatcher = null; }
  if (demoStreamFallbackTimer) { clearInterval(demoStreamFallbackTimer); demoStreamFallbackTimer = null; }
  if (demoStreamDebounceTimer) { clearTimeout(demoStreamDebounceTimer); demoStreamDebounceTimer = null; }
}
function demoStreamCatchUp(res) {
  const snap = demoStreamReadStatus();
  if (!snap || !snap.tasks) return;
  const nowIso = new Date().toISOString();
  for (const [id, t] of Object.entries(snap.tasks)) {
    if (t.status === "dispatched" && t.kanban_task_id) {
      sendEvent(res, "demo", demoStreamFrame(id, t, "created", "todo", t.created_at || nowIso));
      demoStreamMarkSent(id, "todo");
    } else if (t.status === "running") {
      sendEvent(res, "demo", demoStreamFrame(id, t, "claimed", "running", t.started_at || nowIso));
      demoStreamMarkSent(id, "running");
    }
  }
}
try { demoStreamPrevTasks = (demoStreamReadStatus() || { tasks: {} }).tasks || {}; } catch { demoStreamPrevTasks = {}; }

/* ---------------- 路由表（与 mrd 旧路径逐字节同契约） ---------------- */
const routes = {
  // 0825-f: 时钟服务权威时间（实时, 不缓存; {iso, unix, tz: Asia/Shanghai, offset: 480分钟}）
  "/api/time": () => timePayload(),
  "/api/token-stats": () => tokenStatsRoute(),
  "/api/acquisition": () => cached("acquisition", 60 * 1000, () => handleAcquisition()),
  // 0822-t1a: 访问趋势（?days=N 默认 7, 上限 30; 按 days 分缓存 key; 降级 __ttl 由 handleTrends 携带）
  "/api/trends": (q) => {
    const days = Math.min(30, Math.max(7, parseInt(q.get("days") || "7", 10) || 7));
    return cached("trends-" + days, 60 * 1000, () => handleTrends(days));
  },
  // 0822-t1d: 留言/咨询明细读取（管理员 Bearer 鉴权 + IP 脱敏 + 分页; 不缓存, 实时明细）
  "/api/trends/messages": (q, _body, req) => {
    const auth = String(req.headers.authorization || "");
    const m = auth.match(/^Bearer\s+(.+)$/i);
    return handleTrendsMessages(q.get("type"), q.get("limit"), q.get("offset"), m ? m[1].trim() : "");
  },
  "/api/kanban/tasks": (q, _body, req) => handleKanbanTasks(q, req),
  "/api/kanban/feedback": (_q, body, req) => handleKanbanFeedback(body, req),
  // 0824b: done 卡打回（OPC 侧 reopen 语义，runner 实现）
  "/api/kanban/reopen": (_q, body, req) => handleKanbanReopen(body, req),
  "/api/opc/demo": (q, body, req) => demoRoute(q, body, req),
  "/api/opc/demo/status": (q) => demoStatusRoute(q),
  "/api/opc/demo/history": () => demoHistoryRoute(),
  "/api/opc/demo/weather/gz": () => cached("gz-weather", GZ_WEATHER_TTL_MS, () => handleGzWeather()),
  // P0-1: 前端降级轮询 STATUS_URL 的 opc 域等价物（裸 status.json, 与 mrd 静态 /company/opc/status.json 同构）
  // 0826-P0 A4: 全量响应缓存——mtime 未变直接返回原始字符串（零 JSON.parse/stringify）。
  //   旧前端 30s 兜底轮询 + 新前端信号按需拉取都会高频打这个接口, 718KB parse+stringify 每次请求
  //   是风暴放大器之四（旧前端重连风暴下 API 持续劣化至 23s 实测）。bus ~3s 原子写 → 3s 重建一次,
  //   请求命中缓存 O(1) 直出字符串（send 对 string 零序列化）。opcStatusJsonCache 声明在文件顶部。
  "/api/opc/status.json": (q, _body, _req) => {
    let mtime = 0;
    try { mtime = fs.statSync(OPC_STATUS_FILE).mtimeMs; } catch { const e = new Error("status 数据未就绪"); e.status = 503; throw e; }
    if (!opcStatusJsonCache || opcStatusJsonCache.mtime !== mtime) {
      try {
        const raw = fs.readFileSync(OPC_STATUS_FILE, "utf-8");
        JSON.parse(raw);   // 合法性校验（无效则 503, 不缓存坏数据）
        opcStatusJsonCache = { mtime, raw };
      } catch (e) {
        if (e && e.status) throw e;
        const err = new Error("status 数据未就绪"); err.status = 503; throw err;
      }
    }
    return { __rawResponse: opcStatusJsonCache.raw };
  },
  // 0825-e: LLM 网关透明度数据（collector 同步 <OPC_OS_DATA_DIR>/llm-gateway.json, 60s 缓存, 缺失抛 503）
  "/api/opc/llm-gateway.json": () =>
    cached("llm-gateway", 60000, async () => {
      const p = path.join(OPC_DATA, "llm-gateway.json");
      let raw;
      try { raw = fs.readFileSync(p, "utf8"); }
      catch { const e = new Error("llm-gateway 数据未就绪"); e.status = 503; throw e; }
      try { return { __rawResponse: JSON.parse(raw) }; }
      catch { const e = new Error("llm-gateway 数据未就绪"); e.status = 503; throw e; }
    }),
};

/* ---------------- HTTP 服务 ---------------- */
const OPC_ROUTE_PREFIXES = ["/api/opc/", "/api/kanban/"];
const OPC_WHITELISTED = new Set(["/api/opc/demo", "/api/opc/demo/status", "/api/opc/demo/history", "/api/opc/demo/weather/gz",
  "/api/token-stats", "/api/acquisition", "/api/trends", "/api/trends/messages", "/api/kanban/tasks", "/api/kanban/feedback",
  "/api/time"]);

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, "http://localhost");
    const isOpcPath = OPC_ROUTE_PREFIXES.some((p) => u.pathname.startsWith(p)) || OPC_WHITELISTED.has(u.pathname);

    // 跨域预检（www Pages 站跨源读写, 白名单放行）
    if (req.method === "OPTIONS" && isOpcPath) {
      const cors = opcCorsHeaders(req);
      if (cors["Access-Control-Allow-Origin"] == null) {
        send(res, 403, { ok: false, error: "forbidden" }, cors);
      } else {
        send(res, 200, { ok: true }, {
          ...cors,
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, X-Workbench-Token, Authorization",
          "Access-Control-Max-Age": "600",
        });
      }
      return;
    }

    // ---- OPC 全局状态流 SSE ----
    if (u.pathname === "/api/opc/stream" && req.method === "GET") {
      const ip = clientIp(req);
      const cors = opcCorsHeaders(req);
      if (!apiLimiter(ip)) { send(res, 429, { ok: false, error: "too many requests" }, cors); return; }
      if (opcStreamClients.size >= OPC_STREAM_MAX_CLIENTS) {
        send(res, 503, { ok: false, error: "too many concurrent stream clients" }, cors);
        return;
      }
      const headers = { ...cors };
      if (headers["Access-Control-Allow-Origin"] == null) delete headers["Access-Control-Allow-Origin"];
      setSSEHeaders(res, headers);
      // 0826-P0 风暴修复(B): 客户端健康追踪——lastActive 每次成功写(数据/心跳)刷新,
      // slow 累计背压; res error 立即清理(原 noop 导致僵尸连接滞留 opcStreamClients)。
      // TCP keepalive 30s 让内核探测半开连接(cloudflared 转发断链场景), 探测失败触发 error → 清理。
      try { if (res.socket) res.socket.setKeepAlive(true, 30 * 1000); } catch {}
      const client = { res, hb: null, lastActive: Date.now(), slow: 0 };
      client.hb = setInterval(() => {
        try { if (res.write(": ping\n\n")) client.lastActive = Date.now(); } catch {}
      }, OPC_STREAM_HEARTBEAT_MS);
      res.on("error", () => {
        opcStreamClients.delete(client);
        clearInterval(client.hb);
      });
      opcStreamClients.add(client);
      // 0826-P0 风暴修复(A2): 连接建立首帧 = 轻量信号（不再推全量 755KB 快照）。
      //   连接风暴下 N×755KB 首帧写放大 + 逐连接 JSON.stringify 是风暴放大器; 新前端收到信号
      //   即按需拉全量, 旧前端收到信号无 members 不渲染 → 30s 兜底轮询兜底, 不白屏。
      const sig0 = opcStreamBuildSignal();
      if (sig0) sendEvent(res, "status", sig0);
      demoStreamCatchUp(res);
      opcStreamStartWatcher();
      req.on("close", () => {
        opcStreamClients.delete(client);
        clearInterval(client.hb);
        if (opcStreamClients.size === 0) opcStreamStopWatcher();
      });
      return;
    }

    // ---- OPC demo 进展 SSE ----
    const demoStream = u.pathname.match(/^\/api\/opc\/demo\/([^/]{1,64})\/stream$/);
    if (demoStream && req.method === "GET") {
      const ip = clientIp(req);
      const cors = opcCorsHeaders(req);
      if (!apiLimiter(ip)) { send(res, 429, { ok: false, error: "too many requests" }, cors); return; }
      const demoId = demoStream[1];
      const s0 = demoReadStatus();
      if (!s0.tasks[demoId]) { send(res, 404, { ok: false, error: "demo not found" }, cors); return; }
      const headers = { ...cors };
      if (headers["Access-Control-Allow-Origin"] == null) delete headers["Access-Control-Allow-Origin"];
      setSSEHeaders(res, headers);
      let lastSig = "";
      const push = (v) => {
        if (!v) return;
        const sig = `${v.status}|${v.kanban_task_id || ""}|${v.finished_at || ""}`;
        if (sig === lastSig) return;
        lastSig = sig;
        sendEvent(res, "status", v);
      };
      push(demoTaskView(s0, demoId));
      const timer = setInterval(() => {
        const v = demoTaskView(demoReadStatus(), demoId);
        push(v);
        if (v && (v.status === "completed" || v.status === "failed")) {
          clearInterval(timer);
          setTimeout(() => { try { res.end(); } catch {} }, 500);
        }
      }, DEMO_SSE_POLL_MS);
      const maxTimer = setTimeout(() => { clearInterval(timer); try { res.end(); } catch {} }, DEMO_SSE_MAX_MS);
      req.on("close", () => { clearInterval(timer); clearTimeout(maxTimer); });
      return;
    }

    // ---- 常规路由 ----
    if (routes[u.pathname]) {
      const ip = clientIp(req);
      const cors = isOpcPath ? opcCorsHeaders(req) : { "Access-Control-Allow-Origin": null };
      if (!apiLimiter(ip)) {
        send(res, 429, { ok: false, error: "too many requests" }, cors);
        return;
      }
      for (const v of u.searchParams.values()) {
        if (v.length > 2000) {
          send(res, 400, { ok: false, error: "param too long" }, cors);
          return;
        }
      }
      try {
        let body;
        if (req.method === "POST") {
          const r = await readBodyWithLimit(req, 256 * 1024);
          if (r.tooBig) {
            res.on("finish", () => req.destroy());
            send(res, 413, { ok: false, error: "payload too large" }, cors);
            return;
          }
          try { body = JSON.parse(r.buf.toString()); } catch { send(res, 400, { ok: false, error: "invalid json body" }, cors); return; }
        }
        const data = await routes[u.pathname](u.searchParams, body, req);
        if (data && data.__rawResponse !== undefined) {
          send(res, 200, data.__rawResponse, cors);
        } else {
          send(res, 200, { ok: true, data, ts: Date.now() }, cors);
        }
      } catch (e) {
        console.error("[api]", u.pathname, e?.stack || e?.message || e);
        send(res, e?.status || 502, { ok: false, error: e?.status ? e.message : "upstream error" }, cors);
      }
      return;
    }

    if (u.pathname.startsWith("/api/")) {
      send(res, 404, { ok: false, error: "not found" });
      return;
    }

    // 非 /api 路径: 仅健康检查
    if (u.pathname === "/healthz" || u.pathname === "/") {
      send(res, 200, { ok: true, service: "opc-server", port: PORT, ts: Date.now() });
      return;
    }
    send(res, 404, { ok: false, error: "not found" });
  } catch (e) {
    console.error("[server] error:", e?.message || e);
    send(res, 500, { ok: false, error: "internal error" });
  }
});

server.listen(PORT, () => console.log(`[opc-server] listening on :${PORT} (data: ${OPC_DATA})`));
