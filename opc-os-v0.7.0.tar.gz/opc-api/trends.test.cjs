// 访问趋势聚合（0822-t1a t_16ead813）— 4 指标按日序列 + 三层 fallback 单测 (node --test trends.test.cjs)
// 前置: 本机真实数据文件存在（knock.db / demo/status.json / company-site-backend jsonl）; 短链源 mock（网络 hermeric）
"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");

const KNOCK_DB = "/home/gavin/hermes_space/mylauncher/server/data/knock.db";
const OPC_DATA = "/home/gavin/.hermes/opc";
const DEMO_STATUS_FILE = `${OPC_DATA}/demo/status.json`;
const ASSISTANT_LEADS_PATH = "/home/gavin/hermes_space/company-site-backend/server/data/assistant-leads.jsonl";
const FEEDBACK_MESSAGES_PATH = "/home/gavin/hermes_space/company-site-backend/server/data/feedback-messages.jsonl";

const bjToday = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);

function makeCtx(over) {
  return {
    fs,
    bjToday,
    fetchText: async (url) => {
      if (over && over.fetchThrow) throw new Error("network down");
      const m = url.match(/path=(%2Fgo%2F[a-z0-9]+)$/);
      const p = m ? decodeURIComponent(m[1]) : "/go/unknown";
      const hits = {
        "/go/v2ex": 85, "/go/opc": 5, "/go/blog": 5, "/go/github": 6, "/go/rank": 8,
        "/go/mylauncher": 1, "/go/juejin": 1, "/go/devto": 1, "/go/reddit": 5, "/go/youtube": 0, "/go/x": 9,
      };
      const days = hits[p] ? { "2026-08-20": hits[p] } : {};
      return JSON.stringify({ ok: true, data: { path: p, days, total: hits[p] || 0 } });
    },
    KNOCK_DB,
    OPC_DATA,
    DEMO_STATUS_FILE,
    ASSISTANT_LEADS_PATH,
    FEEDBACK_MESSAGES_PATH,
    ...over,
  };
}

test("loadUtmByDate: 按日聚合与实时 DB 一致, 含今日", () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  const u = src.loadUtmByDate();
  assert.ok(u.total > 0, "utm total 应为正");
  assert.ok((u.by_date[bjToday()] || 0) >= 0);
  assert.ok(Object.keys(u.by_date).length >= 1);
});

test("loadShortlinkByDate: mock 11 path 按日聚合 + by_path 模块维度", async () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  const sl = await src.loadShortlinkByDate();
  assert.equal(sl.total, 126, "mock 短链 total 应为 126"); // 85+5+5+6+8+1+1+1+5+0+9
  assert.equal(sl.by_date["2026-08-20"], 126);
  assert.equal(sl.by_path["v2ex"].total, 85);
  assert.equal(sl.by_path["youtube"].total, 0);
  assert.equal(Object.keys(sl.by_path).length, 11);
  assert.equal(sl.degraded, false);
});

test("loadDemoByDate: demo 体验按日（UTC+8 分桶）, total 与 status.json tasks 一致", () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  const d = src.loadDemoByDate();
  const j = JSON.parse(fs.readFileSync(DEMO_STATUS_FILE, "utf8"));
  assert.equal(d.total, Object.keys(j.tasks || {}).length);
  assert.ok(d.total > 100, "demo 任务数应 > 100");
  assert.ok(Object.keys(d.by_date).length >= 3);
});

test("loadFeedbackEventsByDate: submit 主口径按日, 与实时 DB 一致", () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  const f = src.loadFeedbackEventsByDate();
  assert.ok(f.submit_total >= 8, "submit 总数应 ≥ 8");
  assert.ok((f.submit_by_date["2026-08-20"] || 0) >= 5, "08-20 submit 应 ≥ 5");
  assert.ok((f.by_action.submit || 0) >= 8);
  assert.ok((f.by_action.open || 0) >= 5, "open 事件应存在（不计留言）");
});

test("loadFeedbackMessagesByDate: jsonl 交叉核对按日", () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  const m = src.loadFeedbackMessagesByDate();
  assert.ok(m.total >= 12, "feedback-messages 应 ≥ 12 条");
  assert.equal(typeof m.by_date["2026-08-20"], "number");
});

test("loadAssistantLeadsByDate: 跨仓 jsonl 按日（ts→UTC+8）, 与源文件一致", () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  const l = src.loadAssistantLeadsByDate();
  const lines = fs.readFileSync(ASSISTANT_LEADS_PATH, "utf8").split("\n").filter((s) => s.trim()).length;
  assert.equal(l.total, lines);
  assert.ok(l.total >= 15, "assistant-leads 应 ≥ 15 条");
  // 独立重算对照（独立分桶逻辑, 非复用实现）: ts → UTC+8 日
  const expect = {};
  for (const line of fs.readFileSync(ASSISTANT_LEADS_PATH, "utf8").split("\n")) {
    const t = line.trim();
    if (!t) continue;
    try {
      const o = JSON.parse(t);
      const d = new Date(Date.parse(o.ts) + 8 * 3600e3).toISOString().slice(0, 10);
      expect[d] = (expect[d] || 0) + 1;
    } catch {}
  }
  assert.deepEqual(l.by_date, expect, "by_date 应与源文件独立分桶一致");
});

test("handleTrends: 4 指标日序列 ≥7 天, 对齐 days, 无 NaN, 健康态无降级", async () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  const d = await src.handleTrends(7);
  assert.equal(d.days.length, 7);
  assert.equal(d.days[6], bjToday(), "末尾日应为今日(UTC+8)");
  for (const k of ["visits", "experience", "feedback", "consultation"]) {
    const m = d.metrics[k];
    assert.ok(Array.isArray(m.values), `${k}.values 应为数组`);
    assert.equal(m.values.length, 7, `${k} 应对齐 7 天`);
    assert.ok(m.since, `${k}.since 应有采集起点`);
    assert.ok(m.source && m.source.length > 0);
  }
  // 采集前日 null 不造假: utm 起点（since）之前的日期应为 null, 起点起有真实值
  // （0825-f 修正过期断言: 原固定「前 3 天 null」随窗口滑动失效——since 起点已滑入窗口）
  const vSince = d.metrics.visits.since;
  assert.ok(vSince, "visits.since 应有采集起点");
  for (let i = 0; i < 7; i++) {
    const day = d.days[i];
    if (day < vSince) {
      assert.equal(d.metrics.visits.values[i], null, `第${i}天(${day}) 在 since(${vSince}) 前应为 null`);
    } else {
      assert.ok(d.metrics.visits.values[i] >= 0, `第${i}天(${day}) 在 since(${vSince}) 起应有值`);
    }
  }
  // 今日值 = utm 今日 + 短链今日(mock 只含 08-20 → 今日=utm 今日)
  const u = src.loadUtmByDate();
  assert.equal(d.metrics.visits.values[6], u.by_date[bjToday()] || 0);
  // 分量暴露（可独立核对）
  assert.equal(d.metrics.visits.components.utm.length, 7);
  assert.equal(d.metrics.visits.components.shortlink.length, 7);
  assert.equal(d.metrics.visits.by_module["v2ex"].total, 85);
  assert.ok(d.metrics.feedback.components.messages.length === 7, "feedback 应含 jsonl 交叉核对分量");
  // 无 NaN / 无降级标记（全源健康）
  const flat = JSON.stringify(d);
  assert.ok(!flat.includes("NaN"), "响应不得含 NaN");
  assert.ok(!d.degraded_sources, "全源健康时不得标记降级");
  assert.equal(d.__ttl, undefined, "健康数据不带 __ttl");
});

test("handleTrends: 短链上游全挂 → 该源回退, 响应带 degraded + __ttl:5min, 不整卡报错", async () => {
  const src = require("./sources/trends.cjs")(makeCtx({ fetchThrow: true }));
  const d = await src.handleTrends(7); // 必须不抛
  assert.ok(d.degraded_sources.includes("shortlink"));
  assert.equal(d.__ttl, 5 * 60 * 1000);
  assert.equal(d.metrics.visits.by_module["v2ex"].total, 0);
  // 其余源不受牵连
  assert.ok(d.metrics.consultation.values.some((v) => v != null && v > 0));
});

test("全源失败 → 空态三层兜底: 各指标 values 全 null + collecting marker, 绝不抛错", async () => {
  const src = require("./sources/trends.cjs")(makeCtx({
    fetchThrow: true,
    KNOCK_DB: "/nonexistent/knock.db",
    DEMO_STATUS_FILE: "/nonexistent/demo/status.json",
    ASSISTANT_LEADS_PATH: "/nonexistent/assistant-leads.jsonl",
    FEEDBACK_MESSAGES_PATH: "/nonexistent/feedback-messages.jsonl",
  }));
  const d = await src.handleTrends(7); // 必须不抛
  assert.equal(d.degraded_sources.length, 6);
  assert.equal(d.__ttl, 5 * 60 * 1000);
  assert.deepEqual(d.metrics.visits.values, [null, null, null, null, null, null, null]);
  assert.deepEqual(d.metrics.experience.values, [null, null, null, null, null, null, null]);
  assert.deepEqual(d.metrics.consultation.values, [null, null, null, null, null, null, null]);
  assert.deepEqual(d.metrics.experience.markers, ["collecting"]);
  assert.deepEqual(d.metrics.consultation.markers, ["collecting"]);
  assert.deepEqual(d.metrics.feedback.markers, ["collecting"]);
});

test("bjDate: ISO UTC → UTC+8 日界（跨日边界验证）", () => {
  const src = require("./sources/trends.cjs")(makeCtx());
  // 2026-08-18T15:59:59Z = 08-18 23:59:59 UTC+8; 16:00Z = 08-19 00:00 UTC+8
  assert.equal(src.bjDate("2026-08-18T15:59:59Z"), "2026-08-18");
  assert.equal(src.bjDate("2026-08-18T16:00:00Z"), "2026-08-19");
  assert.equal(src.bjDate(""), "");
  assert.equal(src.bjDate("garbage"), "");
});
