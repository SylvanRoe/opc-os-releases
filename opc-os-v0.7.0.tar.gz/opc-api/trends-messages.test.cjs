// 留言/咨询明细读取（0822-t1d t_f2497b0d）— 鉴权 401×2 / 200 授权 / type 非法 400 / limit clamp /
// offset 分页 / IP 脱敏（IPv4/IPv6/空）/ 字段完整性 单测 (node --test trends-messages.test.cjs)
// 前置: 本机真实 jsonl 源文件存在（company-site-backend/server/data/）; 测试 token 与 .env 无关（ctx 注入）
"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");

const ASSISTANT_LEADS_PATH = "/home/gavin/hermes_space/company-site-backend/server/data/assistant-leads.jsonl";
const FEEDBACK_MESSAGES_PATH = "/home/gavin/hermes_space/company-site-backend/server/data/feedback-messages.jsonl";
const TEST_TOKEN = "test-token-for-trends-messages-9f2c";

function makeSrc(over = {}) {
  return require("./sources/trends-messages.cjs")({
    fs,
    ASSISTANT_LEADS_PATH,
    FEEDBACK_MESSAGES_PATH,
    WORKBENCH_TOKEN: TEST_TOKEN,
    ...over,
  });
}

function readRaw(p) {
  const out = [];
  for (const line of fs.readFileSync(p, "utf8").split("\n")) {
    const t = line.trim();
    if (!t) continue;
    try { out.push(JSON.parse(t)); } catch {}
  }
  return out;
}
const FEEDBACK_ROWS = readRaw(FEEDBACK_MESSAGES_PATH);
const LEADS_ROWS = readRaw(ASSISTANT_LEADS_PATH);

/* ---------------- maskIp 单元 ---------------- */

test("maskIp: IPv4 保留前两段", () => {
  const { maskIp } = makeSrc();
  assert.equal(maskIp("27.47.9.187"), "27.47.*.*");
  assert.equal(maskIp("188.253.4.65"), "188.253.*.*");
  assert.equal(maskIp("0.0.0.0"), "0.0.*.*");
  assert.equal(maskIp("255.255.255.255"), "255.255.*.*");
});

test("maskIp: IPv4-mapped IPv6 取尾部 IPv4 脱敏", () => {
  const { maskIp } = makeSrc();
  assert.equal(maskIp("::ffff:127.0.0.1"), "127.0.*.*");
  assert.equal(maskIp("::ffff:114.114.114.114"), "114.114.*.*");
});

test("maskIp: IPv6 展开压缩保留前 4 组", () => {
  const { maskIp } = makeSrc();
  assert.equal(maskIp("2001:db8:85a3:0:0:8a2e:370:7334"), "2001:db8:85a3:0::");
  assert.equal(maskIp("2001:db8:85a3::8a2e:370:7334"), "2001:db8:85a3:0::");
  assert.equal(maskIp("fe80::1"), "fe80:0:0:0::");
  assert.equal(maskIp("::1"), "0:0:0:0::");
});

test("maskIp: 空/非法 → null, 绝不输出原始 IP", () => {
  const { maskIp } = makeSrc();
  assert.equal(maskIp(""), null);
  assert.equal(maskIp("   "), null);
  assert.equal(maskIp(null), null);
  assert.equal(maskIp(undefined), null);
  assert.equal(maskIp(123), null);
  assert.equal(maskIp("garbage"), null);
  assert.equal(maskIp("999.999.1.1"), null);   // 段超 255
  assert.equal(maskIp("1.2.3"), null);          // 非 4 段
  assert.equal(maskIp("2001:db8:85a3:zzzz::1"), null); // 非 hex 组
  assert.equal(maskIp("1:2:3:4:5:6:7:8:9"), null);     // 超 8 组
  assert.equal(maskIp("1:::2"), null);                 // 多个连续冒号
});

/* ---------------- 鉴权 ---------------- */

test("鉴权: 无 token → 401 unauthorized（零明细泄露）", () => {
  const src = makeSrc();
  assert.throws(
    () => src.handleMessages("feedback", undefined, undefined, ""),
    (e) => e.status === 401 && e.message === "unauthorized"
  );
  assert.throws(
    () => src.handleMessages("feedback", undefined, undefined, undefined),
    (e) => e.status === 401 && e.message === "unauthorized"
  );
  assert.throws(
    () => src.handleMessages("consultation", undefined, undefined, null),
    (e) => e.status === 401 && e.message === "unauthorized"
  );
});

test("鉴权: 错 token → 401 unauthorized（零明细泄露）", () => {
  const src = makeSrc();
  assert.throws(
    () => src.handleMessages("feedback", undefined, undefined, "wrong-token"),
    (e) => e.status === 401 && e.message === "unauthorized"
  );
  assert.throws(
    () => src.handleMessages("feedback", undefined, undefined, "Bearer wrong"),
    (e) => e.status === 401 && e.message === "unauthorized"
  );
});

test("鉴权: WORKBENCH_TOKEN 未配置 → 一律 401", () => {
  const src = makeSrc({ WORKBENCH_TOKEN: "" });
  assert.throws(
    () => src.handleMessages("feedback", undefined, undefined, TEST_TOKEN),
    (e) => e.status === 401 && e.message === "unauthorized"
  );
});

/* ---------------- 参数 ---------------- */

test("type 非法 → 400; 仅 feedback|consultation 二值", () => {
  const src = makeSrc();
  for (const bad of ["", "visits", "FOO", "feedback,consultation", "null"]) {
    assert.throws(
      () => src.handleMessages(bad, undefined, undefined, TEST_TOKEN),
      (e) => e.status === 400 && e.message === "invalid type",
      `type=${bad} 应 400`
    );
  }
  // 二值可正常返回
  const f = src.handleMessages("feedback", 1, 0, TEST_TOKEN);
  const c = src.handleMessages("consultation", 1, 0, TEST_TOKEN);
  assert.equal(f.type, "feedback");
  assert.equal(c.type, "consultation");
});

test("limit 默认 50 / 上限 clamp 200; offset 默认 0", () => {
  const src = makeSrc();
  const d1 = src.handleMessages("feedback", undefined, undefined, TEST_TOKEN);
  assert.equal(d1.limit, 50, "limit 缺省应为 50");
  assert.equal(d1.offset, 0);
  const d2 = src.handleMessages("feedback", "999", undefined, TEST_TOKEN);
  assert.equal(d2.limit, 200, "limit 999 应 clamp 到 200");
  const d3 = src.handleMessages("feedback", "0", undefined, TEST_TOKEN);
  assert.equal(d3.limit, 50, "limit 0 应回退默认 50");
  const d4 = src.handleMessages("feedback", "abc", undefined, TEST_TOKEN);
  assert.equal(d4.limit, 50, "limit 非法应回退默认 50");
  const d5 = src.handleMessages("feedback", 50, "-5", TEST_TOKEN);
  assert.equal(d5.offset, 0, "offset 负值应回退 0");
});

/* ---------------- 200 授权 + 数据一致性 ---------------- */

test("feedback: 200 授权, total 与源 jsonl 行数一致, 倒序最新在前", () => {
  const src = makeSrc();
  const d = src.handleMessages("feedback", 200, 0, TEST_TOKEN);
  assert.equal(d.ok, undefined); // data 直接返回（index.cjs 包 ok/data）
  assert.equal(d.total, FEEDBACK_ROWS.length, "total 应与源文件行数一致");
  assert.equal(d.items.length, FEEDBACK_ROWS.length);
  assert.equal(d.has_more, false, "全量取回应 has_more=false");
  // 倒序: ts 降序（Date.parse 非增）
  for (let i = 1; i < d.items.length; i++) {
    assert.ok(Date.parse(d.items[i - 1].ts) >= Date.parse(d.items[i].ts), "ts 应降序（最新在前）");
  }
});

test("consultation: 200 授权, total 与源 jsonl 行数一致, 倒序最新在前", () => {
  const src = makeSrc();
  const d = src.handleMessages("consultation", 200, 0, TEST_TOKEN);
  assert.equal(d.total, LEADS_ROWS.length);
  assert.equal(d.items.length, LEADS_ROWS.length);
  for (let i = 1; i < d.items.length; i++) {
    assert.ok(Date.parse(d.items[i - 1].ts) >= Date.parse(d.items[i].ts), "ts 应降序（最新在前）");
  }
});

test("逐条核对: 前 5 条 ts/question/contact 与源文件降序抽样一致（ts 原样透出不转时区）", () => {
  const src = makeSrc();
  for (const [type, rows, path] of [
    ["feedback", FEEDBACK_ROWS, FEEDBACK_MESSAGES_PATH],
    ["consultation", LEADS_ROWS, ASSISTANT_LEADS_PATH],
  ]) {
    const sorted = rows.slice().sort((a, b) => Date.parse(b.ts) - Date.parse(a.ts));
    const d = src.handleMessages(type, 200, 0, TEST_TOKEN);
    const n = Math.min(5, sorted.length);
    assert.ok(n >= 5, `${type} 源应有 ≥5 条可抽样`);
    for (let i = 0; i < n; i++) {
      const item = d.items[i];
      const raw = sorted[i];
      assert.equal(item.ts, raw.ts, `${type}[${i}].ts 应原样透出（不转时区）`);
      assert.equal(item.question, raw.question, `${type}[${i}].question 应完整透出`);
      assert.equal(item.contact, raw.contact, `${type}[${i}].contact 应完整透出`);
    }
  }
});

/* ---------------- IP 脱敏输出断言 ---------------- */

test("所有 ip_masked 均为脱敏形态, 不含任何原始 IP", () => {
  const src = makeSrc();
  const rawIps = new Set([...FEEDBACK_ROWS, ...LEADS_ROWS].map((r) => r && r.ip).filter(Boolean));
  const MASK_RE = /^(\d{1,3}\.\d{1,3}\.\*\.\*|[0-9a-fA-F:]+::$)$/;
  for (const type of ["feedback", "consultation"]) {
    const d = src.handleMessages(type, 200, 0, TEST_TOKEN);
    for (const item of d.items) {
      assert.ok(MASK_RE.test(item.ip_masked), `${type} ip_masked=${item.ip_masked} 应为脱敏形态`);
      assert.ok(!rawIps.has(item.ip_masked), `${type} ip_masked 不得等于任何原始 IP`);
    }
  }
});

test("字段完整性: feedback 项 = {ts,page,source,question,contact,ip_masked}", () => {
  const src = makeSrc();
  const d = src.handleMessages("feedback", 200, 0, TEST_TOKEN);
  const item = d.items[0];
  for (const k of ["ts", "page", "source", "question", "contact", "ip_masked"]) {
    assert.ok(k in item, `feedback 项应含 ${k}`);
  }
  assert.ok(!("ip" in item), "feedback 项不得透出原始 ip 字段");
  assert.equal(typeof item.question, "string");
  assert.equal(typeof item.contact, "string");
});

test("字段完整性: consultation 项 = {ts,source,question,contact,intent_hits,reply,ip_masked}", () => {
  const src = makeSrc();
  const d = src.handleMessages("consultation", 200, 0, TEST_TOKEN);
  const item = d.items[0];
  for (const k of ["ts", "source", "question", "contact", "intent_hits", "reply", "ip_masked"]) {
    assert.ok(k in item, `consultation 项应含 ${k}`);
  }
  assert.ok(!("ip" in item), "consultation 项不得透出原始 ip 字段");
  assert.ok(Array.isArray(item.intent_hits), "intent_hits 应为数组");
  assert.equal(typeof item.reply, "string");
});

/* ---------------- 分页 ---------------- */

test("offset 分页: 与全量切片一致, has_more 正确", () => {
  const src = makeSrc();
  for (const type of ["feedback", "consultation"]) {
    const all = src.handleMessages(type, 200, 0, TEST_TOKEN);
    const total = all.total;
    // 第 1 页: limit=2 offset=0
    const p1 = src.handleMessages(type, 2, 0, TEST_TOKEN);
    assert.equal(p1.items.length, 2);
    assert.equal(p1.has_more, total > 2, "第 1 页 has_more 应= total>2");
    assert.deepEqual(p1.items, all.items.slice(0, 2));
    // 第 2 页: offset=2 → 与全量第 3-4 条一致
    const p2 = src.handleMessages(type, 2, 2, TEST_TOKEN);
    assert.deepEqual(p2.items, all.items.slice(2, 4));
    // 末页: offset = total-1 → 1 条, has_more=false
    if (total >= 1) {
      const pLast = src.handleMessages(type, 5, total - 1, TEST_TOKEN);
      assert.equal(pLast.items.length, 1);
      assert.equal(pLast.has_more, false, "末页 has_more 应为 false");
    }
    // 越界: offset >= total → 0 条
    const pOver = src.handleMessages(type, 5, total + 100, TEST_TOKEN);
    assert.equal(pOver.items.length, 0);
    assert.equal(pOver.has_more, false);
    // 逐页遍历拼接 = 全量
    const collected = [];
    for (let off = 0; ; off += 3) {
      const page = src.handleMessages(type, 3, off, TEST_TOKEN);
      collected.push(...page.items);
      if (!page.has_more) break;
    }
    assert.deepEqual(collected, all.items, "逐页遍历拼接应等于全量");
  }
});

test("limit 上限 200: 大 limit 只返回 total 条, limit 字段反映 clamp 值", () => {
  const src = makeSrc();
  const d = src.handleMessages("feedback", "10000", "0", TEST_TOKEN);
  assert.equal(d.limit, 200, "limit 10000 应 clamp 到 200");
  assert.equal(d.items.length, FEEDBACK_ROWS.length, "items 不超过 total");
  assert.equal(d.has_more, false);
});
