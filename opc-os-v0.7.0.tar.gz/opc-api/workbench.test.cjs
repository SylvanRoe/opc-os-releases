// 人在 loop 工作台 · 纯逻辑层单测（0821-轨A-8 t_16098289）
// 覆盖: token 常数时间比较 / 载荷校验 / 动作→CLI 计划 / 安全边界。node --test 运行。
const { test } = require("node:test");
const assert = require("node:assert");
const { FB_ACTIONS, taskOperable, tokenOk, validateFeedback, buildPlan } = require("./lib/workbench.cjs");

const TASK = { id: "t_abc123", status: "blocked", assignee: "gavin", block_kind: "needs_input" };

test("tokenOk: 正确 token 通过", () => {
  assert.ok(tokenOk("secret-abc", "secret-abc"));
});
test("tokenOk: 错误 token 拒绝", () => {
  assert.ok(!tokenOk("wrong", "secret-abc"));
});
test("tokenOk: 空值/长度不同拒绝", () => {
  assert.ok(!tokenOk("", "secret-abc"));
  assert.ok(!tokenOk("abc", "abcd"));
  assert.ok(!tokenOk("secret-abc", null));
  assert.ok(!tokenOk(null, "secret-abc"));
});

test("validateFeedback: 合法载荷", () => {
  const r = validateFeedback({ token: "x", task_id: "t_abc123", action: "approve", text: "同意" });
  assert.strictEqual(r.ok, true);
  assert.deepStrictEqual(r.value, { taskId: "t_abc123", action: "approve", text: "同意" });
});
test("validateFeedback: task_id 缺失/非法", () => {
  assert.strictEqual(validateFeedback({ action: "approve" }).ok, false);
  assert.strictEqual(validateFeedback({ task_id: "abc", action: "approve" }).ok, false);
  assert.strictEqual(validateFeedback({ task_id: "t_a<b", action: "approve" }).ok, false);
  assert.strictEqual(validateFeedback({ task_id: "t_abc;DROP", action: "approve" }).ok, false);
});
test("validateFeedback: action 白名单", () => {
  assert.strictEqual(validateFeedback({ task_id: "t_abc", action: "hack" }).ok, false);
  assert.strictEqual(validateFeedback({ task_id: "t_abc", action: "approve" }).ok, true);
  assert.deepStrictEqual(FB_ACTIONS, ["approve", "reject", "comment", "done", "reopen"]);
});
test("validateFeedback: comment/reject/reopen 必须有 text", () => {
  assert.strictEqual(validateFeedback({ task_id: "t_abc", action: "comment" }).ok, false);
  assert.strictEqual(validateFeedback({ task_id: "t_abc", action: "reject" }).ok, false);
  assert.strictEqual(validateFeedback({ task_id: "t_abc", action: "reopen" }).ok, false);
  assert.strictEqual(validateFeedback({ task_id: "t_abc", action: "done" }).ok, true);
  assert.strictEqual(validateFeedback({ task_id: "t_abc", action: "approve" }).ok, true);
  const r = validateFeedback({ task_id: "t_abc", action: "reopen", text: "缺个步骤，打回重做" });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.value.action, "reopen");
  assert.strictEqual(r.value.text, "缺个步骤，打回重做");
});
test("validateFeedback: text 截断 4000 字符", () => {
  const r = validateFeedback({ task_id: "t_abc", action: "comment", text: "x".repeat(5000) });
  assert.strictEqual(r.value.text.length, 4000);
});

test("taskOperable: 只允许 gavin 或 needs_input", () => {
  assert.ok(taskOperable({ assignee: "gavin" }));
  assert.ok(taskOperable({ assignee: "make", block_kind: "needs_input" }));
  assert.ok(!taskOperable({ assignee: "make", block_kind: null }));
  assert.ok(!taskOperable(null));
});

test("buildPlan: approve = 评论(gavin) + unblock", () => {
  const p = buildPlan("approve", TASK, "同意，继续");
  assert.deepStrictEqual(p, [
    ["comment", "t_abc123", "同意，继续", "--author", "gavin"],
    ["unblock", "t_abc123"],
  ]);
});
test("buildPlan: done = 评论(gavin) + complete", () => {
  const p = buildPlan("done", TASK, "");
  assert.deepStrictEqual(p, [
    ["comment", "t_abc123", "Gavin 已标记完成。", "--author", "gavin"],
    ["complete", "t_abc123"],
  ]);
});
test("buildPlan: reject 且已 blocked = 仅评论（保持 blocked）", () => {
  const p = buildPlan("reject", TASK, "方案不行，重议");
  assert.deepStrictEqual(p, [["comment", "t_abc123", "方案不行，重议", "--author", "gavin"]]);
});
test("buildPlan: reject 且非 blocked + recurrences=0 = 评论 + 回堵 needs_input（原行为）", () => {
  const running = { id: "t_abc123", status: "running", assignee: "gavin", block_kind: null, block_recurrences: 0 };
  const p = buildPlan("reject", running, "先停一下");
  assert.deepStrictEqual(p, [
    ["comment", "t_abc123", "先停一下", "--author", "gavin"],
    ["block", "t_abc123", "--kind", "needs_input"],
  ]);
});
test("buildPlan: reject 且非 blocked + recurrences>=1 = 仅评论不回堵（防循环检测误伤, 0821-b）", () => {
  // 已驳回过的卡再回堵会触发内核 block_loop_detected → triage → auto-decomposer 改写真实卡（数据损坏）
  const running = { id: "t_abc123", status: "running", assignee: "gavin", block_kind: null, block_recurrences: 1 };
  const p = buildPlan("reject", running, "方案不行，重议");
  assert.strictEqual(p.length, 1);
  assert.strictEqual(p[0][0], "comment");
  assert.ok(p[0][2].includes("已驳回，卡保持原状态；如需阻止执行请联系庄子"));
  assert.ok(!p.some((s) => s[0] === "block"));
});
test("buildPlan: reject 且 blocked + recurrences>=1 = 仅评论（保持 blocked, 不回堵不追加说明）", () => {
  const blocked = { id: "t_abc123", status: "blocked", assignee: "gavin", block_kind: "needs_input", block_recurrences: 1 };
  const p = buildPlan("reject", blocked, "方案不行");
  assert.deepStrictEqual(p, [["comment", "t_abc123", "方案不行", "--author", "gavin"]]);
});
test("buildPlan: comment = 仅评论", () => {
  const p = buildPlan("comment", TASK, "补充一点");
  assert.deepStrictEqual(p, [["comment", "t_abc123", "补充一点", "--author", "gavin"]]);
});
test("buildPlan: reopen 由 OPC runner 处理——返回空计划（0824b）", () => {
  // 0824b 改造: 官方 main 无 done-reopen CLI verb，打回由 OPC runner
  // （opc_kanban_reopen.py）实现；index.cjs handleKanbanFeedback 在 buildPlan
  // 之前拦截 action=reopen 转 runReopen()。buildPlan 不再产出 CLI reopen 命令
  // （避免 spawn 官方 main 上不存在的 verb），返回空计划。
  const done = { id: "t_abc123", status: "done", assignee: "gavin" };
  const p = buildPlan("reopen", done, "缺个步骤，打回重做");
  assert.deepStrictEqual(p, []);
});
test("buildPlan: reopen 状态门不在此层——非 done 卡同样返回空计划，拒绝在端点/runner 层", () => {
  // 状态合法性（仅 done/archived 可打回）由 index.cjs handleKanbanReopen（409）
  // 与 runner（exit 1 零副作用）双层把关；buildPlan 保持纯规划职责不做状态校验。
  const running = { id: "t_abc123", status: "running", assignee: "gavin" };
  const p = buildPlan("reopen", running, "先打回");
  assert.deepStrictEqual(p, []);
});
