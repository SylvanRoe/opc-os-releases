// 留言/咨询明细读取 API（0822-t1d t_f2497b0d）— 管理员鉴权 + IP 脱敏 + 分页:
//   GET /api/trends/messages?type=feedback|consultation&limit=N&offset=M
// 1. 鉴权: Authorization: Bearer <token>, token === env WORKBENCH_TOKEN 才返回数据;
//    否则 401 {ok:false, error:"unauthorized"}（无 token/错 token 一律 401, 零明细泄露）
// 2. 参数: type 必填（仅 feedback|consultation 二值, 非法 400）; limit 默认 50 上限 200; offset 默认 0
//    响应 data = {type, items, total, limit, offset, has_more}, 倒序 = 最新在前（按 ts 降序）
// 3. IP 脱敏（后端脱敏输出, 前端零处理）: IPv4 保留前两段 → 114.114.*.*;
//    IPv6 展开压缩后保留前 4 组 → 2001:db8:85a3:0::; 空/非法 → null
// 4. 字段透出: feedback 项 = {ts, page, source, question, contact, ip_masked};
//    consultation 项 = {ts, source, question, contact, intent_hits, reply, ip_masked}
//    ts 原样透出（jsonl 内原始值, 不转换时区）
// 5. 只读: 复用 ASSISTANT_LEADS_PATH / FEEDBACK_MESSAGES_PATH 参数化跨仓读（零新跨仓依赖）, 不写任何 jsonl/DB
"use strict";
const fsModule = require("fs");

const { tokenOk } = require("../lib/workbench.cjs");

module.exports = function createTrendsMessages(ctx) {
  const fs = (ctx && ctx.fs) || fsModule;

  // 跨仓只读（红线: 路径参数化, 与 sources/trends.cjs 同源默认值）
  const ASSISTANT_LEADS_PATH = (ctx && ctx.ASSISTANT_LEADS_PATH)
    || process.env.ASSISTANT_LEADS_PATH
    || "/home/gavin/hermes_space/company-site-backend/server/data/assistant-leads.jsonl";
  const FEEDBACK_MESSAGES_PATH = (ctx && ctx.FEEDBACK_MESSAGES_PATH)
    || process.env.FEEDBACK_MESSAGES_PATH
    || "/home/gavin/hermes_space/company-site-backend/server/data/feedback-messages.jsonl";
  // 管理员令牌（.env / 进程 env; 空 = 未配置, 一律 401 不泄露）
  const WORKBENCH_TOKEN = (ctx && ctx.WORKBENCH_TOKEN) || process.env.WORKBENCH_TOKEN || "";

  /** 读 jsonl（跨仓只读）: 每行 JSON, 返回数组; 缺失/损坏返回 null */
  function readJsonl(p) {
    try {
      if (!fs.existsSync(p)) return null;
      const out = [];
      for (const line of fs.readFileSync(p, "utf8").split("\n")) {
        const t = line.trim();
        if (!t) continue;
        try { out.push(JSON.parse(t)); } catch {}
      }
      return out;
    } catch { return null; }
  }

  /** IPv6 压缩展开: "::" → 补零到 8 组; 非法返回 null */
  function expandIpv6(s) {
    const d = s.indexOf("::");
    if (d === -1) {
      const groups = s.split(":");
      if (groups.some((g) => !g) || groups.length > 8) return null;
      return groups;
    }
    if (s.indexOf("::", d + 2) !== -1) return null; // 多个 :: 非法
    const left = d === 0 ? [] : s.slice(0, d).split(":");
    const right = d + 2 >= s.length ? [] : s.slice(d + 2).split(":");
    if (left.some((g) => !g) || right.some((g) => !g)) return null;
    const missing = 8 - left.length - right.length;
    if (missing < 0) return null;
    return [...left, ...Array(missing).fill("0"), ...right];
  }

  /**
   * IP 脱敏（后端输出, 前端零处理）:
   * - IPv4 / IPv4-mapped IPv6（取尾部 IPv4）: 保留前两段 → 114.114.*.*
   * - IPv6: 展开压缩后保留前 4 组 → 2001:db8:85a3:0::
   * - 空/非法 → null（绝不输出完整 IP）
   */
  function maskIp(raw) {
    if (typeof raw !== "string") return null;
    const s = raw.trim();
    if (!s) return null;
    // IPv4 / IPv4-mapped IPv6: 匹配尾部 IPv4, 校验每段 0-255, 保留前两段
    const v4 = s.match(/(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (v4) {
      const segs = v4.slice(1).map((n) => parseInt(n, 10));
      if (segs.every((n) => n >= 0 && n <= 255)) return `${segs[0]}.${segs[1]}.*.*`;
      return null;
    }
    // IPv6: 展开压缩 → 校验各组 1-4 位 hex → 保留前 4 组
    if (s.includes(":")) {
      const groups = expandIpv6(s);
      if (!groups) return null;
      if (!groups.every((g) => /^[0-9a-fA-F]{1,4}$/.test(g))) return null;
      const head = groups.slice(0, 4);
      while (head.length < 4) head.push("0");
      return head.join(":") + "::";
    }
    return null;
  }

  /** ts 排序值: 非法/缺失 → 0（最旧, 倒序排最后） */
  function tsVal(r) {
    const t = r && r.ts ? Date.parse(r.ts) : NaN;
    return Number.isNaN(t) ? 0 : t;
  }

  /** 字段透出: feedback 项 = {ts, page, source, question, contact, ip_masked} */
  function toFeedbackView(r) {
    return {
      ts: r.ts != null ? r.ts : null,
      page: r.page != null ? r.page : null,
      source: r.source != null ? r.source : null,
      question: r.question != null ? r.question : null, // 用户主动提交, 全文透出
      contact: r.contact != null ? r.contact : null,
      ip_masked: maskIp(r.ip),
    };
  }

  /** 字段透出: consultation 项 = {ts, source, question, contact, intent_hits, reply, ip_masked} */
  function toConsultationView(r) {
    return {
      ts: r.ts != null ? r.ts : null,
      source: r.source != null ? r.source : (r.source_key != null ? r.source_key : null),
      question: r.question != null ? r.question : null,
      contact: r.contact != null ? r.contact : null,
      intent_hits: r.intent_hits != null ? r.intent_hits : null,
      reply: r.reply != null ? r.reply : null,
      ip_masked: maskIp(r.ip),
    };
  }

  /**
   * 明细读取（鉴权 + 参数校验 + 分页 + 脱敏透出）。
   * authToken 由 index.cjs 从 Authorization: Bearer <token> 解析传入。
   * 鉴权失败抛 401（响应体仅 {ok:false, error:"unauthorized"}, 零明细字段）。
   */
  function handleMessages(type, limitRaw, offsetRaw, authToken) {
    // 1. 鉴权（常数时间比较, 与工作台 session 校验同机制）: 无 token/错 token/未配置 一律 401
    if (!WORKBENCH_TOKEN || !tokenOk(authToken, WORKBENCH_TOKEN)) {
      const e = new Error("unauthorized");
      e.status = 401;
      throw e;
    }
    // 2. type 必填二值
    if (type !== "feedback" && type !== "consultation") {
      const e = new Error("invalid type");
      e.status = 400;
      throw e;
    }
    // 3. limit 默认 50 上限 200; offset 默认 0
    let limit = parseInt(String(limitRaw == null ? "" : limitRaw), 10);
    if (Number.isNaN(limit) || limit <= 0) limit = 50;
    limit = Math.min(200, limit);
    let offset = parseInt(String(offsetRaw == null ? "" : offsetRaw), 10);
    if (Number.isNaN(offset) || offset < 0) offset = 0;

    // 4. 只读源（跨仓参数化）, 倒序 = 最新在前（按 ts 降序）
    const path = type === "feedback" ? FEEDBACK_MESSAGES_PATH : ASSISTANT_LEADS_PATH;
    const rows = readJsonl(path);
    if (!rows) { const e = new Error("数据未就绪"); e.status = 503; throw e; }
    rows.sort((a, b) => tsVal(b) - tsVal(a));

    const total = rows.length;
    const view = type === "feedback" ? toFeedbackView : toConsultationView;
    const items = rows.slice(offset, offset + limit).map(view);
    return { type, items, total, limit, offset, has_more: offset + items.length < total };
  }

  return { handleMessages, maskIp, expandIpv6, readJsonl };
};
