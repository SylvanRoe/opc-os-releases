// 访问趋势聚合 API（0822-t1a t_16ead813）— 4 指标按日序列:
//   1. visits(访问)      = knock.db utm_visits 按日 + CF KV redirect_hits 短链命中按日（分量分列）
//   2. experience(体验)  = demo/status.json tasks[].created_at 按日（访客 demo 体验次数, UTC+8 分桶）
//   3. feedback(留言数)  = knock.db feedback_events action=submit 按日（主口径; open 为打开表单事件不计）
//   4. consultation(咨询)= company-site-backend assistant-leads.jsonl 按日（ts → UTC+8）
// 跨仓读（红线）: assistant-leads.jsonl / feedback-messages.jsonl 路径参数化
//   （ASSISTANT_LEADS_PATH / FEEDBACK_MESSAGES_PATH env 可覆盖, 参照 acquisition.cjs STATUS_JSON 模式）
// 三层 fallback 铁律（同 acquisition.cjs）: 任一源失败 → last-good → 空态; 绝不整卡报错。
//   任何降级 → 响应带 __ttl: 5*60*1000 短缓存, 上游恢复后尽快重试。
// 口径（写进卡评论的数据源清单, 2026-08-22）:
//   - 采集前日 = null（不造假）; 采集期内零事件 = 0
//   - 短链命中与 utm_visits 存在部分重叠（/go/opc、/go/rank、/go/v2ex 等落地带 UTM 同时进 utm_visits）,
//     visits 按日求和并暴露 components 分量, 重叠留痕不处理
//   - utm_visits 含 08-19 test/ada_test 测试行不滤除（与 acquisition 同口径）
//   - demo 08-17/18 各 50 条疑为种子/压测数据, markers 留痕
"use strict";
const { DatabaseSync } = require("node:sqlite");

module.exports = function createTrends(ctx) {
  const { fetchText, fs, bjToday } = ctx;

  const OPC_DATA = ctx.OPC_DATA || process.env.OPC_OS_DATA_DIR || "/home/gavin/.hermes/opc";
  const KNOCK_DB = ctx.KNOCK_DB || "/home/gavin/hermes_space/mylauncher/server/data/knock.db";
  // 跨仓只读（红线: 路径参数化, 参照 acquisition.cjs STATUS_JSON 模式）
  const ASSISTANT_LEADS_PATH = ctx.ASSISTANT_LEADS_PATH
    || process.env.ASSISTANT_LEADS_PATH
    || "/home/gavin/hermes_space/company-site-backend/server/data/assistant-leads.jsonl";
  const FEEDBACK_MESSAGES_PATH = ctx.FEEDBACK_MESSAGES_PATH
    || process.env.FEEDBACK_MESSAGES_PATH
    || "/home/gavin/hermes_space/company-site-backend/server/data/feedback-messages.jsonl";
  const DEMO_STATUS_FILE = ctx.DEMO_STATUS_FILE || `${OPC_DATA}/demo/status.json`;
  // 模块维度 = 短链 path 分组（_worker.js REDIRECTS 全量 + /go/x 动态特判; /go/x 也走 redirect_hits 计数）
  const SHORTLINK_PATHS = [
    "/go/v2ex", "/go/opc", "/go/blog", "/go/github", "/go/rank", "/go/mylauncher",
    "/go/juejin", "/go/devto", "/go/reddit", "/go/youtube", "/go/x",
  ];
  const SHORTLINK_BASE = "https://www.hermes.cc.cd/api/go/hits?path=";
  const DEGRADED_TTL = 5 * 60 * 1000;

  const lastGood = { utm: null, shortlink: null, demo: null, feedback: null, messages: null, leads: null };

  const emptyByDate = () => ({ by_date: {}, total: 0 });

  /** ISO 时间戳 → UTC+8 自然日（与 knock.db date 分桶/短链 KV 日界一致; 勿用 toISOString 裸切） */
  function bjDate(isoTs) {
    if (!isoTs) return "";
    const t = Date.parse(isoTs);
    if (Number.isNaN(t)) return "";
    return new Date(t + 8 * 3600e3).toISOString().slice(0, 10);
  }

  /** 最近 N 个 UTC+8 自然日（含今日, 正序 = 最早在前 → 今日最后, 趋势图自然时间序） */
  function lastNDates(n) {
    const now = Date.now();
    const out = [];
    for (let i = n - 1; i >= 0; i--) out.push(new Date(now + 8 * 3600e3 - i * 86400e3).toISOString().slice(0, 10));
    return out;
  }

  /** SQLite 只读查询（node:sqlite, 防锁）: 缺失/损坏/查询失败一律 null, 绝不抛给上层 */
  function readSqlite(sql) {
    let db = null;
    try {
      if (!fs.existsSync(KNOCK_DB)) return null;
      db = new DatabaseSync(KNOCK_DB, { readOnly: true });
      return db.prepare(sql).all();
    } catch { return null; }
    finally { try { if (db) db.close(); } catch {} }
  }

  /** 读 jsonl（跨仓只读）: 每行 JSON, 返回数组; 缺失/损坏返回 null */
  function readJsonl(p) {
    try {
      if (!fs.existsSync(p)) return null;
      const out = [];
      for (const line of fs.readFileSync(p, "utf8").split("\n")) {
        const t = line.trim();
        if (!t) continue;
        try { out.push(JSON.parse(t)); } catch {}
      }
      return out;
    } catch { return null; }
  }

  /* ---------------- 源①: knock.db utm_visits 按日 ---------------- */

  function loadUtmByDate() {
    const rows = readSqlite("SELECT date, count FROM utm_visits");
    if (!rows) throw new Error("knock.db utm_visits unavailable");
    const byDate = {};
    let total = 0;
    for (const r of rows) {
      if (!r.date) continue;
      byDate[r.date] = (byDate[r.date] || 0) + r.count;
      total += r.count;
    }
    return { by_date: byDate, total };
  }

  /* ---------------- 源②: 短链命中按日（www /api/go/hits ×11 path, 逐 path 独立成败） ---------------- */

  async function fetchShortlinkPath(p, pathGood) {
    const txt = await fetchText(SHORTLINK_BASE + encodeURIComponent(p));
    const j = JSON.parse(txt);
    if (!j || !j.ok || !j.data) throw new Error("bad hits response for " + p);
    const d = j.data;
    const days = d.days || {};
    let total = 0;
    for (const k in days) total += days[k];
    pathGood[p] = { days, total: d.total != null ? d.total : total };
    return { days, total: d.total != null ? d.total : total };
  }

  async function loadShortlinkByDate() {
    const last = lastGood.shortlink;
    const pathGood = {};
    let degraded = false;
    const settled = await Promise.allSettled(SHORTLINK_PATHS.map((p) => fetchShortlinkPath(p, pathGood)));
    settled.forEach((r, i) => {
      const p = SHORTLINK_PATHS[i];
      if (r.status === "fulfilled") return;
      degraded = true;
      const prev = last && last.by_path && last.by_path[p.replace("/go/", "")];
      pathGood[p] = prev ? { days: prev.days || {}, total: prev.total || 0 } : { days: {}, total: 0 };
    });
    const byDate = {};
    let total = 0;
    const byPath = {};
    for (const p of SHORTLINK_PATHS) {
      const e = pathGood[p];
      byPath[p.replace("/go/", "")] = e;
      total += e.total || 0;
      for (const d in e.days) byDate[d] = (byDate[d] || 0) + (e.days[d] || 0);
    }
    return { by_date: byDate, by_path: byPath, total, degraded };
  }

  /* ---------------- 源③: demo 体验按日（demo/status.json tasks created_at, UTC+8） ---------------- */

  function loadDemoByDate() {
    const raw = fs.readFileSync(DEMO_STATUS_FILE, "utf8");
    const j = JSON.parse(raw);
    const tasks = (j && j.tasks) || {};
    const byDate = {};
    let total = 0;
    for (const id of Object.keys(tasks)) {
      const t = tasks[id] || {};
      const d = bjDate(t.created_at || t.started_at || "");
      if (!d) continue;
      byDate[d] = (byDate[d] || 0) + 1;
      total += 1;
    }
    return { by_date: byDate, total };
  }

  /* ---------------- 源④: knock.db feedback_events 按日（主口径 = submit） ---------------- */

  function loadFeedbackEventsByDate() {
    const rows = readSqlite("SELECT date, action, count FROM feedback_events");
    if (!rows) throw new Error("knock.db feedback_events unavailable");
    const submit = {}, open = {}, byPage = {}, byAction = {};
    let total = 0, submitTotal = 0;
    for (const r of rows) {
      if (!r.date) continue;
      total += r.count;
      if (r.action === "submit") {
        submit[r.date] = (submit[r.date] || 0) + r.count;
        submitTotal += r.count;
      } else if (r.action === "open") {
        open[r.date] = (open[r.date] || 0) + r.count;
      }
      if (r.page) byPage[r.page] = (byPage[r.page] || 0) + r.count;
      byAction[r.action] = (byAction[r.action] || 0) + r.count;
    }
    return { submit_by_date: submit, open_by_date: open, by_page: byPage, by_action: byAction, total, submit_total: submitTotal };
  }

  /* ---------------- 源⑤(交叉核对): feedback-messages.jsonl 按日 ---------------- */

  function loadFeedbackMessagesByDate() {
    const rows = readJsonl(FEEDBACK_MESSAGES_PATH);
    if (!rows) throw new Error("feedback-messages.jsonl unavailable");
    const byDate = {};
    let total = 0;
    for (const r of rows) {
      const d = bjDate(r && r.ts);
      if (!d) continue;
      byDate[d] = (byDate[d] || 0) + 1;
      total += 1;
    }
    return { by_date: byDate, total };
  }

  /* ---------------- 源⑥: assistant-leads.jsonl 按日（跨仓只读, ts → UTC+8） ---------------- */

  function loadAssistantLeadsByDate() {
    const rows = readJsonl(ASSISTANT_LEADS_PATH);
    if (!rows) throw new Error("assistant-leads.jsonl unavailable");
    const byDate = {};
    let total = 0;
    for (const r of rows) {
      const d = bjDate(r && r.ts);
      if (!d) continue;
      byDate[d] = (byDate[d] || 0) + 1;
      total += 1;
    }
    return { by_date: byDate, total };
  }

  /* ---------------- 聚合: 4 指标按日序列（绝不整卡抛错） ---------------- */

  /**
   * 把 by_date 对齐到 days 数组: 采集前日=null（不造假）, 采集期内零事件=0。
   * since = 该源最早有数据的日期（markers 里标注采集起点）。
   */
  function alignSeries(days, byDate) {
    const values = [];
    let since = null;
    for (const d of days) {
      if (byDate[d] != null && byDate[d] > 0) {
        if (since == null) since = d;
        values.push(byDate[d]);
      } else {
        // 数据源有该日记录但为 0 → 0; 早于采集起点 → null
        values.push(since == null ? null : 0);
      }
    }
    if (since == null) {
      // 该源完全无数据（文件缺失/空）: 全 null + marker "collecting"
      for (let i = 0; i < days.length; i++) values[i] = null;
      return { values, since: null, empty: true };
    }
    return { values, since, empty: false };
  }

  async function handleTrends(days) {
    const degraded = [];
    const daysArr = lastNDates(days);

    // 1. visits: utm_visits + 短链命中
    let utm;
    try { utm = loadUtmByDate(); lastGood.utm = utm; }
    catch { utm = lastGood.utm || emptyByDate(); degraded.push("utm_visits"); }

    let sl;
    try {
      sl = await loadShortlinkByDate();
      if (sl.degraded) degraded.push("shortlink");
      lastGood.shortlink = { by_date: sl.by_date, by_path: sl.by_path, total: sl.total };
    } catch {
      sl = lastGood.shortlink
        ? { by_date: lastGood.shortlink.by_date, by_path: lastGood.shortlink.by_path, total: lastGood.shortlink.total }
        : { by_date: {}, by_path: {}, total: 0 };
      degraded.push("shortlink");
    }

    // 2. experience: demo 体验按日
    let demo;
    try { demo = loadDemoByDate(); lastGood.demo = demo; }
    catch { demo = lastGood.demo || emptyByDate(); degraded.push("demo"); }

    // 3. feedback: feedback_events submit（主口径）+ jsonl 交叉核对
    let fb;
    try { fb = loadFeedbackEventsByDate(); lastGood.feedback = fb; }
    catch { fb = lastGood.feedback || { submit_by_date: {}, open_by_date: {}, by_page: {}, by_action: {}, total: 0, submit_total: 0 }; degraded.push("feedback_events"); }

    let msgs;
    try { msgs = loadFeedbackMessagesByDate(); lastGood.messages = msgs; }
    catch { msgs = lastGood.messages || emptyByDate(); degraded.push("feedback_messages"); }

    // 4. consultation: assistant-leads 按日
    let leads;
    try { leads = loadAssistantLeadsByDate(); lastGood.leads = leads; }
    catch { leads = lastGood.leads || emptyByDate(); degraded.push("assistant_leads"); }

    // 访问分量: utm + 短链
    const utmSeries = alignSeries(daysArr, utm.by_date);
    const slSeries = alignSeries(daysArr, sl.by_date);
    const visitsValues = daysArr.map((_, i) => {
      if (utmSeries.values[i] == null && slSeries.values[i] == null) return null;
      return (utmSeries.values[i] || 0) + (slSeries.values[i] || 0);
    });
    const visitsSince = [utmSeries.since, slSeries.since].filter(Boolean).sort()[0] || null;

    const visits = {
      values: visitsValues,
      since: visitsSince,
      source: "knock.db utm_visits + CF KV redirect_hits（短链）",
      components: { utm: utmSeries.values, shortlink: slSeries.values },
      by_module: sl.by_path,
    };

    const expSeries = alignSeries(daysArr, demo.by_date);
    const experience = {
      values: expSeries.values,
      since: expSeries.since,
      source: "demo/status.json tasks created_at（访客 demo 体验次数, UTC+8）",
    };
    if (expSeries.empty) experience.markers = ["collecting"]; // 无按日历史 → 采集中空态起点, 不造假
    else if (demo.by_date["2026-08-17"] || demo.by_date["2026-08-18"]) {
      experience.markers = ["08-17/18 各 50 条疑为种子/压测数据"];
    }

    const fbSeries = alignSeries(daysArr, fb.submit_by_date);
    const feedback = {
      values: fbSeries.values,
      since: fbSeries.since,
      source: "knock.db feedback_events(action=submit)",
      components: { messages: alignSeries(daysArr, msgs.by_date).values }, // 交叉核对分量
    };
    if (fbSeries.empty) feedback.markers = ["collecting"];

    const leadsSeries = alignSeries(daysArr, leads.by_date);
    const consultation = {
      values: leadsSeries.values,
      since: leadsSeries.since,
      source: "assistant-leads.jsonl（ts → UTC+8）",
    };
    if (leadsSeries.empty) consultation.markers = ["collecting"];

    const data = {
      generated_at: new Date().toISOString(),
      days: daysArr,
      metrics: { visits, experience, feedback, consultation },
    };
    if (degraded.length) {
      data.degraded_sources = degraded;
      data.__ttl = DEGRADED_TTL;
    }
    return data;
  }

  return {
    handleTrends, loadUtmByDate, loadShortlinkByDate, loadDemoByDate,
    loadFeedbackEventsByDate, loadFeedbackMessagesByDate, loadAssistantLeadsByDate,
    bjDate, lastNDates,
  };
};
