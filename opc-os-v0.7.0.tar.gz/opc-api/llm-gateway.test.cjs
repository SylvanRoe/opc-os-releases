// LLM 网关透明度数据（0825-e t_1656e465）— 同步产物契约测试 (node --test llm-gateway.test.cjs)
// 前置: 同步脚本已产出 llm-gateway.json（宿主: ~/.hermes/opc/llm-gateway.json）
// 断言消费端（透明办公室页面）依赖的契约字段，上游 0825-b/c 字段漂移时本测试先行暴露。
"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");

const SYNC_OUT = "/home/gavin/.hermes/opc/llm-gateway.json";
const USAGE_STATE = "/home/gavin/.hermes/opc/llm-gateway/monitor/usage_state.json";
const EVENTS = "/home/gavin/.hermes/opc/llm-gateway/events/events.jsonl";

test("透明度同步产物存在且可解析", () => {
  assert.ok(fs.existsSync(SYNC_OUT), `${SYNC_OUT} 缺失（先跑 llm_gateway_sync.py）`);
  const d = JSON.parse(fs.readFileSync(SYNC_OUT, "utf8"));
  assert.equal(d.schema, "llm-gateway/transparency v1");
  assert.equal(d.available, true);
  assert.ok(d.generated_at);
});

test("usage_state 契约：current_provider / providers / switches 字段齐全", () => {
  const d = JSON.parse(fs.readFileSync(SYNC_OUT, "utf8"));
  const us = d.usage_state;
  assert.ok(us, "usage_state 缺失");
  assert.ok(us.current_provider && us.current_provider.name, "current_provider.name 缺失");
  assert.equal(us.current_provider.name, "deepseek", "当前生效 provider 应为 deepseek（主路径）");
  const ds = us.providers.deepseek;
  assert.ok(ds, "deepseek provider 缺失");
  assert.ok(ds.balance && typeof ds.balance.total === "number", "deepseek 余额数值缺失");
  assert.ok(ds.usage && typeof ds.usage.tokens_24h === "number", "deepseek 24h 用量缺失");
  assert.ok(ds.last_check, "last_check 缺失");
  assert.ok(Array.isArray(us.switches.history) && us.switches.history.length >= 1, "切换历史为空");
});

test("切换历史含熔断实测记录（trip + recover 事件）", () => {
  const d = JSON.parse(fs.readFileSync(SYNC_OUT, "utf8"));
  const types = new Set(d.usage_state.switches.history.map((h) => h.type));
  assert.ok(types.has("trip"), "切换历史应含 trip（熔断）事件");
  assert.ok(types.has("recover"), "切换历史应含 recover（恢复）事件");
  // trip 记录应带 provider/status/note 字段（快照断言不钉死具体 provider——
  // history 是滚动窗口，0825-b kimi 403 实测记录已被后续事件顶出）
  const trip = d.usage_state.switches.history.find((h) => h.type === "trip");
  assert.ok(trip && trip.provider, "trip 应记录 provider");
  assert.ok("status" in trip, "trip 应记录 status");
});

test("recent_events 合并：关键生命周期全量 + 噪音/request 限流（类型齐全 + 体积红线）", () => {
  const d = JSON.parse(fs.readFileSync(SYNC_OUT, "utf8"));
  assert.ok(Array.isArray(d.recent_events) && d.recent_events.length > 0);
  const reqs = d.recent_events.filter((e) => e.type === "request");
  assert.ok(reqs.length <= 200, `request 事件 ${reqs.length} 应 ≤200（合并限流）`);
  // 0827-fix P1-3: 噪音事件（probe_fail 等高频失败流）按类型截断 ≤200，防 51MB 死数据复燃
  const noisy = d.recent_events.filter((e) =>
    ["probe_fail", "upstream_error", "error", "model_trip", "model_recover"].includes(e.type));
  for (const t of ["probe_fail", "upstream_error", "error", "model_trip", "model_recover"]) {
    const n = d.recent_events.filter((e) => e.type === t).length;
    assert.ok(n <= 200, `噪音事件 ${t} ${n} 应 ≤200（按类型截断）`);
  }
  assert.ok(noisy.length > 0, "噪音事件应仍有保留（非清零）");
  // 体积红线：透明度文件须 <5MB（修复前 53MB，前端 60s 轮询不卡顿）
  assert.ok(fs.statSync(SYNC_OUT).size < 5 * 1024 * 1024, `llm-gateway.json ${fs.statSync(SYNC_OUT).size}B 应 <5MB`);
  // 与事件日志口径一致：全部非噪音生命周期类型都应出现在合并结果里
  const srcTypes = new Set(
    fs.readFileSync(EVENTS, "utf8")
      .split("\n").filter(Boolean)
      .map((l) => { try { return JSON.parse(l).type; } catch { return null; } })
      .filter(Boolean)
  );
  const mergedTypes = new Set(d.recent_events.map((e) => e.type));
  for (const t of srcTypes) {
    if (t === "request" || ["probe_fail", "upstream_error", "error", "model_trip", "model_recover"].includes(t)) continue;
    assert.ok(mergedTypes.has(t), `关键生命周期类型 ${t} 在合并结果中缺失`);
  }
});

test("上游 0825-b/c 文件未被动过（红线：只消费数据）", () => {
  // 断言源文件仍可解析且结构未变 —— 消费端改动不得波及上游产物
  const us = JSON.parse(fs.readFileSync(USAGE_STATE, "utf8"));
  assert.equal(us.schema, "llm-gateway-monitor/usage-state v1");
  assert.ok(us.providers.deepseek.balance.ok === true);
  const ev = fs.readFileSync(EVENTS, "utf8").split("\n").filter(Boolean);
  assert.ok(ev.length >= 100, "事件日志应持续累积");
  const last = JSON.parse(ev[ev.length - 1]);
  assert.ok(last.ts && last.seq, "事件行应有 ts/seq");
});
