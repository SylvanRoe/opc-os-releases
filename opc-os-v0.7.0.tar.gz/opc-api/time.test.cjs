// 时钟服务 /api/time（0825-f t_a8f864a5）— 权威时间载荷单测 (node --test time.test.cjs)
"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { timePayload, TZ, OFFSET_MIN } = require("./lib/time.cjs");

test("timePayload: tz 恒为 Asia/Shanghai, offset=480 分钟", () => {
  const p = timePayload();
  assert.strictEqual(p.tz, "Asia/Shanghai");
  assert.strictEqual(TZ, "Asia/Shanghai");
  assert.strictEqual(p.offset, 480);
  assert.strictEqual(OFFSET_MIN, 480);
});

test("timePayload: iso 为 ISO8601 且带 +08:00 偏移", () => {
  const p = timePayload();
  assert.match(p.iso, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?\+08:00$/);
});

test("timePayload: iso 墙钟时间 = UTC+8（真实北京时间）", () => {
  const now = new Date("2026-08-25T05:18:57.000Z"); // UTC
  const p = timePayload(now);
  // UTC 05:18:57 + 8h = 13:18:57 北京时间
  assert.match(p.iso, /^2026-08-25T13:18:57/);
});

test("timePayload: unix = 当前 epoch 秒（与 Date.now 偏差 <2s）", () => {
  const before = Math.floor(Date.now() / 1000);
  const p = timePayload();
  const after = Math.floor(Date.now() / 1000);
  assert.ok(p.unix >= before && p.unix <= after, `unix=${p.unix} 应在 [${before},${after}]`);
});

test("timePayload: iso 时间与系统 date 命令偏差 <2s", () => {
  // 用 UTC 秒换算回北京时间 ISO 做交叉核对
  const p = timePayload();
  const isoMs = Date.parse(p.iso);
  const drift = Math.abs(isoMs - Date.now());
  assert.ok(drift < 2000, `iso 与系统时钟偏差 ${drift}ms 应 <2000ms`);
});

test("timePayload: 显式固定时刻的 iso/unix 确定性", () => {
  const p = timePayload(new Date(1787635137000));
  assert.strictEqual(p.unix, 1787635137);
  assert.strictEqual(p.iso, new Date(1787635137000 + 480 * 60e3).toISOString().replace("Z", "+08:00"));
});
