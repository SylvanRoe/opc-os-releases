#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_bump_version.py — 发布工具单元测试（T3 交付：临时 git 仓全链模拟，生产仓零污染）

覆盖：
  1. bump --patch 全链：VERSION + CHANGELOG 顶条 + tag + 文档头标 三源自动同步
  2. check_version 三源一致 / 漂移检出（exit≠0 + 输出差异）
  3. 幂等：同一版本重复 bump → 拒绝（tag/条目不覆盖）
  4. 前置门生效：gate FAIL → bump 拒绝继续，零改动
  5. 三源漂移：bump 前置 check FAIL → 拒绝
  6. 0.x --major 拒绝（§1.3 MAJOR 位锁定为 0）
  7. dry-run 全链走通（不落盘不改 git）

运行：python3 scripts/test_bump_version.py     （独立运行）
       python3 -m unittest scripts.test_bump_version
"""

import datetime
import os
import re
import subprocess
import sys
import tempfile

try:
    import unittest
except ImportError:
    import unittest  # noqa

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import bump_version as bv  # noqa: E402
import check_version as cv  # noqa: E402

CHANGELOG_FIXTURE = """# Changelog

本仓版本制度（资产版本制度 v1.0，2026-08-23 落地）：版本号 = git tag `vX.Y.Z` + 本文件条目；**仓根 `VERSION` 文件为版本单一来源**。

> 历史 tag 处置：保留不删，标注 deprecated。（一次性治理记录，不参与版本判定。）

## [Unreleased]
### Feat（示例未发布变更）
- 未发布变更 A（待发布时确认是否随版）

## [v0.5.1] - 2026-08-27
### Fixed
- 修复 xxx（来源卡号：t_test）
### 影响面
- opc-os
### 兼容性说明
- 向后兼容；客户动作：无
"""

DOC_FIXTURE = {
    "docs/installation-guide.md": "# OPC-OS 安装文档\n\n> 版本：v0.5（客户形态，2026-08-27）\n\n正文。\n",
    "delivery-checklist.md": "# OPC OS 交付清单\n\n> 版本：v0.3.2（2026-08-27）\n\n正文。\n",
    "README.md": "# OPC OS\n\n> Applies to: v0.5 (customer form).\n\nbody.\n",
    "README_CN.md": "# OPC OS\n\n> 适用版本：v0.5（客户形态）。\n\n正文。\n",
}


def _git(repo, *args):
    p = subprocess.run(["git", "-C", repo] + list(args), capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {p.stderr}")
    return p.stdout.strip()


def make_repo(version="0.5.1", ok_gate=True):
    """建临时 git 仓：VERSION + CHANGELOG + 文档 + 假 gate 脚本，三源初始一致。"""
    tmp = tempfile.mkdtemp(prefix="opc-os-bump-test-")
    repo = os.path.join(tmp, "repo")
    os.makedirs(repo)
    subprocess.run(["git", "-C", repo, "init", "-q"])
    _git(repo, "config", "user.email", "test@test.local")
    _git(repo, "config", "user.name", "tester")

    with open(os.path.join(repo, "VERSION"), "w") as f:
        f.write(version + "\n")
    with open(os.path.join(repo, "CHANGELOG.md"), "w") as f:
        f.write(CHANGELOG_FIXTURE)
    for rel, content in DOC_FIXTURE.items():
        p = os.path.join(repo, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(content)

    ok = "exit 0" if ok_gate else "exit 1"
    gate_dir = os.path.join(repo, "scripts")
    os.makedirs(gate_dir, exist_ok=True)
    gate = os.path.join(gate_dir, "fake_gate.sh")
    with open(gate, "w") as f:
        f.write("#!/bin/bash\n%s\n" % ok)
    os.chmod(gate, 0o755)
    _git(repo, "add", "-A")
    _git(repo, "commit", "-q", "-m", "init fixture")
    _git(repo, "tag", "-a", f"v{version}", "-m", f"v{version}: init")
    return repo, gate


def _read(repo, rel):
    with open(os.path.join(repo, rel), encoding="utf-8") as f:
        return f.read()


class TestBumpVersion(unittest.TestCase):

    def test_patch_fullchain(self):
        """bump --patch 全链：三源 + 文档头标自动同步（本地 tag）。"""
        repo, gate = make_repo(version="0.5.1")
        rc = bv.main(["--patch", "-m", "修复发布工具", "--gate-cmd", f"bash {gate}", "--repo", repo])
        self.assertEqual(rc, 0, "bump 应成功")

        self.assertEqual(_read(repo, "VERSION").strip(), "0.5.2")
        cl = _read(repo, "CHANGELOG.md")
        today = datetime.date.today().isoformat()
        self.assertRegex(cl, re.escape(f"## [v0.5.2] - {today}"))
        # 顶条需位于 [Unreleased] 之后、[v0.5.1] 之前
        self.assertLess(cl.index("## [v0.5.2] - "), cl.index("## [v0.5.1] - "))
        self.assertLess(cl.index("## [Unreleased]"), cl.index("## [v0.5.2] - "))
        # 文档头标 = 代码版本
        self.assertIn("适用版本：v0.5.2", _read(repo, "docs/installation-guide.md"))
        self.assertIn("适用版本：v0.5.2", _read(repo, "delivery-checklist.md"))
        self.assertIn("Applies to: v0.5.2", _read(repo, "README.md"))
        self.assertIn("适用版本：v0.5.2", _read(repo, "README_CN.md"))
        # tag
        tags = _git(repo, "tag", "--list")
        self.assertIn("v0.5.2", tags)
        # commit 指向该 tag（annotated tag 需解引用 ^{commit}）
        self.assertEqual(_git(repo, "rev-parse", "v0.5.2^{commit}"), _git(repo, "rev-parse", "HEAD"))
        # 自检：三源一致
        r = cv.check_three_source(repo=repo)
        self.assertTrue(r["consistent"], f"三源应一致: {r}")

    def test_push_with_remote(self):
        """--push：本地 bare remote 验证 tag + 分支真实推送。"""
        repo, gate = make_repo(version="0.5.1")
        remote = os.path.join(os.path.dirname(repo), "remote.git")
        subprocess.run(["git", "init", "--bare", "-q", remote])
        _git(repo, "remote", "add", "origin", remote)
        rc = bv.main(["--patch", "-m", "push 测试", "--gate-cmd", f"bash {gate}", "--push", "--repo", repo])
        self.assertEqual(rc, 0, "--push 应成功")
        ls = subprocess.run(["git", "-C", remote, "tag", "--list"], capture_output=True, text=True).stdout
        self.assertIn("v0.5.2", ls, "远端应收到 tag v0.5.2")

    def test_check_version_drift(self):
        """check_version 漂移检出：改 VERSION → exit≠0 + 输出差异。"""
        repo, gate = make_repo(version="0.5.1")
        # 基线一致
        self.assertEqual(cv.check_three_source(repo=repo)["consistent"], True)
        # 人为制造漂移
        with open(os.path.join(repo, "VERSION"), "w") as f:
            f.write("9.9.9\n")
        rc = cv.main(["--repo", repo])
        self.assertNotEqual(rc, 0, "漂移应 exit≠0")
        self.assertNotEqual(cv.check_three_source(repo=repo)["consistent"], True)

    def test_bump_reject_when_drift(self):
        """三源漂移时 bump 拒绝（前置 check FAIL）。"""
        repo, gate = make_repo(version="0.5.1")
        with open(os.path.join(repo, "VERSION"), "w") as f:
            f.write("9.9.9\n")
        rc = bv.main(["--patch", "-m", "x", "--gate-cmd", f"bash {gate}", "--repo", repo])
        self.assertEqual(rc, 1, "漂移应拒绝 bump")
        self.assertEqual(_read(repo, "VERSION").strip(), "9.9.9", "VERSION 不应被改")

    def test_bump_idempotent(self):
        """幂等：目标版本 tag 已存在 → 拒绝，不覆盖 tag/条目（VERSION 回落到已发布版本场景）。"""
        repo, gate = make_repo(version="0.5.1")
        rc1 = bv.main(["--patch", "-m", "第一次", "--gate-cmd", f"bash {gate}", "--repo", repo])
        self.assertEqual(rc1, 0)
        # 模拟中断恢复前：CHANGELOG/tag 已是 v0.5.2，但 VERSION 文件被回退到 0.5.1
        with open(os.path.join(repo, "VERSION"), "w") as f:
            f.write("0.5.1\n")
        cl_before = _read(repo, "CHANGELOG.md")
        rc2 = bv.main(["--patch", "-m", "重复", "--gate-cmd", f"bash {gate}", "--repo", repo])
        self.assertEqual(rc2, 1, "重复同版本（tag 已存在）应拒绝")
        self.assertEqual(_read(repo, "CHANGELOG.md"), cl_before, "CHANGELOG 不应被改动")
        self.assertEqual(_read(repo, "VERSION").strip(), "0.5.1", "VERSION 不应被改")

    def test_gate_fail_blocks_bump(self):
        """前置门生效：gate FAIL → bump 拒绝继续，零改动。"""
        repo, gate = make_repo(version="0.5.1", ok_gate=False)
        cl_before = _read(repo, "CHANGELOG.md")
        rc = bv.main(["--patch", "-m", "x", "--gate-cmd", f"bash {gate}", "--repo", repo])
        self.assertEqual(rc, 1, "gate FAIL 应拒绝")
        self.assertEqual(_read(repo, "VERSION").strip(), "0.5.1", "VERSION 不应被改")
        self.assertEqual(_read(repo, "CHANGELOG.md"), cl_before)
        self.assertNotIn("v0.5.2", _git(repo, "tag", "--list"))

    def test_zero_x_major_rejected(self):
        """0.x 阶段 --major 拒绝（§1.3 MAJOR 位锁定为 0）。"""
        repo, gate = make_repo(version="0.5.1")
        rc = bv.main(["--major", "-m", "x", "--no-gates", "--repo", repo])
        self.assertEqual(rc, 1, "0.x --major 应拒绝")

    def test_dry_run_no_mutation(self):
        """dry-run 走通且不落盘不改 git。"""
        repo, gate = make_repo(version="0.5.1")
        cl_before = _read(repo, "CHANGELOG.md")
        rc = bv.main(["--patch", "-m", "dry", "--gate-cmd", f"bash {gate}", "--dry-run", "--repo", repo])
        self.assertEqual(rc, 0, "dry-run 应成功")
        self.assertEqual(_read(repo, "VERSION").strip(), "0.5.1")
        self.assertEqual(_read(repo, "CHANGELOG.md"), cl_before)
        self.assertNotIn("v0.5.2", _git(repo, "tag", "--list"))

    def test_doc_header_label_normalized(self):
        """文档头标统一为「适用版本：vX.Y.Z」（消除 v0.5/v0.3.2 独立文档版本）。"""
        repo, gate = make_repo(version="0.5.1")
        bv.main(["--patch", "-m", "doc", "--gate-cmd", f"bash {gate}", "--repo", repo])
        self.assertNotRegex(_read(repo, "docs/installation-guide.md"), r"^> 版本：v0\.5\b")
        self.assertNotRegex(_read(repo, "delivery-checklist.md"), r"^> 版本：v0\.3\.2\b")
        # 说明文字保留（头标只改标签+版本号，不丢后缀）
        self.assertIn("适用版本：v0.5.2（客户形态，2026-08-27）", _read(repo, "docs/installation-guide.md"))
        self.assertIn("适用版本：v0.5.2（2026-08-27）", _read(repo, "delivery-checklist.md"))
        self.assertIn("Applies to: v0.5.2 (customer form).", _read(repo, "README.md"))
        self.assertIn("适用版本：v0.5.2（客户形态）。", _read(repo, "README_CN.md"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
