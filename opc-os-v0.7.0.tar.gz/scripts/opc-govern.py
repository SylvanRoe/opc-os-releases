#!/usr/bin/env python3
"""OPC OS — 治理规则引擎守护进程 opc-govern（gov-3 / R1+R2，2026-08-23）

命题：客户不会有天使投资人盯着——流程必须自驱动。
增量轮询 kanban.db task_events（水位线）→ 发现规则触发事件 → 按规则写卡
（复用 create_task / complete_task / kanban_comment 等价 SQL，事件审计不绕过）→
原子写 state 文件（govern-state.json）。

规则：
  R1 验收 FAIL → 自动派修（触发：验收卡出现 blocked(needs_input)，block reason 含
     「验收不通/验收未通过/验收不合格/FAIL/未通过/fail」）：
     ① 建修复卡（assignee=make，无 parent，立即 ready 派发）
     ② 建复验卡（assignee=ada，parents=[修复卡]，修复 done 后自动放行）
     ③ 验收卡保持 blocked 留档；两卡 body 均写结构化标记 govern-review/govern-block-event/govern-role
     ④ 验收卡留评论（留痕）；幂等键=验收卡id+block事件id（同一 FAIL 批次只派一轮）
     gov-8（0825-retro-6）：修复/复验卡 body 自动含「初验卡 id + 原 FAIL 项清单」——
     _extract_fail_items 从失败卡（一轮=验收卡；二轮=复验卡）body+验收人评论提取
     （**P1-1 xxx** 严重度标题 / ❌✗FAIL 标记行），无命中回退 block reason 原文。
     复验时不用回翻历史（治「文档与脚本一致性」类返工）。
  R2 复验 done → 自动收口（触发：复验卡 done）：
     复验卡（body 带 govern-review 标记，或标题含「复验」+ body 引用验收卡 id）done 且
     其父（修复卡）done → 父验收卡（blocked + 【验收】标记 + 非 gavin）自动 done
     （收口）+ completed 事件留痕 + 评论。
  R4 高风险动作审批校验（触发：created 事件 + 定时全表扫描兜底；2026-08-23 吸收-2a）：
     判定卡是否高风险动作卡：title/body 含 govern-risk: high|critical 标记（正则排除文档
     引用形态：反引号包裹或 high|critical 枚举 → 不算），或 task_kind 属 gov/finance/legal
     类（gov-7 结构化字段，NULL/未标则仅文本判定）。高风险卡必须 assignee=gavin 且
     初始状态（created 事件 payload.status）== blocked（needs_input）才放行；不满足 →
     skip_log 留痕 + 卡评论告警（author=opc-govern），不拦截写路径。幂等：同卡已存在
     opc-govern R4 告警评论则不重复评论（评论次数恒=1）；skip_log 同 (task,stage,reason)
     环内去重。扫描范围：非 done/archived 卡（历史 done 卡不追溯告警，防首扫刷屏）。

与 opc-bus.py 同构：水位线（govern-state.json）/ 原子写（tmp + os.replace）/ 静默容错
（看门狗模式：单轮异常捕获记录，进程不退出，下轮重试）。轮询间隔默认 2s + 定时全表
扫描默认 15s 兜底（重启/漏事件/手工 SQL 写库恢复）。

⚠️ 设计偏差说明（相对 opc-flow-governance-design.md v1.0 的 R1「修复卡 parents=[验收卡]」）：
  内核 kanban 语义：create 带 parents 时若任一 parent 非 done → status=todo，
  recompute_ready 仅在 parent done/archived 后 promote，claim_task 亦强制拒绝
  parent 未 done 的卡 → 修复卡若挂「blocked 留档」的验收卡为父，将永远不被派发。
  实际生产模式（31d/i18n-d 事件链，庄子 07:03 手工建卡）即：修复卡无 parent（立即
  ready 派发）+ 复验卡 parents=[修复卡]（门控）。本实现沿用该拓扑；验收卡 ↔ 修复/
  复验卡关联通过卡 body 结构化标记（govern-review: t_xxx）传递，R2 据此收口，
  不依赖 task_links。架构不变，仅关联通道从 task_links 改为 body 标记。

配置（config.json 顶层 "govern" 段，参考 bus 段风格；环境变量 OPC_GOVERN_* 可覆盖）：
  govern.poll_seconds        事件轮询间隔秒（默认 2.0）
  govern.scan_seconds        定时全表扫描间隔秒（默认 15.0；0=禁用扫描）
  govern.kanban_db           正式 kanban.db（默认 paths.kanban_db）
  govern.state_file          状态/水位线文件（默认 <paths.opc_dir>/govern-state.json）
  govern.review_mark         验收卡附加约定标记（默认 "【验收】"）；gov-6 起验收卡判定
                             放宽为 title/body 含「验收」二字或 body 含 govern-review: 即命中，
                             review_mark 仅作附加自定义标记保留
  govern.rereview_mark       复验卡标题标记（默认 "复验"，仅 legacy 无标记卡回退用）
  govern.fail_keywords       block reason FAIL 关键词（默认 见 cfg；大小写不敏感；
                             gov-6 补「验收不通过/不通过」——32d reason 原文「验收不通过」曾漏判）

gov-6（2026-08-23，32d 止血）：除判定放宽外，R1 _r1_consider / R2 _r2_consider 的每个
  return 路径均写 skip_log（{ts, task_id, stage, reason}，环形保留最近 200 条，随
  save_state 落盘 govern-state.json），同 (task, stage, reason) 在环内去重防扫描刷屏；
  blocked + FAIL reason 但无验收标记的卡留痕「疑似验收卡未确认」不再无声消失。
gov-7b（2026-08-23，方案 A 治本）：R1/R2 验收卡判定从文本标记切换为结构化 task_kind
  字段（7a 内核新增列 + 建卡接口）——task_kind == 'review' 为强判定（不依赖 title/body
  措辞）；NULL/未标回退 gov-6 放宽版文本判定并留痕「未标类型，文本兜底判定」（漏标
  可见不静默）；非 review 字段（ops/fix/feature/gov/chore）直接跳过 + 留痕（字段优先
  于文本，title/body 含「验收」也不误伤）。R1 建卡写 task_kind：修复卡='fix'、复验卡
  ='review'。_fail_reason_match 关键词机制保留为 FAIL 辅助判定（字段解决「是不是验收
  卡」，关键词解决「是不是 FAIL」，后者本质是验收人措辞，未来可升级为 block 结构化
  payload）。存量卡（task_kind=NULL）由 7c 迁移脚本补标，迁移前走文本兜底 + 留痕。
gov-7c（2026-08-24，内核解耦 a1）：task_kind 判定外移 OPC sidecar——官方 main 无
  task_kind 列（7a 为 fork 定制，切官方 main 后丢失）。判定统一读 govern-state.json
  `task_kinds{}`（task_id→kind）：sidecar 优先 → DB 列兜底（官方库无列时自动跳过，
  容错）→ NULL 回退文本判定。R1 内部建卡（create_task）自动登记 sidecar；外部建卡
  由 OPC 建卡包装层调用 `--register-kind` 登记。DB 列写入/读取全部做列存在性探测
  （_task_columns），官方内核建的库（无 task_kind 列）下本进程不报错。
R6（2026-08-24，内核解耦 a1）：sticky blocked 事件补偿——官方 main 实测
  create(initial_status='blocked') 只写 created 事件、不写 blocked 事件 →
  _has_sticky_block 判非 sticky → recompute_ready 把无父卡/父卡 done 的卡自动
  promote 到 ready（31g 官方未防，fork 6680b5f47 修复外移）。补偿：发现 created
  payload.status='blocked' 但无 blocked/unblocked 事件的卡 → 补写 blocked 事件
  （payload source=initial_status_blocked，与 fork 同语义）→ sticky 生效不再 promote；
  已被误 promote 的卡（ready/running）→ 还原 blocked。事件写 task_events 属数据操作
  （非 schema 裸写），与 create_task/complete_task 等价 SQL 风格一致。
R5（2026-08-24，内核解耦 a1）：gavin triage 守卫——gavin 卡可能被 block_loop_detected
  推入 triage；官方 decompose_task 无 gavin skip（fork 245bf4b51 规则外移）→ OPC 侧
  防线：opc-decompose.py wrapper 调用前过滤 + 本守卫扫描留痕（自动跳过语义）+ 快照
  对比检测已改写（title/body 与上次扫描不同 → 告警评论，幂等一次）。规则进 opc-team
  skill（OPC 内 decompose 一律走 wrapper）。
  govern.r1_enabled          R1 开关（默认 true；false=仅留痕不写卡，D2 拍板全自动，开关保留）
  govern.r2_enabled          R2 开关（默认 true；false=不自动收口，D1 拍板自动，开关保留）
  govern.r6_enabled          R6 sticky 补偿开关（默认 true）
  govern.fix_assignee        R1 修复卡 assignee（默认 "make"）
  govern.rereview_assignee   R1 复验卡 assignee（默认 "ada"）
  govern.blocked_kinds       参与 R1 的 block kind（默认 ["needs_input", ""]，""=legacy 无类型）
  govern.author              评论/事件作者名（默认 "opc-govern"）

红线：不改 kanban.db schema / 不加触发器 / 不拦截写路径；规则只做「新建卡 + 状态迁移
（done）」两类动作；复用现有工具等价 SQL（create_task / complete_task / kanban_comment），
禁止绕过事件审计（每次写卡必写 task_events）；G 卡（assignee=gavin）不受影响；
普通 blocked(needs_input) 卡不自动收口/派修；告警通道由 gov-4（opc-govern R3，anran）
持有，本进程只做事件留痕 + 卡评论，不重复实现 telegram。
"""
import json
import os
import re
import secrets
import sqlite3
import sys
import time
import datetime
import contextlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from lib_config import get_cfg  # noqa: E402  与 opc-collect / opc-bus 共享同一份 config.json
except Exception:
    get_cfg = None  # lib_config 缺失（裸拷脚本场景）→ 走下方内建默认


def _cfg_defaults():
    """内建默认（lib_config 不可用时兜底；与 lib_config DEFAULT.govern 同值）。"""
    return {
        'poll_seconds': 2.0,
        'scan_seconds': 15.0,
        'kanban_db': os.path.expanduser('~/.hermes/kanban/boards/opc/kanban.db'),
        'state_file': os.path.expanduser('~/.hermes/opc/govern-state.json'),
        'review_mark': '【验收】',
        'rereview_mark': '复验',
        'fail_keywords': ['验收不通', '验收未通过', '验收不合格', 'FAIL', '未通过', 'fail',
                          '验收不通过', '不通过'],  # gov-6：补「不通过」系列（32d reason 原文「验收不通过」）
        'r1_enabled': True,
        'r2_enabled': True,
        'r4_enabled': True,   # R4 高风险动作审批校验开关（默认 true；false=仅跳过不校验）
        'r6_enabled': True,   # R6 sticky 补偿开关（默认 true）
        'fix_assignee': 'make',
        'rereview_assignee': 'ada',
        'blocked_kinds': ['needs_input', ''],
        'author': 'opc-govern',
    }


def load_cfg():
    """config.json govern 段 → 扁平 dict（lib_config 优先，环境变量 OPC_GOVERN_* 覆盖）。"""
    cfg = {}
    try:
        if get_cfg is not None:
            merged = get_cfg()
            g = merged.get('govern') or {}
            if isinstance(g, dict):
                cfg.update(g)
    except Exception:
        pass
    base = _cfg_defaults()
    for k, v in cfg.items():
        base[k] = v
    # 环境变量覆盖（测试/容器注入）
    env_map = {
        'OPC_GOVERN_POLL_SECONDS': 'poll_seconds',
        'OPC_GOVERN_SCAN_SECONDS': 'scan_seconds',
        'OPC_GOVERN_KANBAN_DB': 'kanban_db',
        'OPC_GOVERN_STATE_FILE': 'state_file',
        'OPC_GOVERN_R1_ENABLED': 'r1_enabled',
        'OPC_GOVERN_R2_ENABLED': 'r2_enabled',
        'OPC_GOVERN_R4_ENABLED': 'r4_enabled',
        'OPC_GOVERN_R6_ENABLED': 'r6_enabled',
        'OPC_GOVERN_FIX_ASSIGNEE': 'fix_assignee',
        'OPC_GOVERN_REREVIEW_ASSIGNEE': 'rereview_assignee',
        'OPC_GOVERN_AUTHOR': 'author',
    }
    for env, key in env_map.items():
        v = os.environ.get(env)
        if v is None:
            continue
        if key in ('r1_enabled', 'r2_enabled', 'r4_enabled', 'r6_enabled'):
            base[key] = str(v).strip().lower() in ('1', 'true', 'yes', 'on')
        elif key in ('poll_seconds', 'scan_seconds'):
            try:
                base[key] = float(v)
            except ValueError:
                pass
        else:
            base[key] = v.strip()
    # 空串回退内建默认：宿主无 config.json 时 lib_config DEFAULT.govern 以空串占位
    # （注释语义「空 → paths.kanban_db / <paths.opc_dir>/govern-state.json」），
    # 解析成内建默认，否则 db='' 首启校准抛异常 → pm2 无限重启（08-23 实踩）。
    for key in ('kanban_db', 'state_file'):
        if not base.get(key):
            base[key] = _cfg_defaults()[key]
    return base


CFG = load_cfg()
KANBAN_DB = CFG['kanban_db']
STATE_FILE = CFG['state_file']
POLL_SECONDS = max(0.5, float(CFG['poll_seconds']))
SCAN_SECONDS = max(0.0, float(CFG['scan_seconds']))
REVIEW_MARK = CFG['review_mark']
REREVIEW_MARK = CFG['rereview_mark']
FAIL_KEYWORDS = [str(k) for k in CFG['fail_keywords'] if k]
R1_ENABLED = bool(CFG['r1_enabled'])
R2_ENABLED = bool(CFG['r2_enabled'])
R4_ENABLED = bool(CFG.get('r4_enabled', True))
R6_ENABLED = bool(CFG.get('r6_enabled', True))
FIX_ASSIGNEE = CFG['fix_assignee']
REREVIEW_ASSIGNEE = CFG['rereview_assignee']
BLOCKED_KINDS = [str(k) for k in CFG['blocked_kinds']]
AUTHOR = CFG['author']

GOVERN_REVIEW_RE = re.compile(r'govern-review:\s*(t_[0-9a-f]{8})')
GOVERN_BLOCK_EVENT_RE = re.compile(r'govern-block-event:\s*(\d+)')
# R4 高风险标记：govern-risk: high|critical。真实标记形态=独立成行/行首/前有空白
# （如 body 单独一行「govern-risk: high」或「govern-risk: high，需审批」）；文档引用
# 形态（反引号包裹「`govern-risk: high`」、枚举「high|critical」、括号内嵌「（govern-risk: high）」）
# 前后被紧贴 → 排除，防实施卡/验收卡 body 自我误伤。
GOVERN_RISK_RE = re.compile(
    r'(?<!\S)govern-risk:\s*(high|critical)(?![\w|`（）()])', re.IGNORECASE)
RISK_TASK_KINDS = ('gov', 'finance', 'legal')  # R4 字段判定：task_kind 属 gov/finance/legal 类
RISK_MARK_LEVELS = {'high': 'high', 'critical': 'critical'}
# legacy（庄子手工建卡）body 中的验收卡引用：验收卡 t_xxx / 验收（t_xxx）/(t_xxx)
LEGACY_REVIEW_RE = re.compile(
    r'验收卡\s*(?:[（(]\s*)?(t_[0-9a-f]{8})'
    r'|验收（(t_[0-9a-f]{8})）'
)


def log(msg):
    print('[%s] %s' % (datetime.datetime.now().strftime('%H:%M:%S'), msg), flush=True)


def _err_once(last_ts, key, msg):
    """错误日志限流：同 key 60s 内只记首次，避免刷屏。"""
    now = time.time()
    if now - last_ts.get(key, 0.0) >= 60:
        last_ts[key] = now
        log(msg)


_err_ts = {}


# ─────────────────────────── 状态持久化（水位线 + 已处理记录） ───────────────────────────

def load_state():
    """读状态文件；缺失/损坏 → 空 dict（触发首启校准，不重放历史）。"""
    try:
        with open(STATE_FILE, encoding='utf-8') as fh:
            s = json.load(fh)
        return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def save_state(state):
    """原子落盘（tmp + os.replace）：重启后从该处续读，水位线不重放。"""
    tmp = STATE_FILE + '.govern-tmp'
    d = os.path.dirname(STATE_FILE)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(state, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, STATE_FILE)


# ─────────────────────────── SQL 工具（等价 kanban_create / complete / comment） ───────────────────────────

def _append_event(con, task_id, kind, payload=None, run_id=None):
    """等价 kanban_db._append_event：事件审计不绕过。"""
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (task_id, run_id, kind,
         json.dumps(payload, ensure_ascii=False) if payload else None,
         int(time.time())),
    )


def _new_task_id(con):
    """等价 kanban_db._new_task_id：4 hex 字节，撞库重试。"""
    for _ in range(3):
        tid = 't_' + secrets.token_hex(4)
        if con.execute('SELECT 1 FROM tasks WHERE id = ?', (tid,)).fetchone() is None:
            return tid
    raise RuntimeError('task id collision')


def create_task(con, *, title, body, assignee, status, parents=(), idempotency_key=None,
                task_kind=None, state=None):
    """等价 kanban_db.create_task 的写路径（INSERT tasks + task_links + created 事件）。

    幂等：idempotency_key 命中非 archived 卡 → 返回既有 id，不重复建卡（同 FAIL 批次只派一轮）。
    task_kind（gov-7b/7c）：结构化卡类型（review/fix/feature/ops/gov/chore）。gov-7c 起：
    DB 列写入动态（_task_columns 探测，官方库无 task_kind 列则跳过列写入，仅透传
    created 事件 payload）+ 登记 govern-state.json task_kinds{} sidecar（state 传入时）。
    必须在调用方已开启的写事务内执行。
    """
    if idempotency_key:
        row = con.execute(
            "SELECT id FROM tasks WHERE idempotency_key = ? AND status != 'archived' "
            "ORDER BY created_at DESC LIMIT 1", (idempotency_key,)).fetchone()
        if row:
            return row['id']
    task_id = _new_task_id(con)
    now = int(time.time())
    has_tk_col = 'task_kind' in _task_columns()
    if has_tk_col:
        con.execute(
            "INSERT INTO tasks (id, title, body, assignee, status, priority, created_by, "
            "created_at, workspace_kind, workspace_path, branch_name, project_id, tenant, "
            "idempotency_key, max_runtime_seconds, skills, max_retries, model_override, "
            "provider_override, reasoning_effort, goal_mode, goal_max_turns, session_id, "
            "task_kind) "
            "VALUES (?, ?, ?, ?, ?, 0, ?, ?, 'scratch', NULL, NULL, NULL, NULL, ?, NULL, "
            "NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, ?)",
            (task_id, title.strip(), body, assignee, status, AUTHOR, now, idempotency_key,
             task_kind),
        )
    else:
        # 官方内核库（无 task_kind 列）：不写列，sidecar 登记
        con.execute(
            "INSERT INTO tasks (id, title, body, assignee, status, priority, created_by, "
            "created_at, workspace_kind, workspace_path, branch_name, project_id, tenant, "
            "idempotency_key, max_runtime_seconds, skills, max_retries, model_override, "
            "provider_override, reasoning_effort, goal_mode, goal_max_turns, session_id) "
            "VALUES (?, ?, ?, ?, ?, 0, ?, ?, 'scratch', NULL, NULL, NULL, NULL, ?, NULL, "
            "NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL)",
            (task_id, title.strip(), body, assignee, status, AUTHOR, now, idempotency_key),
        )
    for pid in parents:
        con.execute(
            "INSERT OR IGNORE INTO task_links (parent_id, child_id) VALUES (?, ?)",
            (pid, task_id))
    _append_event(con, task_id, 'created', {
        'assignee': assignee,
        'status': status,
        'parents': list(parents),
        'tenant': None,
        'workspace_kind': 'scratch',
        'workspace_path': None,
        'branch_name': None,
        'project_id': None,
        'skills': None,
        'goal_mode': None,
        'model_override': None,
        'provider_override': None,
        'task_kind': task_kind,
    })
    if state is not None:
        register_task_kind(state, task_id, task_kind)
    return task_id


def complete_task(con, task_id, *, summary, metadata=None):
    """等价 kanban_db.complete_task（blocked → done 路径）：状态迁移 + run 收尾 + completed 事件。

    幂等：WHERE status IN (...) + rowcount 判定；已 done 的卡 rowcount=0 → 返回 False。
    必须在调用方已开启的写事务内执行。
    """
    now = int(time.time())
    cur = con.execute(
        "UPDATE tasks SET status='done', result=?, completed_at=?, claim_lock=NULL, "
        "claim_expires=NULL, worker_pid=NULL, block_kind=NULL, block_recurrences=0 "
        "WHERE id=? AND status IN ('running', 'ready', 'blocked', 'review')",
        (summary, now, task_id))
    if cur.rowcount != 1:
        return False
    md_json = json.dumps(metadata, ensure_ascii=False) if metadata else None
    row = con.execute("SELECT current_run_id FROM tasks WHERE id = ?", (task_id,)).fetchone()
    run_id = None
    if row and row['current_run_id']:
        run_id = int(row['current_run_id'])
        con.execute(
            "UPDATE task_runs SET status='done', outcome='completed', summary=?, error=NULL, "
            "metadata=?, ended_at=?, claim_lock=NULL, claim_expires=NULL, worker_pid=NULL "
            "WHERE id=? AND ended_at IS NULL",
            (summary, md_json, now, run_id))
        con.execute("UPDATE tasks SET current_run_id = NULL WHERE id = ?", (task_id,))
    else:
        trow = con.execute(
            "SELECT assignee, current_step_key FROM tasks WHERE id = ?", (task_id,)).fetchone()
        profile = trow['assignee'] if trow else None
        step_key = trow['current_step_key'] if trow else None
        cur2 = con.execute(
            "INSERT INTO task_runs (task_id, profile, step_key, status, outcome, summary, "
            "error, metadata, started_at, ended_at) VALUES (?, ?, ?, 'completed', 'completed', "
            "?, NULL, ?, ?, ?)",
            (task_id, profile, step_key, summary, md_json, now, now))
        run_id = int(cur2.lastrowid or 0)
    ev_lines = (summary or '').strip().splitlines()
    ev_summary = ev_lines[0][:400] if ev_lines else ''
    _append_event(con, task_id, 'completed',
                  {'result_len': 0, 'summary': ev_summary or None}, run_id=run_id)
    return True


def add_comment(con, task_id, body):
    """等价 kanban_comment：task_comments 行 + commented 事件。"""
    now = int(time.time())
    con.execute(
        "INSERT INTO task_comments (task_id, author, body, created_at) VALUES (?, ?, ?, ?)",
        (task_id, AUTHOR, body, now))
    _append_event(con, task_id, 'commented', {'author': AUTHOR, 'len': len(body)})


# ─────────────────────────── 只读查询 ───────────────────────────

def _get_task(con, task_id):
    # 注意：不 SELECT task_kind（gov-7c 外移后判定统一走 sidecar；官方库无此列）
    row = con.execute(
        "SELECT id, title, body, assignee, status, block_kind, completed_at "
        "FROM tasks WHERE id = ?",
        (task_id,)).fetchone()
    return row


def _latest_block_event(con, task_id):
    """任务最近的 blocked 事件（含 payload）；无 → None。"""
    row = con.execute(
        "SELECT id, payload FROM task_events WHERE task_id = ? AND kind = 'blocked' "
        "ORDER BY id DESC LIMIT 1", (task_id,)).fetchone()
    if not row:
        return None
    payload = {}
    try:
        p = json.loads(row['payload']) if row['payload'] else {}
        if isinstance(p, dict):
            payload = p
    except (json.JSONDecodeError, TypeError):
        payload = {}
    return {'id': row['id'], 'payload': payload}


def _parents_of(con, task_id):
    """task_links 直接父卡 id 列表 + 每父状态。"""
    rows = con.execute(
        "SELECT l.parent_id, t.status FROM task_links l "
        "LEFT JOIN tasks t ON t.id = l.parent_id WHERE l.child_id = ?",
        (task_id,)).fetchall()
    return [{'id': r['parent_id'], 'status': r['status']} for r in rows]


def _children_of(con, task_id):
    rows = con.execute(
        "SELECT child_id FROM task_links WHERE parent_id = ?", (task_id,)).fetchall()
    return [r['child_id'] for r in rows]


def _review_id_of(con, task_id, title, body):
    """从卡 body 提取关联验收卡 id：结构化标记优先，legacy 标题「复验」+ body 引用回退。"""
    m = GOVERN_REVIEW_RE.search(body or '')
    if m:
        return m.group(1)
    if REREVIEW_MARK and REREVIEW_MARK in (title or ''):
        for m in LEGACY_REVIEW_RE.finditer(body or ''):
            rid = next(g for g in m.groups() if g)
            if rid:
                return rid
    return None


def _fail_reason_match(reason):
    """block reason 是否命中 FAIL 关键词（大小写不敏感）。"""
    if not reason:
        return False
    low = reason.lower()
    return any(k.lower() in low for k in FAIL_KEYWORDS)


def _is_review_card(title, body):
    """验收卡判定（gov-6 放宽版）：title/body 含「验收」二字，或 body 含 govern-review: 结构化
    标记，或命中配置 review_mark（默认【验收】，已被「验收」二字覆盖，保留兼容自定义标记）。
    替代原【验收】精确匹配（32d 止血：title 无【验收】的验收卡曾被静默漏判）。"""
    t = title or ''
    b = body or ''
    if '验收' in t or '验收' in b:
        return True
    if 'govern-review:' in b:
        return True
    if REVIEW_MARK and (REVIEW_MARK in t or REVIEW_MARK in b):
        return True
    return False


SKIP_LOG_MAX = 200  # skip_log 环形裁剪上限（保留最近 200 条）


def _skip(state, task_id, stage, reason):
    """跳过留痕（gov-6）：R1/R2/R4 每个 return 路径记录 {ts, task_id, stage, reason}，
    随 save_state 落盘 govern-state.json skip_log[]。同 (task_id, stage, reason) 在当前
    环内已存在 → 不重复追加（防 15s 全表扫描把同一结论刷屏）。
    返回 True=本次新增留痕；False=环内已存在同因（去重命中）。"""
    entries = state.setdefault('skip_log', [])
    for e in reversed(entries):
        if e.get('task_id') == task_id and e.get('stage') == stage and e.get('reason') == reason:
            return False
    entries.append({'ts': int(time.time()), 'task_id': task_id,
                    'stage': stage, 'reason': reason})
    if len(entries) > SKIP_LOG_MAX:
        del entries[:-SKIP_LOG_MAX]
    return True


# ─────────────────────────── task_kind sidecar（gov-7c 外移） ───────────────────────────

_TASK_COLS = None  # tasks 表列集合缓存（探测一次；官方库无 task_kind 列时自动降级）
_TK_CACHE = None   # task_kind 合并映射缓存（模块级，不落盘；register/迁移/每轮扫描失效）


def _invalidate_tk_cache():
    global _TK_CACHE
    _TK_CACHE = None


def _task_columns():
    """tasks 表列名集合（PRAGMA 探测缓存）。官方内核建的库无 task_kind 列 → 不含该列。"""
    global _TASK_COLS
    if _TASK_COLS is None:
        try:
            con = _readonly_con(KANBAN_DB)
            try:
                _TASK_COLS = {r['name'] for r in con.execute('PRAGMA table_info(tasks)')}
            finally:
                con.close()
        except Exception:
            _TASK_COLS = set()
    return _TASK_COLS


def _task_kind_map(state):
    """task_id → kind 合并映射：sidecar（govern-state.json task_kinds{}）优先，
    DB task_kind 列兜底（列存在才读；官方库无列 → 跳过）。结果缓存模块级
    _TK_CACHE（不落盘），register/迁移/每轮扫描前失效。"""
    global _TK_CACHE
    if _TK_CACHE is not None:
        return _TK_CACHE
    m = {}
    for tid, tk in (state.get('task_kinds') or {}).items():
        if tk:
            m[str(tid)] = str(tk).strip().lower()
    try:
        if 'task_kind' in _task_columns():
            con = _readonly_con(KANBAN_DB)
            try:
                for r in con.execute(
                        "SELECT id, task_kind FROM tasks "
                        "WHERE task_kind IS NOT NULL AND task_kind != ''"):
                    if r['task_kind'] and str(r['id']) not in m:
                        m[str(r['id'])] = str(r['task_kind']).strip().lower()
            finally:
                con.close()
    except Exception:
        pass
    _TK_CACHE = m
    return m


def _task_kind_of(state, task_id):
    """单卡 task_kind（sidecar 优先 → DB 列兜底 → None）。判定点统一入口。"""
    tk = _task_kind_map(state).get(str(task_id))
    return str(tk).strip().lower() if tk else None


def register_task_kind(state, task_id, kind):
    """登记 task_kind 到 sidecar（R1 建卡自动调用 + 外部建卡包装层 --register-kind）。"""
    if not kind:
        return
    state.setdefault('task_kinds', {})[str(task_id)] = str(kind).strip().lower()
    _invalidate_tk_cache()


def _migrate_task_kinds_from_db(state):
    """存量迁移：DB task_kind 列 → sidecar（一次性；列存在才读）。返回登记条数。"""
    m = state.setdefault('task_kinds', {})
    before = len(m)
    try:
        if 'task_kind' in _task_columns():
            con = _readonly_con(KANBAN_DB)
            try:
                for r in con.execute(
                        "SELECT id, task_kind FROM tasks "
                        "WHERE task_kind IS NOT NULL AND task_kind != ''"):
                    if r['task_kind'] and str(r['id']) not in m:
                        m[str(r['id'])] = str(r['task_kind']).strip().lower()
            finally:
                con.close()
    except Exception:
        pass
    _invalidate_tk_cache()
    return len(m) - before


# ─────────────────────────── R1：验收 FAIL → 自动派修 ───────────────────────────

# 原 FAIL 项清单提取（0825-retro-6，复盘改进项 6/11）：蔡婉验收报告格式为
# **P1-1 标题** / **P2-x 标题** 严重度标题行（或 ❌/✗/FAIL/不通过 标记行）；
# 无命中回退 block reason 原文。复验卡/修复卡 body 固化清单后，复验时不用回翻历史。
FAIL_ITEM_TITLE_RE = re.compile(r'^\*{2}\s*(P\d+[-\.]\d+\s*.*?)\*{2}\s*$')
FAIL_ITEM_MARKERS = ('❌', '✗', '×', 'FAIL', '不通过', '未通过', '打回')


def _extract_fail_items(con, failed_tid, reason, max_items=15):
    """从 FAIL 卡（body + 验收人评论）提取原 FAIL 项清单；block reason 恒追加兜底。

    0825-retro-6：修复/复验卡 body 固化「初验卡 id + 原 FAIL 项清单」。
    来源优先级：①验收人评论中的严重度标题行（**P1-1 xxx**）与 FAIL 标记加粗行；
    ②body「原 FAIL 项清单」段内条目（二轮起该段=上一轮清单，段外 FAIL 字样噪声大
    不采——红线/规则句也含 FAIL）；③当前轮 block reason 原文恒追加（权威 FAIL 陈述，
    去重：首 30 字已被条目覆盖则跳过）。failed_tid = 本次实际 FAIL 的卡
    （一轮=验收卡；二轮=复验卡，其评论/body 含最新报告）。
    """
    items = []
    try:
        for row in con.execute(
                "SELECT author, body FROM task_comments WHERE task_id = ? ORDER BY id",
                (failed_tid,)):
            if row['author'] == AUTHOR:
                continue  # opc-govern 自身 R1/R2 留痕评论不算验收报告
            for raw in (row['body'] or '').splitlines():
                line = raw.strip()
                if not line:
                    continue
                m = FAIL_ITEM_TITLE_RE.match(line)
                if m:
                    items.append(m.group(1).strip())
                elif line.startswith('**') and line.endswith('**') and \
                        any(mk in line for mk in FAIL_ITEM_MARKERS):
                    items.append(line.strip('*').strip())
    except Exception:
        pass
    try:
        row = con.execute("SELECT body FROM tasks WHERE id = ?", (failed_tid,)).fetchone()
        in_section = False
        for raw in ((row['body'] or '') if row else '').splitlines():
            line = raw.strip()
            if line.startswith('## '):
                in_section = 'FAIL 项清单' in line
                continue
            if not in_section or not line or line.startswith('|'):
                continue
            items.append(line.lstrip('-*# ').strip())
    except Exception:
        pass
    # 去重（保留首次出现）+ 截断
    seen, out = set(), []
    for it in items:
        key = it[:60]
        if key not in seen:
            seen.add(key)
            out.append(it)
        if len(out) >= max_items:
            break
    # 当前轮 block reason 原文恒追加（当前 FAIL 权威陈述；同义覆盖则不重复）
    reason_t = (reason or '').strip()
    if reason_t:
        covered = any(reason_t[:30] in it or it[:30] in reason_t for it in out)
        if not covered and len(out) < max_items:
            out.append(reason_t)
    if not out:
        out.append('（无 FAIL 摘要）')
    return out


def _build_fix_body(review, reason, block_ev_id, rereview_id, con=None, failed_tid=None):
    fail_items = _extract_fail_items(con, failed_tid or review['id'], reason)
    items_txt = '\n'.join(f'- {it}' for it in fail_items)
    return (
        '## 【opc-govern R1 · 自动派修】验收 FAIL → 修复卡\n'
        f'- 初验卡：{review["id"]}（{review["title"]}）\n'
        f'- 验收人 block reason：{reason}\n'
        f'- 完整验收报告：见初验卡 {review["id"]} 评论与 body 验收清单（验收人留档）\n'
        f'- 复验卡：{rereview_id}（assignee={REREVIEW_ASSIGNEE}，父=本卡，本卡 done 后自动放行）\n'
        '- 初验卡保持 blocked 留档；复验通过后由 opc-govern R2 自动收口\n\n'
        f'govern-review: {review["id"]}\n'
        f'govern-block-event: {block_ev_id}\n'
        'govern-role: fix\n\n'
        '## 原 FAIL 项清单（修复+复验依据，逐条覆盖）\n'
        f'{items_txt}\n\n'
        '## 修复要求\n'
        f'1. 对照初验卡 {review["id"]} body 验收清单与评论，逐条修复上方 FAIL 项\n'
        '2. 全量回归：修复不得引入新缺陷（验收清单非 FAIL 项仍须达标）\n'
        '3. 修完无需通知：复验卡已自动放行（本卡 done → 复验卡 promote 派发）\n'
    )


def _build_rereview_body(review, reason, block_ev_id, fix_id, con=None, failed_tid=None):
    fail_items = _extract_fail_items(con, failed_tid or review['id'], reason)
    items_txt = '\n'.join(f'- {it}' for it in fail_items)
    return (
        '## 【opc-govern R1 · 自动派修】复验卡（聚焦 FAIL 项 + 回归）\n'
        f'- 初验卡：{review["id"]}（{review["title"]}，blocked 留档）\n'
        f'- 修复卡：{fix_id}（父卡，done 后本卡自动放行）\n'
        '- 首轮验收结论：见初验卡评论（验收人留档）\n\n'
        f'govern-review: {review["id"]}\n'
        f'govern-block-event: {block_ev_id}\n'
        'govern-role: rereview\n\n'
        '## 原 FAIL 项清单（逐条复验，不用回翻历史）\n'
        f'{items_txt}\n\n'
        '## 复验要点\n'
        f'1. 缺陷复验：上方 FAIL 项逐条复验（对应初验卡 {review["id"]} 验收清单）\n'
        '2. 回归：初验卡清单其余项全量回归，不得出现新 FAIL\n\n'
        '## 红线\n'
        '- 只读验收不改代码；发现问题 kanban_block(needs_input, reason 含 FAIL + 修复指引)（将再次触发自动派修）\n'
        '- 全部达标 → kanban_complete（触发 R2 自动收口父验收卡）\n'
    )


def _r1_fire(state, review, block_ev, failed_tid=None):
    """对一张 FAIL 验收卡执行自动派修（create 修复卡 + 复验卡 + 评论 + 记录）。原子事务。

    0825-retro-6：修复/复验卡 body 自动含「初验卡 id + 原 FAIL 项清单」
    （_extract_fail_items 从失败卡 body+验收人评论提取，无命中回退 block reason）。
    failed_tid = 本次实际 FAIL 的卡（一轮=验收卡；二轮=复验卡）。
    """
    review_id = review['id']
    block_ev_id = block_ev['id']
    reason = (block_ev.get('payload') or {}).get('reason') or ''
    # 幂等键 = 验收卡id + FAIL 批次（block 事件 id）；同批次重复触发返回既有卡
    key_fix = f'govern-r1-fix:{review_id}:{block_ev_id}'
    key_rereview = f'govern-r1-rereview:{review_id}:{block_ev_id}'

    con = _write_con()
    try:
        with write_txn(con):
            fix_id = create_task(
                con, title=f'【govern-fix】{review["title"]} 修复（验收 FAIL 自动派修）',
                body=_build_fix_body(review, reason, block_ev_id, '',
                                     con=con, failed_tid=failed_tid),
                assignee=FIX_ASSIGNEE, status='ready', idempotency_key=key_fix,
                task_kind='fix', state=state)
            rereview_id = create_task(
                con, title=f'【govern-复验】{review["title"]} 复验（自动复验）',
                body=_build_rereview_body(review, reason, block_ev_id, fix_id,
                                          con=con, failed_tid=failed_tid),
                assignee=REREVIEW_ASSIGNEE, status='todo', parents=[fix_id],
                idempotency_key=key_rereview, task_kind='review', state=state)
            # 幂等命中时 fix body 里 rereview_id 为空占位 → 补写正确 id（仅当为空）
            frow = con.execute(
                "SELECT body FROM tasks WHERE id = ?", (fix_id,)).fetchone()
            if frow and frow['body'] and '- 复验卡：（assignee=' in frow['body']:
                new_body = frow['body'].replace(
                    '- 复验卡：（assignee=', f'- 复验卡：{rereview_id}（assignee=')
                con.execute("UPDATE tasks SET body = ? WHERE id = ?", (new_body, fix_id))
            add_comment(
                con, review_id,
                f'【opc-govern R1】验收 FAIL 自动派修完成：\n'
                f'- 修复卡 {fix_id}（{FIX_ASSIGNEE}）已就绪\n'
                f'- 复验卡 {rereview_id}（{REREVIEW_ASSIGNEE}，修复 done 后自动放行）\n'
                '- 本卡保持 blocked 留档，复验通过后 opc-govern R2 自动收口')
            state['processed_blocks'].add(str(block_ev_id))
            state['chains'][review_id] = {
                'fix': fix_id, 'rereview': rereview_id,
                'block_event_id': str(block_ev_id),
                'first_fail_at': block_ev.get('created_at') or int(time.time()),
                'rounds': int(state['chains'].get(review_id, {}).get('rounds', 0)) + 1,
            }
    finally:
        con.close()
    return fix_id, rereview_id


def _r1_consider(con, state, task):
    """对单张卡执行 R1 判定 + 派修。task 为只读行（id/title/body/assignee/status[/task_kind]）。

    gov-6：每个 return 路径 _skip 留痕；验收标记判定放宽（_is_review_card）；
    疑似验收卡兜底（blocked + FAIL reason 但无验收标记 → 留痕不派修）。
    gov-7b：验收卡判定切换为结构化 task_kind 字段——task_kind == 'review' 为强判定
    （不依赖 title/body 措辞）；NULL/未标回退文本判定（放宽版）并留痕「未标类型，
    文本兜底判定」（漏标可见不静默）；非 review 字段直接跳过 + 留痕（字段优先于文本，
    即使 title/body 含「验收」也不误伤）。
    """
    if not R1_ENABLED:
        return
    tid = task['id']
    if task['assignee'] == 'gavin':
        _skip(state, tid, 'R1', 'G 卡不受影响，跳过')
        return
    if task.get('status') != 'blocked':
        _skip(state, tid, 'R1', '非 blocked（已 done/被 unblock 重开），不派修')
        return
    title = task['title'] or ''
    body = task['body'] or ''
    # 修复卡自身 blocked 是依赖等待，不派新轮（gov-7b 移到字段判定前：修复卡语义独立于验收判定）
    if 'govern-role: fix' in body:
        _skip(state, tid, 'R1', '修复卡自身 blocked 是依赖等待，不派新轮')
        return
    # block 事件提前取：疑似验收卡兜底需要 reason 判定（即使无验收标记）
    be = _latest_block_event(con, tid)
    reason = ((be or {}).get('payload') or {}).get('reason') or ''
    # gov-7c：task_kind 判定统一读 sidecar（task_kinds{}），DB 列兜底；无 → 文本兜底
    task_kind = _task_kind_of(state, tid)
    if task_kind:
        # 字段判定优先（gov-7b）：task_kind == 'review' 为强判定，不依赖 title/body 文本
        if task_kind != 'review':
            _skip(state, tid, 'R1', f'字段判定非验收卡（task_kind={task_kind}），跳过')
            return
    else:
        # 未标类型 → 文本兜底判定（gov-6 放宽版）；留痕把「漏标」变成可见问题，不静默
        if not _is_review_card(title, body):
            if _fail_reason_match(reason):
                _skip(state, tid, 'R1',
                      '疑似验收卡未确认（blocked + FAIL reason 但无验收标记），跳过')
            else:
                _skip(state, tid, 'R1', '非验收卡，跳过')
            return
        _skip(state, tid, 'R1', '未标类型，文本兜底判定')
    # 该 FAIL 已存在 done 的复验卡（body 引用本验收卡 id：结构化标记或 legacy 散文）→
    # 已复验通过、待 R2 收口，不派新一轮（防首扫/事件批处理时对已解决 FAIL 重复派修）
    done_rereview = con.execute(
        "SELECT 1 FROM tasks WHERE status = 'done' AND title LIKE '%复验%' "
        "AND body LIKE ? LIMIT 1", (f'%{tid}%',)).fetchone()
    if done_rereview:
        _skip(state, tid, 'R1', '已有 done 复验卡（待 R2 收口），不重复派修')
        return
    if be is None:
        _skip(state, tid, 'R1', '无 blocked 事件记录，跳过')
        return
    payload = be['payload']
    kind = payload.get('kind')
    if kind is not None and str(kind) not in BLOCKED_KINDS:
        _skip(state, tid, 'R1', f'block kind={kind} 不在白名单 {BLOCKED_KINDS}，跳过')
        return
    if not _fail_reason_match(reason):
        _skip(state, tid, 'R1', 'block reason 无 FAIL 词，跳过')
        return
    if str(be['id']) in state['processed_blocks']:
        _skip(state, tid, 'R1', f'该 FAIL 批次已处理（幂等，block ev#{be["id"]}），跳过')
        return
    # 链上卡（复验卡二轮 FAIL）：关联验收卡取标记；原验收卡取自身
    ref = _review_id_of(con, tid, title, body) or tid
    rrow = _get_task(con, ref)
    if rrow is None:
        _skip(state, tid, 'R1', f'关联验收卡 {ref} 不存在，跳过')
        return
    try:
        fix_id, rereview_id = _r1_fire(state, dict(rrow), be, failed_tid=tid)
        log(f'R1 fired: 验收卡 {ref} FAIL (block ev#{be["id"]}) → '
            f'修复卡 {fix_id} + 复验卡 {rereview_id}')
    except Exception as e:
        _err_once(_err_ts, 'r1', f'R1 fire 失败（{ref}）: {e}')
        _skip(state, tid, 'R1', f'派修执行异常：{e}')
        return


# ─────────────────────────── R2：复验 done → 自动收口 ───────────────────────────

def _r2_consider(con, state, task):
    """对一张 done 卡执行 R2 判定 + 收口。task 为只读行（id/title/body/assignee/status[/completed_at]）。

    gov-6：每个 return 路径 _skip 留痕。例外（降噪）：完全无治理信号且非近 24h 内完成的
    done 卡走「非复验卡」return 时不留痕——全表扫描每 15s 覆盖数百张历史 done 卡，无条件
    留痕会让 200 条环形缓冲每轮全量轮换，真实信号反而被冲掉。
    """
    if not R2_ENABLED:
        return
    task_id = task['id']
    if task_id in state['closed_reviews']:
        _skip(state, task_id, 'R2', '已收口记录，跳过')
        return
    title = task['title'] or ''
    body = task['body'] or ''
    review_id = _review_id_of(con, task_id, title, body)
    if not review_id:
        recent = int(task.get('completed_at') or 0) >= int(time.time()) - 86400
        has_signal = ('复验' in title or '验收' in title or 'govern-' in body)
        if recent or has_signal:
            _skip(state, task_id, 'R2', '非复验卡（无 govern-review/legacy 验收卡引用），跳过')
        return
    # 复验卡的父（修复卡）必须全部 done；无父卡不视为复验卡（修复卡自身也有标记，需排除）
    parents = _parents_of(con, task_id)
    if not parents:
        _skip(state, task_id, 'R2', '无父卡（修复卡自身也有标记，排除），跳过')
        return
    if any(p['status'] != 'done' for p in parents):
        _skip(state, task_id, 'R2', '父卡未全部 done（依赖等待中），跳过')
        return
    rrow = _get_task(con, review_id)
    if rrow is None:
        _skip(state, task_id, 'R2', f'关联验收卡 {review_id} 不存在，跳过')
        return
    if rrow['status'] != 'blocked':
        _skip(state, task_id, 'R2',
              f'验收卡 {review_id} 非 blocked（status={rrow["status"]}），不收口')
        return
    if rrow['assignee'] == 'gavin':
        _skip(state, task_id, 'R2', 'G 卡不受影响，跳过')
        return
    rtitle = rrow['title'] or ''
    rbody = rrow['body'] or ''
    # gov-7c：验收卡 task_kind 统一读 sidecar
    rtask_kind = _task_kind_of(state, review_id)
    if rtask_kind:
        # 字段判定优先（gov-7b）：验收卡 task_kind == 'review' 为强判定，不依赖文本措辞
        if rtask_kind != 'review':
            _skip(state, task_id, 'R2',
                  f'验收卡 {review_id} 字段判定非验收卡（task_kind={rtask_kind}），不收口')
            return
    else:
        # 未标类型 → 文本兜底判定（放宽版）；留痕可见「漏标」
        if not _is_review_card(rtitle, rbody):
            _skip(state, task_id, 'R2',
                  f'验收卡 {review_id} 未标类型且无验收标记，不收口')
            return
        _skip(state, task_id, 'R2', f'验收卡 {review_id} 未标类型，文本兜底判定')
    # 事件留痕 + 自动收口（同事务原子，独立写连接）
    fix_ids = [p['id'] for p in parents]
    summary = (f'【opc-govern R2】复验卡 {task_id} done → 验收卡自动收口'
               f'（复验通过，依据：复验卡 {title} done + 父修复卡 {",".join(fix_ids)} done）')
    metadata = {
        'rule': 'R2', 'govern': True,
        'review_id': review_id, 'rereview_id': task_id,
        'fix_id': fix_ids[0] if len(fix_ids) == 1 else fix_ids,
    }
    con = _write_con()
    try:
        with write_txn(con):
            ok = complete_task(con, review_id, summary=summary, metadata=metadata)
            if not ok:
                _skip(state, task_id, 'R2', '收口竞态：验收卡状态已变更，无事发生')
                return
            add_comment(
                con, review_id,
                f'【opc-govern R2】复验卡 {task_id}（{title}）done → 本验收卡自动收口'
                f'（依据：复验通过 + 修复卡 {",".join(fix_ids)} done）')
            state['closed_reviews'].add(review_id)
    finally:
        con.close()
    log(f'R2 fired: 复验卡 {task_id} done → 验收卡 {review_id} 自动收口')


# ─────────────────────────── R4：高风险动作审批校验 ───────────────────────────

def _r4_risk_of(title, body, task_kind):
    """R4 高风险判定 → (level, label) 或 None。

    level: 'high'/'critical'（标记给定）；label 用于告警文案（govern-risk: high / task_kind=gov）。
    判定源（OR）：
      ① title/body 含 govern-risk: high|critical 标记（正则排除文档引用形态——
         反引号包裹或「high|critical」枚举，防实施/验收卡 body 自我误伤）
      ② task_kind 属 gov/finance/legal 类（gov-7 结构化字段；NULL/未标 → 仅文本判定）
    """
    text = f"{title or ''}\n{body or ''}"
    m = GOVERN_RISK_RE.search(text)
    if m:
        lv = m.group(1).lower()
        return lv, f'govern-risk: {lv}'
    tk = (task_kind or '').strip().lower()
    if tk and tk in RISK_TASK_KINDS:
        return 'high', f'task_kind={tk}'
    return None


def _r4_initial_status(con, task_id):
    """卡的初始 status：第一条 created 事件 payload.status（建卡即定）。

    kanban_create(initial_status='blocked') 时内核在 created 事务内写 payload.status='blocked'
    （31g G 卡守卫，create 即 sticky blocked）。无 created 事件（手工 SQL 建卡）→ None，
    由调用方降级当前 status 判定。
    """
    row = con.execute(
        "SELECT payload FROM task_events WHERE task_id = ? AND kind = 'created' "
        "ORDER BY id ASC LIMIT 1", (task_id,)).fetchone()
    if not row or not row['payload']:
        return None
    try:
        p = json.loads(row['payload'])
        if isinstance(p, dict) and p.get('status'):
            return p['status']
    except (json.JSONDecodeError, TypeError):
        pass
    return None


def _r4_consider(con, state, task):
    """R4：对单张卡执行高风险审批校验。task 为只读行（id/title/body/assignee/status[/task_kind]）。

    高风险卡（标记或 task_kind 判定命中）必须 assignee=gavin 且初始状态（created 事件
    payload.status）== blocked → 满足：正常放行不告警；不满足 → skip_log 留痕 +
    卡评论告警（author=opc-govern）。幂等：同卡已有 R4 告警评论或 state.r4_warned
    已记录 → 不重复（评论次数恒=1，即使 skip_log 环被挤出也不重复刷屏）。可靠留痕
    双写：skip_log（与其他规则同构的审计流，环形 200 条可能被 R2 批量条目挤出）+
    state.r4_warned（独立持久化 dict，不被挤，验收/审计以它为准）。
    非高风险卡静默跳过（不留痕，防全表扫描刷屏挤掉真实信号）。
    """
    if not R4_ENABLED:
        return
    tid = task['id']
    # 状态守卫：done/archived 卡不校验（动作已完成，事后告警无行动价值；且 created 事件
    # 重放/水位线重置时不误伤历史卡）——与 scan_r4 的查询口径（非 done/archived）一致。
    if task.get('status') in ('done', 'archived'):
        return
    risk = _r4_risk_of(task.get('title') or '', task.get('body') or '',
                       _task_kind_of(state, tid))
    if risk is None:
        return
    label = risk[1]
    assignee = task.get('assignee') or ''
    init_status = _r4_initial_status(con, tid)
    if init_status is None:
        init_status = task.get('status') or ''
    if assignee == 'gavin' and init_status == 'blocked':
        return  # 合法 G 卡（真人审批卡），正常放行，不告警不留痕
    problems = []
    if assignee != 'gavin':
        problems.append(f'assignee={assignee or "空"} 非 gavin')
    if init_status != 'blocked':
        problems.append(f'初始状态={init_status or "未知"} 非 blocked')
    reason = f'高风险动作卡（{label}）' + '，'.join(problems) + '，未走真人审批'
    # 幂等：同卡已告警过（评论存在 或 r4_warned 已记录）→ 不重复
    existing = con.execute(
        "SELECT 1 FROM task_comments WHERE task_id = ? AND author = ? AND body LIKE ? LIMIT 1",
        (tid, AUTHOR, '【opc-govern R4】%')).fetchone()
    warned = state.get('r4_warned', {}).get(tid)
    if existing or warned:
        return
    if not _skip(state, tid, 'R4', reason):
        return  # skip 环内已留痕同因（同一轮扫描去重）
    # 可靠留痕（独立于 skip_log 环形，不被 R2 批量条目挤出）
    state.setdefault('r4_warned', {})[tid] = {
        'ts': int(time.time()), 'reason': reason, 'label': label,
        'assignee': assignee, 'init_status': init_status,
    }
    wcon = _write_con()
    try:
        with write_txn(wcon):
            add_comment(wcon, tid, f'【opc-govern R4】{reason}')
    finally:
        wcon.close()
    log(f'R4 warned: {tid} ({label}, assignee={assignee}, init={init_status})')


def scan_r4(con, state):
    """全表扫描 R4：非 done/archived 卡逐张校验高风险审批（created 事件漏网兜底）。

    历史 done 卡不追溯告警（动作已完成，事后告警无行动价值且会刷屏）——40 张存量
    gov 类 done 卡（assignee=make/linjing 等实施卡）不受影响。
    task_kind 判定走 sidecar（gov-7c），SELECT 不再取列（官方库无 task_kind 列）。
    """
    rows = con.execute(
        "SELECT id, title, body, assignee, status FROM tasks "
        "WHERE status NOT IN ('done', 'archived')").fetchall()
    for r in rows:
        try:
            _r4_consider(con, state, dict(r))
        except Exception as e:
            _err_once(_err_ts, f'r4scan:{r["id"]}', f'R4 扫描异常（{r["id"]}）: {e}')


# ─────────────────────────── R6：sticky blocked 事件补偿（内核解耦 a1） ───────────────────────────

def _has_sticky_block_event(con, task_id):
    """等价官方 _has_sticky_block：最近 blocked/unblocked 事件 == blocked 才算 sticky。"""
    row = con.execute(
        "SELECT kind FROM task_events WHERE task_id = ? "
        "AND kind IN ('blocked', 'unblocked') ORDER BY id DESC LIMIT 1",
        (task_id,)).fetchone()
    return bool(row) and row['kind'] == 'blocked'


def _created_status_of(con, task_id):
    """第一条 created 事件 payload.status（官方 create 必写 created；无 → None）。"""
    row = con.execute(
        "SELECT payload FROM task_events WHERE task_id = ? AND kind = 'created' "
        "ORDER BY id ASC LIMIT 1", (task_id,)).fetchone()
    if not row or not row['payload']:
        return None
    try:
        p = json.loads(row['payload'])
        return p.get('status') if isinstance(p, dict) else None
    except (json.JSONDecodeError, TypeError):
        return None


def sticky_compensate(state):
    """R6：补偿官方 create(initial_status='blocked') 缺 sticky 事件（31g，官方 main 未防）。

    官方 main 实测：create(initial_status=blocked) 只写 created 事件 → _has_sticky_block
    判非 sticky → recompute_ready 把无父卡/父卡 done 的卡自动 promote 到 ready。
    补偿：created payload.status=='blocked' 且无 blocked/unblocked 事件 → 补写 blocked
    事件（payload source=initial_status_blocked，与 fork 6680b5f47 同语义）→ sticky 生效，
    recompute_ready 不再 promote；已被误 promote 的卡（ready/running）→ 还原 blocked。
    事件写 task_events 属数据操作（非 schema 裸写）；还原状态与 create_task/complete_task
    等价 SQL 风格一致（官方无 triage/ready→blocked 的公开迁移 API）。
    幂等：补写后 blocked 事件存在，天然幂等。自持写连接 + 单事务。返回本次补写条数。
    """
    if not R6_ENABLED:
        return 0
    con = _write_con()
    try:
        with write_txn(con):
            rows = con.execute(
                "SELECT id, status FROM tasks "
                "WHERE status NOT IN ('done', 'archived')").fetchall()
            patched = 0
            for r in rows:
                tid = r['id']
                if _has_sticky_block_event(con, tid):
                    continue
                if _created_status_of(con, tid) != 'blocked':
                    continue
                # 补写 blocked 事件（数据操作，与 fork create 修复同语义）
                _append_event(con, tid, 'blocked', {'source': 'initial_status_blocked'})
                if r['status'] in ('ready', 'running'):
                    # 已被内核 recompute_ready 误 promote → 还原 blocked
                    con.execute(
                        "UPDATE tasks SET status = 'blocked', claim_lock = NULL, "
                        "claim_expires = NULL, worker_pid = NULL "
                        "WHERE id = ? AND status IN ('ready', 'running')",
                        (tid,))
                    _skip(state, tid, 'R6', 'sticky 补偿：误 promote 已还原 blocked')
                else:
                    _skip(state, tid, 'R6', 'sticky 补偿：initial_status=blocked 补写 blocked 事件')
                patched += 1
    finally:
        con.close()
    return patched


# ─────────────────────────── R5：gavin triage 守卫（内核解耦 a1） ───────────────────────────

def scan_r5(con, state):
    """R5：gavin 人工卡 triage 守卫——decompose 自动跳过语义的守护面。

    背景：gavin 卡可能被内核 block_loop_detected 推入 triage；官方 decompose_task 无
    gavin skip（fork 245bf4b51 规则已外移）→ OPC 侧防线：opc-decompose.py wrapper 调用
    前过滤 + 本守卫扫描留痕（skip_log，自动跳过可见）+ 快照对比检测已改写（title/body
    与上次扫描不一致 → 说明被 decompose 改写 → 卡评论告警，幂等一次）。
    守卫只留痕/告警，不改状态（红线：不拦截写路径、不自动改写人工卡）。
    """
    rows = con.execute(
        "SELECT id, title, body FROM tasks "
        "WHERE status = 'triage' AND assignee = 'gavin'").fetchall()
    snaps = state.setdefault('gavin_triage_snapshot', {})
    for r in rows:
        tid = r['id']
        title = r['title'] or ''
        body = r['body'] or ''
        snap = snaps.get(tid)
        if snap is not None and (snap.get('title') != title or snap.get('body') != body):
            # 已被 decompose 改写 → 告警（幂等：仅一次；同 R4 评论判定）
            existing = con.execute(
                "SELECT 1 FROM task_comments WHERE task_id = ? AND author = ? "
                "AND body LIKE ? LIMIT 1",
                (tid, AUTHOR, '【opc-govern R5】%')).fetchone()
            if not existing:
                warned = _skip(state, tid, 'R5', 'gavin 人工卡被 decompose 改写（快照不一致），需人工介入')
                if warned:
                    wcon = _write_con()
                    try:
                        with write_txn(wcon):
                            add_comment(wcon, tid,
                                        '【opc-govern R5】gavin 人工卡被 decompose 改写'
                                        f'（title/body 与快照不一致）——人工卡不应被自动分解，'
                                        '请人工核对恢复。')
                    finally:
                        wcon.close()
                    log(f'R5 warned: {tid} gavin 人工卡被改写')
        else:
            _skip(state, tid, 'R5', 'gavin 人工卡在 triage：decompose 跳过（OPC 守卫）')
        snaps[tid] = {'title': title, 'body': body, 'ts': int(time.time())}


# ─────────────────────────── 事件轮询 + 全表扫描 ───────────────────────────

def poll_events(db_path, watermark):
    """只读连接拉取：①关注的 kind 新事件（blocked/completed/created，触发判定）；②当前 MAX(id)（水位线）。"""
    con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=5)
    try:
        rows = con.execute(
            "SELECT id, task_id, kind, created_at, payload FROM task_events "
            "WHERE id > ? AND kind IN ('blocked', 'completed', 'created') ORDER BY id",
            (watermark,)).fetchall()
        max_id = con.execute(
            "SELECT COALESCE(MAX(id), 0) FROM task_events").fetchone()[0]
    finally:
        con.close()
    return rows, max_id


def _readonly_con(db_path):
    con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    return con


@contextlib.contextmanager
def write_txn(con):
    """开启 IMMEDIATE 写事务（with 块）。调用方需持有可写连接。"""
    con.execute('BEGIN IMMEDIATE')
    try:
        yield
        con.commit()
    except BaseException:
        con.rollback()
        raise


def _write_con():
    """独立的可写连接（mutation 函数自持，避免扫描用只读连接时写库报错）。"""
    con = sqlite3.connect(KANBAN_DB, timeout=15)
    con.row_factory = sqlite3.Row
    return con


def scan_r1(con, state):
    """全表扫描 R1：blocked + needs_input + 非 gavin + 验收判定 → 逐张判定。
    task_kind 判定走 sidecar（gov-7c），SELECT 不再取列。"""
    rows = con.execute(
        "SELECT id, title, body, assignee, status FROM tasks "
        "WHERE status = 'blocked' AND assignee != 'gavin'").fetchall()
    for r in rows:
        try:
            _r1_consider(con, state, dict(r))
        except Exception as e:
            _err_once(_err_ts, f'r1scan:{r["id"]}', f'R1 扫描异常（{r["id"]}）: {e}')


def scan_r2(con, state):
    """全表扫描 R2：done 卡逐张判定复验卡收口（legacy 手工链兜底）。"""
    rows = con.execute(
        "SELECT id, title, body, assignee, status, completed_at FROM tasks "
        "WHERE status = 'done'").fetchall()
    for r in rows:
        try:
            _r2_consider(con, state, dict(r))
        except Exception as e:
            _err_once(_err_ts, f'r2scan:{r["id"]}', f'R2 扫描异常（{r["id"]}）: {e}')


def handle_events(rows, state):
    """事件驱动的规则判定（blocked → R1；completed → R2；created → R4）。返回处理过的事件 id 集合。"""
    con = sqlite3.connect(KANBAN_DB, timeout=10)
    con.row_factory = sqlite3.Row
    seen = set()
    try:
        for ev in rows:
            ev_id, t_id, kind = ev[0], ev[1], ev[2]
            if kind == 'blocked':
                t = _get_task(con, t_id)
                if t is None:
                    continue
                _r1_consider(con, state, dict(t))
                seen.add(str(ev_id))
            elif kind == 'completed':
                t = _get_task(con, t_id)
                if t is None:
                    continue
                _r2_consider(con, state, dict(t))
                seen.add(str(ev_id))
            elif kind == 'created':
                t = _get_task(con, t_id)
                if t is None:
                    continue
                _r4_consider(con, state, dict(t))
                seen.add(str(ev_id))
    finally:
        con.close()
    return seen


def main():
    log(f'opc-govern start (poll={POLL_SECONDS}s, scan={SCAN_SECONDS}s, db={KANBAN_DB}, '
        f'state={STATE_FILE}, R1={R1_ENABLED}, R2={R2_ENABLED}, R4={R4_ENABLED}, '
        f'fix={FIX_ASSIGNEE}, rereview={REREVIEW_ASSIGNEE})')
    state = load_state()
    state.setdefault('watermark', None)
    state.setdefault('processed_blocks', [])
    state.setdefault('closed_reviews', [])
    state.setdefault('chains', {})
    state.setdefault('skip_log', [])  # gov-6：R1/R2 跳过留痕（环形 200 条）
    state.setdefault('task_kinds', {})  # gov-7c：task_kind sidecar（task_id→kind）
    state.setdefault('gavin_triage_snapshot', {})  # R5：gavin triage 卡快照（改写检测）
    # 幂等集合用 set 便于判重，落盘时转回 list
    state['processed_blocks'] = set(state['processed_blocks'])
    state['closed_reviews'] = set(state['closed_reviews'])

    # gov-7c 存量迁移：sidecar 为空且 DB 有 task_kind 列 → 一次性灌入（fork 库切换官方前）
    if not state['task_kinds']:
        migrated = _migrate_task_kinds_from_db(state)
        if migrated:
            log(f'gov-7c: migrated {migrated} task_kind entries from DB column to sidecar')
            save_state({**state, 'processed_blocks': sorted(state['processed_blocks']),
                        'closed_reviews': sorted(state['closed_reviews'])})

    watermark = state['watermark']
    if watermark is None:
        _, max_id = poll_events(KANBAN_DB, 0)
        watermark = int(max_id)
        state['watermark'] = watermark
        save_state({**state, 'processed_blocks': sorted(state['processed_blocks']),
                    'closed_reviews': sorted(state['closed_reviews'])})
        log(f'first run: watermark calibrated to {watermark} (no replay)')
    else:
        log(f'resume: watermark={watermark} (no replay)')

    last_scan = 0.0
    while True:
        try:
            rows, max_id = poll_events(KANBAN_DB, int(state['watermark']))
            if rows:
                last_id = rows[-1][0]
                seen = handle_events(rows, state)
                state['watermark'] = max(last_id, int(state['watermark']))
                save_state({**state, 'processed_blocks': sorted(state['processed_blocks']),
                            'closed_reviews': sorted(state['closed_reviews'])})
                log(f'events {len(rows)} (id {rows[0][0]}..{last_id}) processed, '
                    f'watermark={state["watermark"]}')
            elif max_id > int(state['watermark']):
                state['watermark'] = int(max_id)
                save_state({**state, 'processed_blocks': sorted(state['processed_blocks']),
                            'closed_reviews': sorted(state['closed_reviews'])})
        except Exception as e:
            _err_once(_err_ts, 'loop', f'error(events): {e}')

        if SCAN_SECONDS > 0 and time.time() - last_scan >= SCAN_SECONDS:
            last_scan = time.time()
            try:
                con = _readonly_con(KANBAN_DB)
                con.row_factory = sqlite3.Row
                try:
                    _invalidate_tk_cache()  # 每轮扫描前失效 task_kind 合并缓存（新卡/新登记可见）
                    # R6 先跑：initial_status=blocked 卡补 sticky 事件（官方 main 不写），
                    # 避免 recompute_ready 误 promote；R1 对 blocked 判定也因此正确
                    try:
                        n6 = sticky_compensate(state)
                        if n6:
                            log(f'R6 fired: {n6} 卡 sticky 补偿')
                    except Exception as e:
                        _err_once(_err_ts, 'r6scan', f'R6 扫描异常: {e}')
                    # R2 先扫：先收口已复验通过的验收卡，避免 R1 对已解决 FAIL 重复派修
                    scan_r2(con, state)
                    scan_r1(con, state)
                    scan_r4(con, state)
                    scan_r5(con, state)
                finally:
                    con.close()
                save_state({**state, 'processed_blocks': sorted(state['processed_blocks']),
                            'closed_reviews': sorted(state['closed_reviews'])})
            except Exception as e:
                _err_once(_err_ts, 'scan', f'error(scan): {e}')

        time.sleep(POLL_SECONDS)


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='opc-govern 治理规则引擎（OPC 侧）')
    parser.add_argument('--register-kind', nargs=2, metavar=('TASK_ID', 'KIND'),
                        help='gov-7c：登记 task_kind 到 sidecar（建卡包装层调用）')
    parser.add_argument('--migrate-task-kinds', action='store_true',
                        help='gov-7c：存量迁移——DB task_kind 列 → sidecar（一次性）')
    parser.add_argument('--list-kinds', action='store_true',
                        help='gov-7c：列出 sidecar 中已登记的 task_kind 数')
    parser.add_argument('--sticky-compensate', action='store_true',
                        help='R6：立即执行 sticky 补偿并退出（守护周期外手动/测试用）')
    args = parser.parse_args()

    if args.register_kind:
        tid, kind = args.register_kind
        st = load_state()
        st.setdefault('task_kinds', {})
        register_task_kind(st, tid, kind)
        save_state(st)
        print(f'registered: {tid} -> {kind.lower()}')
        raise SystemExit(0)
    if args.migrate_task_kinds:
        st = load_state()
        st.setdefault('task_kinds', {})
        n = _migrate_task_kinds_from_db(st)
        save_state(st)
        print(f'migrated: {n} entries (sidecar total={len(st["task_kinds"])})')
        raise SystemExit(0)
    if args.list_kinds:
        st = load_state()
        kinds = st.get('task_kinds') or {}
        print(f'sidecar task_kinds: {len(kinds)} entries')
        from collections import Counter
        c = Counter(str(v).lower() for v in kinds.values())
        for k, v in c.most_common():
            print(f'  {k}: {v}')
        raise SystemExit(0)
    if args.sticky_compensate:
        st = load_state()
        st.setdefault('task_kinds', {})
        st.setdefault('skip_log', [])
        n = sticky_compensate(st)
        save_state(st)
        print(f'sticky_compensate: {n} cards patched')
        raise SystemExit(0)

    main()
