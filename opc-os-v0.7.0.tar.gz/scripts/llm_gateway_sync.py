#!/usr/bin/env python3
"""LLM 网关透明度数据同步（0825-e 消费端 —— 只消费 0825-b/c 产物，零改动上游）

把 llm-gateway 的监控状态 JSON（usage_state.json, 0825-c monitor 产物）与
事件日志（events.jsonl, 0825-b 网关产物）合并成一份「透明度数据文件」，供
透明办公室页面的 LLM 网关区块直接消费：

  - 宿主（生产 opc-server pm2 进程读 OPC_DATA）:
      python3 llm_gateway_sync.py --src ~/.hermes/opc/llm-gateway \
                                  --out ~/.hermes/opc/llm-gateway.json
  - 容器（opc-os 部署包 collector 写 /data, web/opc-api 读 /data）:
      python3 llm_gateway_sync.py --src /data/hermes-home/opc/llm-gateway \
                                  --out /data/llm-gateway.json

成功时 stdout 为空（watchdog silent 契约：cron 只在失败时收到 stderr 错误）；
输出文件 atomic 写入 + 0644（29f 坑：mkstemp 默认 0600 会让 nginx 读 403）。
事件合并策略：关键生命周期/管理事件全量 + 最近 max_noise_events 条噪音事件
（probe_fail/upstream_error/error/model_trip/model_recover 等高频失败流）+ 最近
max_events 条 request，按 ts 升序 —— 时间线展示不丢 trip/recover/failover，
日志体积可控（0827-fix P1-3：probe_fail 15 万条曾撑出 51MB 死数据，前端不消费）。
"""
import argparse
import json
import os
import sys
import tempfile
from datetime import datetime, timezone

# 关键事件（量小且语义重要，全量保留）：启动/熔断/恢复/切换/轮换/配置热载/管理操作
CRITICAL_TYPES = ('startup', 'trip', 'recover', 'failover', 'rotate', 'config_reload',
                  'admin_provider_test', 'admin_provider_update',
                  'admin_set_default_provider', 'admin_provider_create',
                  'admin_provider_delete', 'admin_update_thresholds')
# 噪音事件（高频失败流，按类型截断保留最近 N 条）：健康探测失败/上游错误/模型熔断
NOISY_TYPES = ('probe_fail', 'upstream_error', 'error', 'model_trip', 'model_recover')
# 兼容引用：全生命周期类型 = 关键 + 噪音
LIFECYCLE_TYPES = CRITICAL_TYPES + NOISY_TYPES


def atomic_write(path, payload):
    """atomic 写 JSON（0644, 幂等）。"""
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=directory, prefix='.llm-gw-', suffix='.tmp')
    try:
        os.fchmod(fd, 0o644)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def load_usage_state(path):
    """读 monitor usage_state.json；缺失/损坏返回 None。"""
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def load_events(path, max_requests, max_noise):
    """读 events.jsonl → 关键事件全量 + 最近 max_noise 条/类型的噪音事件
    + 最近 max_requests 条 request，按 ts 升序。

    0827-fix P1-3：probe_fail 曾 15.4 万条全量合入（51MB 死数据），现按类型截断；
    未知类型按噪音处理（保守限流，防止未来新增高频事件再次撑爆文件）。
    """
    if not os.path.exists(path):
        return []
    critical, noisy, requests = [], [], []
    try:
        with open(path, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except Exception:
                    continue
                if not isinstance(ev, dict) or 'ts' not in ev:
                    continue
                ev_type = ev.get('type')
                if ev_type in CRITICAL_TYPES:
                    critical.append(ev)
                elif ev_type == 'request':
                    requests.append(ev)
                else:
                    # 噪音事件 + 未知类型：按类型各保留最近 max_noise 条
                    noisy.append(ev)
        requests = requests[-max_requests:]
        by_type = {}
        for ev in noisy:
            by_type.setdefault(ev.get('type', '?'), []).append(ev)
        noisy_trimmed = []
        for lst in by_type.values():
            noisy_trimmed.extend(lst[-max_noise:])
        merged = sorted(critical + noisy_trimmed + requests, key=lambda e: e.get('ts', ''))
        return merged
    except Exception:
        return []


def main():
    ap = argparse.ArgumentParser(description='LLM 网关透明度数据同步')
    ap.add_argument('--src', default='/home/gavin/.hermes/opc/llm-gateway',
                    help='llm-gateway 产物目录（usage_state.json / events.jsonl 所在）')
    ap.add_argument('--out', default='/home/gavin/.hermes/opc/llm-gateway.json',
                    help='输出透明度数据文件')
    ap.add_argument('--max-events', type=int, default=200,
                    help='合并时保留的最近 request 事件条数（默认 200）')
    ap.add_argument('--max-noise-events', type=int, default=200,
                    help='合并时噪音事件（probe_fail 等失败流）按类型保留的最近条数（默认 200）')
    args = ap.parse_args()

    usage_path = os.path.join(args.src, 'monitor', 'usage_state.json')
    events_path = os.path.join(args.src, 'events', 'events.jsonl')

    usage_state = load_usage_state(usage_path)
    if usage_state is None and os.path.exists(args.src):
        # 目录存在但 usage_state 缺失/损坏 —— 仍尝试同步 events，并在文件中留痕
        print(f'[llm-gateway-sync] usage_state 缺失或损坏: {usage_path}', file=sys.stderr)

    events = load_events(events_path, args.max_events, args.max_noise_events)

    payload = {
        'schema': 'llm-gateway/transparency v1',
        'generated_at': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        'available': usage_state is not None,
        'source': {
            'usage_state': usage_path,
            'events': events_path,
        },
        'usage_state': usage_state,
        'recent_events': events,
    }
    atomic_write(args.out, payload)
    # 成功静默（stdout 空 = watchdog silent 契约）


if __name__ == '__main__':
    main()
