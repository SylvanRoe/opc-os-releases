#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
opc-os-check-update —— OPC-OS 版本检查（Gavin 0827「已部署客户及时收到更新通知」）
================================================================================
职责：读取本地 VERSION 文件 → 探测远端最新版本 → semver 比较 → 有新版本时
      双落点通知（alert-bus + update-available.json）。无新版/离线时静默退出 0。

远端版本源优先级：
  1. GitHub Releases API https://api.github.com/repos/theBigGavin/opc-os/releases/latest
     （公开仓免凭据，超时 10s）→ tag_name（如 v0.6.0）
  2. git ls-remote --tags origin（git 形态部署 fallback，需仓内 git remote）
  3. 全部失败 → 静默退出 0 + 记录 last_check 时间（离线不打扰，下次再试）

通知双落点（D3）：
  1. alert-bus：scripts/opc-alert-bus.py append type=upgrade-available
     （severity=P2 信息留痕；schema 含 current/latest/summary；env OPC_ALERT_DIR 可覆盖）
  2. <opc-os-state-dir>/update-available.json：
     {current, latest, changelog_summary, detected_at}（透明办公室 web 后续可读）

路径 env 参数化（D7 合入规范，installation-guide §14 红线 7）：
  OPC_OS_REPO         —— opc-os 仓根（默认：本脚本上级目录）
  OPC_OS_STATE_DIR    —— 升级状态目录（默认 ~/.opc-os；update-available.json / last-check.json / upgrade.log 落此）
  OPC_ALERT_DIR       —— alert-bus 告警目录（默认 /home/gavin/.hermes/opc/alerts，生产兜底）
  OPC_UPDATE_CHECK_URL—— GitHub Releases API URL 覆盖（自测用 mock）
  OPC_UPDATE_CHECK_INTERVAL_H —— 距上次检查至少间隔小时数（默认 24；cron 每日一次）

用法：
  python3 scripts/opc-os-check-update.py [--json] [--force]
    --force  忽略间隔限制强制检查（默认距上次检查 < interval 时直接跳过）
    --json   输出 {current, latest, update_available, ...} JSON 到 stdout
退出码：0（成功/无新版/离线静默）；非 0（本脚本自身错误，如 VERSION 文件损坏）
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime

# ---------- 常量（全部 env 可覆盖，默认值仅生产兜底） ----------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_DIR = os.environ.get("OPC_OS_REPO", os.path.normpath(os.path.join(SCRIPT_DIR, "..")))
STATE_DIR = os.environ.get("OPC_OS_STATE_DIR", os.path.expanduser("~/.opc-os"))
UPDATE_AVAILABLE_FILE = os.path.join(STATE_DIR, "update-available.json")
LAST_CHECK_FILE = os.path.join(STATE_DIR, "last-check.json")
GITHUB_API_URL = os.environ.get(
    "OPC_UPDATE_CHECK_URL",
    "https://api.github.com/repos/theBigGavin/opc-os/releases/latest",
)
FETCH_TIMEOUT = 10           # GitHub API 超时（秒）
DEFAULT_INTERVAL_H = 24      # 距上次检查最小间隔（小时）
SEMVER_RE = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)(?:[-+].*)?$")


def _now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def read_local_version():
    """读取本地 VERSION 文件（仓根）。文件缺失/内容非法 → 抛错。"""
    vfile = os.path.join(REPO_DIR, "VERSION")
    if not os.path.exists(vfile):
        raise RuntimeError(f"VERSION 文件缺失: {vfile}")
    with open(vfile, encoding="utf-8") as f:
        ver = f.read().strip()
    if not SEMVER_RE.match(ver):
        raise RuntimeError(f"VERSION 内容非法（须 主.次.补丁 如 0.6.0）: {ver!r}")
    return ver


def semver_key(v):
    """semver 比较键：(主, 次, 补丁)。v 形如 0.6.0 / v0.6.0。"""
    m = SEMVER_RE.match(v)
    if not m:
        raise ValueError(f"非法版本号: {v!r}")
    return tuple(int(g) for g in m.groups()[:3])


def fetch_github_latest():
    """GitHub Releases API → (tag_name, body)。超时/网络失败 → 抛异常。"""
    import urllib.request

    req = urllib.request.Request(
        GITHUB_API_URL,
        headers={"User-Agent": "opc-os-check-update", "Accept": "application/vnd.github+json"},
    )
    with urllib.request.urlopen(req, timeout=FETCH_TIMEOUT) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    tag = (data.get("tag_name") or "").strip()
    body = (data.get("body") or "").strip()
    if not tag:
        raise RuntimeError("GitHub Releases API 响应无 tag_name")
    return tag, body


def fetch_git_tags():
    """git ls-remote --tags origin → 最新 tag（按 semver 排序）。非 git 形态/失败 → 抛异常。"""
    if not os.path.isdir(os.path.join(REPO_DIR, ".git")):
        raise RuntimeError("非 git 形态部署（无 .git 目录），跳过 git tag fallback")
    proc = subprocess.run(
        ["git", "-C", REPO_DIR, "ls-remote", "--tags", "origin"],
        capture_output=True, text=True, timeout=FETCH_TIMEOUT,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"git ls-remote 失败: {proc.stderr.strip()[:200]}")
    tags = []
    for line in proc.stdout.splitlines():
        # 取 refs/tags/<name>，剔除 ^{} 剥离行
        ref = line.split("\t", 1)[-1].strip()
        if not ref.startswith("refs/tags/"):
            continue
        if ref.endswith("^{}"):
            continue
        tag = ref[len("refs/tags/"):]
        if SEMVER_RE.match(tag):
            tags.append(tag)
    if not tags:
        raise RuntimeError("git ls-remote 无 semver tag")
    tags.sort(key=lambda t: semver_key(t))
    return tags[-1], ""


def resolve_latest():
    """按优先级链取远端最新版本 → (version, changelog)。全部失败 → (None, None)。"""
    for name, fn in (("github", fetch_github_latest), ("git", fetch_git_tags)):
        try:
            ver, body = fn()
            return ver.lstrip("v"), body
        except Exception as e:  # noqa: BLE001 —— 源失败降级到下一级
            print(f"[opc-os-check-update] {name} 源失败: {e}", file=sys.stderr)
    return None, None


def _changelog_summary(body, latest):
    """从 Release body 截取变更摘要（前 ~300 字，单行化）。无 body → 提示看 CHANGELOG。"""
    if not body:
        return f"请查看 CHANGELOG 中 {latest} 对应段落"
    body = re.sub(r"\s+", " ", body).strip()
    return body[:300] + ("…" if len(body) > 300 else "")


def _ensure_state_dir():
    os.makedirs(STATE_DIR, exist_ok=True)


def notify(latest, summary):
    """双落点通知（D3）：alert-bus + update-available.json。任一失败不致命。"""
    local_ver = read_local_version()
    detected_at = _now_iso()
    # 落点 1：update-available.json（透明办公室 web 可读）
    payload = {
        "current": local_ver,
        "latest": latest,
        "changelog_summary": summary,
        "detected_at": detected_at,
    }
    try:
        _ensure_state_dir()
        with open(UPDATE_AVAILABLE_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        print(f"[opc-os-check-update] 已写 {UPDATE_AVAILABLE_FILE}")
    except OSError as e:
        print(f"[opc-os-check-update] ⚠️ 写 update-available.json 失败: {e}", file=sys.stderr)
    # 落点 2：alert-bus（P2 信息留痕，走既有告警路由）
    try:
        bus = os.path.join(SCRIPT_DIR, "opc-alert-bus.py")
        if os.path.exists(bus):
            subprocess.run(
                [sys.executable, bus, "append",
                 "--source", "opc-os-check-update",
                 "--severity", "P2",
                 "--type", "upgrade-available",
                 "--title", f"OPC-OS 新版本可用: {local_ver} → {latest}",
                 "--evidence", summary],
                capture_output=True, text=True, timeout=30,
            )
    except Exception as e:  # noqa: BLE001 —— 告警总线失败不阻塞检查结果
        print(f"[opc-os-check-update] ⚠️ alert-bus 通知失败: {e}", file=sys.stderr)


def record_last_check():
    """记录本次检查时间（离线静默/无新版也记，供间隔跳过）。"""
    try:
        _ensure_state_dir()
        with open(LAST_CHECK_FILE, "w", encoding="utf-8") as f:
            json.dump({"last_check": _now_iso(), "ts": int(time.time())}, f)
    except OSError:
        pass


def main(argv=None):
    p = argparse.ArgumentParser(
        prog="opc-os-check-update",
        description="OPC-OS 版本检查：本地 VERSION vs 远端最新版，有新版本时双落点通知",
    )
    p.add_argument("--json", action="store_true", help="输出 JSON 到 stdout（机器可读）")
    p.add_argument("--force", action="store_true", help="忽略间隔限制强制检查")
    args = p.parse_args(argv)

    # 本地版本（读不到 = 部署包损坏，非静默）
    try:
        local_ver = read_local_version()
    except RuntimeError as e:
        print(f"opc-os-check-update: 错误: {e}", file=sys.stderr)
        return 2

    # 间隔限制（非 --force；距上次 < interval 直接跳过）
    interval_h = int(os.environ.get("OPC_UPDATE_CHECK_INTERVAL_H", DEFAULT_INTERVAL_H))
    if not args.force and os.path.exists(LAST_CHECK_FILE):
        try:
            with open(LAST_CHECK_FILE, encoding="utf-8") as f:
                last_ts = json.load(f).get("ts", 0)
            if last_ts and (time.time() - last_ts) < interval_h * 3600:
                result = {
                    "current": local_ver, "latest": None,
                    "update_available": False, "skipped": True, "reason": "interval",
                }
                if args.json:
                    print(json.dumps(result, ensure_ascii=False))
                return 0
        except (OSError, ValueError):
            pass  # last-check 损坏 → 正常检查

    # 远端探测（全失败 = 离线静默退出 0）
    latest, body = resolve_latest()
    if latest is None:
        record_last_check()
        result = {
            "current": local_ver, "latest": None,
            "update_available": False, "skipped": False, "reason": "offline",
        }
        if args.json:
            print(json.dumps(result, ensure_ascii=False))
        return 0

    # semver 比较
    update_available = semver_key(latest) > semver_key(local_ver)
    summary = _changelog_summary(body, latest) if update_available else ""
    if update_available:
        notify(latest, summary)
        print(f"[opc-os-check-update] 发现新版本: {local_ver} → {latest}")
    else:
        # 无新版：清除上次的 update-available.json（避免残留误报）
        try:
            if os.path.exists(UPDATE_AVAILABLE_FILE):
                os.remove(UPDATE_AVAILABLE_FILE)
        except OSError:
            pass
        print(f"[opc-os-check-update] 已是最新版本 ({local_ver})")
    record_last_check()

    result = {
        "current": local_ver,
        "latest": latest,
        "update_available": update_available,
        "changelog_summary": summary,
        "detected_at": _now_iso(),
        "skipped": False,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
