#!/bin/bash
# OPC OS — 本地验收冒烟测试（一条命令验证部署包健康）
# 用法: scripts/smoke_test.sh [PORT]
# 检查: 服务进程/端口 / 页面 200 / 数据出现（成员/任务/token）/ 数据总线 / 脱敏红线（无 OPC 真名）
# 0826-osv-1 去 docker 版：容器检查全部改为进程级（pgrep / HTTP 端口），
# 数据文件检查改为 HTTP 拉取（web /opc/data/* 直连 opc-init 输出目录）
set -e
PORT="${1:-8081}"
BASE="http://127.0.0.1:$PORT"
GW_PORT="${OPC_GATEWAY_PORT:-18080}"
API_PORT="${OPC_API_PORT:-3033}"
PASS=0; FAIL=0

check() {  # check <描述> <命令>
  if eval "$2" >/dev/null 2>&1; then
    echo "  ✓ $1"; PASS=$((PASS+1))
  else
    echo "  ✗ $1"; FAIL=$((FAIL+1))
  fi
}

http_code() { curl -s -o /dev/null -w '%{http_code}' "$1"; }

echo "== OPC OS 冒烟测试 (port $PORT) =="

# 1. 服务进程在线（原生进程化：pgrep / 端口探活）
echo "[进程]"
check "llm-gateway 进程运行 (node server.js)" "pgrep -f 'node server\.js'"
check "opc-api 进程运行 (node index.cjs)" "pgrep -f 'node index\.cjs'"
check "web 进程运行 (web-serve.js)" "pgrep -f 'web-serve\.js'"
check "dispatcher 进程运行 (kanban_dispatcher.cli)" "pgrep -f 'kanban_dispatcher\.cli'"
check "opc-bus 数据总线存活 (opc-bus.py)" "pgrep -f 'opc-bus\.py'"
check "网关端口 $GW_PORT 探活" "[ \"$(http_code http://127.0.0.1:$GW_PORT/v1/models)\" != 000 ]"
check "opc-api 端口 $API_PORT 探活" "[ \"$(http_code http://127.0.0.1:$API_PORT/api/time)\" != 000 ]"

# 2. HTTP 可达
echo "[HTTP]"
check "首页 301 → /opc/" "curl -sf -o /dev/null -w '%{http_code}' $BASE/ | grep -q 301"
check "透明办公室 200" "curl -sf -o /dev/null $BASE/opc/"
check "治理仪表盘 200" "curl -sf -o /dev/null $BASE/opc/governance.html"
check "工作台 workbench.html 200" "curl -sf -o /dev/null $BASE/opc/workbench.html"
check "状态数据 200" "curl -sf -o /dev/null $BASE/opc/data/status.json"
check "token 数据 200" "curl -sf -o /dev/null $BASE/opc/data/token-stats.json"
check "健康检查 200" "curl -sf -o /dev/null $BASE/healthz"

# 2.6. clean-URL（0826-osv-2c：无扩展名语义页 → 实际 html，与 CF Pages 生产路由一致；未知路径禁 SPA 兜底）
echo "[clean-url]"
check "clean-url /opc/workbench 200 且 text/html" "curl -sI $BASE/opc/workbench | grep -qi '^HTTP/.* 200' && curl -sI $BASE/opc/workbench | grep -qi 'Content-Type: text/html'"
check "clean-url /opc/governance 200" "curl -sf -o /dev/null $BASE/opc/governance"
check "clean-url /opc/workbench.html 200（兼容原直映）" "curl -sf -o /dev/null $BASE/opc/workbench.html"
check "clean-url 数据路由 /opc/data/status.json 200（未被重写破坏）" "curl -sf -o /dev/null $BASE/opc/data/status.json"
check "clean-url 未知路径 /opc/no-such-page 404（禁 SPA 兜底）" "[ \"$(http_code $BASE/opc/no-such-page)\" = 404 ]"

# 2.5. 工作台 API 参数化（0821-wb-cors: 部署期 WORKBENCH_API 可注入, 默认保持 mrd.hermes.cc.cd）
echo "[workbench]"
check "API 注入点 OPC_WORKBENCH_API 在位" "curl -sf $BASE/opc/workbench.html | grep -q 'window.OPC_WORKBENCH_API'"
check "无旧硬编码 var API = 'https://mrd.hermes.cc.cd'" "! curl -sf $BASE/opc/workbench.html | grep -q \"var API = 'https://mrd.hermes.cc.cd'\""
if [ -n "${WORKBENCH_API:-}" ]; then
  check "WORKBENCH_API 已注入到页面" "curl -sf $BASE/opc/workbench.html | grep -Fq \"window.OPC_WORKBENCH_API || '$WORKBENCH_API'\""
fi

# 3. 数据出现（非写死：成员/任务/token 来自 opc-init 输出目录）
echo "[数据]"
curl -sf "$BASE/opc/data/status.json" -o /tmp/opcos_status.json
curl -sf "$BASE/opc/data/token-stats.json" -o /tmp/opcos_ts.json
check "成员 ≥9" "grep -o '\"id\": \"[a-z]*\"' /tmp/opcos_status.json | sort -u | wc -l | grep -q '^9$'"
check "kanban 任务 >0" "grep -o '\"total\": [0-9]*' /tmp/opcos_status.json | head -1 | grep -qv ': 0$'"
check "token 归因 >0" "grep -o '\"tokens\": [0-9]*' /tmp/opcos_ts.json | head -1 | grep -qv ': 0$'"
check "成员按 token/成本/任务/通过率展示" "grep -q 'pass_rate' /tmp/opcos_ts.json && grep -q 'cost_usd' /tmp/opcos_ts.json && grep -q 'tasks_done' /tmp/opcos_ts.json"

# 3.5. 数据总线（opc-bus 进程存活 + status.json sources.kanban 段级元数据 + 水位线经 HTTP 可读）
echo "[总线]"
check "status.json 含 sources.kanban 元数据" "grep -q '\"sources\"' /tmp/opcos_status.json && grep -q '\"watermark\"' /tmp/opcos_status.json"
check "bus 水位线文件经 web 可读" "curl -sf -o /dev/null $BASE/opc/data/bus-state.json"

# 4. 脱敏红线（无 OPC 真实 9 人身份数据）
echo "[脱敏红线]"
curl -sf "$BASE/opc/" -o /tmp/opcos_index.html
for name in 庄子 马克 安然 林静 温雯 钱莉 潘明 蔡婉 苏木; do
  check "页面无真名「$name」" "! grep -q '$name' /tmp/opcos_index.html"
done
check "状态数据无真名" "! grep -qE '庄子|马克|安然|林静|温雯|钱莉|潘明|蔡婉|苏木' /tmp/opcos_status.json"

echo ""
echo "== 结果: PASS=$PASS FAIL=$FAIL =="
[ "$FAIL" -eq 0 ] && echo "ALL GREEN ✓" || { echo "有失败项 ✗"; exit 1; }
