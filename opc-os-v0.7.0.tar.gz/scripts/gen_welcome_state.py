#!/usr/bin/env python3
"""OPC OS — 欢迎态状态生成器（31c）

customer 形态首启且未初始化（无 /data/init-state.json）时，由 entrypoint_collector.sh 调用：
生成「未初始化欢迎态」的 status.json（标记 uninitialized，透明办公室前端显示引导页，
而非软件公司 demo）+ 空 token-stats.json（web 治理面板读得到空数据，不报错）。

产物（与 opc_collect.py 输出结构兼容，前端 applyStatus 不崩）：
  1. status.json      —— 顶层 init_state=uninitialized + members=[] + 空 kanban/activities/metrics
  2. token-stats.json —— 空归因结构（tokens=0 / profiles={} / series_daily=[]）

不生成任何真实/演示业务数据（红线：欢迎态零业务数据，仅初始化引导标记）。
"""
import json
import os
import sys
import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib_config import get_cfg

CFG = get_cfg()
P = CFG['paths']
OUT_STATUS = P['out_status']
OUT_SECONDARY = P.get('out_status_secondary') or ''
OUT_TS = P.get('token_stats_out') or os.path.join(P['opc_dir'], 'token-stats.json')


def atomic_write(path, obj):
    """原子写（tmp + os.replace），与 opc_collect.py 同款；29f 教训：mkstemp 后须 fchmod 0644
    （默认 0600 会让 opc-os web nginx user 身份读 403）。"""
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    import tempfile
    fd, tmp = tempfile.mkstemp(dir=d or '.', prefix='.welcome-', suffix='.tmp')
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write('\n')
    os.chmod(tmp, 0o644)   # 29f：mkstemp 默认 0600 → web nginx user 读 403，必须显式 0644
    os.replace(tmp, path)


def build_status():
    now = datetime.datetime.now()
    unix = int(now.timestamp())
    sh = datetime.timezone(datetime.timedelta(hours=8))
    return {
        'ts': now.isoformat(),
        'server_time': {'iso': datetime.datetime.fromtimestamp(unix, tz=sh).isoformat(timespec='seconds'),
                        'unix': unix, 'tz': 'Asia/Shanghai', 'offset': 480},  # 0825-f: 时钟服务同构
        'init_state': 'uninitialized',          # 31c：透明办公室前端识别 → 显示初始化引导页
        'running_days': 0,
        'members': [],
        'activities': [],
        'metrics': {'init_state': 'uninitialized'},
        'kanban': _kanban_empty(),
        'kanban_demo': _kanban_empty(),
        'meeting': {'members': [], 'subjects': []},
    }


def _kanban_empty():
    return {
        'ts': datetime.datetime.now().isoformat(),
        'tasks': [],
        'by_member': {},
        'summary': {'total': 0, 'done': 0, 'running': 0, 'todo': 0, 'blocked': 0,
                    'human_waiting': 0},
        'error': None,
    }


def build_token_stats():
    now = datetime.datetime.now()
    return {
        'generated_at': now.isoformat(),
        'today': {'tokens': 0, 'cost_usd': 0, 'sessions': 0, 'cron_runs': 0},
        'total': {'tokens': 0, 'cost_usd': 0, 'sessions': 0, 'cron_runs': 0},
        'profiles': {},
        'kanban': {'total_tasks': 0, 'done': 0, 'review_cards_total': 0,
                   'review_cards_done': 0, 'review_fail_batches': 0,
                   'acceptance_pass_rate': None, 'rework_done_total': 0,
                   'source': 'welcome-uninitialized'},
        'series_daily': [],
        'attribution': {'generator': 'welcome', 'sources': ['init-state absent'],
                        'red_line': '欢迎态：零业务数据', 'doc': None},
    }


def main():
    status = build_status()
    atomic_write(OUT_STATUS, status)
    if OUT_SECONDARY:
        atomic_write(OUT_SECONDARY, status)
    atomic_write(OUT_TS, build_token_stats())
    print(f'[welcome] 欢迎态已生成: {OUT_STATUS}（init_state=uninitialized，透明办公室将显示引导页）')
    print(f'[welcome] 空 token-stats: {OUT_TS}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
