#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""opc-alert-bus.py 单元自测（t_085c7093 交付物，2026-08-27）
覆盖：append 原子性（并发多进程不丢行）/ P2 直接 resolved / read_new 过滤 /
      mark_routed / mark_resolved 状态迁移 / fingerprint 默认公式 / 证据截断。
注意：测试使用临时 ALERT_DIR，通过 monkeypatch 模块常量，不影响生产总线。
"""
import json
import os
import subprocess
import sys
import tempfile
import threading

import importlib.util
_WS = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location(
    "opc_alert_bus", os.path.join(_WS, "opc-alert-bus.py"))
bus = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bus)

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {extra}")


def run_cli(args, **kw):
    env = dict(os.environ)
    env["OPC_ALERT_DIR"] = bus.ALERT_DIR  # CLI 子进程走同一临时目录
    return subprocess.run(
        [sys.executable, os.path.join(_WS, "opc-alert-bus.py")] + args,
        capture_output=True, text=True, env=env, **kw)


def main():
    global tmp_dir
    tmp_dir = tempfile.mkdtemp(prefix="opc-bus-test-")
    tmp = tmp_dir
    bus.ALERT_DIR = tmp
    bus.BUS_FILE = os.path.join(tmp_dir, "bus.jsonl")
    bus.LOCK_FILE = os.path.join(tmp_dir, ".bus.lock")
    print(f"测试目录: {tmp_dir}")

    print("1) append 基础 + fingerprint 默认公式")
    e1 = bus.append_entry("system-monitor", "P1", "disk-root-high", "根磁盘 ≥90%", "df -h /: / 91%")
    check("默认 fingerprint = source:type:date", e1["fingerprint"] == "system-monitor:disk-root-high:" + e1["ts"][:10],
          e1["fingerprint"])
    check("P1 初始 status=new", e1["status"] == "new")
    check("card_id 初始 None", e1["card_id"] is None)
    check("ts 有值", bool(e1["ts"]))

    print("2) P2 → 直接 resolved（信息留痕，不进 read_new）")
    e2 = bus.append_entry("system-monitor", "P2", "hourly-summary", "整点汇总", "负载正常")
    check("P2 status=resolved", e2["status"] == "resolved")
    check("read_new 不含 P2", all(r["fingerprint"] != e2["fingerprint"] for r in bus.read_new()))

    print("3) read_new 只含 new")
    rn = bus.read_new()
    check("read_new 数量=1（仅 P1 那条）", len(rn) == 1, f"got {len(rn)}")
    check("read_new 全为 new", all(r["status"] == "new" for r in rn))

    print("4) mark_routed：new → routed + card_id")
    fp = e1["fingerprint"]
    n = bus.mark_routed(fp, "t_test001")
    check("mark_routed 改动 1 条", n == 1)
    row = [r for r in bus._load_all() if r["fingerprint"] == fp][0]
    check("status=routed", row["status"] == "routed")
    check("card_id=t_test001", row["card_id"] == "t_test001")
    check("read_new 已清空", len(bus.read_new()) == 0)

    print("5) mark_resolved：routed → resolved")
    n = bus.mark_resolved(fp)
    check("mark_resolved 改动 1 条", n == 1)
    row = [r for r in bus._load_all() if r["fingerprint"] == fp][0]
    check("status=resolved", row["status"] == "resolved")

    print("6) 幂等回写：已 resolved 再 mark → 0 条")
    n = bus.mark_resolved(fp)
    check("重复 resolved 改动 0 条", n == 0)

    print("7) evidence 截断（>3000 → 截断）")
    e3 = bus.append_entry("server-monitor", "P1", "opc-server-health", "探针失败", "x" * 5000)
    check("evidence 长度 ≤3000", len(e3["evidence"]) <= 3000, f"{len(e3['evidence'])}")

    print("8) 并发 append 原子性：10 线程 × 30 条 = 300 条不丢")
    def worker(k):
        for i in range(30):
            bus.append_entry("test", "P1", f"t{k}", f"thread {k} {i}")
    threads = [threading.Thread(target=worker, args=(k,)) for k in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    rows = bus._load_all()
    check("总行数=303（3 条前述 + 300 并发）", len(rows) == 303, f"got {len(rows)}")
    import re as _re
    fp_ok = all(
        _re.fullmatch(r"test:t\d+:\d{4}-\d{2}-\d{2}", r["fingerprint"]) is not None
        for r in rows if r["source"] == "test")
    check("每行可解析且 fingerprint 格式正确", fp_ok)

    print("9) CLI 冒烟：read_new / count_new / mark 回写走真实 CLI")
    bus.append_entry("cli", "P1", "smoke", "CLI 冒烟告警")
    r = run_cli(["read_new", "--json"])
    check("CLI read_new 返回 0", r.returncode == 0, r.stderr)
    parsed = [json.loads(l) for l in r.stdout.strip().splitlines()]
    check("CLI read_new 输出含 cli:smoke", any(x["fingerprint"].startswith("cli:smoke") for x in parsed))
    r = run_cli(["count_new"])
    check("CLI count_new 输出 new=N", "new=" in r.stdout, r.stdout)
    r = run_cli(["mark_routed", "cli:smoke:" + bus._now_iso()[:10], "t_smoke"])
    check("CLI mark_routed 返回 0", r.returncode == 0, r.stderr)
    r = run_cli(["list", "--status", "routed"])
    check("CLI list routed 非空", "cli:smoke" in r.stdout, r.stdout)

    print("10) CLI 参数校验：非法 severity 拒绝")
    r = run_cli(["append", "--source", "x", "--severity", "P9", "--type", "y", "--title", "z"])
    check("非法 severity 返回非 0", r.returncode != 0, f"rc={r.returncode}")

    print(f"\n结果: {PASS} 通过 / {FAIL} 失败")
    if FAIL:
        print(f"临时目录保留: {tmp}")
    else:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
        print("临时目录已清理")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
