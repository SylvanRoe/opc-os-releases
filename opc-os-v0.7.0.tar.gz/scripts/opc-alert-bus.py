#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
opc-alert-bus —— OPC 统一告警总线（监控脚本 → 路由 agent → kanban 闭环）
================================================================================
定稿：/home/gavin/.hermes/opc/reports/2026-08-27-alert-auto-loop.md

职责：监控脚本（system-monitor / sched-health / telegram-watchdog /
      server-monitor / assignee-anomaly）在输出告警到 stdout 的同时，
      调本组件 append 一条总线记录；路由 agent（make profile cron）周期
      读 status=new 条目 → 分级建卡 → 回写 mark_routed；卡 done 后回写
      mark_resolved。

总线文件：/home/gavin/.hermes/opc/alerts/bus.jsonl（O_APPEND 单行 JSON）
schema（定稿固定，勿改字段名）：
  {"ts","source","severity(P0/P1/P2)","type","fingerprint",
   "title","evidence","status(new|routed|resolved)","card_id"}
fingerprint = source:type:YYYY-MM-DD（幂等键：同日同源同类型只算一个问题）

CLI 子命令（脚本/agent 共用，均无第三方依赖）：
  append    --source S --severity P0|P1|P2 --type T --title TTL
            [--evidence E] [--fingerprint FP] [--ts T]
            → 写一条总线（O_APPEND，<4KB 原子）；P2 直接 status=resolved（信息留痕）
  read_new  → 输出 status=new 条目（JSON lines，供路由 agent）
  mark_routed <fingerprint> <card_id>
            → 该 fingerprint 的 new 条目 → status=routed + card_id
  mark_resolved <fingerprint>
            → 该 fingerprint 的 routed 条目 → status=resolved
  count_new → 输出未处理（status=new）条目数 + 指纹列表
  list      [--status new|routed|resolved] [--limit N] → 调试用，JSON lines

设计约束（定稿红线）：
- 不引入第二套去重状态机：脚本层已有 was_alert/dedup 逻辑，append 只做
  O_APPEND 原子追加，不在本组件内做时间窗去重
- 并发安全：append 用 O_APPEND 单行原子（<4KB）；回写（mark_*）用 flock
  排他锁 + 临时文件原子替换，防止与并发 append 竞态丢行
- 路径硬编码 /home/gavin（cron/agent 会话 HOME 被重定向，不可用 expanduser）
"""
import argparse
import fcntl
import json
import os
import sys
import tempfile
import time
from datetime import datetime

# ---------- 常量（硬编码绝对路径：cron 派生会话 HOME 被重定向） ----------
ALERT_DIR = os.environ.get("OPC_ALERT_DIR", "/home/gavin/.hermes/opc/alerts")
BUS_FILE = os.path.join(ALERT_DIR, "bus.jsonl")
LOCK_FILE = os.path.join(ALERT_DIR, ".bus.lock")   # mark_* 回写互斥锁（与 append 无冲突）
MAX_EVIDENCE = 3000          # evidence 截断，保证单行 <4KB 原子写
FINGERPRINT_DATE_FMT = "%Y-%m-%d"
VALID_SEVERITY = {"P0", "P1", "P2"}
VALID_STATUS = {"new", "routed", "resolved"}


def _now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _ensure_dir():
    os.makedirs(ALERT_DIR, exist_ok=True)


def _load_all():
    """读全部总线条目（list[dict]）。文件不存在/损坏行 → 跳过损坏行。"""
    if not os.path.exists(BUS_FILE):
        return []
    rows = []
    try:
        with open(BUS_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except ValueError:
                    continue  # 损坏行跳过（不阻塞总线）
    except OSError:
        return []
    return rows


def _write_all(rows):
    """整文件原子替换（mark_* 用，调用方须持 LOCK_FILE 排他锁）。"""
    fd, tmp = tempfile.mkstemp(dir=ALERT_DIR, prefix=".bus.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        os.replace(tmp, BUS_FILE)
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _lock_exclusive():
    """mark_* 回写前拿排他锁（防止与并发 append 竞态导致重写丢行）。"""
    _ensure_dir()
    fh = open(LOCK_FILE, "w")
    fcntl.flock(fh, fcntl.LOCK_EX)
    return fh


def append_entry(source, severity, type_, title, evidence="", fingerprint=None, ts=None):
    """追加一条总线记录。返回写入的 dict。
    - severity 必为 P0/P1/P2；P2 → status 直接 resolved（信息留痕，不进 read_new）
    - fingerprint 默认 source:type:YYYY-MM-DD（幂等键，定稿公式）
    - O_APPEND 单行 JSON：<4KB 原子，无需锁
    """
    _ensure_dir()
    severity = severity.upper()
    if severity not in VALID_SEVERITY:
        raise ValueError(f"severity 必须 ∈ {sorted(VALID_SEVERITY)}，got {severity!r}")
    if not source or not type_ or not title:
        raise ValueError("source/type/title 必填")
    if fingerprint is None:
        fingerprint = f"{source}:{type_}:{datetime.now().strftime(FINGERPRINT_DATE_FMT)}"
    entry = {
        "ts": ts or _now_iso(),
        "source": source,
        "severity": severity,
        "type": type_,
        "fingerprint": fingerprint,
        "title": title,
        "evidence": (evidence or "")[:MAX_EVIDENCE],
        "status": "resolved" if severity == "P2" else "new",
        "card_id": None,
    }
    line = json.dumps(entry, ensure_ascii=False) + "\n"
    if len(line.encode("utf-8")) > 4096:
        # 兜底：仍超 4KB → 压缩 evidence（单行原子写红线）
        cut = len(entry["evidence"]) - 800
        entry["evidence"] = entry["evidence"][:max(cut, 0)] + "…[截断]"
        line = json.dumps(entry, ensure_ascii=False) + "\n"
    with open(BUS_FILE, "a", encoding="utf-8") as f:
        f.write(line)
    return entry


def read_new():
    """返回 status=new 的条目列表（路由 agent 处理对象）。"""
    return [r for r in _load_all() if r.get("status") == "new"]


def mark_routed(fingerprint, card_id):
    """该 fingerprint 的 status=new 条目 → routed + card_id。返回改动的条数。"""
    fh = _lock_exclusive()
    try:
        rows = _load_all()
        n = 0
        for r in rows:
            if r.get("fingerprint") == fingerprint and r.get("status") == "new":
                r["status"] = "routed"
                r["card_id"] = card_id
                n += 1
        if n:
            _write_all(rows)
        return n
    finally:
        fh.close()


def mark_resolved(fingerprint, card_id=None):
    """该 fingerprint 的 new/routed 条目 → resolved。返回改动的条数。"""
    fh = _lock_exclusive()
    try:
        rows = _load_all()
        n = 0
        for r in rows:
            if r.get("fingerprint") == fingerprint and r.get("status") in ("new", "routed"):
                r["status"] = "resolved"
                if card_id is not None:
                    r["card_id"] = card_id
                n += 1
        if n:
            _write_all(rows)
        return n
    finally:
        fh.close()


def count_new():
    rows = read_new()
    fps = sorted({r.get("fingerprint") for r in rows})
    return len(rows), fps


# ---------- CLI ----------
def cmd_append(args):
    entry = append_entry(
        source=args.source,
        severity=args.severity,
        type_=args.type,
        title=args.title,
        evidence=args.evidence or "",
        fingerprint=args.fingerprint,
        ts=args.ts,
    )
    print(f"appended {entry['ts']} {entry['severity']} {entry['fingerprint']} status={entry['status']}")
    return 0


def cmd_read_new(args):
    rows = read_new()
    if args.json:
        for r in rows:
            print(json.dumps(r, ensure_ascii=False))
    else:
        for r in rows:
            print(f"[{r['severity']}] {r['fingerprint']} | {r['title']}")
            if r.get("evidence"):
                print(f"    {r['evidence'][:200]}")
    return 0


def cmd_mark_routed(args):
    n = mark_routed(args.fingerprint, args.card_id)
    print(f"mark_routed: {n} 条 → routed (fingerprint={args.fingerprint}, card={args.card_id})")
    return 0


def cmd_mark_resolved(args):
    n = mark_resolved(args.fingerprint, args.card_id)
    print(f"mark_resolved: {n} 条 → resolved (fingerprint={args.fingerprint})")
    return 0


def cmd_count_new(args):
    n, fps = count_new()
    print(f"new={n}")
    for fp in fps:
        print(fp)
    return 0


def cmd_list(args):
    rows = _load_all()
    if args.status:
        rows = [r for r in rows if r.get("status") == args.status]
    if args.limit:
        rows = rows[-args.limit:]
    for r in rows:
        print(json.dumps(r, ensure_ascii=False))
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="opc-alert-bus", description="OPC 统一告警总线")
    sub = p.add_subparsers(dest="cmd", required=True)

    pa = sub.add_parser("append", help="追加一条告警总线记录（脚本层用）")
    pa.add_argument("--source", required=True, help="来源脚本短名（system-monitor/sched-health/telegram-watchdog/server-monitor/assignee-anomaly）")
    pa.add_argument("--severity", required=True, choices=["P0", "P1", "P2"])
    pa.add_argument("--type", required=True, help="告警类型英文短码（如 disk-root-high）")
    pa.add_argument("--title", required=True)
    pa.add_argument("--evidence", default="")
    pa.add_argument("--fingerprint", default=None, help="默认 source:type:YYYY-MM-DD")
    pa.add_argument("--ts", default=None)
    pa.set_defaults(func=cmd_append)

    pr = sub.add_parser("read_new", help="输出 status=new 条目（路由 agent 用）")
    pr.add_argument("--json", action="store_true", help="输出完整 JSON lines")
    pr.set_defaults(func=cmd_read_new)

    pm = sub.add_parser("mark_routed", help="指纹 → routed + card_id（建卡后回写）")
    pm.add_argument("fingerprint")
    pm.add_argument("card_id")
    pm.set_defaults(func=cmd_mark_routed)

    ps = sub.add_parser("mark_resolved", help="指纹 → resolved（卡 done 后回写）")
    ps.add_argument("fingerprint")
    ps.add_argument("--card-id", default=None)
    ps.set_defaults(func=cmd_mark_resolved)

    pc = sub.add_parser("count_new", help="未处理条数 + 指纹列表")
    pc.set_defaults(func=cmd_count_new)

    pl = sub.add_parser("list", help="调试：列出总线条目")
    pl.add_argument("--status", choices=sorted(VALID_STATUS))
    pl.add_argument("--limit", type=int, default=None)
    pl.set_defaults(func=cmd_list)

    args = p.parse_args(argv)
    try:
        return args.func(args)
    except (OSError, ValueError) as e:
        print(f"opc-alert-bus: 错误: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
