#!/usr/bin/env python3
"""opc-kanban-reopen — OPC 侧「done 卡打回重做」runner（0824b，Hermes 内核解耦外移 2/2）

官方 main 仅有 reopen-review（review 状态打回），无 done/archived → ready/todo 的完整
reopen 语义。OPC 打回语义（Gavin 0822 拍板：验收卡验收不通过必须能打回重做）在 OPC 侧重建：
组合官方 kanban_db 公开函数（_landing_status_after_parents / _append_event / add_comment /
invalidate_descendants_for_parent_reopen / _reclaim_dangling_run / _terminate_reclaimed_worker）
在同一写事务内完成：状态翻转（done/archived → ready/todo，父卡未 done 落 todo）+ reopened 事件
+ legacy status 事件 + REOPENED 评论留痕 + 子树失效（ready/review/running/done 后代 → todo，
running 后代 worker 提交后终止）。语义与 fork 内核 reopen_task（a4b3f4a7f）逐行对齐，
仅在官方 main 缺 reopen_task 时由本脚本在 OPC 侧复刻（fork/main 两份 kanban_db 均含所需公开函数，
签名一致，切换 main 后零改动继续可用）。

红线遵守：不 ALTER kanban.db、不裸写 schema——仅数据级 UPDATE（状态迁移，与内核同 SQL），
事件/评论/子树失效全部走官方公开函数；非 done/archived 目标零副作用返回失败。

用法:
  opc_kanban_reopen.py <task_id> [--reason TEXT] [--author NAME] [--db PATH]
  --db 默认 $KANBAN_DB_PATH 或 /home/gavin/.hermes/kanban/boards/opc/kanban.db
退出码: 0 成功（stdout 单行 JSON）; 1 目标非 done/archived 或不存在（零副作用）; 2 用法/异常
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

try:
    import hermes_cli.kanban_db as kb
except Exception as e:  # pragma: no cover - env 异常
    print(json.dumps({"ok": False, "error": f"kanban_db import failed: {e}"}, ensure_ascii=False))
    sys.exit(2)

DEFAULT_DB = "/home/gavin/.hermes/kanban/boards/opc/kanban.db"


def reopen_one(conn, task_id, *, author, reason):
    """复刻 fork reopen_task：单事务状态翻转 + 事件/评论留痕 + 子树失效。

    Returns (result_dict, error_str) —— error 非空表示零副作用失败。
    """
    now = int(time.time())
    terminations = []
    with kb.write_txn(conn):
        row = conn.execute(
            "SELECT status FROM tasks WHERE id = ?", (task_id,)
        ).fetchone()
        if row is None:
            return None, "任务卡不存在"
        if row["status"] not in ("done", "archived"):
            return None, f"cannot reopen {task_id} (not done/archived?)"
        previous_status = row["status"]
        # 防御性回收泄漏的 run 指针（done/archived 卡通常没有；与 unblock/reopen-review 同路径）
        kb._reclaim_dangling_run(
            conn, task_id, statuses=("done", "archived"), now=now,
            note="invariant recovery on reopen",
        )
        # 落点：全部父卡 done/archived → ready，否则 todo（dispatcher 不得 spawn 上游未完成的卡）
        new_status = kb._landing_status_after_parents(conn, task_id)
        cur = conn.execute(
            "UPDATE tasks SET status = ?, completed_at = NULL, "
            "claim_lock = NULL, claim_expires = NULL, worker_pid = NULL, "
            "current_run_id = NULL, consecutive_failures = 0 "
            "WHERE id = ? AND status IN ('done', 'archived')",
            (new_status, task_id),
        )
        if cur.rowcount != 1:
            return None, f"cannot reopen {task_id} (not done/archived?)"
        payload = {"status": new_status, "previous_status": previous_status}
        if reason:
            payload["reason"] = reason
        kb._append_event(conn, task_id, "reopened", payload)
        # legacy status 事件：现有 live-feed 消费者只渲染 status，无需学习新事件种类
        kb._append_event(
            conn, task_id, "status",
            {
                "status": new_status,
                "requested_status": new_status,
                "previous_status": previous_status,
                "reason": "operator_reopen",
                **({"reason_text": reason} if reason else {}),
            },
        )
        if reason:
            kb.add_comment(conn, task_id, author, f"REOPENED: {reason}")
        # 子树失效：ready/review/running/done 后代 → todo + descendant_invalidated/status 事件
        # + Invalidated 评论；running 后代 run 收尾 reclaimed，worker 严格提交后终止
        result = kb.invalidate_descendants_for_parent_reopen(
            conn, task_id, author=author,
        )
        terminations.extend(result["terminations"])
    for pid, claim_lock in terminations:
        kb._terminate_reclaimed_worker(pid, claim_lock)
    return {
        "new_status": new_status,
        "previous_status": previous_status,
        "invalidated": [inv["id"] for inv in result["invalidated"]],
    }, None


def main():
    ap = argparse.ArgumentParser(description="OPC done-reopen runner")
    ap.add_argument("task_id")
    ap.add_argument("--reason", default=None)
    ap.add_argument("--author", default="opc-api")
    ap.add_argument("--db", default=os.environ.get("KANBAN_DB_PATH") or DEFAULT_DB)
    args = ap.parse_args()

    reason = (args.reason or "").strip() or None
    author = (args.author or "").strip() or "opc-api"

    try:
        with kb.connect_closing(db_path=Path(args.db)) as conn:
            result, err = reopen_one(conn, args.task_id, author=author, reason=reason)
    except Exception as e:  # 内部异常（非目标状态拒绝），报错退出
        print(json.dumps({"ok": False, "error": f"reopen failed: {e}"}, ensure_ascii=False))
        sys.exit(2)

    if err:
        print(json.dumps({"ok": False, "error": err}, ensure_ascii=False))
        sys.exit(1)
    out = {"ok": True, "task_id": args.task_id, **result}
    if reason:
        out["reason"] = reason
    print(json.dumps(out, ensure_ascii=False))
    sys.exit(0)


if __name__ == "__main__":
    main()
