#!/usr/bin/env python3
"""OPC OS — 透明办公室静态页降级补丁生成器

把 company-site/opc 的线上静态页复制进部署包 web/，并打「静态降级」补丁：
部署包环境没有 mrd server（无 /api/opc/stream、/api/opc/demo、/api/token-stats、
/api/assistant、/api/acquisition），页面必须：
  1. 数据只读本地静态文件（status.json / token-stats.json），绝不外连 opc.hermes.cc.cd
     / mrd.hermes.cc.cd（红线：部署包不泄露 OPC 真实内部数据，也不依赖外部服务）
  2. SSE / demo / AI 助理 / 引流数据域 全部降级（隐藏入口或静默失败）
  3. 保持核心能力：透明办公室 canvas + 活动流 + 任务看板 + 治理仪表盘（token/成本/任务/通过率）

用法: python3 patch_static.py [--src /path/to/company-site] [--out /path/to/web]
默认 src=/home/gavin/hermes_space/company-site, out=<本文件所在目录>/../web
"""
import json
import os
import re
import shutil
import sys

# [0826-os-3] 治理仪表盘 token 消耗模块（删 网站访问趋势/引流效果/留言明细 + 注入 token 统计；
# 单一事实源，见 governance_tokens.py；部署副本与 company-site 源重建共用同一变换）
from governance_tokens import transform_governance_html, transform_locale

SRC_DEFAULT = '/home/gavin/hermes_space/company-site'
OUT_DEFAULT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                            '..', 'web'))

# 10 个成员 id 槽位（前端 canvas MEMBER_STATES 固定布局）
SLOT_IDS = ['zhuangzi', 'make', 'anran', 'linjing', 'wenwen', 'qianli',
            'panming', 'ada', 'iris', 'arch']
# 占位头像配色（HSV 均匀分布，无真实成员特征）
SLOT_COLORS = [
    (52, 160, 164), (120, 120, 200), (220, 140, 90), (90, 170, 120),
    (200, 100, 140), (150, 130, 90), (100, 150, 200), (180, 120, 180),
    (130, 160, 100), (250, 140, 120),
]


# 成员真实名 → 演示名映射（脱敏红线：部署包不含 OPC 真实 9 人身份数据）
# 覆盖中文名 + 英文代号（Hermes/Mason/...），用于 index.html / governance.html / 语言包
DEMASK_ZH = {
    '庄子': '演示CEO', '马克': '演示开发', '安然': '演示运维', '林静': '演示营销',
    '温雯': '演示客服', '钱莉': '演示财务', '潘明': '演示情报', '蔡婉': '演示测试',
    '苏木': '演示设计', '昭阳': '演示架构',
}
DEMASK_EN = {
    'Hermes': 'Demo CEO', 'Mason': 'Demo Dev', 'Anchor': 'Demo Ops', 'Echo': 'Demo Mkt',
    'Amber': 'Demo CS', 'Penny': 'Demo Fin', 'Owl': 'Demo Intel', 'Ada': 'Demo QA',
    'Iris': 'Demo UX', 'Michelangelo': 'Demo Arch',
}


def demask(text):
    """把页面/语言包中的 OPC 真实成员名替换为演示名（含 JS 映射表 / MEMBER_STATES /
    canvas 名字 / demo 气泡 / 注释 / 语言包 m1-m9 与决策文案）。"""
    for zh, demo in DEMASK_ZH.items():
        text = text.replace(zh, demo)
    for en, demo in DEMASK_EN.items():
        text = text.replace(en, demo)
    return text


# [31c] 欢迎态 i18n 键（各语言文案；opc 命名空间，注入语言包 JSON）
WELCOME_I18N = {
    'zh': {'welcomeTitle': 'OPC OS 尚未初始化',
           'welcomeSub': '初始化你的 AI 办公室：选择行业模板，生成客户自己的团队。透明办公室将显示你的团队，而不是演示数据。',
           'welcomeHint': '查看 README.md / deploy-guide.md 获取完整初始化指引'},
    'en': {'welcomeTitle': 'OPC OS is not initialized yet',
           'welcomeSub': 'Initialize your AI office: pick an industry template and generate your own team. The transparent office will show your team, not demo data.',
           'welcomeHint': 'See README.md / deploy-guide.md for the full initialization guide'},
    'de': {'welcomeTitle': 'OPC OS ist noch nicht initialisiert',
           'welcomeSub': 'Initialisieren Sie Ihr KI-Büro: Wählen Sie eine Branchenvorlage und generieren Sie Ihr eigenes Team. Das transparente Büro zeigt Ihr Team, keine Demo-Daten.',
           'welcomeHint': 'Vollständige Anleitung: README.md / deploy-guide.md'},
    'fr': {'welcomeTitle': "OPC OS n'est pas encore initialisé",
           'welcomeSub': "Initialisez votre bureau IA : choisissez un modèle sectoriel et générez votre propre équipe. Le bureau transparent affichera votre équipe, pas des données de démo.",
           'welcomeHint': "Guide complet : README.md / deploy-guide.md"},
    'ja': {'welcomeTitle': 'OPC OS はまだ初期化されていません',
           'welcomeSub': 'AIオフィスを初期化してください：業界テンプレートを選んで、顧客自身のチームを生成します。透明オフィスにはデモではなくあなたのチームが表示されます。',
           'welcomeHint': '完全な初期化ガイド: README.md / deploy-guide.md'},
    'ko': {'welcomeTitle': 'OPC OS가 아직 초기화되지 않았습니다',
           'welcomeSub': 'AI 사무실을 초기화하세요: 업종 템플릿을 선택하고 고객만의 팀을 생성합니다. 투명 사무실에는 데모가 아닌 고객 팀이 표시됩니다.',
           'welcomeHint': '전체 초기화 가이드: README.md / deploy-guide.md'},
    'ar': {'welcomeTitle': 'OPC OS لم تتم تهيئته بعد',
           'welcomeSub': 'قم بتهيئة مكتب الذكاء الاصطناعي الخاص بك: اختر قالب قطاع وأنشئ فريقك الخاص. سيعرض المكتب الشفاف فريقك، وليس بيانات تجريبية.',
           'welcomeHint': 'الدليل الكامل: README.md / deploy-guide.md'},
}

# [0826-os-1] 首次登录引导卡片 i18n 键（客户视角三问三答：这是什么/怎么派活/怎么看任务。
# 纯前端一次性引导，localStorage 'opc-guide-v1' 记录已跳过/已看完；12 语言包 + OPC_ZH 兜底）
GUIDE_I18N = {
    'zh': {'guideTitle': '欢迎来到你的 AI 办公室',
           'guideQ1': '这是什么？',
           'guideA1': '你部署了一个 AI 团队办公室——每位成员都是可派遣的 AI 数字员工，像真人同事一样领活、干活、汇报。',
           'guideQ2': '怎么派活？',
           'guideA2': '打开「任务」或工作台，新建一张任务卡指派给某个成员，他认领后会自动开始干活。',
           'guideQ3': '怎么看任务？',
           'guideA3': '看板按「待办 / 进行中 / 受阻 / 完成」分列展示，点卡片可看详情；成员活动实时留痕在右侧活动流。',
           'guideSkip': '跳过',
           'guideStart': '开始使用'},
    'en': {'guideTitle': 'Welcome to your AI office',
           'guideQ1': 'What is this?',
           'guideA1': "You've deployed an AI team office — every member is an AI digital employee who can pick up work, execute, and report like a real colleague.",
           'guideQ2': 'How do I assign work?',
           'guideA2': 'Open Tasks or the workbench, create a task card and assign it to a member. They will claim it and start working automatically.',
           'guideQ3': 'How do I track tasks?',
           'guideA3': 'The board groups tasks into Todo / In Progress / Blocked / Done — click any card for details; every member\'s activity is also logged live in the feed on the right.',
           'guideSkip': 'Skip',
           'guideStart': 'Get started'},
    'de': {'guideTitle': 'Willkommen in Ihrem KI-Büro',
           'guideQ1': 'Was ist das?',
           'guideA1': 'Sie haben ein KI-Teambüro bereitgestellt — jedes Mitglied ist ein KI-Digitalmitarbeiter, der Aufgaben übernehmen, ausführen und berichten kann wie ein echter Kollege.',
           'guideQ2': 'Wie weise ich Arbeit zu?',
           'guideA2': 'Öffnen Sie Aufgaben oder die Workbench, erstellen Sie eine Aufgabenkarte und weisen Sie sie einem Mitglied zu. Es übernimmt die Karte und beginnt automatisch zu arbeiten.',
           'guideQ3': 'Wie verfolge ich Aufgaben?',
           'guideA3': 'Das Board zeigt die Aufgaben in Spalten Offen / In Arbeit / Blockiert / Erledigt — klicken Sie auf eine Karte für Details; die Aktivität jedes Mitglieds wird live im Feed rechts protokolliert.',
           'guideSkip': 'Überspringen',
           'guideStart': 'Loslegen'},
    'fr': {'guideTitle': 'Bienvenue dans votre bureau IA',
           'guideQ1': 'Qu\'est-ce que c\'est ?',
           'guideA1': 'Vous avez déployé un bureau d\'équipe IA — chaque membre est un employé numérique IA capable de prendre des tâches, de les exécuter et de rendre compte comme un vrai collègue.',
           'guideQ2': 'Comment assigner du travail ?',
           'guideA2': 'Ouvrez l\'onglet Tâches ou le workbench, créez une carte et assignez-la à un membre. Il la prendra en charge et commencera à travailler automatiquement.',
           'guideQ3': 'Comment suivre les tâches ?',
           'guideA3': 'Le tableau organise les tâches en colonnes À faire / En cours / Bloqué / Terminé — cliquez sur une carte pour les détails ; l\'activité de chaque membre est journalisée en direct dans le fil de droite.',
           'guideSkip': 'Passer',
           'guideStart': 'Commencer'},
    'ja': {'guideTitle': 'あなたの AI オフィスへようこそ',
           'guideQ1': 'これは何ですか？',
           'guideA1': 'AI チームオフィスをデプロイしました。各メンバーは AI デジタル社員で、実際の同僚のようにタスクを受け取り、実行し、報告できます。',
           'guideQ2': '仕事を割り当てるには？',
           'guideA2': '「タスク」またはワークベンチを開き、タスクカードを作成してメンバーに割り当てます。メンバーが受け取ると自動で作業を開始します。',
           'guideQ3': 'タスクを確認するには？',
           'guideA3': 'ボードは「未着手 / 進行中 / ブロック中 / 完了」の列で表示。カードをクリックすると詳細が見られ、メンバーの活動は右側のフィードにリアルタイムで記録されます。',
           'guideSkip': 'スキップ',
           'guideStart': 'はじめる'},
    'ko': {'guideTitle': 'AI 오피스에 오신 것을 환영합니다',
           'guideQ1': '이것은 무엇인가요?',
           'guideA1': 'AI 팀 오피스를 배포했습니다. 각 멤버는 AI 디지털 직원으로, 실제 동료처럼 업무를 받아 실행하고 보고할 수 있습니다.',
           'guideQ2': '업무를 어떻게 배정하나요?',
           'guideA2': "'태스크' 또는 워크벤치를 열고 작업 카드를 만들어 멤버에게 지정하세요. 멤버가 수락하면 자동으로 작업을 시작합니다.",
           'guideQ3': '작업을 어떻게 확인하나요?',
           'guideA3': "보드는 '대기 / 진행 중 / 차단 / 완료' 열로 표시되며, 카드를 클릭하면 상세를 볼 수 있습니다. 멤버 활동은 오른쪽 피드에 실시간으로 기록됩니다.",
           'guideSkip': '건너뛰기',
           'guideStart': '시작하기'},
    'ar': {'guideTitle': 'مرحبًا بك في مكتب الذكاء الاصطناعي الخاص بك',
           'guideQ1': 'ما هذا؟',
           'guideA1': 'لقد قمت بنشر مكتب فريق ذكاء اصطناعي — كل عضو هو موظف رقمي ذكي يمكنه استلام المهام وتنفيذها وتقديم التقارير مثل زميل حقيقي.',
           'guideQ2': 'كيف أوزّع العمل؟',
           'guideA2': 'افتح «المهام» أو منصة العمل، وأنشئ بطاقة مهمة وخصصها لأحد الأعضاء. سيقوم باستلامها والبدء في العمل تلقائيًا.',
           'guideQ3': 'كيف أتابع المهام؟',
           'guideA3': 'تعرض اللوحة المهام في أعمدة: قيد الانتظار / قيد التنفيذ / معطلة / مكتملة — انقر على أي بطاقة للتفاصيل؛ ويُسجل نشاط كل عضو مباشرة في خلاصة الجانب الأيمن.',
           'guideSkip': 'تخطي',
           'guideStart': 'ابدأ'},
    'ru': {'guideTitle': 'Добро пожаловать в ваш ИИ-офис',
           'guideQ1': 'Что это?',
           'guideA1': 'Вы развернули ИИ-офис команды — каждый участник это ИИ-сотрудник, который может брать задачи, выполнять их и отчитываться как настоящий коллега.',
           'guideQ2': 'Как назначать задачи?',
           'guideA2': 'Откройте вкладку «Задачи» или рабочее место, создайте карточку задачи и назначьте участника. Он примет её и начнёт работать автоматически.',
           'guideQ3': 'Как отслеживать задачи?',
           'guideA3': 'Доска группирует задачи по колонкам: К выполнению / В работе / Заблокировано / Готово — нажмите на карточку для деталей; активность участников пишется в ленту справа в реальном времени.',
           'guideSkip': 'Пропустить',
           'guideStart': 'Начать'},
    'es': {'guideTitle': 'Bienvenido a tu oficina de IA',
           'guideQ1': '¿Qué es esto?',
           'guideA1': 'Has desplegado una oficina de equipo de IA: cada miembro es un empleado digital de IA que puede tomar tareas, ejecutarlas e informar como un colega real.',
           'guideQ2': '¿Cómo asigno trabajo?',
           'guideA2': 'Abre la pestaña Tareas o el workbench, crea una tarjeta de tarea y asígnala a un miembro. La tomará y empezará a trabajar automáticamente.',
           'guideQ3': '¿Cómo hago seguimiento de las tareas?',
           'guideA3': 'El tablero agrupa las tareas en columnas Pendiente / En curso / Bloqueada / Hecha — haz clic en una tarjeta para ver los detalles; la actividad de cada miembro queda registrada en vivo en el feed de la derecha.',
           'guideSkip': 'Saltar',
           'guideStart': 'Empezar'},
    'tr': {'guideTitle': 'AI ofisinize hoş geldiniz',
           'guideQ1': 'Bu nedir?',
           'guideA1': 'Bir AI ekip ofisi kurdunuz — her üye, gerçek bir meslektaş gibi görev alabilen, yürütebilen ve raporlayabilen bir AI dijital çalışandır.',
           'guideQ2': 'İş nasıl atanır?',
           'guideA2': 'Görevler sekmesini veya çalışma masasını açın, bir görev kartı oluşturun ve bir üyeye atayın. Üye kartı devralıp otomatik olarak çalışmaya başlar.',
           'guideQ3': 'Görevler nasıl takip edilir?',
           'guideA3': 'Pano görevleri Bekliyor / Devam ediyor / Engellendi / Tamamlandı sütunlarında gösterir — ayrıntılar için bir karta tıklayın; her üyenin etkinliği sağdaki akışta canlı olarak kaydedilir.',
           'guideSkip': 'Geç',
           'guideStart': 'Başla'},
    'pl': {'guideTitle': 'Witamy w Twoim biurze AI',
           'guideQ1': 'Co to jest?',
           'guideA1': 'Wdrożyłeś biuro zespołu AI — każdy członek to cyfrowy pracownik AI, który może podejmować zadania, wykonywać je i raportować jak prawdziwy współpracownik.',
           'guideQ2': 'Jak przydzielać pracę?',
           'guideA2': 'Otwórz kartę Zadania lub workbench, utwórz kartę zadania i przypisz ją członkowi. Przejmie ją i automatycznie zacznie pracować.',
           'guideQ3': 'Jak śledzić zadania?',
           'guideA3': 'Tablica grupuje zadania w kolumny Do zrobienia / W toku / Zablokowane / Gotowe — kliknij kartę, aby zobaczyć szczegóły; aktywność każdego członka jest na żywo rejestrowana w strumieniu po prawej.',
           'guideSkip': 'Pomiń',
           'guideStart': 'Zacznij'},
    'pt': {'guideTitle': 'Bem-vindo ao seu escritório de IA',
           'guideQ1': 'O que é isto?',
           'guideA1': 'Você implantou um escritório de equipe de IA — cada membro é um funcionário digital de IA que pode assumir tarefas, executá-las e reportar como um colega real.',
           'guideQ2': 'Como atribuo trabalho?',
           'guideA2': 'Abra a aba Tarefas ou o workbench, crie um cartão de tarefa e atribua-o a um membro. Ele assumirá e começará a trabalhar automaticamente.',
           'guideQ3': 'Como acompanho as tarefas?',
           'guideA3': 'O quadro agrupa as tarefas nas colunas A fazer / Em andamento / Bloqueado / Concluído — clique em um cartão para ver os detalhes; a atividade de cada membro é registrada ao vivo no feed à direita.',
           'guideSkip': 'Pular',
           'guideStart': 'Começar'},
}


def inject_welcome_i18n(content, filename):
    """把 OPC-OS 专属键（欢迎态 + 首次登录引导卡）注入语言包 JSON（幂等：已有键则跳过）。
    未命中的语言保留英文兜底。"""
    lang = os.path.basename(filename)[:2]
    try:
        data = json.loads(content)
    except Exception:
        return content
    opc = data.setdefault('opc', {})
    changed = False
    for marker, table in (('welcomeTitle', WELCOME_I18N), ('guideTitle', GUIDE_I18N)):
        if marker in opc:
            continue   # 幂等：该组键已注入
        words = table.get(lang, table['en'])
        for k, v in words.items():
            opc[k] = v
        changed = True
    if not changed:
        return content
    return json.dumps(data, ensure_ascii=False, indent=2) + '\n'


def patch_index(html):
    """opc/index.html 降级补丁。"""
    # 1. STATUS_URL → 本地静态文件（降级轮询的主数据通道；status.json 在卷子路径 /opc/data/）
    # P0-1 拆分: 源页面已切 opc 域, 匹配串同步更新
    html = html.replace(
        "var STATUS_URL = 'https://opc.hermes.cc.cd/api/opc/status.json';",
        "var STATUS_URL = './data/status.json';")
    # 2. STATIC_MODE：不建 SSE，直接走 60s 慢轮询（无 404 重连噪音）
    html = html.replace(
        "  function startGlobalStream() {\n"
        "    if (globalES) { try { globalES.close(); } catch (e) {} globalES = null; }",
        "  function startGlobalStream() {\n"
        "    if (window.OPC_STATIC) { startFallbackPolling(); return; }\n"
        "    if (globalES) { try { globalES.close(); } catch (e) {} globalES = null; }")
    # 3. 隐藏「访客体验」tab 与「体验一下」按钮（demo 依赖 mrd server 派活）
    html = html.replace(
        '<button class="tab-btn" data-tab="demo" aria-selected="false">',
        '<button class="tab-btn" data-tab="demo" aria-selected="false" style="display:none">')
    html = html.replace(
        '<button class="demo-btn" id="demoBtn"',
        '<button class="demo-btn" id="demoBtn" style="display:none"')
    # 4. API base → 本地（埋点/反馈打到本地 404 静默，不外连）
    html = html.replace("var API = 'https://mrd.hermes.cc.cd';", "var API = '';")
    # 4b. P0-2: 官网后台拆分后反馈走 api 域, 部署包同样置空（不外连 api.hermes.cc.cd）
    html = html.replace("var API_FB = 'https://api.hermes.cc.cd';", "var API_FB = '';")
    html = html.replace("fetch('https://api.hermes.cc.cd/api/assistant'", "fetch(''")
    # 4c. [0825-e] LLM 网关透明度区块：数据源降级到本地静态文件（collector 同步
    #     /data/llm-gateway.json → web 卷 /opc/data/llm-gateway.json）。必须在兜底
    #     https://opc.hermes.cc.cd 替换之前执行，否则会被清成 /api/opc/llm-gateway.json（404）。
    html = html.replace(
        "var GW_URL = 'https://opc.hermes.cc.cd/api/opc/llm-gateway.json';",
        "var GW_URL = './data/llm-gateway.json';")
    # 5. 兜底：任何残余 opc/mrd/api 绝对 URL → 本地相对路径（demo/assistant 请求 404 静默，
    #    部署包环境绝不外连 OPC 线上服务，红线：不泄露真实数据、不依赖外部）
    html = html.replace('https://opc.hermes.cc.cd', '')
    html = html.replace('https://mrd.hermes.cc.cd', '')
    html = html.replace('https://api.hermes.cc.cd', '')
    # 6. [31c] 欢迎态引导页：status.json init_state=uninitialized → 显示「未初始化」引导页
    #    （替代软件公司 demo/空办公室）。仅部署包版注入，company-site 官网源零改动
    #    （官网 self 形态永远 initialized，不需要引导页）。
    if '<body>' in html and 'function applyStatus(d) {' in html:
        # 6a. body 开头注入欢迎态 DOM（默认隐藏；文案 data-i18n + 原文兜底）
        welcome_dom = (
            '<div id="opcWelcome" class="opc-welcome" style="display:none">'
            '<div class="opc-welcome-card">'
            '<div class="opc-welcome-logo">OPC</div>'
            '<h2 data-i18n="opc.welcomeTitle">OPC OS 尚未初始化</h2>'
            '<p data-i18n="opc.welcomeSub">初始化你的 AI 办公室：选择行业模板，生成客户自己的团队。透明办公室将显示你的团队，而不是演示数据。</p>'
            '<ol class="opc-welcome-steps">'
            '<li><code>docker compose run --rm init --template manufacturing --name "公司名"</code></li>'
            '<li><code>docker compose up -d --build</code></li>'
            '</ol>'
            '<p class="opc-welcome-hint" data-i18n="opc.welcomeHint">查看 README.md / deploy-guide.md 获取完整初始化指引</p>'
            '</div></div>'
        )
        # [0826-os-1] 首次登录引导卡片 DOM + 引导脚本（一次性；localStorage 'opc-guide-v1' 记忆，
        # ?view=visitor 只读旁观不弹；z-index 1000 高于欢迎态 999，未初始化欢迎态上同样可跳过）
        guide_dom = (
            '<div id="opcGuide" class="opc-guide" style="display:none" role="dialog" aria-modal="true" aria-label="Welcome guide">'
            '<div class="opc-guide-card">'
            '<button type="button" class="opc-guide-skip" id="opcGuideSkip" data-i18n="opc.guideSkip">跳过</button>'
            '<div class="opc-guide-logo">OPC OS</div>'
            '<h2 data-i18n="opc.guideTitle">欢迎来到你的 AI 办公室</h2>'
            '<div class="opc-guide-qa">'
            '<div class="opc-guide-item"><div class="opc-guide-q" data-i18n="opc.guideQ1">这是什么？</div>'
            '<div class="opc-guide-a" data-i18n="opc.guideA1">你部署了一个 AI 团队办公室——每位成员都是可派遣的 AI 数字员工，像真人同事一样领活、干活、汇报。</div></div>'
            '<div class="opc-guide-item"><div class="opc-guide-q" data-i18n="opc.guideQ2">怎么派活？</div>'
            '<div class="opc-guide-a" data-i18n="opc.guideA2">打开「任务」或工作台，新建一张任务卡指派给某个成员，他认领后会自动开始干活。</div></div>'
            '<div class="opc-guide-item"><div class="opc-guide-q" data-i18n="opc.guideQ3">怎么看任务？</div>'
            '<div class="opc-guide-a" data-i18n="opc.guideA3">看板按「待办 / 进行中 / 受阻 / 完成」分列展示，点卡片可看详情；成员活动实时留痕在右侧活动流。</div></div>'
            '</div>'
            '<div class="opc-guide-foot"><button type="button" class="opc-guide-btn" id="opcGuideStart" data-i18n="opc.guideStart">开始使用</button></div>'
            '</div></div>'
            '<script>(function(){try{'
            "if(new URLSearchParams(location.search).get('view')==='visitor')return;"
            "var K='opc-guide-v1',done=null;try{done=localStorage.getItem(K);}catch(e){}"
            "var c=document.getElementById('opcGuide');if(done==='1'||!c)return;"
            "c.style.display='flex';"
            "function dismiss(){try{localStorage.setItem(K,'1');}catch(e){}c.style.display='none';}"
            "var s=document.getElementById('opcGuideSkip'),b=document.getElementById('opcGuideStart');"
            "if(s)s.addEventListener('click',dismiss);if(b)b.addEventListener('click',dismiss);"
            '}catch(e){}})();</script>'
        )
        html = html.replace('<body>\n<div class="wrap">',
                            '<body>\n' + welcome_dom + '\n' + guide_dom + '\n<div class="wrap">', 1)
        # 6b. CSS（欢迎态卡片样式，注入到 </style> 前最后一个）
        welcome_css = (
            '\n/* [31c] 欢迎态引导页 */\n'
            '.opc-welcome{position:fixed;inset:0;z-index:999;display:flex;align-items:center;'
            'justify-content:center;background:var(--bg,#f6f7fb);padding:20px;}\n'
            '.opc-welcome-card{max-width:560px;width:100%;background:var(--card,#fff);'
            'border:1px solid var(--border,#e5e7eb);border-radius:18px;padding:36px 32px;'
            'box-shadow:0 12px 40px rgba(0,0,0,.08);}\n'
            '.opc-welcome-logo{font-size:13px;font-weight:700;letter-spacing:2px;'
            'color:var(--accent,#7c3aed);margin-bottom:12px;}\n'
            '.opc-welcome-card h2{margin:0 0 10px;font-size:22px;color:var(--fg,#111827);}\n'
            '.opc-welcome-card p{margin:0 0 16px;color:var(--muted,#6b7280);font-size:14px;line-height:1.7;}\n'
            '.opc-welcome-steps{margin:0 0 14px;padding-left:20px;color:var(--fg,#111827);font-size:13.5px;}\n'
            '.opc-welcome-steps li{margin-bottom:8px;}\n'
            '.opc-welcome-steps code,.opc-welcome-hint code{background:var(--code-bg,#f3f4f6);'
            'padding:2px 6px;border-radius:5px;font-size:12.5px;}\n'
            '.opc-welcome-hint{font-size:12px;color:var(--muted,#9ca3af);}\n'
        )
        # [0826-os-1] 首次登录引导卡片样式（沿用欢迎态/卡片 slate 灰阶 + 主题变量，不另起风格）
        guide_css = (
            '\n/* [0826-os-1] 首次登录引导卡片 */\n'
            '.opc-guide{position:fixed;inset:0;z-index:1000;display:flex;align-items:center;'
            'justify-content:center;background:rgba(15,23,42,.45);padding:20px;}\n'
            '.opc-guide-card{position:relative;max-width:520px;width:100%;background:var(--card,#fff);'
            'border:1px solid var(--border,#e5e7eb);border-radius:18px;padding:30px 28px 26px;'
            'box-shadow:0 12px 40px rgba(0,0,0,.12);}\n'
            '.opc-guide-skip{position:absolute;top:12px;inset-inline-end:14px;border:0;background:none;'
            'color:var(--muted,#9ca3af);font-size:12.5px;cursor:pointer;padding:4px 8px;border-radius:6px;}\n'
            '.opc-guide-skip:hover{color:var(--fg,#111827);background:var(--code-bg,#f3f4f6);}\n'
            '.opc-guide-logo{font-size:12px;font-weight:700;letter-spacing:2px;'
            'color:var(--accent,#7c3aed);margin-bottom:10px;}\n'
            '.opc-guide-card h2{margin:0 0 18px;font-size:20px;color:var(--fg,#111827);}\n'
            '.opc-guide-qa{display:flex;flex-direction:column;gap:12px;}\n'
            '.opc-guide-item{border:1px solid var(--border,#e5e7eb);border-radius:12px;'
            'padding:12px 14px;background:var(--bg,#f6f7fb);}\n'
            '.opc-guide-q{font-size:14px;font-weight:600;color:var(--fg,#111827);margin-bottom:4px;}\n'
            '.opc-guide-a{font-size:13px;color:var(--muted,#6b7280);line-height:1.65;}\n'
            '.opc-guide-foot{margin-top:20px;display:flex;justify-content:flex-end;}\n'
            '.opc-guide-btn{border:0;background:var(--accent,#7c3aed);color:#fff;font-size:14px;'
            'font-weight:600;padding:9px 22px;border-radius:10px;cursor:pointer;}\n'
            '.opc-guide-btn:hover{filter:brightness(1.08);}\n'
            '@media (max-width:640px){.opc-guide-card{padding:24px 20px 22px;}'
            '.opc-guide-card h2{font-size:18px;}.opc-guide-btn{width:100%;justify-content:center;}}\n'
        )
        html = html.replace('</style>', welcome_css + guide_css + '</style>', 1)
        # 6c. OPC_ZH 平铺键注入（i18n 兜底：语言包未加载/缺键时欢迎态+引导卡文案不显示裸 key）
        zh_keys = (
            '"welcomeTitle": "OPC OS 尚未初始化",\n'
            '  "welcomeSub": "初始化你的 AI 办公室：选择行业模板，生成客户自己的团队。透明办公室将显示你的团队，而不是演示数据。",\n'
            '  "welcomeHint": "查看 README.md / deploy-guide.md 获取完整初始化指引",\n'
            '  "guideTitle": "欢迎来到你的 AI 办公室",\n'
            '  "guideSkip": "跳过",\n'
            '  "guideStart": "开始使用",\n'
            '  "guideQ1": "这是什么？",\n'
            '  "guideA1": "你部署了一个 AI 团队办公室——每位成员都是可派遣的 AI 数字员工，像真人同事一样领活、干活、汇报。",\n'
            '  "guideQ2": "怎么派活？",\n'
            '  "guideA2": "打开「任务」或工作台，新建一张任务卡指派给某个成员，他认领后会自动开始干活。",\n'
            '  "guideQ3": "怎么看任务？",\n'
            '  "guideA3": "看板按「待办 / 进行中 / 受阻 / 完成」分列展示，点卡片可看详情；成员活动实时留痕在右侧活动流。",\n'
        )
        html = html.replace('  var OPC_ZH = {\n', '  var OPC_ZH = {\n  ' + zh_keys, 1)
        # 6d. applyStatus 入口：uninitialized → 显示引导页；否则隐藏（恢复正常渲染）
        old_apply = "  function applyStatus(d) {\n    if (!d || !Array.isArray(d.members)) return;"
        new_apply = (
            "  // [31c] 欢迎态：status.json init_state=uninitialized → 显示初始化引导页（非 demo/空办公室）\n"
            "  function showWelcomeInit() {\n"
            "    var w = document.getElementById('opcWelcome');\n"
            "    var wrap = document.querySelector('.wrap');\n"
            "    if (w) w.style.display = 'flex';\n"
            "    if (wrap) wrap.style.display = 'none';\n"
            "  }\n"
            "  function hideWelcomeInit() {\n"
            "    var w = document.getElementById('opcWelcome');\n"
            "    var wrap = document.querySelector('.wrap');\n"
            "    if (w) w.style.display = 'none';\n"
            "    if (wrap) wrap.style.display = '';\n"
            "  }\n"
            "  function applyStatus(d) {\n"
            "    if (!d || !Array.isArray(d.members)) return;\n"
            "    if (d.init_state === 'uninitialized') { showWelcomeInit(); return; }\n"
            "    hideWelcomeInit();"
        )
        if old_apply in html:
            html = html.replace(old_apply, new_apply, 1)
        else:
            print('⚠️  欢迎态 applyStatus 补丁未命中（源码结构可能已变，请人工核对）', file=sys.stderr)
        # 6e. 新增 i18n 键 → 递增 __I18N_VER（防止语言包缓存）。幂等性成立：每次重跑都
        #     从 company-site 源重读（源固定官方版 V），副本恒为 V+1（欢迎态+引导卡键增量），
        #     重跑不会继续累加——因为 +1 永远作用在源版号上。
        m = re.search(r'window\.__I18N_VER = (\d+);', html)
        if m:
            html = html.replace(m.group(0), f'window.__I18N_VER = {int(m.group(1)) + 1};', 1)
    else:
        print('⚠️  欢迎态注入锚点缺失（<body> 或 applyStatus 未找到），跳过欢迎态补丁', file=sys.stderr)
    return html


def patch_governance(html):
    """opc/governance.html 降级补丁。"""
    # 1. token-stats 只读本地（去掉 opc API 主源 + fallback 链，防外连泄露真实数据）
    old_load = (
        "    return fetch('https://opc.hermes.cc.cd/api/token-stats')\n"
        "      .then(function (r) { if (!r.ok) throw new Error('http ' + r.status); return r.json(); })\n"
        "      .then(function (j) { return j && j.ok ? j.data : j; })\n"
        "      .catch(function () {\n"
        "        return fetch('./token-stats.json').then(function (r) { if (!r.ok) throw new Error('fallback http ' + r.status); return r.json(); })\n"
        "          .then(function (j) { return j && j.data ? j.data : j; });\n"
        "      });")
    new_load = (
        "    // 静态降级（OPC OS 部署包）：只读本地 JSON，不外连 mrd API\n"
        "    return fetch('./data/token-stats.json').then(function (r) { if (!r.ok) throw new Error('http ' + r.status); return r.json(); })\n"
        "      .then(function (j) { return j && j.data ? j.data : j; });")
    if old_load not in html:
        print('⚠️  governance load() 补丁未命中（源码结构可能已变，请人工核对）', file=sys.stderr)
    else:
        html = html.replace(old_load, new_load)
    # 2. 引流数据域 → 本地不存在路径（404 → 骨架空态，不红条；不外连真实数据）
    html = html.replace(
        "return fetch('https://opc.hermes.cc.cd/api/acquisition')",
        "return fetch('./data/acquisition.json')  // 静态降级：本地无此文件 → 骨架空态")
    # 3. 访问趋势数据域 → 本地不存在路径（404 → 显式空态「数据采集中」；不外连真实数据）
    old_trends = (
        "    return fetch('https://opc.hermes.cc.cd/api/trends?days=30')\n"
        "      .then(function (r) { if (!r.ok) throw new Error('http ' + r.status); return r.json(); })\n"
        "      .then(function (j) { return j && j.ok ? j.data : j; })\n"
        "      .catch(function () {\n"
        "        return fetch('./trends.json').then(function (r) { if (!r.ok) throw new Error('fallback http ' + r.status); return r.json(); })\n"
        "          .then(function (j) { return j && j.data ? j.data : j; });\n"
        "      });")
    new_trends = (
        "    // 静态降级（OPC OS 部署包）：只读本地 JSON，本地无此文件 → 显式空态\n"
        "    return fetch('./data/trends.json').then(function (r) { if (!r.ok) throw new Error('http ' + r.status); return r.json(); })\n"
        "      .then(function (j) { return j && j.data ? j.data : j; });")
    if old_trends not in html:
        print('⚠️  governance loadTrends() 补丁未命中（源码结构可能已变，请人工核对）', file=sys.stderr)
    else:
        html = html.replace(old_trends, new_trends)
    # 4. 留言/咨询明细数据域（0822-t1e）→ API base 置空（静态包无 opc-api 后端：
    #    登录校验 /api/kanban/tasks 与明细读取 /api/trends/messages 404 降级，绝不外连真实数据）
    html = html.replace(
        "var MSG_API = 'https://opc.hermes.cc.cd';",
        "var MSG_API = '';")
    # 5. [0826-os-3] Gavin 拍板：删「网站访问趋势/引流效果」两区块 + 留言明细抽屉（唯一入口是
    #    流量 KPI 卡，区块删除后为不可达死代码），新增「token 消耗统计」模块（本地 token-stats 数据）。
    #    统一走 governance_tokens.transform_governance_html（单一事实源，含 i18n 键清理 + __I18N_VER 递增）
    html = transform_governance_html(html)
    return html


# canvas 房间素材（index.html BASE='/opc/img/' 加载；缺图 → canvas 静默降级无贴图）
ROOM_ASSETS = ('floor.png', 'lounge.png', 'meeting.png',
               'desk-1.png', 'desk-2.png', 'desk-3.png')


def copy_room_assets(src_opc_img, out_img):
    """拷贝透明办公室 canvas 房间素材 PNG 到 out/img/（与 avatars 平级）。

    素材源 = company-site/opc/img/（生产站同款演示素材，无真实成员特征）。
    部署包缺这些图 → Image 加载失败 → canvas 静默降级（lounge/floor 不画、
    meeting/desk 走几何兜底），用户看到「房间没贴图」。
    """
    os.makedirs(out_img, exist_ok=True)
    copied = 0
    for name in ROOM_ASSETS:
        srcf = os.path.join(src_opc_img, name)
        if os.path.exists(srcf):
            shutil.copy2(srcf, os.path.join(out_img, name))
            copied += 1
        else:
            print(f'⚠️  房间素材缺失: {srcf}', file=sys.stderr)
    print(f'[patch] 房间素材拷贝: {out_img} ({copied} 张)')
    return copied


def gen_avatar_jpgs(out_avatars):
    """PIL 生成 10 张纯色渐变占位头像 JPEG（无文字、无真实成员特征）。"""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print('⚠️  PIL 不可用，跳过占位头像生成（页面将以灰块 fallback 显示）', file=sys.stderr)
        return False
    os.makedirs(out_avatars, exist_ok=True)
    for i, aid in enumerate(SLOT_IDS):
        r, g, b = SLOT_COLORS[i]
        size = 160
        img = Image.new('RGB', (size, size))
        dr = ImageDraw.Draw(img)
        # 对角渐变（左上亮 → 右下暗）
        for y in range(size):
            f = y / size
            row = (int(r * (1 - 0.35 * f)), int(g * (1 - 0.35 * f)), int(b * (1 - 0.35 * f)))
            dr.line([(0, y), (size, y)], fill=row)
        # 白色圆环（成员圆头像样式）
        cx = cy = size // 2
        rad = size // 2 - 6
        dr.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], outline=(255, 255, 255), width=6)
        path = os.path.join(out_avatars, f'{aid}.jpg')
        img.save(path, 'JPEG', quality=90)
    print(f'[patch] 占位头像生成: {out_avatars} ({len(SLOT_IDS)} 张)')
    return True


# [0826-os-2] 底部「Powered by Gavin's Lab」回传脚本引用（部署包专属，官网源零改动；
# footer.js 为 opc-os 原生文件，位于 web/opc/footer.js，随 web/ 整目录进镜像）
FOOTER_TAG = '<script src="/opc/footer.js"></script>'


def inject_footer(html):
    """在 </body> 前注入 footer.js 引用（幂等：已注入则跳过）。"""
    if FOOTER_TAG in html:
        return html
    if '</body>' in html:
        return html.replace('</body>', FOOTER_TAG + '\n</body>', 1)
    print('⚠️  footer.js 注入锚点缺失（</body> 未找到），跳过', file=sys.stderr)
    return html


def main():
    src = SRC_DEFAULT
    out = OUT_DEFAULT
    args = sys.argv[1:]
    if '--src' in args:
        src = args[args.index('--src') + 1]
    if '--out' in args:
        out = args[args.index('--out') + 1]

    src_opc = os.path.join(src, 'opc')
    if not os.path.isdir(src_opc):
        print(f'❌ 源目录不存在: {src_opc}', file=sys.stderr)
        sys.exit(1)

    os.makedirs(os.path.join(out, 'opc'), exist_ok=True)
    os.makedirs(os.path.join(out, 'img', 'avatars'), exist_ok=True)
    os.makedirs(os.path.join(out, 'locales'), exist_ok=True)

    # 1. opc 页面补丁 + 脱敏（真实成员名 → 演示名）
    for fname in ('index.html', 'governance.html'):
        fpath = os.path.join(src_opc, fname)
        if not os.path.exists(fpath):
            print(f'⚠️  源文件缺失: {fpath}', file=sys.stderr)
            continue
        with open(fpath, encoding='utf-8') as f:
            html = f.read()
        html = patch_index(html) if fname == 'index.html' else patch_governance(html)
        html = demask(html)
        # [0826-os-2] 底部 Powered by footer 回传脚本引用（部署包专属，官网源零改动）
        html = inject_footer(html)
        with open(os.path.join(out, 'opc', fname), 'w', encoding='utf-8') as f:
            f.write(html)
        print(f'[patch] {fname} → web/opc/{fname}（降级补丁 + 脱敏已应用）')

    # 2. 语言包（复制 + 脱敏成员名 + [31c] 欢迎态键注入）
    src_loc = os.path.join(src, 'locales')
    if os.path.isdir(src_loc):
        for lf in sorted(os.listdir(src_loc)):
            if lf.endswith('.json'):
                with open(os.path.join(src_loc, lf), encoding='utf-8') as f:
                    content = f.read()
                content = demask(content)
                # [31c] 欢迎态 i18n 键注入（welcomeTitle/welcomeSub/welcomeHint，opc 命名空间）
                content = inject_welcome_i18n(content, lf)
                # [0826-os-3] 治理 i18n 键变换：删 governance.trends/acquisition/messages，加 governance.tokens
                content = transform_locale(content, lf)
                with open(os.path.join(out, 'locales', lf), 'w', encoding='utf-8') as f:
                    f.write(content)
        print(f'[patch] 语言包复制+脱敏+欢迎态键: {len(os.listdir(out + "/locales"))} 个')

    # 3. 占位头像（不复制真实成员照片）
    gen_avatar_jpgs(os.path.join(out, 'img', 'avatars'))

    # 3b. 房间素材（canvas 贴图：floor/lounge/meeting/desk-*.png；0826-osv-2a：
    #     Gavin sandbox1 实测「房间 canvas 没贴图」根因=部署包缺素材）
    #     拷两份：out/img/（与 avatars 平级，素材归属） + out/opc/img/
    #     （canvas BASE='/opc/img/' 的实际加载路径——web 静态 root=web/，
    #      /opc/img/* 解析到 web/opc/img/，只放 web/img/ 会 404 依旧无贴图）
    copy_room_assets(os.path.join(src_opc, 'img'), os.path.join(out, 'img'))
    copy_room_assets(os.path.join(src_opc, 'img'), os.path.join(out, 'opc', 'img'))

    # 4. 公共组件文件（0822-a：ui.js/ui.css 纯静态文件，无成员名，不需 demask；
    #    公共 markdown 渲染器 renderMarkdown 与复制按钮样式必须进部署包副本）
    for uf in ('ui.js', 'ui.css'):
        srcf = os.path.join(src, uf)
        if os.path.exists(srcf):
            shutil.copy2(srcf, os.path.join(out, uf))
            print(f'[patch] {uf} → web/{uf}（公共组件副本）')
        else:
            print(f'⚠️  源文件缺失: {srcf}', file=sys.stderr)

    print(f'[patch] 完成: {out}')


if __name__ == '__main__':
    main()
