#!/usr/bin/env node
'use strict';
// OPC-OS — web 静态服务（原生进程化版，替代 nginx 容器；0826-osv-1 Gavin 拍板去 docker）
//
// 职责（与 entrypoint_web.sh + nginx 语义对齐，零 npm 依赖）：
//   - 静态文件服务：WEB_ROOT（默认 <repo>/web）→ /opc/index.html、governance.html、
//     workbench.html、ui.css、ui.js、locales/、img/ 等
//   - 数据映射：/opc/data/* → OPC_DATA_DIR（默认 <repo>/web/opc/data；install-services.sh
//     传 OPC_INIT_OUT 输出目录）——对应容器形态 bind 卷 <out> → nginx html/opc/data
//   - / 301 → /opc/（对齐 nginx 默认 server 块，smoke_test 依赖该语义）
//   - /healthz → 200 ok（容器形态 nginx 健康检查等价物）
//   - MIME 类型表（html/css/js/json/svg/png/jpg/ico/woff2 等），默认 application/octet-stream
//
// 用法：PORT=8081 WEB_ROOT=<repo>/web OPC_DATA_DIR=<out> node scripts/web-serve.js
// 守护：systemd unit（opcos-web.service）或 install-services.sh --no-systemd 的 nohup 模式

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.PORT || '8081', 10);
const WEB_ROOT = path.resolve(process.env.WEB_ROOT || path.join(__dirname, '..', 'web'));
const OPC_DATA_DIR = path.resolve(process.env.OPC_DATA_DIR || path.join(WEB_ROOT, 'opc', 'data'));

// clean-URL 白名单（0826-osv-2c）：无扩展名语义页 → 实际 html 文件，与 CF Pages 生产路由语义一致。
// 命中 → 直接服务目标 html（200）；未命中 → 走下方静态映射，未知路径保持 404（禁 SPA 兜底，
// 避免误伤 /opc/data、/healthz、静态资源）。目录 /opc/ 已有 index.html 逻辑，不重复处理。
const CLEAN_URLS = {
  '/opc/workbench': '/opc/workbench.html',
  '/opc/governance': '/opc/governance.html',
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

// 防目录穿越：归一化后必须落在 root 内
function safeJoin(root, rel) {
  const target = path.normalize(path.join(root, rel));
  if (target !== root && !target.startsWith(root + path.sep)) return null;
  return target;
}

function send(res, code, body, type) {
  res.writeHead(code, {
    'Content-Type': type || 'text/plain; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function serveFile(res, filePath) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      send(res, 404, '404 Not Found\n', 'text/plain; charset=utf-8');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': 'no-cache',
    });
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  let urlPath;
  try {
    urlPath = decodeURIComponent(new URL(req.url, `http://127.0.0.1:${PORT}`).pathname);
  } catch (e) {
    return send(res, 400, '400 Bad Request\n');
  }

  if (urlPath === '/healthz') return send(res, 200, 'ok\n');

  // 数据映射：/opc/data/* → OPC_DATA_DIR（先于静态目录，覆盖仓库内 web/opc/data 残留）
  const dataPrefix = '/opc/data/';
  if (urlPath === '/opc/data' || urlPath.startsWith(dataPrefix)) {
    const rel = urlPath === '/opc/data' ? '' : urlPath.slice(dataPrefix.length);
    const target = safeJoin(OPC_DATA_DIR, rel);
    if (!target) return send(res, 403, '403 Forbidden\n');
    return serveFile(res, target);
  }

  // 根路径 → /opc/（nginx 301 语义，smoke_test 依赖）
  if (urlPath === '/') {
    res.writeHead(301, { Location: '/opc/' });
    return res.end();
  }

  // clean-URL 重写（0826-osv-2c，放在 /opc/data 数据路由之后、静态映射之前）
  const cleanTarget = CLEAN_URLS[urlPath];
  if (cleanTarget) {
    const cleanPath = safeJoin(WEB_ROOT, cleanTarget);
    if (!cleanPath) return send(res, 403, '403 Forbidden\n');
    return serveFile(res, cleanPath);
  }

  const target = safeJoin(WEB_ROOT, urlPath);
  if (!target) return send(res, 403, '403 Forbidden\n');

  fs.stat(target, (err, st) => {
    if (!err && st.isDirectory()) {
      // 目录 → 找 index.html（/opc/ → /opc/index.html）
      const idx = path.join(target, 'index.html');
      return fs.stat(idx, (err2) => {
        if (err2) return send(res, 403, '403 Forbidden\n');
        serveFile(res, idx);
      });
    }
    serveFile(res, target);
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[web-serve] listening on http://127.0.0.1:${PORT}`);
  console.log(`[web-serve] web_root=${WEB_ROOT}`);
  console.log(`[web-serve] opc_data_dir=${OPC_DATA_DIR}`);
});
