#!/usr/bin/env python3
"""OPC OS — 数据采集脚本（参数化版）

扫描成员 profile 的运行痕迹（cron 输出 + delegation 记录 + kanban + state.json）
→ 生成 status.json（透明办公室/治理仪表盘数据源）。

零本机硬编码：所有 profile 名册 / CRON_MEMBER 映射 / 路径 / 角色表从 config.json 读取
（见 lib_config.py）。换机器部署 = 复制 config.json 改 paths 即可，脚本本身不动。

数据源（全本地，无外部 API）：
  1. <hermes_home>/profiles/<p>/cron/output/*/*.md   —— 成员 cron 运行痕迹
  2. <hermes_home>/cache/delegation/live 及各 profile 的 delegation —— delegate 派活痕迹
  3. kanban.db（tasks/task_runs）—— 任务产出/领活（只读）
  4. state.json —— 团队名册/指标（单一事实来源）

用法: python3 opc_collect.py [--config <path>]
输出: status.json（out_status；可选第二副本 out_status_secondary）
成功静默（供 cron watchdog 使用），失败打印错误并退出非 0。
"""
import json
import os
import time
import datetime
import re
import sqlite3
import sys
import glob
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib_config import get_cfg

CFG = get_cfg()
P = CFG['paths']

HOME = P['hermes_home']
OPC_DIR = P['opc_dir']
OUT_PUBLIC = P['out_status']
OUT_DIST = P['out_status_secondary']

# 成员 profile（config.json PROFILES 可配，换机器/换团队改配置即可）
PROFILES = CFG['profiles']
CRON_MEMBER = CFG['cron_member']
NAME_ID = CFG['name_id']
NAME_EN = CFG['name_en']
ROLES = CFG['roles']
ROLE_EN = CFG['role_en']

KANBAN_DB = P['kanban_db']
DEMO_KANBAN_DB = P.get('demo_kanban_db') or ''
# 27c 协调协议：bus 水位线文件（与 opc-bus.py 同源：config.json bus 段 → 默认 <opc_dir>/bus-state.json）
BUS_STATE = (CFG.get('bus') or {}).get('bus_state_file') or os.path.join(P['opc_dir'], 'bus-state.json')
TITLE_MAX = 60
PROFILE_NAME = {v: k for k, v in NAME_ID.items()}
# 兜底演示名 = 名册首项（config.json 已脱敏为「演示X」；禁止写死真人名，防真实数据接入后污染输出）
DEFAULT_NAME = next(iter(NAME_ID))
DONE_TITLE_MAX = 40
RUNNING_SINCE = CFG.get('running_since', '2026-08-12')

# ── 3a 状态机（0823-吸收-3a，庄子拍板，worker 不得另定；与运行版 opc_collect.py 同口径）──
# 6 态：working / searching / writing / awaiting / blocked / idle。
# 诚实原则：能用现有字段推导什么就显示什么，推导不出就 idle，绝不编造状态。
_TITLE_PREFIX_CATEGORY = {
    'feature': 'coding', 'bug': 'coding',
    '内容': 'writing', '情报': 'writing',
    'ops': 'monitoring', '监控': 'monitoring',
    '验收': 'testing',
    '客服': 'support',
    '财务': 'finance',
    'chore': 'ops',
}
# 类别 → state 细分：仅 writing 有专属状态（【内容】/【情报】→writing）；
# searching 无工具级钩子数据（不强区分，不编造），其余类别归 working
_CATEGORY_STATE = {
    'coding': 'working', 'writing': 'writing', 'monitoring': 'working',
    'testing': 'working', 'support': 'working', 'finance': 'working',
    'ops': 'working',
}
# 类别 → state_detail 文案前缀（+「：标题」，总长 ≤40 字；无匹配用「执行中」）
_CATEGORY_DETAIL = {
    'coding': '正在写代码', 'writing': '正在写作', 'monitoring': '监控中',
    'testing': '测试中', 'support': '客服处理中', 'finance': '财务处理中',
    'ops': '运维中',
}
_STATE_DETAIL_MAX = 40   # state_detail 截断长度（决策第 4 点，≤40 字）
_HB_FRESH_SECONDS = 120  # 心跳新鲜窗口：run.last_heartbeat_at 距今 <120s → working（决策第 3 点）


def _title_prefix_category(title):
    """标题【前缀】→ 动作类别（决策第 2 点）；无匹配返回 None。"""
    for tag in re.findall(r'【([^】]+)】', title or ''):
        cat = _TITLE_PREFIX_CATEGORY.get(tag)
        if cat:
            return cat
    return None


def _state_detail_text(category, title):
    """状态机动作文本：类别文案 + 标题，≤40 字（决策第 4 点）。"""
    prefix = _CATEGORY_DETAIL.get(category, '执行中') if category else '执行中'
    s = f'{prefix}：{title}'
    if len(s) > _STATE_DETAIL_MAX:
        s = s[:_STATE_DETAIL_MAX]
    return s


def now():
    return time.time()


def fmt_ts(ts):
    return datetime.datetime.fromtimestamp(ts).strftime('%H:%M')


def _act_ts(v):
    """活动时间归一化：epoch 秒 或 'HH:MM' 展示字符串 → epoch 秒。

    'HH:MM' 无日期信息：解析为「最接近 now 的 HH:MM」（今日；若算出的是 >1h 后的
    未来时刻则视为昨日），仅用于 600s 近因判定与排序，展示仍用原字符串。
    """
    if isinstance(v, (int, float)):
        return v
    try:
        hh, mm = (int(x) for x in str(v).split(':'))
        now_dt = datetime.datetime.now()
        t = now_dt.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if t > now_dt + datetime.timedelta(hours=1):
            t -= datetime.timedelta(days=1)
        return t.timestamp()
    except Exception:
        return 0.0


def ts_iso(ts):
    """epoch 秒 → ISO 字符串；None 原样返回。"""
    if not ts:
        return None
    return datetime.datetime.fromtimestamp(ts).isoformat()


def server_time_payload():
    """时钟服务（0825-f）：权威服务器时间，与 opc-api /api/time 同构。

    返回 {iso, unix, tz, offset}——Asia/Shanghai 墙钟（+08:00 固定偏移，
    该时区无 DST），供前端透明办公室显示真实服务器时间，agent 也可据此校准。
    """
    unix = int(time.time())
    sh = datetime.timezone(datetime.timedelta(hours=8))
    iso = datetime.datetime.fromtimestamp(unix, tz=sh).isoformat(timespec='seconds')
    return {'iso': iso, 'unix': unix, 'tz': 'Asia/Shanghai', 'offset': 480}


def sanitize_error(text, limit=60):
    """错误文本清洗（隐私红线）：剥异常前缀、去 URL / API key、压缩空白、截断 ≤60 字。"""
    line = (text or '').strip()
    if not line:
        return None
    line = re.sub(r'^RuntimeError:\s*', '', line).strip()
    line = re.sub(r'https?://\S+', '', line)
    line = re.sub(r'\bsk-[A-Za-z0-9_\-]+\b', '[key]', line)
    line = re.sub(r'\s+', ' ', line).strip()
    if not line:
        return None
    if len(line) > limit:
        cut = line.rfind(' ', 0, limit)
        if cut < limit * 0.4:
            cut = limit
        line = line[:cut].rstrip() + '…'
    return line


def extract_error(text):
    """从 cron 会话文本提取失败原因：`## Error` 段 fenced block 第一行 → 清洗。"""
    m = re.search(r'## Error\s*\n+\s*```[^\n]*\n(.+?)\n\s*```', text, re.DOTALL)
    if not m:
        return None
    first = m.group(1).strip().split('\n', 1)[0].strip()
    return sanitize_error(first)


def collect_cron(activities):
    """扫描各成员 profile 的 cron output 目录（主循环唤醒 + 例行 cron 痕迹）。"""
    cutoff = now() - 24 * 3600
    seen = {}
    for pid in PROFILES:
        cron_out = f'{HOME}/profiles/{pid}/cron/output'
        for jobdir in glob_list(f'{cron_out}/*/'):
            # 29d: glob→getmtime 竞态守卫——cron 输出轮转/清理会并发删除文件，
            #      单文件缺失只跳过该文件，不因 FileNotFoundError 炸整轮采集。
            md_files = []
            for f in glob_list(f'{jobdir}/*.md'):
                try:
                    md_files.append((os.path.getmtime(f), f))
                except OSError:
                    continue  # 并发删除：跳过
            md_files.sort(reverse=True)
            for mtime, f in md_files:
                if mtime < cutoff:
                    continue
                try:
                    with open(f, encoding='utf-8') as fh:
                        head = fh.read()
                except Exception:
                    continue
                # 跳过"静默唤警"output（no_agent watchdog / monitor 模式的条件唤警被抑制）
                if re.search(r'^\*\*Status:\*\*\s*(?:silent|no_change)\b', head,
                             re.IGNORECASE | re.MULTILINE):
                    continue
                resp = re.search(r'## Response\s*(.*?)(?:\n## |\Z)', head, re.DOTALL)
                if resp and re.fullmatch(r'\s*\[SILENT\]\s*', resp.group(1), re.IGNORECASE):
                    continue
                m = re.search(r'# Cron Job: (.+)', head)
                if not m:
                    continue
                jobname = m.group(1).strip().replace(' (FAILED)', '')
                if jobname not in CRON_MEMBER:
                    continue
                if seen.get(jobname, 0) >= 2:
                    continue
                seen[jobname] = seen.get(jobname, 0) + 1
                failed = m.group(1).rstrip().endswith('(FAILED)')
                member, action, detail = CRON_MEMBER[jobname]
                activities.append({
                    'member': member, 'action': action, 'detail': detail,
                    'failed': failed, 'error': extract_error(head) if failed else None,
                    'ts': mtime,
                })


def glob_list(pattern):
    return glob.glob(pattern)


def classify_action(goal):
    if any(k in goal for k in ('开发', '编码', '修复', '实现', '重构', '部署', '写代码', 'bug', '功能', '接口', '页面')):
        return 'code'
    if any(k in goal for k in ('监控', '扫描', '盯', 'watch', '巡检')):
        return 'monitor'
    if any(k in goal for k in ('校验', '蒸馏', '调研', '报告', '文案', '撰写', '整理')):
        return 'write'
    if any(k in goal for k in ('开会', '汇总', '汇报', '复盘', '日报', '周报', '会议')):
        return 'meet'
    return 'work'


# 0823-吸收-4b-fix(D1): 内部路径/环境变量指纹（visitor 零泄露红线）——源头清洗 + 前端渲染前打码双保险
# 排除字符集含全角标点（（）「」【】、。，；）——路径到标点即停，避免吞掉后续中文
INTERNAL_PATH_RE = re.compile(
    r'(?:/home/|/root/|/tmp/|/opt/|/var/|/data/)[^\s"\'`<>（）「」【】、。，；;:：]*'   # 绝对路径
    r'|hermes_space'                                                                   # 内部工作目录
    r'|PM2_HOME[^\s"\'`<>（）「」【】、。，；;:：]*'                                      # 环境变量赋值
    r'|[\w./-]+\.db\b'                                                                 # 数据库文件路径
)


# 0823-吸收-4b-fix(D2): 客户线索标识打码——线索编号（lead-0xx）与邮箱（PII，kanban 任务标题里的
# 客户跟进线索：如「【客服】lead-002 预注册线索跟进（user@example.com…」）
INTERNAL_INFO_RE = re.compile(
    r'lead-\d+'                                                                        # 客户线索编号
    r'|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'                                 # 邮箱
)


def sanitize_internal_path(text):
    """0823-吸收-4b-fix(D1/D2): 内部路径/线索打码——命令细节/任务标题里的 /home、hermes_space、
    PM2_HOME、/tmp、.db 等指纹替换为「[内部路径]」，lead-0xx/邮箱等客户线索标识替换为
    「[内部信息]」。visitor 页面零泄露的源头防线（前端另有渲染前过滤兜底）。"""
    if not text:
        return text
    return INTERNAL_INFO_RE.sub('[内部信息]', INTERNAL_PATH_RE.sub('[内部路径]', text))


def extract_detail(goal):
    g = goal.strip()
    g = re.sub(r'^你是[^。；;]*[。；;]', '', g)   # 去"你是马克（Mason），...。"前缀
    g = re.sub(r'^(任务|目标|请|帮我|需要你)[:：]?', '', g)
    g = sanitize_internal_path(g)   # 0823-吸收-4b-fix(D1): 源头清洗——剥命令细节里的内部路径/环境变量
    return (g.strip() or '协作任务')[:40]


def extract_involved(goal):
    """从 delegate goal 文本提取涉及成员名。"""
    m_actor = re.match(r'^你是([\u4e00-\u9fa5]{2,4})', goal)
    if m_actor and m_actor.group(1) in NAME_ID:
        return [m_actor.group(1)]
    return [n for n in NAME_ID if n in goal]


def collect_delegate(activities):
    """扫描 hermes_home + 各 profile 的 delegation 记录。"""
    cutoff = now() - 24 * 3600
    deleg_dirs = [f'{HOME}/cache/delegation/live'] + \
                 [f'{HOME}/profiles/{p}/cache/delegation/live' for p in PROFILES]
    for deleg_dir in deleg_dirs:
        for d in glob_list(f'{deleg_dir}/deleg_*/'):
            mf = os.path.join(d, 'manifest.json')
            # 29d: exists→getmtime TOCTOU 守卫——exists 后、stat 前被并发清理仍会抛
            #      FileNotFoundError（OSError 子类），统一 try 包 getmtime，缺失即跳过
            try:
                mtime = os.path.getmtime(mf)
            except OSError:
                continue
            if mtime < cutoff:
                continue
            try:
                m = json.load(open(mf, encoding='utf-8'))
            except Exception:
                continue
            for t in m.get('tasks', []):
                goal = t.get('goal', '') or ''
                if not goal:
                    continue
                involved = extract_involved(goal)
                action = classify_action(goal)
                detail = extract_detail(goal)
                for name in (involved or [DEFAULT_NAME]):
                    activities.append({
                        'member': name, 'action': action, 'detail': detail,
                        'failed': False, 'ts': mtime,
                    })


def _kanban_empty():
    return {
        'ts': datetime.datetime.now().isoformat(),
        'tasks': [], 'by_member': {}, 'error': None,
        'summary': {'total': 0, 'done': 0, 'running': 0, 'blocked': 0, 'todo': 0, 'ready': 0},
    }


def collect_kanban(db_path=None):
    """读 kanban.db tasks 表 → 任务列表 + 按成员统计（只读，绝不写库）。"""
    empty = _kanban_empty()
    db = db_path or KANBAN_DB
    try:
        con = sqlite3.connect(f'file:{db}?mode=ro', uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        tasks = cur.execute(
            'SELECT id, title, assignee, status, priority, created_at, started_at, '
            '       completed_at, block_kind FROM tasks WHERE status != ? '
            'ORDER BY priority DESC, created_at DESC',
            ('archived',)
        ).fetchall()
        runs = {r['task_id']: r for r in cur.execute(
            'SELECT task_id, profile, status, outcome, started_at, ended_at, last_heartbeat_at '
            'FROM task_runs WHERE id IN (SELECT MAX(id) FROM task_runs GROUP BY task_id)'
        )}
        con.close()
    except Exception as e:
        res = dict(empty)
        res['error'] = str(e)
        return res

    out_tasks = []
    by_member = {}
    summary = dict(empty['summary'])
    for t in tasks:
        status = t['status'] or 'todo'
        assignee = t['assignee'] or '未指派'
        name = PROFILE_NAME.get(assignee, assignee)
        title = (t['title'] or '').strip()
        title = sanitize_internal_path(title)   # 0823-吸收-4b-fix(D1): kanban.tasks 段标题源头清洗（bus 每秒经此重算，勿漏）
        if len(title) > TITLE_MAX:
            title = title[:TITLE_MAX] + '…'
        item = {
            'id': t['id'],
            'title': title,
            'assignee': name,
            'status': status,
            'priority': t['priority'],
            'created_at': ts_iso(t['created_at']),
            'started_at': ts_iso(t['started_at']),
            'completed_at': ts_iso(t['completed_at']),
        }
        if status == 'blocked':
            item['block_kind'] = t['block_kind']
        run = runs.get(t['id'])
        if run:
            item['run'] = {
                'profile': PROFILE_NAME.get(run['profile'], run['profile']),
                'status': run['status'],
                'outcome': run['outcome'],
                'started_at': ts_iso(run['started_at']),
                'ended_at': ts_iso(run['ended_at']),
                # 3a 状态机：心跳探活（epoch 秒，bus 1s 刷新下判定新鲜；无值=无法证明新鲜）
                'last_heartbeat_at': run['last_heartbeat_at'],
            }
        out_tasks.append(item)

        m = by_member.setdefault(name, dict(empty['summary']))
        m['total'] += 1
        m[status] = m.get(status, 0) + 1
        summary['total'] += 1
        summary[status] = summary.get(status, 0) + 1

    return {
        'ts': datetime.datetime.now().isoformat(),
        'tasks': out_tasks,
        'by_member': by_member,
        'summary': summary,
        'error': None,
    }


def collect_kanban_done(activities):
    """近 24h 内 status='done' 的 kanban 任务 → 「完成任务」活动记录。"""
    cutoff = now() - 24 * 3600
    try:
        con = sqlite3.connect(f'file:{KANBAN_DB}?mode=ro', uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        rows = cur.execute(
            'SELECT id, title, assignee, completed_at FROM tasks '
            'WHERE status = ? AND completed_at IS NOT NULL AND completed_at >= ?',
            ('done', cutoff)
        ).fetchall()
        runs = {r['task_id']: r for r in cur.execute(
            'SELECT task_id, outcome, error FROM task_runs '
            'WHERE id IN (SELECT MAX(id) FROM task_runs GROUP BY task_id)'
        )}
        con.close()
    except Exception:
        return

    for t in rows:
        assignee = t['assignee'] or '未指派'
        name = PROFILE_NAME.get(assignee, assignee)
        title = (t['title'] or '').strip()
        title = sanitize_internal_path(title)   # 0823-吸收-4b-fix(D1): 源头清洗任务标题里的内部路径指纹
        if len(title) > DONE_TITLE_MAX:
            title = title[:DONE_TITLE_MAX] + '…'
        run = runs.get(t['id'])
        failed = bool(run and run['outcome'] in ('blocked', 'failed'))
        error = sanitize_error(run['error']) if (failed and run and run['error']) else None
        activities.append({
            'member': name, 'action': 'done',
            'detail': title,
            'failed': failed, 'error': error, 'ts': t['completed_at'],
        })


def collect_kanban_work(activities):
    """近 24h 内 status='running' 的 kanban 任务 → 「领活干活」活动记录。"""
    cutoff = now() - 24 * 3600
    try:
        con = sqlite3.connect(f'file:{KANBAN_DB}?mode=ro', uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        rows = cur.execute(
            'SELECT id, title, assignee, started_at FROM tasks '
            'WHERE status = ? AND started_at IS NOT NULL AND started_at >= ?',
            ('running', cutoff)
        ).fetchall()
        con.close()
    except Exception:
        return

    for t in rows:
        assignee = t['assignee'] or '未指派'
        name = PROFILE_NAME.get(assignee, assignee)
        title = (t['title'] or '').strip()
        title = sanitize_internal_path(title)   # 0823-吸收-4b-fix(D1): 源头清洗任务标题里的内部路径指纹
        if len(title) > DONE_TITLE_MAX:
            title = title[:DONE_TITLE_MAX] + '…'
        activities.append({
            'member': name, 'action': 'work',
            'detail': title,
            'failed': False, 'ts': t['started_at'],
        })


def activity_items(activities, limit=60):
    """27f: 原始活动列表 → status.json activities 段展示格式（collect 与 opc-bus 共用，同口径）。

    collect main 与 bus merge 都经此格式化：member_id 反查 + ts 转 'HH:MM' + failed/error 透传，
    保证两条链路产出内容等价（collector 10min 重写无回退抖动）。
    """
    return [
        {'member': a['member'],
         'member_id': NAME_ID.get(a['member'], a['member']),
         'action': a['action'], 'detail': a['detail'],
         'ts': fmt_ts(a['ts']), 'failed': a['failed'], 'error': a.get('error')}
        for a in activities[:limit]
    ]


def _kanban_activity_state(kanban_tasks):
    """27f: kanban 任务 → 活动维度状态映射 {(成员, 标题≤40) : {'work'|'done'}}。

    与 collect_kanban_work/done 同源（同 DONE_TITLE_MAX 截断、done 仅近 24h），
    供 bus 剪枝 existing 里已过期的 kanban 维度记录（如任务 running→done 后遗留的
    work 记录——collect 全量重算不会再有它，bus 也须剔除，防回退抖动）。
    """
    cutoff = now() - 24 * 3600
    state = {}
    for t in kanban_tasks or []:
        title = (t.get('title') or '').strip()
        if len(title) > DONE_TITLE_MAX:
            title = title[:DONE_TITLE_MAX] + '…'
        member = t.get('assignee')
        if not member:
            continue
        st = t.get('status')
        if st == 'running':
            state.setdefault((member, title), set()).add('work')
        elif st == 'done':
            c = t.get('completed_at')
            try:
                cts = datetime.datetime.fromisoformat(c).timestamp() if c else 0
            except Exception:
                cts = 0
            if cts >= cutoff:
                state.setdefault((member, title), set()).add('done')
    return state


def merge_kanban_activities(existing, ka, kanban_tasks, limit=60):
    """27f: kanban 维度实时活动并入现有 activities 段（opc-bus 1s 轮询调用）。

    - existing: status.json 现有 activities（展示格式，ts='HH:MM' 字符串）
    - ka: collect_kanban_work/done 生成的实时活动（原始格式，ts=epoch 秒）——当前 kanban 状态权威
    - kanban_tasks: collect_kanban() 的 tasks 列表，用于剪枝已过期的 kanban 维度记录
    - 剪枝：existing 里 action∈{work,done} 且命中 kanban 任务的记录，仅当动作与任务当前状态
      匹配时保留（running→work、done→done），否则剔除（任务状态迁移后旧记录不残留）
    - 去重 key=(member, action, detail, ts 展示字符串)：同 key 跳过（幂等，bus 每 1s 重跑，
      同一 running 任务每次生成同 key 记录只保留首条，防重复插入）
    - 按 ts 展示字符串降序排序（'HH:MM' 字典序=同日时间序），截断 limit 条（与 collect 一致）
    - 返回展示格式列表（供 status['activities']）
    """
    state = _kanban_activity_state(kanban_tasks)
    seen = set()
    out = []
    for a in existing or []:
        if a.get('action') in ('work', 'done'):
            valid = state.get((a.get('member'), a.get('detail')))
            if valid is not None and a.get('action') not in valid:
                continue  # 任务状态已迁移（如 done/blocked）→ 旧 work/done 记录剔除
        key = (a.get('member'), a.get('action'), a.get('detail'), a.get('ts'))
        if key in seen:
            continue
        seen.add(key)
        out.append(a)
    for a in ka or []:
        item = {'member': a['member'],
                'member_id': NAME_ID.get(a['member'], a['member']),
                'action': a['action'], 'detail': a['detail'],
                'ts': fmt_ts(a['ts']), 'failed': a['failed'], 'error': a.get('error')}
        key = (item['member'], item['action'], item['detail'], item['ts'])
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    # 按归一化 epoch 降序（_act_ts 兼容 'HH:MM' 字符串；纯字符串序跨午夜会错位——
    # '23:55' > '00:50'，今日凌晨记录会被排到昨日晚间后面，截断 60 时被挤出）
    out.sort(key=lambda a: _act_ts(a.get('ts')), reverse=True)
    return out[:limit]


def build_members(team, activities, kanban_data):
    """27f+3a: 成员状态构建（collect 与 opc-bus 共享，两条链路同口径；与运行版同逻辑）。

    状态机推导（0823-吸收-3a，按成员取该成员 assignee 的最新卡，决策第 3 点）：
    - running 卡且 run.last_heartbeat_at 距今 <120s → state='working'（动作文本=标题，
      前缀【feature】/【bug】→「正在写代码」等，【内容】/【情报】细分 writing，映射不到
      归 working；不强区分 searching——无工具级钩子数据，不编造）
    - running 卡但心跳 ≥120s（stale）或缺失 → state='idle'，state_detail='任务挂起'
    - blocked 卡且 block_kind='needs_input' 或 assignee='gavin' → state='awaiting'
    - blocked 卡其他 → state='blocked'（等审批/依赖，status='active'）
    - 无 running/blocked 卡 → state='idle'（近 600s 有活动仍显示 idle，activity 保留
      最近活动文本）
    state 与现有 status 映射（决策第 5 点）：working/awaiting/blocked → status='active'；
    idle → status='idle'。现有 status/activity/action/last_ts 字段保留（向后兼容）。
    """
    acts = [dict(a, ts=_act_ts(a.get('ts'))) for a in activities]
    running = {}
    blocked = {}
    for t in (kanban_data or {}).get('tasks', []):
        assignee = t.get('assignee')
        if not assignee or t.get('status') not in ('running', 'blocked'):
            continue
        ts = t.get('started_at') or t.get('created_at') or ''
        cur = running if t['status'] == 'running' else blocked
        if assignee not in cur or ts > (cur[assignee].get('started_at')
                                        or cur[assignee].get('created_at') or ''):
            cur[assignee] = t
    members = []
    for m in team:
        name = m.get('name_zh', '')
        if name not in NAME_ID:
            continue
        latest = max((a for a in acts if a['member'] == name),
                     key=lambda a: a['ts'], default=None)
        rtask = running.get(name)
        if rtask:
            # running 卡：心跳新鲜 → working；stale/无心跳 → idle（诚实原则，不编造 working）
            title = (rtask.get('title') or '').strip()
            title = sanitize_internal_path(title)   # 0823-吸收-4b-fix(D1): state_detail/activity 源头清洗
            if len(title) > DONE_TITLE_MAX:
                title = title[:DONE_TITLE_MAX] + '…'
            hb = (rtask.get('run') or {}).get('last_heartbeat_at')
            if hb is not None and now() - hb < _HB_FRESH_SECONDS:
                cat = _title_prefix_category(title)
                state = _CATEGORY_STATE.get(cat, 'working')
                state_detail = _state_detail_text(cat, title)
                status = 'active'
                action = 'work'
            else:
                state = 'idle'
                state_detail = '任务挂起'
                status = 'idle'
                action = 'idle'
            activity = title
            last_ts = (rtask.get('started_at') or '')[11:16]  # ISO 'YYYY-MM-DDTHH:MM:SS...' → 'HH:MM'
        elif blocked.get(name):
            # blocked 卡：needs_input / gavin 卡 → awaiting（等人/等 Gavin），其余 → blocked
            btask = blocked[name]
            title = (btask.get('title') or '').strip()
            title = sanitize_internal_path(title)   # 0823-吸收-4b-fix(D1): state_detail/activity 源头清洗
            if len(title) > DONE_TITLE_MAX:
                title = title[:DONE_TITLE_MAX] + '…'
            if btask.get('block_kind') == 'needs_input' or btask.get('assignee') == 'gavin':
                state = 'awaiting'
                state_detail = ('等待审批：' + title)[:_STATE_DETAIL_MAX]
            else:
                state = 'blocked'
                state_detail = ('阻塞中：' + title)[:_STATE_DETAIL_MAX]
            status = 'active'
            action = 'work'
            activity = title
            last_ts = (btask.get('started_at') or btask.get('created_at') or '')[11:16]
        else:
            # 无 running/blocked 卡 → idle：近 600s 有活动仍显示 idle（决策第 3 点），
            # activity 保留最近活动文本（如「完成任务：xx」），旧 action/last_ts 语义不变
            state = 'idle'
            state_detail = ''
            status = 'idle'
            action = latest['action'] if latest else 'idle'
            activity = latest['detail'] if latest else ''
            last_ts = fmt_ts(latest['ts']) if latest else ''
        role = m.get('role', ROLES.get(name, ''))
        members.append({
            'id': NAME_ID[name],
            'name': name,
            'name_en': NAME_EN.get(NAME_ID[name], name),
            'role': role,
            'role_en': ROLE_EN.get(role, role),
            'avatar': f"img/avatars/{NAME_ID[name]}.jpg",
            'status': status,
            'activity': activity,
            'action': action,
            'last_ts': last_ts,
            # 3a 状态机（3b 前端消费）：state 6 态枚举 + state_detail 当前动作文本（≤40 字）
            'state': state,
            'state_detail': state_detail,
        })
    return members


def collect_meeting_attendees(kanban):
    """从真实留痕推导「谁该进会议室」（成员 id 列表，不含 CEO 本人）。"""
    cutoff = now() - 24 * 3600
    names = set()
    deleg_dirs = [f'{HOME}/cache/delegation/live'] + \
                 [f'{HOME}/profiles/{p}/cache/delegation/live' for p in PROFILES]
    for deleg_dir in deleg_dirs:
        for d in glob_list(f'{deleg_dir}/deleg_*/'):
            mf = os.path.join(d, 'manifest.json')
            # 29d: exists→getmtime TOCTOU 守卫（同 collect_delegate）：缺失即跳过
            try:
                if os.path.getmtime(mf) < cutoff:
                    continue
            except OSError:
                continue
            try:
                m = json.load(open(mf, encoding='utf-8'))
            except Exception:
                continue
            for t in m.get('tasks', []):
                goal = t.get('goal', '') or ''
                if goal:
                    names.update(extract_involved(goal))
    for task in kanban.get('tasks', []):
        if task.get('status') == 'running' and task.get('assignee'):
            names.add(task['assignee'])
    ceo_name = next((n for n, aid in NAME_ID.items() if aid == _ceo_id()), None)
    if ceo_name:
        names.discard(ceo_name)
    attendees = [aid for aid in NAME_ID.values() if aid != _ceo_id()
                 and _name_of(aid) in names]
    if not attendees:
        attendees = [aid for aid in NAME_ID.values() if aid != _ceo_id()]
    return attendees


def _ceo_id():
    # CEO = name_en 表第一个成员（惯例 zhuangzi）；config 可改
    return list(NAME_ID.values())[0]


def _name_of(aid):
    return PROFILE_NAME.get(aid, aid)


def build_meeting(members, activities, kanban):
    """会议上下文顶层字段。"""
    ceo = _ceo_id()
    zz = next((m for m in members if m.get('id') == ceo), None)
    if not (zz and zz.get('status') == 'active' and zz.get('action') == 'meet'):
        return {'active': False}
    since_ts = next((a['ts'] for a in activities
                     if a['member'] == _name_of(ceo) and a['action'] == 'meet'), now())
    return {
        'active': True,
        'attendees': collect_meeting_attendees(kanban),
        'since': fmt_ts(since_ts),
    }


def sync_state_tasks():
    """把 kanban 任务状态回写到 state.json tasks[]（kanban.db 是权威，state 跟随）。"""
    KB2STATE = {'done': 'done', 'running': 'in_progress', 'blocked': 'blocked',
                'todo': 'ready', 'ready': 'ready'}
    today = datetime.date.today().isoformat()
    mark = f'[opc-collect 同步] {today}'
    try:
        con = sqlite3.connect(f'file:{KANBAN_DB}?mode=ro', uri=True, timeout=5)
        cur = con.cursor()
        kb = {r[0]: r[1] for r in cur.execute('SELECT id, status FROM tasks')}
        con.close()
    except Exception:
        return

    try:
        with open(f'{OPC_DIR}/state.json', encoding='utf-8') as f:
            state = json.load(f)
    except Exception:
        return

    changed = False
    for t in state.get('tasks', []):
        kid = t.get('kanban')
        if not kid or kid not in kb:
            continue
        kb_status = kb[kid]
        if kb_status not in KB2STATE:
            continue
        target = KB2STATE[kb_status]
        if t.get('status') == target:
            continue
        t['status'] = target
        note = t.get('note') or ''
        if mark not in note:
            t['note'] = (note + '；' if note else '') + mark
        changed = True

    if not changed:
        return
    try:
        with open(f'{OPC_DIR}/state.json', 'w', encoding='utf-8') as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ── 27c 协调协议：collect 与 opc-bus 的 status.json 段级写协调 ─────────────────
# 依据：opc-data-bus-design.md v1.1 §4.3 一致性设计 + §4.5 降级路径（Gavin 2026-08-21 拍板）。
# 分工：bus（opc-bus.py，1s 高频）只写 status.json 的 kanban 段 + sources.kanban 元数据；
#       collect（本脚本，10min 全量兜底）写其余段（cron/delegation/state 等源提取不动）。
# 写协调策略：段不重叠 → 采用「最后写者胜」，不引入 fcntl.flock（无死锁风险、零额外文件句柄）：
#   1. 两写方均原子写（tmp + os.replace，atomic_write 同款），SSE fs.watch 只见完整文件，
#      交替写不产生半截状态（27c 验收：bus 运行中 collect 与 bus 交替写无异常/无半截）；
#   2. collect 全量重算仍含 kanban 段（bus 挂时兜底修复，§4.5 降级路径「照旧不劣化」），
#      但写盘前按 bus 水位线判定：若现有 sources.kanban.watermark >= 当前 MAX(id)（bus 段
#      不旧于本次重算）→ 保留 bus 写的 kanban 段，避免覆盖 bus 秒级刷新的新鲜数据；
#   3. collect 写盘后把 bus 水位线同步为当前 MAX(id)（只前进不回退）——避免 collect 覆盖
#      后 bus 下一轮重放历史事件导致双写/重复刷新（§4.3「collect 全量写时顺带把 bus
#      水位线同步为当前 MAX(id)」落地；bus 1s 高频可能已把水位线推到更大，故取 max）；
#   4. sources 段只增不删：collect 保留现有 sources（bus 写的段级元数据不被全量写抹掉），
#      bus 挂/落后导致 collect 兜底覆盖 kanban 段时，同步刷新 sources.kanban 时间戳。

def current_task_events_max():
    """只读查询 task_events 当前 MAX(id)（27c 协调查询，mode=ro 绝不写库）。失败返回 None。"""
    try:
        con = sqlite3.connect(f'file:{KANBAN_DB}?mode=ro', uri=True, timeout=5)
        mx = con.execute('SELECT COALESCE(MAX(id), 0) FROM task_events').fetchone()[0]
        con.close()
        return mx
    except Exception:
        return None


def read_status_existing():
    """读现有 status.json（out_status 优先，secondary 兜底）→ dict；不存在/损坏返回 None。

    bus 与 collect 双写 out_status(+secondary)，同一写路径下各文件内容一致；collect 只读一份。
    """
    for p in (P['out_status'], P.get('out_status_secondary') or ''):
        if not p:
            continue
        try:
            with open(p, encoding='utf-8') as fh:
                return json.load(fh)
        except Exception:
            continue
    return None


def atomic_write(path, obj):
    """tmp + os.replace 原子写：SSE fs.watch 只见完整文件，杜绝半截读。

    29e: tmp 改唯一名（mkstemp）+ os.replace 包 OSError 静默守卫。多写方
    （collect 1min cron / opc_demo_dispatch 分钟级）共用固定 status.json.tmp，
    一方 os.replace 移走 tmp 后另一方 replace 同名路径抛 FileNotFoundError
    （29e 生产实测 12:26:05）。唯一名下各写方 rename 各自 tmp，后写者胜、
    内容完整；极端并发删除时守卫静默跳过，与三读点同语义（并发删除跳过，
    不重试不告警）。
    """
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + '.', suffix='.tmp', dir=d)
    try:
        os.fchmod(fd, 0o644)   # 29f: mkstemp 默认 0600，os.replace 保留该模式 → web 容器 nginx(user) 读 403；
                               # 显式 fchmod 644 恢复全网可读（smoke_test「状态数据 200」回归）
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            json.dump(obj, fh, ensure_ascii=False, indent=2)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    try:
        os.replace(tmp, path)
    except OSError:
        # 并发删除/竞态：静默跳过（与三读点同语义），不重试不告警
        try:
            os.unlink(tmp)
        except OSError:
            pass


def sync_bus_watermark(max_id):
    """把 bus 水位线同步为 max_id（collect 全量写盘后调用，§4.3 协调协议）。

    只前进不回退：bus 1s 高频可能已把 bus-state.json 推进到比 max_id 更大的值，
    直接覆盖会回退水位线 → bus 重放已处理事件造成双写/重复刷新；取 max(现有, max_id)
    保证单调。失败静默：bus 下个事件仍会自行推进，collect 兜底不劣化。
    """
    if max_id is None:
        return
    try:
        cur = 0
        cur_state = {}
        try:
            with open(BUS_STATE, encoding='utf-8') as fh:
                cur_state = json.load(fh)
                if not isinstance(cur_state, dict):
                    cur_state = {}
                cur = int(cur_state.get('kanban_watermark', 0) or 0)
        except Exception:
            pass
        # 30b: 保留 demo_watermark（bus 第二水位线）——只前进 kanban_watermark，
        # 否则覆盖为单键版本会丢 demo_watermark → bus 重启误判首启重校准（重放口径破坏）
        cur_state['kanban_watermark'] = max(cur, max_id)
        atomic_write(BUS_STATE, cur_state)
    except Exception:
        pass  # 水位线同步失败静默：bus 后续事件推进会自愈


def main():
    activities = []
    collect_cron(activities)
    collect_delegate(activities)
    collect_kanban_done(activities)
    collect_kanban_work(activities)
    activities.sort(key=lambda a: -a['ts'])

    sync_state_tasks()

    try:
        state = json.load(open(f'{OPC_DIR}/state.json', encoding='utf-8'))
    except Exception:
        state = {}

    team = list(state.get('team', []))
    metrics = state.get('metrics', {})

    ceo = state.get('company', {}).get('ceo', {})
    if ceo:
        ceo_name = ceo.get('name_zh') or _name_of(_ceo_id())
        # 31c: opc-init 生成的 state.json team 首位已含 CEO（31b 契约 is_ceo 首位，
        # config name_id 首项=CEO）→ 去重，避免「CEO/主控」与「厂长/CEO」双插重复。
        # OPC 自用 state.json（team 不含 CEO）行为不变：仍插入 CEO/主控。
        if not any(t.get('name_zh') == ceo_name for t in team):
            team.insert(0, {'name_zh': ceo_name, 'role': 'CEO/主控'})

    # 27f: 先 collect_kanban 再构建 members（build_members 需 kanban running 判定，最高优先）
    kanban_data = collect_kanban()
    members = build_members(team, activities, kanban_data)
    try:
        since = datetime.date.fromisoformat(RUNNING_SINCE)
        running_days = (datetime.date.today() - since).days
    except Exception:
        running_days = 0
    status = {
        'ts': datetime.datetime.now().isoformat(),
        'server_time': server_time_payload(),   # 0825-f: 权威时钟（Asia/Shanghai, 前端实时显示）
        'running_days': running_days,
        'members': members,
        'activities': activity_items(activities),
        'metrics': metrics,
        'kanban': kanban_data,
        'kanban_demo': collect_kanban(DEMO_KANBAN_DB) if DEMO_KANBAN_DB else _kanban_empty(),
        'meeting': build_meeting(members, activities, kanban_data),
    }
    # 31d: customer 形态标识——opc-init 产物 state.json company.template 存在（self 官网
    # state.json company 无 template）→ status.json 顶层带 mode/company/template，
    # 前端据此动态化画布 + 去 OPC 官网品牌；self 形态零字段变化（零回归）。
    company_meta = state.get('company') or {}
    if company_meta.get('template'):
        status['mode'] = 'customer'
        status['company'] = company_meta.get('name') or ''
        status['template'] = company_meta['template']

    # ── 27c 协调协议：写盘前段级协调（协议说明见上方函数注释块）────────────────
    # collect 全量重算含 kanban 段（bus 挂时兜底修复）；但若 bus 水位线已覆盖本次重算
    # 读到的全部事件（sources.kanban.watermark >= 当前 MAX(id)），现有 kanban 段不旧于
    # 本次重算 → 保留 bus 版本，避免覆盖 bus 秒级刷新的新鲜数据（段不重叠最后写者胜）。
    existing = read_status_existing()
    max_id = current_task_events_max()
    sources = existing.get('sources') if existing and isinstance(existing.get('sources'), dict) else None
    kb_wm = (sources or {}).get('kanban', {}).get('watermark')
    if existing and 'kanban' in existing and kb_wm is not None and max_id is not None and kb_wm >= max_id:
        status['kanban'] = existing['kanban']   # bus 的段更新/不旧 → 保留（不覆盖）
        # 30c: kanban_demo 段同样让位——bus 活着时 bus 已秒级保鲜（refresh_demo_status 补写），
        # collect 不再重算/覆盖；existing 缺段（老 status.json）保留本次全量算的兜底值
        if existing.get('kanban_demo'):
            status['kanban_demo'] = existing['kanban_demo']
    else:
        # collect 兜底覆盖 kanban 段（bus 挂/落后/首启）：sources.kanban 同步为本次刷新时刻，
        # events=0 表示全量兜底刷新（非事件驱动），bus 下次事件会覆盖回自身元数据
        if sources is None:
            sources = {}
        sources['kanban'] = {'ts': status['ts'],
                             'watermark': max_id if max_id is not None else (kb_wm or 0),
                             'events': 0}
    status['sources'] = sources   # 保留 bus 写的段级元数据（27a 协议），collect 全量写不抹掉

    # 27c：原子写（tmp + os.replace）防 SSE 半截读；bus 与 collect 交替写无半截状态
    for p in (OUT_PUBLIC, OUT_DIST):
        if not p:
            continue
        try:
            atomic_write(p, status)
        except Exception as e:
            print(f'⚠️ 写输出失败 {p}: {e}', file=sys.stderr)
            sys.exit(1)
    # 27c：collect 全量写盘后把 bus 水位线同步为当前 MAX(id)（只前进不回退）——
    # 避免 collect 后 bus 下一轮重放已覆盖的历史事件导致双写/重复刷新（§4.3）
    sync_bus_watermark(max_id)
    # silent 模式：成功不输出 stdout（供 cron no_agent watchdog 使用）


if __name__ == '__main__':
    main()
