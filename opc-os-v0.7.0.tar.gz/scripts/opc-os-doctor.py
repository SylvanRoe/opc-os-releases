#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
opc-os-doctor.py — OPC-OS 运行期自助诊断工具（P0-3 · Gavin 点名「C 能诊断」验收项）

一条命令定位 5 服务（llm-gateway / opc-api / web / collector / dispatcher）哪里坏了、
坏在哪、怎么修（每条 FAIL 附一条可复制执行的修复命令）。零第三方依赖（python3 标准库）。

检查项（11 组）：
  1. 运行时依赖   node ≥20 / python3 ≥3.10 / uv / git 版本与存在性
  2. 进程存活     5 服务进程 pgrep（web 兜底：端口+HTTP 健康即 PASS，兼容容器形态）
  3. systemd unit  opcos-{gateway,api,web,collector,dispatcher} = active + enabled + Restart=always
                  + EnvironmentFile 注入面存在（模板与实机都查；无 systemd 时退化检查 pidfile）
  4. 端口监听     18080（仅 127.0.0.1）/ 3033 / 8081 + HTTP 探活
  5. 网关可达     /healthz 200 + 配置校验（providers 池 / default_provider / unified_model）
  6. 代理连通     按配置探测代理（默认 127.0.0.1:7890），curl -x 探测外网可达性
  7. 模型 key     llm.env/gateway.env 存在 + 非占位符 + 权限 600 + 网关侧状态（只显示掩码）
  8. kanban 派发  kanban.db 可读写 + 最近 spawned/claimed 事件 + dispatcher 存活
  9. collector 流 status.json / token-stats.json / bus-state.json 新鲜度 + bus watermark
 10. 红线复核    凭据文件权限 600 / 无明文 key 落配置·代码·文档 / 无裸进程（nohup 退化除外）
 11. dispatcher 环境自检（0827 事故固化）daemon environ 含 GATEWAY_CLIENT_TOKEN +
                  /v1/chat/completions 带 token 实测算连通 + 近 1h spawn 失败率（>30% 告警）
                  + auto_blocked 残留 + worker 日志 401 窗口 + staging 注记

输出：
  - 人类可读报告（默认）：每组 PASS/FAIL/WARN + 一行状态 + 修复建议命令
  - --json：结构化 [{group, name, status, detail, fix}, ...] + 退出码
  - 退出码：0=全绿 / 1=存在 FAIL（--strict 时 WARN 也算）/ 2=工具自身错误或环境不可判定

用法示例：
  python3 opc-os-doctor.py                          # 自动探测数据目录
  python3 opc-os-doctor.py --out ~/opc-test         # 指定 opc-init 输出目录
  python3 opc-os-doctor.py --json                   # 机器可读
  python3 opc-os-doctor.py --group 7                # 只跑第 7 组（排查用）
  python3 opc-os-doctor.py --deep                   # 触发一次真实模型探话（消耗极少 token）
  python3 opc-os-doctor.py --strict                 # WARN 计入失败（退出码 1）

红线：本工具严禁打印任何凭证明文（key/token 一律掩码 sk-***）；凭据检查只判
「存在 / 权限 / 非占位符」，绝不输出 key 值。
"""

import argparse
import datetime as _dt
import json
import os
import re
import shutil
import signal
import socket
import sqlite3
import stat
import subprocess
import sys
import time
import urllib.error
import urllib.request

VERSION = "0.2.0"
SERVICES = ["gateway", "api", "web", "collector", "dispatcher"]
UNIT_NAMES = {s: f"opcos-{s}.service" for s in SERVICES}

# 进程匹配模式（pgrep -f 多模式，任一命中即视为存活）
PROC_PATTERNS = {
    "gateway":    [r"node server\.js"],
    "api":        [r"node .*index\.cjs", r"index\.cjs"],
    "web":        [r"web-serve\.js"],
    "collector":  [r"opc-bus\.py"],
    "dispatcher": [r"opc-dispatcher\.py", r"kanban_dispatcher", r"-m kanban_dispatcher"],
}

# 端口 → (服务, HTTP 探活路径, 预期码)
PORT_PROBES = [
    (18080, "gateway", "/healthz", {200}),
    (3033,  "api",     "/healthz", {200}),
    (8081,  "web",     "/healthz", {200}),
]

# 代理外网探测目标（顺序探测，任一命中预期状态码即通）
PROXY_PROBES = [
    ("https://www.gstatic.com/generate_204", {204}),
    ("https://github.com", {200}),
    ("https://api.telegram.org", {200, 302}),
]

PLACEHOLDER_RE = re.compile(
    r"^(sk-xxx|your[-_]?key|changeme|change_me|placeholder|<[^>]+>|xxx+|dummy|test|demo|"
    r"replace[-_]?me|nan|none|null|undefined|\.\.\.)$",
    re.IGNORECASE,
)
SK_RE = re.compile(r"\bsk-[A-Za-z0-9_-]{8,}\b")


def now_iso():
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def run(cmd, timeout=15, text=True):
    """subprocess 封装：返回 (returncode, stdout, stderr)，永不抛异常。"""
    try:
        p = subprocess.run(cmd, capture_output=True, text=text, timeout=timeout)
        return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", f"command not found: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout}s: {' '.join(cmd[:4])}"


def user_home():
    """真实用户 home（worker profile 会改 $HOME，expanduser 不可靠）。"""
    try:
        import pwd
        return pwd.getpwuid(os.getuid()).pw_dir
    except Exception:
        return os.path.expanduser("~")


def which(cmd):
    return shutil.which(cmd)


def path_mode(p):
    """返回文件权限八进制字符串（如 '600'），不存在返回 None。"""
    try:
        return oct(stat.S_IMODE(os.stat(p).st_mode))[2:]
    except OSError:
        return None


def mask_key(value):
    """凭据掩码：严禁明文。统一 sk-*** 风格；非 sk- 前缀取前 3 字符 + ***。"""
    if not value:
        return "<empty>"
    if value.startswith("sk-"):
        return "sk-***"
    return value[:3] + "***"


def sec_ago(ts):
    d = int(time.time() - ts)
    if d < 0:
        return "刚刚"
    if d < 60:
        return f"{d}s 前"
    if d < 3600:
        return f"{d // 60}m{d % 60}s 前"
    return f"{d // 3600}h{d % 3600 // 60}m 前"


def parse_http_code(url, proxy=None, timeout=8):
    """返回 HTTP 状态码（int），失败返回 None。优先 curl（--max-time），退化 urllib。"""
    curl = which("curl")
    if curl:
        cmd = [curl, "-s", "-o", os.devnull, "-w", "%{http_code}", "--max-time", str(timeout), "-L"]
        if proxy:
            cmd += ["-x", proxy]
        cmd += [url]
        code, out, _ = run(cmd, timeout=timeout + 5)
        if code == 0 and out.strip().isdigit():
            return int(out.strip())
        return None
    # urllib 兜底
    try:
        handlers = []
        if proxy:
            handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
        opener = urllib.request.build_opener(*handlers)
        req = urllib.request.Request(url, method="GET")
        with opener.open(req, timeout=timeout) as resp:
            return resp.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return None


# ---------------------------------------------------------------- 环境定位

def find_out_dir(explicit):
    """定位 opc-init 输出目录（数据根）。返回 (path|None, how)。"""
    if explicit:
        if not os.path.isdir(explicit):
            return None, f"--out 指定目录不存在: {explicit}"
        return os.path.abspath(explicit), "--out 参数"

    env = os.environ.get("OPC_OS_DATA_DIR") or os.environ.get("OPC_DATA_DIR")
    if env and os.path.isdir(env):
        return os.path.abspath(env), "环境变量"

    # systemd 反推：opcos-api.service 的 OPC_OS_DATA_DIR / OPC_DATA_DIR
    if os.path.isdir("/run/systemd/system") and which("systemctl"):
        for unit in ("opcos-api.service", "opcos-web.service"):
            code, out, _ = run(["systemctl", "show", unit, "-p", "Environment"], timeout=10)
            if code == 0:
                m = re.search(r"(?:OPC_OS_DATA_DIR|OPC_DATA_DIR)=([^\s\"']+)", out)
                if m and os.path.isdir(m.group(1)):
                    return m.group(1), f"systemd {unit} 反推"

    candidates = [
        os.path.join(user_home(), ".hermes/opc"),
        os.path.join(user_home(), "opc-test"),
        os.path.join(user_home(), ".opc-os"),
        os.path.join(user_home(), "opc-data"),
        os.path.join(user_home(), "opc-init-out"),
        os.path.join(user_home(), "opc-os"),
        "/opt/opc-os",
        "/srv/opc-os",
        "/data",
    ]
    for c in candidates:
        # 数据根特征：任一关键文件存在即可
        if os.path.isdir(c) and (
            os.path.isfile(os.path.join(c, "status.json"))
            or os.path.isfile(os.path.join(c, "llm.env"))
            or os.path.isfile(os.path.join(c, "config", "config.json"))
            or os.path.isdir(os.path.join(c, "llm-gateway"))
        ):
            return c, "常见路径探测"
    return None, "未探测到（服务未安装，或需 --out 显式指定）"


def find_repo_dir(explicit, script_path):
    """定位 opc-os 部署包仓库根（systemd 模板检查用）。"""
    if explicit:
        return os.path.abspath(explicit) if os.path.isdir(explicit) else None
    # 脚本在 repo/scripts/ 下 → 上级即 repo
    base = os.path.dirname(os.path.abspath(script_path))
    for d in (base, os.path.dirname(base)):
        if os.path.isdir(os.path.join(d, "systemd")) and os.path.isdir(os.path.join(d, "scripts")):
            return d
    return None


def find_kanban_db(out, explicit):
    if explicit:
        return explicit if os.path.isfile(explicit) else None
    # 显式 --out 时，out/kanban.db 是权威（先于环境变量，避免误连其它板）
    if out:
        p = os.path.join(out, "kanban.db")
        if os.path.isfile(p):
            return p
    env = os.environ.get("HERMES_KANBAN_DB")
    if env and os.path.isfile(env):
        return env
    for cand in (
        os.path.join(user_home(), ".hermes/kanban/boards/opc/kanban.db"),
        os.path.join(user_home(), ".hermes/kanban.db"),
    ):
        if cand and os.path.isfile(cand):
            return cand
    # 最新 mtime 的 boards/*/kanban.db
    boards = os.path.join(user_home(), ".hermes/kanban/boards")
    if os.path.isdir(boards):
        hits = []
        for name in os.listdir(boards):
            p = os.path.join(boards, name, "kanban.db")
            if os.path.isfile(p):
                hits.append((os.path.getmtime(p), p))
        if hits:
            hits.sort(reverse=True)
            return hits[0][1]
    return None


def find_cred_file(out):
    """凭据文件：部署形态 OUT/llm.env，生产形态 OUT/llm-gateway/gateway.env。"""
    for cand in (os.path.join(out, "llm.env"),
                 os.path.join(out, "llm-gateway", "gateway.env")):
        if os.path.isfile(cand):
            return cand
    return None


def read_env_file(path):
    """解析 KEY=VALUE 行，返回 dict。值可能是引号包裹，剥离引号。"""
    data = {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip('"').strip("'")
                if k:
                    data[k] = v
    except OSError:
        pass
    return data


def parse_ss_listen():
    """ss -tlnp 解析 → {port: {"addr": set, "procs": set}}。失败返回 {}。"""
    if not which("ss"):
        return {}
    code, out, _ = run(["ss", "-tlnp"], timeout=10)
    if code != 0:
        return {}
    res = {}
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 4:
            continue
        local = parts[3]
        try:
            addr, port = local.rsplit(":", 1)
            port = int(port)
        except ValueError:
            continue
        entry = res.setdefault(port, {"addr": set(), "procs": set()})
        entry["addr"].add(addr)
        # users:(("name",pid=123,fd=8)) 解析进程名
        m = re.search(r'users:\s*\(\((.+?)\)\)', line)
        if m:
            for seg in m.group(1).split('"),("'):
                mm = re.search(r'"([^"]+)"\s*,\s*pid=(\d+)', seg)
                if mm:
                    entry["procs"].add(f"{mm.group(1)}(pid {mm.group(2)})")
    return res


def pgrep_find(patterns):
    """pgrep -f 多模式 → 命中 pid 列表。"""
    pids = []
    for pat in patterns:
        code, out, _ = run(["pgrep", "-f", pat], timeout=10)
        if code == 0 and out.strip():
            for pid in out.split():
                try:
                    pids.append(int(pid))
                except ValueError:
                    pass
    return sorted(set(pids))


def pid_cmdline(pid):
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            return f.read().replace(b"\x00", b" ").decode("utf-8", "replace").strip()[:160]
    except OSError:
        return "?"


def pid_cgroup(pid):
    try:
        with open(f"/proc/{pid}/cgroup", "r") as f:
            return f.read().strip()
    except OSError:
        return ""


def systemd_available():
    return os.path.isdir("/run/systemd/system") and which("systemctl") is not None


# ---------------------------------------------------------------- 检查组

class Doctor:
    def __init__(self, args, out_dir, out_how, repo_dir, kanban_db, cred_file, listeners):
        self.args = args
        self.out = out_dir
        self.out_how = out_how
        self.repo = repo_dir
        self.kanban_db = kanban_db
        self.cred_file = cred_file
        self.listeners = listeners
        self.groups = []
        self.results = {}          # 组号 → 状态
        self.details = {}          # 组号 → detail 文本
        self.fixes = {}            # 组号 → fix 文本
        self.svc_procs = {}        # 服务 → pid 列表（G2 记录，G10 复用）
        self.svc_http_ok = {}      # 服务 → 端口 HTTP 兜底是否健康

    # ---- 工具方法 ----
    def add(self, gid, name, status, detail, fix=""):
        self.groups.append({"group": gid, "name": name, "status": status,
                            "detail": detail, "fix": fix})
        self.results[gid] = status
        self.details[gid] = detail
        self.fixes[gid] = fix

    def port_open(self, port):
        return port in self.listeners

    def port_http(self, port, path):
        url = f"http://127.0.0.1:{port}{path}"
        code = parse_http_code(url, timeout=5)
        return code, url

    # ============ G1 运行时依赖 ============
    def g1_runtime(self):
        checks = []
        parts, fails, warns = [], [], []
        for name, min_ver, ver_cmd in (
            ("node", (20,), ["node", "--version"]),
            ("python3", (3, 10), ["python3", "--version"]),
            ("uv", None, ["uv", "--version"]),
            ("git", None, ["git", "--version"]),
        ):
            exe = which(name)
            if not exe:
                checks.append((name, False, "未安装", "FAIL"))
                continue
            code, out, _ = run(ver_cmd, timeout=10)
            if code != 0:
                checks.append((name, True, f"{out or '版本读取失败'}", "WARN"))
                continue
            version = re.search(r"\d+(\.\d+)*", out)
            ver_str = version.group(0) if version else out[:40]
            if min_ver is None:
                checks.append((name, True, ver_str, "PASS"))
                continue
            major = int(ver_str.split(".")[0])
            minor = int(ver_str.split(".")[1]) if len(ver_str.split(".")) > 1 else 0
            ok = (major, minor) >= min_ver[:2] if len(min_ver) > 1 else major >= min_ver[0]
            checks.append((name, ok, ver_str, "PASS" if ok else "FAIL"))

        parts, fails = [], []
        for name, ok, ver, _st in checks:
            mark = "✓" if ok else "✗"
            parts.append(f"{name} {ver} {mark}")
            if not ok:
                fails.append(name)
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        detail = " / ".join(parts)
        fix = ""
        if "node" in fails:
            fix += "node <20：nodesource 安装（见 installation-guide §3）：curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt install -y nodejs；"
        if "python3" in fails:
            fix += "python3 <3.10：sudo apt install -y python3；"
        if "uv" in fails:
            fix += "uv：curl -LsSf https://astral.sh/uv/install.sh | sh；"
        if "git" in fails:
            fix += "git：sudo apt install -y git；"
        self.add(1, "运行时依赖", status, detail, fix.rstrip("；"))

    # ============ G2 进程存活 ============
    def g2_processes(self):
        parts, fails, warns = [], [], []
        for svc in SERVICES:
            pids = pgrep_find(PROC_PATTERNS[svc])
            self.svc_procs[svc] = pids
            if pids:
                parts.append(f"{svc} ✓ (pid {','.join(str(p) for p in pids[:3])})")
                continue
            # web 兜底：端口 + HTTP 健康（容器/其它托管形态）
            if svc == "web":
                ok_http = False
                for port, svc2, path, codes in PORT_PROBES:
                    if svc2 != "web":
                        continue
                    if self.port_open(port):
                        code, url = self.port_http(port, path)
                        if code in codes:
                            ok_http = True
                            procs = self.listeners.get(port, {}).get("procs", set())
                            who = "、".join(sorted(procs)) if procs else "未知进程"
                            parts.append(f"web ✓ (pgrep 未命中，但端口 {port} 健康：{who})")
                            self.svc_http_ok["web"] = True
                if not ok_http:
                    parts.append(f"web ✗ (无 web-serve.js 进程且 8081 无健康响应)")
                    fails.append("web")
                continue
            parts.append(f"{svc} ✗ (进程未找到)")
            fails.append(svc)
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if fails:
            fix = "sudo systemctl restart " + " ".join(f"opcos-{s}" for s in fails) + " 2>/dev/null || scripts/install-services.sh restart --out " + (self.out or "<数据目录>")
        self.add(2, "进程存活", status, "；".join(parts), fix)

    # ============ G3 systemd unit ============
    def g3_systemd(self):
        if not systemd_available():
            # 无 systemd：pidfile 退化守护检查（install-services.sh nohup 路径）
            parts, fails, warns = [], [], []
            out = self.out
            for svc in SERVICES:
                pidfile = os.path.join(out, "run", f"{svc}.pid") if out else ""
                if pidfile and os.path.isfile(pidfile):
                    pid = 0
                    alive = False
                    try:
                        pid = int(open(pidfile).read().strip())
                        alive = os.path.exists(f"/proc/{pid}")
                    except Exception:
                        alive = False
                    parts.append(f"{svc} {'✓' if alive else '✗'} pidfile {pid}")
                    if not alive:
                        fails.append(svc)
                else:
                    parts.append(f"{svc} ✗ 无 pidfile（未安装或以其它方式运行）")
                    fails.append(svc)
            status = "FAIL" if fails else ("WARN" if warns else "PASS")
            fix = ("scripts/install-services.sh restart --out " + (out or "<数据目录>")
                   if fails else "")
            self.add(3, "systemd unit", status, "无 systemd，退化 pidfile 检查：" + "；".join(parts), fix)
            return

        # 实机 unit 状态
        parts, fails, warns = [], [], []
        for svc in SERVICES:
            unit = UNIT_NAMES[svc]
            code, out, _ = run(["systemctl", "show", unit, "-p", "ActiveState", "-p", "SubState",
                                "-p", "UnitFileState", "-p", "Restart", "-p", "EnvironmentFiles"], timeout=10)
            state = {}
            for kv in out.splitlines():
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    state[k] = v
            # unit 不存在：无 UnitFileState 且 inactive（systemctl show 对缺失 unit 仍可能 exit 0）
            if code != 0 or not out.strip() or (not state.get("UnitFileState") and state.get("ActiveState") in (None, "inactive")):
                # unit 不存在
                if svc == "web" and self.port_open(8081):
                    parts.append(f"{unit} ⚠ unit 不存在，但 8081 端口健康（容器/其它形态托管）")
                    warns.append("web-unit")
                else:
                    parts.append(f"{unit} ✗ unit 不存在")
                    fails.append(unit)
                continue
            active = state.get("ActiveState") == "active"
            enabled = state.get("UnitFileState") in ("enabled", "static", "linked", "alias")
            restart = state.get("Restart", "")
            # EnvironmentFile 注入面（P2 固化）：unit 须有 EnvironmentFile 且指向存在的文件
            ef_raw = state.get("EnvironmentFiles", "").strip()
            ef_path = ef_raw.split(" ", 1)[0].rstrip("(") if ef_raw else ""
            ef_missing = (not ef_path) or (not os.path.isfile(ef_path))
            ok = active and enabled and restart == "always" and not ef_missing
            if active and not enabled:
                parts.append(f"{unit} ⚠ active 但未 enabled")
                warns.append(unit)
            elif active and restart != "always":
                parts.append(f"{unit} ⚠ active 但 Restart={restart}（应 always）")
                warns.append(unit)
            elif ef_missing:
                parts.append(f"{unit} ✗ EnvironmentFile 缺失或指向文件不存在（{ef_path or '<空>'}）——token 注入面断，401 风险（手册 §8.8）")
                fails.append(unit)
            elif ok:
                parts.append(f"{unit} ✓ active + enabled + Restart=always + EnvironmentFile={ef_path}")
            else:
                parts.append(f"{unit} ✗ active={active} enabled={enabled} Restart={restart}")
                fails.append(unit)

        # 模板 Restart 策略 + EnvironmentFile 约束（部署包质量检查）
        tpl_fail = []
        if self.repo:
            for svc in SERVICES:
                tpl = os.path.join(self.repo, "systemd", f"opcos-{svc}.service.in")
                if not os.path.isfile(tpl):
                    tpl_fail.append(f"{os.path.basename(tpl)} 缺失")
                    continue
                content = open(tpl, encoding="utf-8").read()
                m = re.search(r"^Restart=(\S+)", content, re.M)
                if not m or m.group(1) != "always":
                    tpl_fail.append(f"{os.path.basename(tpl)} Restart={m.group(1) if m else '<无>'}")
                ef_m = re.search(r"^EnvironmentFile=(\S+)", content, re.M)
                if not ef_m:
                    tpl_fail.append(f"{os.path.basename(tpl)} 缺 EnvironmentFile= 实线（P2 固化：5 个 unit 全须含）")
            if tpl_fail:
                parts.append("模板 " + "、".join(tpl_fail))
                fails.append("template")
        elif not self.args.repo:
            parts.append("⚠ 未定位部署包模板目录（--repo 可指定），跳过模板 Restart/EnvironmentFile 校验")
            warns.append("template-skip")

        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        detail = "；".join(parts)
        fix = ""
        if fails:
            unit_list = [u for u in fails if u.endswith(".service")]
            if unit_list:
                fix = "sudo systemctl enable --now " + " ".join(unit_list)
            elif "template" in fails:
                fix = "改部署包 systemd/*.service.in 为 Restart=always + EnvironmentFile=@@ENV_FILE@@ 并 git commit（或先本地手动改 /etc/systemd/system/opcos-*.service 后 daemon-reload）"
        self.add(3, "systemd unit", status, detail, fix)

    # ============ G4 端口监听 ============
    def g4_ports(self):
        parts, fails, warns = [], [], []
        # 18080 必须仅回环
        p180 = self.listeners.get(18080)
        if not p180:
            parts.append("18080 ✗ 无监听")
            fails.append("18080")
        else:
            addrs = p180["addr"]
            procs = "、".join(sorted(p180["procs"])) or "未知进程"
            loopback = all(a in ("127.0.0.1", "::1", "[::1]") for a in addrs)
            if loopback:
                parts.append(f"18080 ✓ 仅回环 ({'、'.join(sorted(addrs))}) [{procs}]")
            else:
                parts.append(f"18080 ✗ 非回环监听 ({'、'.join(sorted(addrs))})——红线要求仅 127.0.0.1")
                fails.append("18080-non-loopback")
                warns.append("18080-non-loopback")
        # 3033 / 8081 有监听即可
        for port, svc, path, codes in PORT_PROBES:
            if port == 18080:
                continue
            if self.port_open(port):
                procs = "、".join(sorted(self.listeners[port]["procs"])) or "未知进程"
                parts.append(f"{port} ✓ 监听中 [{procs}]")
            else:
                parts.append(f"{port} ✗ 无监听（{svc} 未启动）")
                fails.append(str(port))
        # HTTP 探活
        for port, svc, path, codes in PORT_PROBES:
            if self.port_open(port):
                code, url = self.port_http(port, path)
                if code in codes:
                    parts.append(f"{port}{path} → {code} ✓")
                else:
                    parts.append(f"{port}{path} → {code or '超时/失败'} ✗")
                    fails.append(f"{port}-http")
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if fails:
            svc_map = {"18080": "gateway", "3033": "api", "8081": "web"}
            svcs = sorted({svc_map[f.split("-")[0]] for f in fails if f.split("-")[0] in svc_map})
            fix = ("sudo systemctl restart " + " ".join(f"opcos-{s}" for s in svcs)
                   + " 2>/dev/null || scripts/install-services.sh restart --out " + (self.out or "<数据目录>"))
            if "18080-non-loopback" in fails:
                fix = "网关必须仅监听 127.0.0.1（改 gateway.config.json host 字段后 systemctl restart opcos-gateway）；" + fix
        self.add(4, "端口监听", status, "；".join(parts), fix)

    # ============ G5 网关可达 + 配置校验 ============
    def g5_gateway(self):
        parts, fails, warns = [], [], []
        # healthz（免鉴权）
        code, url = self.port_http(18080, "/healthz")
        if code == 200:
            parts.append(f"{url} → 200 ✓")
        else:
            parts.append(f"{url} → {code or '失败'} ✗")
            fails.append("gateway-healthz")
        # 配置校验
        cfg_path = os.path.join(self.out, "llm-gateway", "gateway.config.json")
        if not os.path.isfile(cfg_path):
            cfg_path = os.path.join(self.out, "llm-gateway", "gateway.config.json") if False else None
        if not cfg_path and self.out:
            alt = os.path.join(self.out, "llm-gateway", "gateway.config.json")
            cfg_path = alt if os.path.isfile(alt) else None
        if cfg_path:
            try:
                cfg = json.load(open(cfg_path, encoding="utf-8"))
                providers = cfg.get("providers", []) or []
                enabled = [p.get("name") for p in providers if p.get("enabled")]
                dp = cfg.get("default_provider", "")
                um = cfg.get("unified_model", "")
                ok_pool = len(enabled) >= 1
                ok_dp = dp in {p.get("name") for p in providers}
                ok_um = bool(um)
                parts.append(f"配置: providers={len(providers)}(enabled {len(enabled)}) default={dp} unified={um}")
                if not ok_pool:
                    fails.append("no-provider")
                    parts.append("providers 池为空或全部禁用 ✗")
                if not ok_dp:
                    fails.append("bad-default-provider")
                    parts.append(f"default_provider={dp} 不在 providers 池 ✗")
                if not ok_um:
                    fails.append("no-unified-model")
                    parts.append("unified_model 为空 ✗")
            except Exception as e:
                warns.append("cfg-unreadable")
                parts.append(f"配置读取失败: {e}")
        else:
            parts.append("gateway.config.json 未找到（llm-gateway 未初始化）")
            warns.append("no-cfg")
        # /v1/models 带 Bearer（从凭据文件取 GATEWAY_CLIENT_TOKEN，只用于请求头，不打印）
        token = self._client_token()
        if token:
            mcode = self._models_with_token(token)
            if mcode == 200:
                parts.append("/v1/models (Bearer) → 200 ✓ 鉴权通过")
            elif mcode == 401:
                parts.append("/v1/models → 401（token 无效或已轮换）")
                warns.append("bad-token")
            else:
                parts.append(f"/v1/models → {mcode}（网关异常）")
                warns.append("models-err")
        else:
            mcode0 = parse_http_code("http://127.0.0.1:18080/v1/models", timeout=5)
            if mcode0 == 401:
                parts.append("/v1/models 无 token → 401 ✓（鉴权生效，未验证模型列表）")
            else:
                parts.append(f"/v1/models 无 token → {mcode0}（异常，应为 401）")
                warns.append("models-unexpected")
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if "gateway-healthz" in fails:
            fix = "sudo systemctl restart opcos-gateway && journalctl -u opcos-gateway -n 50 --no-pager"
        if fails and "gateway-healthz" not in fails:
            fix = "修复 gateway.config.json（providers 池 / default_provider / unified_model 须合法）后 sudo systemctl restart opcos-gateway"
        self.add(5, "网关可达", status, "；".join(parts), fix)

    def _client_token(self):
        if not self.cred_file:
            return None
        env = read_env_file(self.cred_file)
        for k in ("GATEWAY_CLIENT_TOKEN", "GATEWAY_ADMIN_TOKEN"):
            v = env.get(k, "").strip()
            if v and not PLACEHOLDER_RE.match(v):
                return v
        # secrets.env 兜底
        sec = os.path.join(self.out, "secrets.env")
        if os.path.isfile(sec):
            env2 = read_env_file(sec)
            for k in ("GATEWAY_CLIENT_TOKEN", "WORKBENCH_TOKEN"):
                v = env2.get(k, "").strip()
                if v and not PLACEHOLDER_RE.match(v):
                    return v
        return None

    def _models_with_token(self, token):
        """/v1/models 带真实 Bearer 探测。只用 urllib：token 不进命令行 argv（避免 ps 暴露）。
        （v0.2.0 修复：旧版 curl 分支误发字面量 'Bearer ***'，有 token 也恒 401 → G5 假告警。）"""
        try:
            req = urllib.request.Request("http://127.0.0.1:18080/v1/models",
                                         headers={"Authorization": f"Bearer {token}"})
            with urllib.request.urlopen(req, timeout=8) as resp:
                return resp.status
        except urllib.error.HTTPError as e:
            return e.code
        except Exception:
            return None

    # ---- G11 工具方法 ----
    def _proc_env_has_token(self, pid):
        """读 /proc/<pid>/environ 判 GATEWAY_CLIENT_TOKEN 存在且非空。
        返回 True/False/None（None=不可读，如权限或进程已退出）。"""
        try:
            raw = open(f"/proc/{pid}/environ", "rb").read()
        except OSError:
            return None
        for kv in raw.split(b"\x00"):
            if b"=" not in kv:
                continue
            k, _, v = kv.partition(b"=")
            if k == b"GATEWAY_CLIENT_TOKEN" and v.strip():
                return True
        return False

    def _proc_is_staging(self, pid):
        """按 cmdline 区分 staging daemon（opc-dispatcher.py --kanban-home .hermes-staging）。"""
        cl = pid_cmdline(pid)
        return "opc-dispatcher.py" in cl or ".hermes-staging" in cl

    def _chat_completions_probe(self, token):
        """/v1/chat/completions 带 Bearer 实测算连通（max_tokens=1，消耗极少）。
        返回 HTTP 状态码；401=token 无效（worker 将全量 401），None=网关不可达。"""
        model = "hermes-opc-v1"
        if self.out:
            cfg = os.path.join(self.out, "llm-gateway", "gateway.config.json")
            if os.path.isfile(cfg):
                try:
                    um = json.load(open(cfg, encoding="utf-8")).get("unified_model")
                    if um:
                        model = um
                except Exception:
                    pass
        body = json.dumps({"model": model,
                           "messages": [{"role": "user", "content": "ping"}],
                           "max_tokens": 1}).encode()
        req = urllib.request.Request(
            "http://127.0.0.1:18080/v1/chat/completions", data=body,
            headers={"Authorization": f"Bearer {token}",
                     "Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status
        except urllib.error.HTTPError as e:
            return e.code
        except Exception:
            return None

    def _spawn_health(self, parts, fails, warns):
        """近 1h worker spawn 成功率：crashed+protocol_violation 视为失败，>30% 告警。
        （0827 事故的 30+ 次 401 crash 在 task_events 记作 protocol_violation，必须计入失败。）"""
        db = self.kanban_db
        if not db:
            parts.append("近 1h spawn 成功率 ✗ 无法统计（kanban.db 未定位）")
            warns.append("spawn-no-db")
            return
        try:
            conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
            try:
                row = conn.execute(
                    "SELECT "
                    "SUM(CASE WHEN kind='spawned' THEN 1 ELSE 0 END), "
                    "SUM(CASE WHEN kind IN ('crashed','protocol_violation') THEN 1 ELSE 0 END), "
                    "SUM(CASE WHEN kind='protocol_violation' THEN 1 ELSE 0 END) "
                    "FROM task_events WHERE created_at > ?",
                    (time.time() - 3600,)).fetchone()
            finally:
                conn.close()
        except sqlite3.Error as e:
            parts.append(f"近 1h spawn 统计失败: {e}")
            warns.append("spawn-stats-err")
            return
        spawned, failed, pv = (int(x or 0) for x in row)
        if spawned + failed == 0:
            parts.append("近 1h 无派发事件（空闲板，成功率不判定）")
            return
        ratio = failed / (spawned + failed)
        mark = "✗" if ratio > 0.30 else "✓"
        parts.append(f"近 1h spawn 失败率 {ratio*100:.0f}% {mark}（spawned={spawned} failed={failed} 其中 protocol_violation={pv}；阈值 30%）")
        if ratio > 0.30:
            fails.append("spawn-crash-ratio")
        elif pv >= 10:
            warns.append("protocol-violation-burst")

    def _fail_events_window(self, window_s):
        """近 window_s 秒 failed 事件统计（权威源=task_events，不扫日志文本）：
        (n_failed, n_pv, first_ts, last_ts)。crashed+protocol_violation 视为失败
        （0827 事故的 401 crash 记作 protocol_violation）。DB 不可读返回 (None,)*4。"""
        db = self.kanban_db
        if not db:
            return (None,) * 4
        try:
            conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
            try:
                row = conn.execute(
                    "SELECT COUNT(*), "
                    "SUM(CASE WHEN kind='protocol_violation' THEN 1 ELSE 0 END), "
                    "MIN(created_at), MAX(created_at) "
                    "FROM task_events WHERE kind IN ('crashed','protocol_violation') "
                    "AND created_at > ?", (time.time() - window_s,)).fetchone()
            finally:
                conn.close()
        except sqlite3.Error:
            return (None,) * 4
        n = int(row[0] or 0)
        pv = int(row[1] or 0)
        return (n, pv, row[2], row[3])

    def _auto_block_residue(self):
        """auto_blocked 残留：status='blocked' 且 last_failure_error 带 401/auth/protocol 签名。
        返回 [(task_id, error摘要)]。"""
        db = self.kanban_db
        if not db:
            return []
        try:
            conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
            try:
                return conn.execute(
                    "SELECT id, substr(COALESCE(last_failure_error,''),1,70) FROM tasks "
                    "WHERE status='blocked' AND last_failure_error IS NOT NULL "
                    "AND (last_failure_error LIKE '%401%' OR last_failure_error LIKE '%unauthorized%' "
                    "OR last_failure_error LIKE '%Bearer%' OR last_failure_error LIKE '%protocol violation%')"
                ).fetchall()
            finally:
                conn.close()
        except sqlite3.Error:
            return []

    def _staging_note(self):
        """staging opcos-dispatcher.service 注记（若启用，同样检查；当前写进文档）。"""
        unit = "/etc/systemd/system/opcos-dispatcher.service"
        if not os.path.isfile(unit):
            return ("staging opcos-dispatcher.service 未安装（仅生产 opc-dispatcher.service 在跑）；"
                    "若启用 staging 需同检查：unit EnvironmentFile 含 GATEWAY_CLIENT_TOKEN + 18080 连通")
        code, out, _ = run(["systemctl", "is-active", "opcos-dispatcher"], timeout=10)
        active = out.strip() == "active"
        if not active:
            return "staging opcos-dispatcher.service 已安装但未运行（启用时同检查 token 注入面）"
        pid = None
        _, out2, _ = run(["systemctl", "show", "opcos-dispatcher", "-p", "ExecMainPID", "--value"], timeout=10)
        if out2.strip().isdigit():
            pid = int(out2.strip())
        if pid:
            r = self._proc_env_has_token(pid)
            if r is True:
                return f"staging opcos-dispatcher.service active，daemon(pid {pid}) environ 含 token ✓"
            if r is False:
                return (f"staging opcos-dispatcher.service active，但 daemon(pid {pid}) environ 缺 "
                        "GATEWAY_CLIENT_TOKEN ⚠（staging 板派活时 worker 会 401；当前板空转未触发。"
                        "修复：unit 加 EnvironmentFile=/home/gavin/.hermes/.env 后 systemctl daemon-reload && sudo systemctl restart opcos-dispatcher）")
        return f"staging opcos-dispatcher.service active（pid 不可读）"

    # ============ G11 dispatcher 环境自检（0827 事故固化） ============
    # 事故：18:05 生产切换外部 dispatcher 后 daemon 裸进程启动无 GATEWAY_CLIENT_TOKEN
    #      （unit 缺 EnvironmentFile），worker 的 LLM provider=hermes-opc(18080) 全部 401，
    #      30+ 次 crash / 13 卡 auto_blocked。本组把根因前置为可检测项。
    def g11_dispatcher_env(self):
        parts, fails, warns = [], [], []
        # ---- 11a daemon 进程 environ 含 GATEWAY_CLIENT_TOKEN（非空） ----
        pids = self.svc_procs.get("dispatcher", [])
        if not pids:
            parts.append("dispatcher 进程 ✗ 未运行（G8 已判 FAIL；环境自检无对象）")
            fails.append("dispatcher-down")
        else:
            for pid in pids:
                r = self._proc_env_has_token(pid)
                if r is True:
                    parts.append(f"pid {pid} environ 含 GATEWAY_CLIENT_TOKEN ✓")
                elif r is False:
                    if self._proc_is_staging(pid):
                        # staging 板空转时仅注记（见 _staging_note），不判 FAIL
                        parts.append(f"staging daemon(pid {pid}) environ 无 GATEWAY_CLIENT_TOKEN（见 staging 注记）")
                    else:
                        parts.append(f"pid {pid} environ 缺 GATEWAY_CLIENT_TOKEN ✗（0827 401 事故同款根因：裸进程启动/未带 EnvironmentFile）")
                        fails.append("env-no-token")
                else:
                    parts.append(f"pid {pid} environ 不可读（权限/已退出）")
                    warns.append("environ-unreadable")
        # ---- 11b llm-gateway /v1/chat/completions 带 token 实测算连通 ----
        token = self._client_token()
        if not token:
            parts.append("/v1/chat/completions ✗ 无可用 client token（~/.hermes/.env / llm.env 未找到）")
            warns.append("no-client-token")
        else:
            code = self._chat_completions_probe(token)
            if code == 200:
                parts.append("/v1/chat/completions (Bearer, max_tokens=1) → 200 ✓ 实测算连通")
            elif code == 401:
                parts.append("/v1/chat/completions → 401 ✗（token 无效/网关未放行 → worker 将全量 401）")
                fails.append("chat-401")
            elif code is None:
                parts.append("/v1/chat/completions → 无响应（18080 不通，见 G4/G5）")
                fails.append("chat-unreachable")
            else:
                parts.append(f"/v1/chat/completions → {code}（网关响应但非 200）")
                warns.append(f"chat-{code}")
        # ---- 11c worker spawn 成功率（近 1h） ----
        self._spawn_health(parts, fails, warns)
        # ---- 11d auto_blocked 残留 + 近 24h failed 事件窗口（DB 权威源，不扫日志文本） ----
        residue = self._auto_block_residue()
        if residue:
            ids = ",".join(r[0] for r in residue[:8])
            parts.append(f"auto_blocked 残留 {len(residue)} 卡（{ids}）：token 修复后需人工 unblock 重排")
            warns.append("auto-block-residue")
        else:
            parts.append("auto_blocked 残留 0 卡 ✓")
        n24, pv24, t0, t1 = self._fail_events_window(86400)
        if n24 is None:
            parts.append("近 24h failed 事件统计失败（DB 不可读）")
            warns.append("fail-stats-err")
        elif n24 == 0:
            parts.append("近 24h failed 事件 0 次 ✓（无 401/崩溃窗口）")
        else:
            rng = (f"{time.strftime('%m-%d %H:%M', time.localtime(t0))}~{time.strftime('%H:%M', time.localtime(t1))}"
                   if t0 and t1 else "?")
            parts.append(f"近 24h failed 事件 {n24} 次（protocol_violation {pv24}，窗口 {rng}）：已恢复则观察，持续则见 11c")
        # ---- 11e staging 注记（若启用同样检查；当前写进文档） ----
        parts.append(self._staging_note())
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if "env-no-token" in fails:
            fix = "systemctl --user restart opc-dispatcher.service（unit 已含 EnvironmentFile=%h/.hermes/.env；启动后确认 /proc/<pid>/environ 含 GATEWAY_CLIENT_TOKEN）"
        if "chat-401" in fails:
            fix = ("检查 ~/.hermes/.env 的 GATEWAY_CLIENT_TOKEN 与网关配置一致性，然后 "
                   "systemctl --user restart opc-dispatcher.service（worker 全 401 即此因）")
        if "spawn-crash-ratio" in fails:
            fix = (fix + "；" if fix else "") + \
                  "查 worker 日志 ~/.hermes/kanban/boards/opc/logs/t_*.log 的 401 行；token 修复后 unblock 重排：hermes kanban unblock <task_id>"
        if "auto-block-residue" in warns:
            fix = (fix + "；" if fix else "") + "残留卡 unblock：hermes kanban unblock <task_id>（批量可用 $(hermes kanban list --status blocked) 循环）"
        self.add(11, "dispatcher 环境自检", status, "；".join(parts), fix)

    # ============ G6 代理连通 ============
    def g6_proxy(self):
        # 解析代理地址
        proxy = self.args.proxy
        if not proxy:
            for k in ("HTTPS_PROXY", "https_proxy", "ALL_PROXY", "all_proxy", "HTTP_PROXY", "http_proxy"):
                v = os.environ.get(k, "").strip()
                if v:
                    proxy = v
                    break
        if not proxy:
            proxy = "http://127.0.0.1:7890"
        # 代理端口是否监听
        m = re.search(r"//([^:/]+):(\d+)", proxy)
        proxy_alive = None
        if m:
            host, port = m.group(1), int(m.group(2))
            proxy_alive = (port in self.listeners) if host in ("127.0.0.1", "localhost") else None
            if proxy_alive is None:
                try:
                    s = socket.create_connection((host, port), timeout=2)
                    s.close()
                    proxy_alive = True
                except OSError:
                    proxy_alive = False
        detail = f"代理: {proxy} {'(端口有监听)' if proxy_alive else '(端口无监听)'}"
        # 探测
        try_proxy = proxy_alive is not False  # 有监听或未知时都先试代理
        if try_proxy:
            for url, codes in PROXY_PROBES:
                c = parse_http_code(url, proxy=proxy)
                if c in codes:
                    self.add(6, "代理连通", "PASS",
                             f"{detail}；{url} → {c} ✓（经代理出网正常）")
                    return
        # 代理不通 → 直连兜底（无墙环境）
        for url, codes in PROXY_PROBES:
            c = parse_http_code(url, proxy=None)
            if c in codes:
                self.add(6, "代理连通", "PASS",
                         f"{detail}；代理探测失败，但直连 {url} → {c} ✓（无墙环境）")
                return
        self.add(6, "代理连通", "FAIL",
                 f"{detail}；经代理与直连均无法访问外网",
                 "检查代理进程（如 sing-box，systemctl status sing-box 或看门狗日志）；有墙环境必须先起代理，无墙环境无需代理")

    # ============ G7 模型 key 有效 ============
    def g7_keys(self):
        parts, fails, warns = [], [], []
        cred = self.cred_file
        if not cred:
            self.add(7, "模型 key", "FAIL",
                     "未找到 llm.env / gateway.env（凭据文件缺失）",
                     "运行 opc-init 生成 llm.env（或确认数据目录 --out 正确）；上游 key 只写入 llm.env 并 chmod 600")
            return
        mode = path_mode(cred)
        env = read_env_file(cred)
        # 1) 权限 600
        if mode is None:
            fails.append("cred-missing")
            parts.append(f"{os.path.basename(cred)} 不可读")
        elif (int(mode, 8) & 0o077) != 0:
            fails.append("cred-perm")
            parts.append(f"{os.path.basename(cred)} 权限 {mode}（需 600）")
        else:
            parts.append(f"{os.path.basename(cred)} 权限 {mode} ✓")
        # 2) 非占位符：上游 key 至少 1 个有效
        upstream = {k: v for k, v in env.items() if k.endswith("_API_KEY") and v}
        valid_upstream = {k: v for k, v in upstream.items()
                          if not PLACEHOLDER_RE.match(v) and len(v) >= 8}
        tok_keys = {k: v for k, v in env.items()
                    if k in ("GATEWAY_CLIENT_TOKEN", "GATEWAY_ADMIN_TOKEN", "WORKBENCH_TOKEN") and v}
        valid_tok = {k: v for k, v in tok_keys.items()
                     if not PLACEHOLDER_RE.match(v) and len(v) >= 8}
        if upstream:
            for k, v in upstream.items():
                mark = "✓" if k in valid_upstream else "✗(占位符)"
                parts.append(f"{k}={mask_key(v)} {mark}")
        else:
            parts.append("无 *_API_KEY 上游 key")
            fails.append("no-upstream-key")
        if valid_tok:
            for k in valid_tok:
                parts.append(f"{k}={mask_key(valid_tok[k])} ✓")
        else:
            warns.append("no-token")
            parts.append("无有效 GATEWAY_CLIENT_TOKEN/ADMIN_TOKEN（网关鉴权不可验证）")
        # secrets.env 权限
        sec = os.path.join(self.out, "secrets.env")
        if os.path.isfile(sec):
            smode = path_mode(sec)
            if smode and (int(smode, 8) & 0o077) != 0:
                fails.append("secrets-perm")
                parts.append(f"secrets.env 权限 {smode}（需 600）")
            else:
                parts.append(f"secrets.env 权限 {smode} ✓")
        # 3) 网关侧探测（读 llm-gateway.json 快照，不触发真实调用）
        gw_json = os.path.join(self.out, "llm-gateway.json")
        if os.path.isfile(gw_json):
            try:
                snap = json.load(open(gw_json, encoding="utf-8"))
                avail = snap.get("available")
                us = snap.get("usage_state", {}) or {}
                mon = us.get("monitor", {}) or {}
                cur = us.get("current_provider", {}) or {}
                provs = us.get("providers", {}) or {}
                online = mon.get("gateway_online")
                cur_name = cur.get("name")
                enabled_n = sum(1 for p in provs.values() if isinstance(p, dict) and p.get("enabled"))
                if avail is True:
                    parts.append("llm-gateway.json available=true ✓")
                else:
                    warns.append("gw-snapshot")
                    parts.append(f"llm-gateway.json available={avail}")
                if online is True:
                    parts.append(f"网关在线 ✓（current_provider={cur_name}）")
                else:
                    warns.append("gw-offline")
                    parts.append(f"网关 online={online}（current_provider={cur_name}）")
                if provs and enabled_n == 0:
                    warns.append("no-enabled-provider")
                    parts.append("providers 快照中无 enabled 项")
            except Exception as e:
                warns.append("gw-json-err")
                parts.append(f"llm-gateway.json 解析失败: {e}")
        else:
            warns.append("no-gw-json")
            parts.append("llm-gateway.json 未生成（llm_gateway_sync 未跑过）")
        # 4) --deep：真实探话（显式开启才触发）
        if self.args.deep:
            token = self._client_token()
            if token:
                body = json.dumps({"model": "hermes-opc-v1", "messages": [{"role": "user", "content": "ping"}],
                                   "max_tokens": 8})
                code, out, _ = run(["curl", "-s", "-o", os.devnull, "-w", "%{http_code}",
                                    "--max-time", "30", "-H", f"Authorization: Bearer {token}",
                                    "-H", "Content-Type: application/json", "-d", body,
                                    "http://127.0.0.1:18080/v1/chat/completions"], timeout=35)
                if code == 0 and out.strip() == "200":
                    parts.append("--deep 真实探话 → 200 ✓")
                else:
                    warns.append("deep-fail")
                    parts.append(f"--deep 真实探话 → {out.strip() or '失败'}")
            else:
                warns.append("deep-no-token")
                parts.append("--deep 跳过：无有效 token")
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if "cred-perm" in fails or "secrets-perm" in fails:
            fix = "chmod 600 llm.env secrets.env（key 只进凭据文件）"
        if "no-upstream-key" in fails or "cred-missing" in fails:
            fix = "把真实上游 API key 写入 " + (cred or "<数据目录>/llm.env") + "（key 只显示掩码，严禁明文落码/配置/文档）"
        self.add(7, "模型 key", status, "；".join(parts), fix)

    # ============ G8 kanban 派发链路 ============
    def g8_kanban(self):
        parts, fails, warns = [], [], []
        db = self.kanban_db
        if not db:
            self.add(8, "kanban 派发", "FAIL",
                     "未定位 kanban.db（--kanban-db 可指定）",
                     "确认 HERMES_KANBAN_DB 或 --out 数据目录含 kanban.db；未初始化则运行 opc-init")
            return
        parts.append(f"DB: {db}")
        # 可读写
        try:
            conn = sqlite3.connect(db, timeout=3)
            cur = conn.cursor()
            cur.execute("PRAGMA integrity_check")
            ic = cur.fetchone()[0]
            cur.execute("BEGIN IMMEDIATE")
            cur.execute("SELECT 1")
            cur.execute("ROLLBACK")
            conn.close()
            parts.append(f"integrity={ic} 可读写 ✓" if ic == "ok" else f"integrity={ic} ✗")
            if ic != "ok":
                fails.append("db-corrupt")
        except sqlite3.Error as e:
            parts.append(f"SQLite 不可用: {e} ✗")
            fails.append("db-unreadable")
            conn = None
        # 派发事件新鲜度
        if conn is not None:
            try:
                conn = sqlite3.connect(db, timeout=3)
                cur = conn.cursor()
                row = cur.execute(
                    "SELECT MAX(created_at) FROM task_events WHERE kind IN ('spawned','claimed','completed')"
                ).fetchone()
                if row and row[0]:
                    age = time.time() - row[0]
                    parts.append(f"最近派发事件 {sec_ago(row[0])}（<24h）✓")
                    if age > 86400:
                        warns.append("stale-events")
                else:
                    parts.append("task_events 无派发事件（冷启动空板）")
                    warns.append("no-events")
                # running 任务 + 心跳
                n_run = cur.execute("SELECT COUNT(*) FROM tasks WHERE status='running'").fetchone()[0]
                stale = cur.execute(
                    "SELECT COUNT(*) FROM tasks WHERE status='running' AND "
                    "(last_heartbeat_at IS NULL OR last_heartbeat_at < ?)",
                    (time.time() - 900,)).fetchone()[0]
                if n_run:
                    parts.append(f"running 任务 {n_run}（心跳过期 {stale}）")
                    if stale:
                        warns.append("stale-heartbeat")
                conn.close()
            except sqlite3.Error as e:
                parts.append(f"事件查询失败: {e}")
                warns.append("ev-query-err")
        # dispatcher 存活（进程 + unit）
        disp_pids = self.svc_procs.get("dispatcher", [])
        if disp_pids:
            parts.append(f"dispatcher 进程 ✓ (pid {','.join(str(p) for p in disp_pids[:3])})")
        else:
            parts.append("dispatcher 进程 ✗ 未找到")
            fails.append("dispatcher-down")
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if "dispatcher-down" in fails:
            fix = "sudo systemctl start opcos-dispatcher 2>/dev/null || (cd <部署包>/scripts && python3 -m kanban_dispatcher.cli --config <out>/config/dispatcher.yaml)"
        if "db-unreadable" in fails:
            fix = "chmod 600/644 检查 kanban.db 权限；或从 backups/ 恢复：scripts/backup.sh 对应备份集"
        self.add(8, "kanban 派发", status, "；".join(parts), fix)

    # ============ G9 collector 数据流 ============
    def g9_collector(self):
        parts, fails, warns = [], [], []
        threshold = self.args.threshold_min * 60
        out = self.out
        # 数据文件（OUT 直下 / OUT/data 容器形态）
        def _locate(name):
            for base in (out, os.path.join(out, "data") if out else None):
                if base:
                    p = os.path.join(base, name)
                    if os.path.isfile(p):
                        return p
            return None

        spec = [
            ("status.json",       "FAIL", "opc-bus 数据总线停止（status.json 未更新）", 1),
            ("token-stats.json",  "WARN", "collector 采集停止（token-stats.json 未更新）", 6),
            ("bus-state.json",    "FAIL", "opc-bus 水位线文件未更新", 1),
            ("llm-gateway.json",  "WARN", "网关同步源未更新（llm-gateway.json 过期）", 12),
        ]
        for name, on_stale, stale_msg, fail_mult in spec:
            p = _locate(name)
            if not p:
                parts.append(f"{name} ✗ 不存在")
                if on_stale == "FAIL":
                    fails.append(name)
                else:
                    warns.append(name)
                continue
            age = time.time() - os.path.getmtime(p)
            fresh = age < threshold
            hard_bad = age >= threshold * fail_mult
            if fresh:
                mark = "✓"
                parts.append(f"{name} ✓ {sec_ago(os.path.getmtime(p))}（阈值 {self.args.threshold_min}min）")
            elif on_stale == "FAIL":
                mark = "✗"
                parts.append(f"{name} ✗ {sec_ago(os.path.getmtime(p))}（阈值 {self.args.threshold_min}min）")
                fails.append(name)
            elif hard_bad:
                mark = "✗"
                parts.append(f"{name} ✗ {sec_ago(os.path.getmtime(p))}（> {self.args.threshold_min * fail_mult}min，{stale_msg}）")
                fails.append(name)
            else:
                mark = "⚠"
                parts.append(f"{name} ⚠ {sec_ago(os.path.getmtime(p))}（超过 {self.args.threshold_min}min，{stale_msg}）")
                warns.append(name)
        # bus watermark
        bp = _locate("bus-state.json")
        if bp:
            try:
                bus = json.load(open(bp, encoding="utf-8"))
                wm = bus.get("kanban_watermark")
                parts.append(f"bus 水位线 kanban_watermark={wm}" + (" ✓" if isinstance(wm, int) and wm > 0 else " ⚠"))
                if not (isinstance(wm, int) and wm > 0):
                    warns.append("no-watermark")
            except Exception:
                warns.append("bus-json-err")
                parts.append("bus-state.json 解析失败")
        # crontab 块（部署形态应有 OPC-OS collector 块；生产形态可无，仅注记）
        code, out2, _ = run(["crontab", "-l"], timeout=10)
        has_block = code == 0 and "OPC-OS collector" in out2
        parts.append("crontab OPC-OS 块 " + ("✓ 存在" if has_block else "（无，生产形态由 systemd/timer 维护时正常）"))
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if "status.json" in fails or "bus-state.json" in fails:
            fix = "sudo systemctl restart opcos-collector && journalctl -u opcos-collector -n 30 --no-pager"
        if "token-stats.json" in fails:
            fix = "检查 crontab 采集任务：crontab -l | grep OPC-OS；缺失则重跑 scripts/install-services.sh install --out " + (out or "<数据目录>")
        if "llm-gateway.json" in fails:
            fix = "检查 llm_gateway_sync 任务（crontab */5 或 systemd timer）；手动跑：python3 scripts/llm_gateway_sync.py --src <out>/llm-gateway --out <out>/llm-gateway.json"
        self.add(9, "collector 数据流", status, "；".join(parts), fix)

    def _scan_file(self, fp, sk_hits):
        """单文件明文 key 扫描（跳过凭据 env 文件；每文件只报一次，不打印 key 内容）。"""
        fn = os.path.basename(fp)
        if fn in ("llm.env", "gateway.env", "secrets.env", "env.sh") or fn.endswith(".env"):
            return
        try:
            content = open(fp, "r", encoding="utf-8", errors="replace").read()
        except OSError:
            return
        if SK_RE.search(content):
            rel = os.path.relpath(fp, self.out or self.repo)
            if rel not in sk_hits:
                sk_hits.append(rel)

    # ============ G10 红线复核 ============
    def g10_redline(self):
        parts, fails, warns = [], [], []
        # 1) 凭据权限（G7 已查，汇总到一组）
        for f in (self.cred_file, os.path.join(self.out, "secrets.env")):
            if f and os.path.isfile(f):
                mode = path_mode(f)
                if mode and (int(mode, 8) & 0o077) != 0:
                    parts.append(f"{os.path.basename(f)} 权限 {mode} ✗（需 600）")
                    fails.append(f"{os.path.basename(f)}-perm")
                else:
                    parts.append(f"{os.path.basename(f)} 权限 {mode} ✓")
        # 2) 明文 key 扫描（配置/代码/文档；凭据 env 文件本身排除）
        #    范围 = 部署包（scripts/systemd/docs/deploy/顶层） + OUT 的 config/*.json + 顶层数据 *.json
        #    （OUT 顶层 *.md 是生产运维/历史文档，不属于交付形态，不扫，避免编码/示例噪音）
        scan_dirs = []
        if self.out:
            cfg = os.path.join(self.out, "config")
            if os.path.isdir(cfg):
                scan_dirs.append(cfg)
            data_json = os.path.join(self.out, "*.json")
            if os.path.isdir(self.out):
                scan_dirs.append(data_json)  # glob 模式，下方特判
        if self.repo:
            for sub in ("scripts", "systemd", "docs", "deploy"):
                base = os.path.join(self.repo, sub)
                if os.path.isdir(base):
                    scan_dirs.append(base)
            scan_dirs.append(os.path.join(self.repo, "*.json"))
            scan_dirs.append(os.path.join(self.repo, "*.md"))
        sk_hits = []
        seen = set()
        for base in scan_dirs:
            key = os.path.abspath(base)
            if key in seen:
                continue
            seen.add(key)
            if base.endswith("*.json") or base.endswith("*.md"):
                for fp in __import__("glob").glob(base):
                    self._scan_file(fp, sk_hits)
                continue
            for root, dirs, files in os.walk(base):
                dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "node_modules", "vendor",
                                                        "backups", "events", "logs", "run", "tests",
                                                        ".backup", "demo", "data")]
                for fn in files:
                    if not fn.endswith((".py", ".js", ".cjs", ".json", ".md", ".in", ".yml", ".yaml", ".sh")):
                        continue
                    self._scan_file(os.path.join(root, fn), sk_hits)
        if sk_hits:
            parts.append(f"疑似明文 key: {', '.join(sk_hits)} ✗（key 只允许在凭据 env 文件）")
            fails.append("plaintext-key")
        else:
            parts.append("配置/代码/文档 sk- 模式扫描 0 命中 ✓")
        # 3) 无裸进程（systemd 环境：cgroup 归属）
        if systemd_available():
            for svc in SERVICES:
                for pid in self.svc_procs.get(svc, [])[:2]:
                    cg = pid_cgroup(pid)
                    if f"opcos-{svc}.service" in cg:
                        continue
                    if "/docker/" in cg or "docker" in cg:
                        parts.append(f"{svc}(pid {pid}) 容器托管（docker cgroup）——非裸进程 ✓")
                        continue
                    if "/system.slice/" in cg and "opcos-" not in cg:
                        parts.append(f"{svc}(pid {pid}) ⚠ 在 system.slice 但无 opcos unit 归属（疑似裸进程）")
                        warns.append("bare-proc")
                    elif "opcos-" not in cg:
                        parts.append(f"{svc}(pid {pid}) ⚠ cgroup 无 opcos 归属（裸进程：{cg[:60]}）")
                        warns.append("bare-proc")
        else:
            parts.append("无 systemd：nohup+pidfile 为文档化退化路径，跳过裸进程检查 ✓")
        status = "FAIL" if fails else ("WARN" if warns else "PASS")
        fix = ""
        if "plaintext-key" in fails:
            fix = "从配置/代码/文档移除明文 key，改为引用环境变量（如 ${GATEWAY_CLIENT_TOKEN}）；key 唯一事实源=凭据 env 文件"
        if any(f.endswith("-perm") for f in fails):
            fix = "chmod 600 " + " ".join(
                [os.path.basename(f) for f in (self.cred_file, os.path.join(self.out, "secrets.env"))
                 if f and os.path.isfile(f)]) + "；"
        self.add(10, "红线复核", status, "；".join(parts), fix)

    # ---- 汇总 ----
    def run_all(self):
        self.g1_runtime()
        self.g2_processes()
        self.g3_systemd()
        self.g4_ports()
        self.g5_gateway()
        self.g6_proxy()
        self.g7_keys()
        self.g8_kanban()
        self.g9_collector()
        self.g10_redline()
        self.g11_dispatcher_env()

    def summary(self):
        n_pass = sum(1 for g in self.groups if g["status"] == "PASS")
        n_fail = sum(1 for g in self.groups if g["status"] == "FAIL")
        n_warn = sum(1 for g in self.groups if g["status"] == "WARN")
        strict = self.args.strict and n_warn > 0
        exit_code = 2 if self.args.group and self.args.group not in self.results else (1 if n_fail or strict else 0)
        return n_pass, n_fail, n_warn, exit_code


def human_report(doc, n_pass, n_fail, n_warn, exit_code):
    out = []
    out.append(f"OPC-OS Doctor v{VERSION} — 运行期自助诊断（Gavin P0-3 验收项 C 能诊断）")
    out.append(f"时间: {now_iso()}")
    out.append(f"数据目录: {doc.out or '<未定位>'}（{doc.out_how}）")
    out.append(f"看板 DB: {doc.kanban_db or '<未定位>'}")
    if doc.repo:
        out.append(f"部署包: {doc.repo}")
    out.append("")
    for g in doc.groups:
        if doc.args.group and g["group"] != doc.args.group:
            continue
        name = f"[{g['group']:02d}/{len(doc.groups)}] {g['name']}"
        status = g["status"]
        icon = {"PASS": "✅ PASS", "FAIL": "❌ FAIL", "WARN": "⚠️ WARN"}[status]
        out.append(f"{name:<34} {icon}")
        if g["detail"]:
            for line in g["detail"].split("；"):
                if line.strip():
                    out.append(f"      {line.strip()}")
        if g["fix"]:
            out.append(f"      修复: {g['fix']}")
        out.append("")
    out.append(f"结果: {n_pass} PASS / {n_fail} FAIL / {n_warn} WARN  →  退出码 {exit_code}")
    out.append("退出码: 0=全绿 / 1=存在 FAIL（--strict 时 WARN 计入）/ 2=工具错误或环境不可判定")
    if n_fail:
        out.append("")
        out.append("=== FAIL 项修复命令汇总（照抄执行可自愈）===")
        for g in doc.groups:
            if g["status"] == "FAIL" and g["fix"]:
                out.append(f"  [{g['group']:02d}] {g['name']}:")
                out.append(f"      {g['fix']}")
    return "\n".join(out)


def json_report(doc, n_pass, n_fail, n_warn, exit_code):
    return json.dumps({
        "tool": "opc-os-doctor",
        "version": VERSION,
        "timestamp": now_iso(),
        "out_dir": doc.out,
        "kanban_db": doc.kanban_db,
        "repo": doc.repo,
        "exit_code": exit_code,
        "summary": {"pass": n_pass, "fail": n_fail, "warn": n_warn},
        "groups": doc.groups,
    }, ensure_ascii=False, indent=2)


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="opc-os-doctor",
        description="OPC-OS 运行期自助诊断：11 组检查（运行时/进程/systemd/端口/网关/代理/key/kanban/数据流/红线/dispatcher 环境自检）+ 修复建议。",
        epilog="退出码: 0=全绿 / 1=存在 FAIL / 2=工具错误或环境不可判定",
    )
    ap.add_argument("--out", help="opc-init 输出目录（数据根）；默认自动探测")
    ap.add_argument("--repo", help="opc-os 部署包仓库根（systemd 模板检查）；默认从脚本路径推断")
    ap.add_argument("--kanban-db", help="看板 SQLite 路径；默认 OUT/kanban.db → HERMES_KANBAN_DB → 常见位置")
    ap.add_argument("--proxy", help="代理地址（如 http://127.0.0.1:7890）；默认环境变量或 127.0.0.1:7890")
    ap.add_argument("--json", action="store_true", help="机器可读 JSON 输出")
    ap.add_argument("--deep", action="store_true",
                    help="触发一次真实模型探话（max_tokens=8，消耗极少 token；默认只读快照不触发计费）")
    ap.add_argument("--threshold-min", type=int, default=5,
                    help="collector 数据文件新鲜度阈值（分钟，默认 5）")
    ap.add_argument("--strict", action="store_true", help="WARN 计入失败（退出码 1）")
    ap.add_argument("--group", type=int, choices=range(1, 12),
                    help="只跑指定组（1-11，排查用）")
    args = ap.parse_args(argv)

    # 工具自身错误先拦截：--out 显式但不存在
    if args.out and not os.path.isdir(args.out):
        msg = f"数据目录不存在: {args.out}（--out 需指向 opc-init 输出目录）"
        if args.json:
            print(json.dumps({"tool": "opc-os-doctor", "version": VERSION, "timestamp": now_iso(),
                              "exit_code": 2, "error": msg}, ensure_ascii=False, indent=2))
        else:
            print(f"OPC-OS Doctor v{VERSION} — ❌ 工具错误: {msg}")
        return 2

    out_dir, out_how = find_out_dir(args.out)
    repo_dir = find_repo_dir(args.repo, os.path.abspath(__file__))
    kanban_db = find_kanban_db(out_dir or "", args.kanban_db)
    cred_file = find_cred_file(out_dir) if out_dir else None
    listeners = parse_ss_listen()

    doc = Doctor(args, out_dir, out_how, repo_dir, kanban_db, cred_file, listeners)
    try:
        doc.run_all()
    except Exception as e:
        msg = f"工具内部异常: {type(e).__name__}: {e}"
        if args.json:
            print(json.dumps({"tool": "opc-os-doctor", "version": VERSION, "timestamp": now_iso(),
                              "exit_code": 2, "error": msg}, ensure_ascii=False, indent=2))
        else:
            print(f"OPC-OS Doctor v{VERSION} — ❌ {msg}")
        return 2

    n_pass, n_fail, n_warn, exit_code = doc.summary()
    if args.json:
        print(json_report(doc, n_pass, n_fail, n_warn, exit_code))
    else:
        print(human_report(doc, n_pass, n_fail, n_warn, exit_code))
    return exit_code


if __name__ == "__main__":
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    sys.exit(main())
