#!/usr/bin/env python3
"""OPC OS — 治理仪表盘「token 消耗统计」模块（0826-os-3）

Gavin 拍板 G-2026-08-26-007·②：治理仪表盘删除「网站访问趋势/引流效果」两块（官网母体数据，
客户部署后无意义），改为展示客户自己部署的 AI 成员 token 消耗统计。

本模块 = 该改造的单一事实源（single source of truth）：
  - TOKENS_I18N：12 语言 tokens.* 文案（进 OPC_ZH 兜底 + locales/*.json）
  - transform_governance_html()：把旧版 governance.html（含 0822-t1b 流量区块 / 0820-ka 引流区块 /
    0822-t1e 留言明细抽屉）变换为新版（三块全删 + token 模块注入 + i18n 键清理 + __I18N_VER 递增）
  - transform_locale()：locale JSON 删 governance.trends/acquisition/messages 键、加 governance.tokens

使用方：
  - scripts/patch_static.py patch_governance()（company-site 源 → 部署包副本，保持重建一致）
  - 本机生成 web/opc/governance.html 与 web/locales/*.json 的部署产物（脚本直跑）

幂等：重复执行结果稳定（基于确定性标记切片/替换；__I18N_VER 递增作用于源版号）。
"""
import json
import os
import re

# ================= i18n：governance.tokens.*（12 语言） =================
# 与既有 locale 文件的语气/术语保持一致；zh 为源语言，其余按对应语言风格翻译。
TOKENS_I18N = {
    'zh': {
        'secTitle': 'Token 消耗统计', 'secTag': '// tokens',
        'secHint': '各成员 / 角色 token 用量与成本，数据来自本地 token-stats',
        'noteEst': '估算成本 = 模型报价估算，非实际账单',
        'kpiTotal': '累计 Token', 'kpiTotalSub': '会话 + cron 用量合计',
        'kpiCost': '估算成本', 'kpiCostSub': '模型报价估算，非实际账单',
        'kpiSessions': '会话数', 'kpiSessionsSub': '累计会话 · cron {cron} 次',
        'th': {'member': '成员 / 角色', 'tokIn': 'Token 输入', 'tokOut': 'Token 输出',
               'total': '合计', 'cost': '成本 (USD)', 'share': '消耗占比'},
        'trendTitle': '30 天消耗趋势', 'trendSub': '每日 token 总量或成本，可切换',
        'trendAria': '30 天 token 消耗趋势图',
        'tabAria': '切换趋势指标', 'tabTokens': 'Token', 'tabCost': '成本',
        'empty': '数据采集中，稍后回来看看',
    },
    'en': {
        'secTitle': 'Token Consumption', 'secTag': '// tokens',
        'secHint': 'Per-member / role token usage & cost, from local token-stats',
        'noteEst': 'Estimated cost = model pricing estimate, not an actual bill',
        'kpiTotal': 'Total Tokens', 'kpiTotalSub': 'Sessions + cron usage',
        'kpiCost': 'Estimated Cost', 'kpiCostSub': 'Model pricing estimate, not an actual bill',
        'kpiSessions': 'Sessions', 'kpiSessionsSub': 'Total sessions · cron {cron}',
        'th': {'member': 'Member / Role', 'tokIn': 'Token In', 'tokOut': 'Token Out',
               'total': 'Total', 'cost': 'Cost (USD)', 'share': 'Share'},
        'trendTitle': '30-Day Consumption Trend', 'trendSub': 'Daily token total or cost, switchable',
        'trendAria': '30-day token consumption trend chart',
        'tabAria': 'Switch trend metric', 'tabTokens': 'Token', 'tabCost': 'Cost',
        'empty': 'Collecting data, check back later',
    },
    'ja': {
        'secTitle': 'トークン消費統計', 'secTag': '// tokens',
        'secHint': 'メンバー / 役割別トークン使用量とコスト（ローカル token-stats）',
        'noteEst': '推定コスト = モデル料金による見積もり（実際の請求書ではありません）',
        'kpiTotal': '累計トークン', 'kpiTotalSub': 'セッション + cron 使用量',
        'kpiCost': '推定コスト', 'kpiCostSub': 'モデル料金の見積もり',
        'kpiSessions': 'セッション数', 'kpiSessionsSub': '累計セッション · cron {cron} 回',
        'th': {'member': 'メンバー / 役割', 'tokIn': '入力', 'tokOut': '出力',
               'total': '合計', 'cost': 'コスト (USD)', 'share': '割合'},
        'trendTitle': '30日消費トレンド', 'trendSub': '日次トークン総量またはコスト（切替可）',
        'trendAria': '30日トークン消費トレンド図',
        'tabAria': '指標を切り替え', 'tabTokens': 'トークン', 'tabCost': 'コスト',
        'empty': 'データ収集中です。後で確認してください',
    },
    'ko': {
        'secTitle': '토큰 소비 통계', 'secTag': '// tokens',
        'secHint': '멤버 / 역할별 토큰 사용량과 비용 (로컬 token-stats)',
        'noteEst': '추정 비용 = 모델 요금 추정치 (실제 청구서 아님)',
        'kpiTotal': '누적 토큰', 'kpiTotalSub': '세션 + cron 사용량',
        'kpiCost': '추정 비용', 'kpiCostSub': '모델 요금 추정치',
        'kpiSessions': '세션 수', 'kpiSessionsSub': '누적 세션 · cron {cron}회',
        'th': {'member': '멤버 / 역할', 'tokIn': '입력', 'tokOut': '출력',
               'total': '합계', 'cost': '비용 (USD)', 'share': '비율'},
        'trendTitle': '30일 소비 추이', 'trendSub': '일별 토큰 총량 또는 비용 (전환 가능)',
        'trendAria': '30일 토큰 소비 추이 차트',
        'tabAria': '지표 전환', 'tabTokens': '토큰', 'tabCost': '비용',
        'empty': '데이터 수집 중입니다. 나중에 다시 확인하세요',
    },
    'fr': {
        'secTitle': 'Consommation de tokens', 'secTag': '// tokens',
        'secHint': 'Utilisation de tokens par membre / rôle et coût (token-stats local)',
        'noteEst': 'Coût estimé = estimation selon les tarifs du modèle, pas une facture réelle',
        'kpiTotal': 'Tokens totaux', 'kpiTotalSub': 'Sessions + usage cron',
        'kpiCost': 'Coût estimé', 'kpiCostSub': 'Estimation selon les tarifs du modèle',
        'kpiSessions': 'Sessions', 'kpiSessionsSub': 'Sessions totales · cron {cron}',
        'th': {'member': 'Membre / Rôle', 'tokIn': 'Entrée', 'tokOut': 'Sortie',
               'total': 'Total', 'cost': 'Coût (USD)', 'share': 'Part'},
        'trendTitle': 'Tendance 30 jours', 'trendSub': 'Total de tokens ou coût par jour, commutable',
        'trendAria': 'Graphique de consommation de tokens sur 30 jours',
        'tabAria': 'Changer de métrique', 'tabTokens': 'Tokens', 'tabCost': 'Coût',
        'empty': 'Collecte des données, revenez plus tard',
    },
    'de': {
        'secTitle': 'Token-Verbrauch', 'secTag': '// tokens',
        'secHint': 'Token-Nutzung & Kosten pro Mitglied / Rolle (lokales token-stats)',
        'noteEst': 'Geschätzte Kosten = Modellpreisschätzung, keine echte Rechnung',
        'kpiTotal': 'Gesamt-Tokens', 'kpiTotalSub': 'Sessions + Cron-Nutzung',
        'kpiCost': 'Geschätzte Kosten', 'kpiCostSub': 'Modellpreisschätzung',
        'kpiSessions': 'Sessions', 'kpiSessionsSub': 'Gesamtsessions · Cron {cron}',
        'th': {'member': 'Mitglied / Rolle', 'tokIn': 'Eingabe', 'tokOut': 'Ausgabe',
               'total': 'Gesamt', 'cost': 'Kosten (USD)', 'share': 'Anteil'},
        'trendTitle': '30-Tage-Verbrauchstrend', 'trendSub': 'Tägliche Token-Gesamtmenge oder Kosten, umschaltbar',
        'trendAria': '30-Tage-Token-Verbrauchsdiagramm',
        'tabAria': 'Metrik wechseln', 'tabTokens': 'Token', 'tabCost': 'Kosten',
        'empty': 'Daten werden gesammelt, schauen Sie später wieder vorbei',
    },
    'ar': {
        'secTitle': 'إحصائيات استهلاك التوكنات', 'secTag': '// tokens',
        'secHint': 'استهلاك التوكنات والتكلفة لكل عضو / دور (من token-stats المحلي)',
        'noteEst': 'التكلفة التقديرية = تقدير أسعار النموذج، وليست فاتورة فعلية',
        'kpiTotal': 'إجمالي التوكنات', 'kpiTotalSub': 'الجلسات + استخدام cron',
        'kpiCost': 'التكلفة التقديرية', 'kpiCostSub': 'تقدير أسعار النموذج',
        'kpiSessions': 'الجلسات', 'kpiSessionsSub': 'إجمالي الجلسات · cron {cron}',
        'th': {'member': 'العضو / الدور', 'tokIn': 'الإدخال', 'tokOut': 'الإخراج',
               'total': 'الإجمالي', 'cost': 'التكلفة (USD)', 'share': 'الحصة'},
        'trendTitle': 'اتجاه الاستهلاك (30 يومًا)', 'trendSub': 'إجمالي التوكنات اليومي أو التكلفة، قابل للتبديل',
        'trendAria': 'مخطط استهلاك التوكنات لـ 30 يومًا',
        'tabAria': 'تبديل المقياس', 'tabTokens': 'توكن', 'tabCost': 'التكلفة',
        'empty': 'جاري جمع البيانات، عد لاحقًا',
    },
    'ru': {
        'secTitle': 'Статистика потребления токенов', 'secTag': '// tokens',
        'secHint': 'Использование токенов и стоимость по участникам / ролям (локальный token-stats)',
        'noteEst': 'Оценка стоимости = по тарифам модели, не реальный счёт',
        'kpiTotal': 'Всего токенов', 'kpiTotalSub': 'Сессии + cron',
        'kpiCost': 'Оценка стоимости', 'kpiCostSub': 'По тарифам модели',
        'kpiSessions': 'Сессии', 'kpiSessionsSub': 'Всего сессий · cron {cron}',
        'th': {'member': 'Участник / Роль', 'tokIn': 'Вход', 'tokOut': 'Выход',
               'total': 'Итого', 'cost': 'Стоимость (USD)', 'share': 'Доля'},
        'trendTitle': 'Тренд за 30 дней', 'trendSub': 'Дневной объём токенов или стоимость (переключаемо)',
        'trendAria': 'График потребления токенов за 30 дней',
        'tabAria': 'Сменить метрику', 'tabTokens': 'Токены', 'tabCost': 'Стоимость',
        'empty': 'Идёт сбор данных, загляните позже',
    },
    'es': {
        'secTitle': 'Consumo de tokens', 'secTag': '// tokens',
        'secHint': 'Uso de tokens y coste por miembro / rol (token-stats local)',
        'noteEst': 'Coste estimado = estimación según tarifas del modelo, no una factura real',
        'kpiTotal': 'Tokens totales', 'kpiTotalSub': 'Sesiones + uso de cron',
        'kpiCost': 'Coste estimado', 'kpiCostSub': 'Estimación según tarifas del modelo',
        'kpiSessions': 'Sesiones', 'kpiSessionsSub': 'Sesiones totales · cron {cron}',
        'th': {'member': 'Miembro / Rol', 'tokIn': 'Entrada', 'tokOut': 'Salida',
               'total': 'Total', 'cost': 'Coste (USD)', 'share': 'Cuota'},
        'trendTitle': 'Tendencia de 30 días', 'trendSub': 'Total de tokens diario o coste, conmutable',
        'trendAria': 'Gráfico de consumo de tokens de 30 días',
        'tabAria': 'Cambiar métrica', 'tabTokens': 'Token', 'tabCost': 'Coste',
        'empty': 'Recopilando datos, vuelve más tarde',
    },
    'tr': {
        'secTitle': 'Token Tüketimi İstatistikleri', 'secTag': '// tokens',
        'secHint': 'Üye / rol başına token kullanımı ve maliyet (yerel token-stats)',
        'noteEst': 'Tahmini maliyet = model fiyat tahmini, gerçek fatura değil',
        'kpiTotal': 'Toplam Token', 'kpiTotalSub': 'Oturumlar + cron kullanımı',
        'kpiCost': 'Tahmini Maliyet', 'kpiCostSub': 'Model fiyat tahmini',
        'kpiSessions': 'Oturumlar', 'kpiSessionsSub': 'Toplam oturum · cron {cron}',
        'th': {'member': 'Üye / Rol', 'tokIn': 'Giriş', 'tokOut': 'Çıkış',
               'total': 'Toplam', 'cost': 'Maliyet (USD)', 'share': 'Pay'},
        'trendTitle': '30 Günlük Tüketim Trendi', 'trendSub': 'Günlük token toplamı veya maliyet (değiştirilebilir)',
        'trendAria': '30 günlük token tüketim grafiği',
        'tabAria': 'Metriği değiştir', 'tabTokens': 'Token', 'tabCost': 'Maliyet',
        'empty': 'Veriler toplanıyor, daha sonra tekrar bakın',
    },
    'pl': {
        'secTitle': 'Statystyki zużycia tokenów', 'secTag': '// tokens',
        'secHint': 'Użycie tokenów i koszt wg członka / roli (lokalny token-stats)',
        'noteEst': 'Szacunkowy koszt = wycena wg stawek modelu, nie rzeczywista faktura',
        'kpiTotal': 'Łącznie tokenów', 'kpiTotalSub': 'Sesje + użycie cron',
        'kpiCost': 'Szacunkowy koszt', 'kpiCostSub': 'Wycena wg stawek modelu',
        'kpiSessions': 'Sesje', 'kpiSessionsSub': 'Łącznie sesji · cron {cron}',
        'th': {'member': 'Członek / Rola', 'tokIn': 'Wejście', 'tokOut': 'Wyjście',
               'total': 'Razem', 'cost': 'Koszt (USD)', 'share': 'Udział'},
        'trendTitle': 'Trend 30 dni', 'trendSub': 'Dzienny wolumen tokenów lub koszt (przełączalny)',
        'trendAria': 'Wykres zużycia tokenów z 30 dni',
        'tabAria': 'Zmień metrykę', 'tabTokens': 'Token', 'tabCost': 'Koszt',
        'empty': 'Zbieranie danych, zajrzyj później',
    },
    'pt': {
        'secTitle': 'Consumo de tokens', 'secTag': '// tokens',
        'secHint': 'Uso de tokens e custo por membro / função (token-stats local)',
        'noteEst': 'Custo estimado = estimativa com base nos preços do modelo, não uma fatura real',
        'kpiTotal': 'Total de tokens', 'kpiTotalSub': 'Sessões + uso de cron',
        'kpiCost': 'Custo estimado', 'kpiCostSub': 'Estimativa com base nos preços do modelo',
        'kpiSessions': 'Sessões', 'kpiSessionsSub': 'Total de sessões · cron {cron}',
        'th': {'member': 'Membro / Função', 'tokIn': 'Entrada', 'tokOut': 'Saída',
               'total': 'Total', 'cost': 'Custo (USD)', 'share': 'Participação'},
        'trendTitle': 'Tendência de 30 dias', 'trendSub': 'Total diário de tokens ou custo, comutável',
        'trendAria': 'Gráfico de consumo de tokens em 30 dias',
        'tabAria': 'Alternar métrica', 'tabTokens': 'Token', 'tabCost': 'Custo',
        'empty': 'Coletando dados, volte mais tarde',
    },
}

# ================= 注入的 token 模块 HTML =================
TOKEN_SECTION_HTML = (
    '  <!-- ===== 0826-os-3 Token 消耗统计（客户部署的 AI 成员 token 用量；数据源 = 本地 '
    'token-stats.json，无数据 → 空态；与「成员总览」区分：本模块聚焦消耗视角）===== -->\n'
    '  <div class="section" id="secTokens">\n'
    '    <div class="section-title">\n'
    '      <h2 data-i18n="opc.governance.tokens.secTitle">Token 消耗统计</h2><span class="tag" '
    'data-i18n="opc.governance.tokens.secTag">// tokens</span>\n'
    '      <span class="hint" data-i18n="opc.governance.tokens.secHint">各成员 / 角色 token 用量与成本，'
    '数据来自本地 token-stats</span>\n'
    '    </div>\n'
    '    <div class="kpis" id="tokKpis"></div>\n'
    '    <div class="tok-note" data-i18n="opc.governance.tokens.noteEst">估算成本 = 模型报价估算，非实际账单</div>\n'
    '    <div class="table-wrap">\n'
    '      <table>\n'
    '        <thead>\n'
    '          <tr>\n'
    '            <th data-i18n="opc.governance.tokens.th.member">成员 / 角色</th>\n'
    '            <th data-i18n="opc.governance.tokens.th.tokIn">Token 输入</th>\n'
    '            <th data-i18n="opc.governance.tokens.th.tokOut">Token 输出</th>\n'
    '            <th data-i18n="opc.governance.tokens.th.total">合计</th>\n'
    '            <th data-i18n="opc.governance.tokens.th.cost">成本 (USD)</th>\n'
    '            <th data-i18n="opc.governance.tokens.th.share">消耗占比</th>\n'
    '          </tr>\n'
    '        </thead>\n'
    '        <tbody id="tokRows"></tbody>\n'
    '      </table>\n'
    '    </div>\n'
    '    <div class="trend-card">\n'
    '      <h3 data-i18n="opc.governance.tokens.trendTitle">30 天消耗趋势</h3>\n'
    '      <div class="c-sub" data-i18n="opc.governance.tokens.trendSub">每日 token 总量或成本，可切换</div>\n'
    '      <div class="trend-tabs" id="tokTabs" role="tablist" aria-label="切换趋势指标" '
    'data-i18n-aria="opc.governance.tokens.tabAria">\n'
    '        <button class="ttab" type="button" role="tab" data-metric="tokens" aria-selected="true" '
    'data-i18n="opc.governance.tokens.tabTokens">Token</button>\n'
    '        <button class="ttab" type="button" role="tab" data-metric="cost" aria-selected="false" '
    'data-i18n="opc.governance.tokens.tabCost">成本</button>\n'
    '      </div>\n'
    '      <svg class="trend-svg" id="tokSvg" viewBox="0 0 760 240" role="img" '
    'aria-label="30 天 token 消耗趋势图" data-i18n-aria="opc.governance.tokens.trendAria"></svg>\n'
    '      <div class="tok-empty" id="tokEmpty" style="display:none" '
    'data-i18n="opc.governance.tokens.empty">数据采集中，稍后回来看看</div>\n'
    '    </div>\n'
    '  </div>\n'
)

# ================= 注入的 token 模块 CSS（占位原 0822-t1e/0820-ka 样式区） =================
TOKEN_CSS = (
    '/* 0826-os-3: token 消耗统计——口径行 + 空态（数据未生成 → 「数据采集中」，禁白屏/红条，'
    '遵循既有空态约定） */\n'
    '.tok-note { margin: 12px 0 16px; padding: 10px 14px; font-size: 11.5px; color: var(--muted); '
    'background: var(--card); border: 1px solid var(--border); border-radius: var(--radius-md); }\n'
    '.tok-empty { padding: 26px 16px; text-align: center; color: var(--muted); font-size: 12.5px; '
    'line-height: 1.7; }\n'
)

# ================= 注入的 token 模块 JS（占位原留言明细 JS 区，bootstrap 之前） =================
TOKEN_JS = (
    '  // ===== Token 消耗统计（0826-os-3）：数据复用主 token-stats（DATA），聚焦消耗视角 =====\n'
    '  // 与「成员总览」区分：本模块只看消耗（输入/输出/合计/成本/占比 + 30 天趋势），不含产出/返工\n'
    '  var TOK_ACTIVE = \'tokens\';   // tokens | cost\n'
    '  function tokRowTotal(p) { return (p.tokens ? p.tokens.total : 0) + (p.cron && p.cron.tokens ? p.cron.tokens : 0); }\n'
    '  function renderTok(d) {\n'
    '    renderTokKpis(d);\n'
    '    renderTokRows(d);\n'
    '    drawTokTrend(d);\n'
    '    setTimeout(drawBars, 60);\n'
    '  }\n'
    '  function renderTokKpis(d) {\n'
    '    var el = document.getElementById(\'tokKpis\');\n'
    '    if (!el) return;\n'
    '    var t = d.total || {};\n'
    '    var items = [\n'
    '      { label: T(\'opc.governance.tokens.kpiTotal\'), ico: \'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>\', num: t.tokens || 0, dec: 0, suf: \'\', sub: T(\'opc.governance.tokens.kpiTotalSub\') },\n'
    '      { label: T(\'opc.governance.tokens.kpiCost\'), ico: \'<path d="M12 1v22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>\', num: t.cost_usd || 0, dec: 2, suf: \'\', sub: T(\'opc.governance.tokens.kpiCostSub\') },\n'
    '      { label: T(\'opc.governance.tokens.kpiSessions\'), ico: \'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>\', num: t.sessions || 0, dec: 0, suf: \'\', sub: T(\'opc.governance.tokens.kpiSessionsSub\', { cron: (t.cron_runs || 0) }) }\n'
    '    ];\n'
    '    var html = \'\';\n'
    '    items.forEach(function (it) {\n'
    '      html += \'<div class="kpi"><div class="k-label"><svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">\' + it.ico + \'</svg>\' + esc(it.label) + \'</div><div class="k-num"><span class="cnt">0</span><small>\' + it.suf + \'</small></div><div class="k-sub">\' + esc(it.sub) + \'</div></div>\';\n'
    '    });\n'
    '    el.innerHTML = html;\n'
    '    document.querySelectorAll(\'#tokKpis .cnt\').forEach(function (c, i) { countUp(c, items[i].num, items[i].dec); });\n'
    '    requestAnimationFrame(tick);\n'
    '  }\n'
    '  function renderTokRows(d) {\n'
    '    var box = document.getElementById(\'tokRows\');\n'
    '    if (!box) return;\n'
    '    var rows = [], sum = 0;\n'
    '    MEMBER_ORDER.forEach(function (id) {\n'
    '      var p = d.profiles && d.profiles[id];\n'
    '      if (!p) return;\n'
    '      var total = tokRowTotal(p);\n'
    '      rows.push({ id: id, p: p, total: total, cost: p.cost_usd || 0 });\n'
    '      sum += total;\n'
    '    });\n'
    '    rows.sort(function (a, b) { return b.total - a.total; });\n'
    '    if (!rows.length) {\n'
    '      box.innerHTML = \'<tr><td colspan="6" class="tok-empty">\' + esc(T(\'opc.governance.tokens.empty\')) + \'</td></tr>\';\n'
    '      return;\n'
    '    }\n'
    '    var html = \'\';\n'
    '    rows.forEach(function (r) {\n'
    '      var p = r.p, t = p.tokens || {};\n'
    '      var pct = sum > 0 ? (r.total / sum) * 100 : 0;\n'
    '      var mName = (LANG !== \'zh\' && p.name_en) ? p.name_en : p.name_zh;\n'
    '      html += \'<tr>\' +\n'
    '        \'<td><div class="member-cell"><span class="member-ava"><svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span><span><span class="member-name">\' + esc(mName) + \'</span><span class="member-role">\' + esc(displayRole(p)) + \'</span></span></div></td>\' +\n'
    '        \'<td class="num">\' + fmtFull(t.input || 0) + \'</td>\' +\n'
    '        \'<td class="num">\' + fmtFull(t.output || 0) + \'</td>\' +\n'
    '        \'<td class="num" style="font-weight:600">\' + fmtInt(r.total) + \'</td>\' +\n'
    '        \'<td class="cost-num">\' + fmtCost(r.cost) + \'</td>\' +\n'
    '        \'<td class="bar-cell"><div class="bar" data-w="\' + Math.max(2, pct) + \'"><i></i></div></td>\' +\n'
    '        \'</tr>\';\n'
    '    });\n'
    '    box.innerHTML = html;\n'
    '  }\n'
    '  function drawTokTrend(d) {\n'
    '    var svg = document.getElementById(\'tokSvg\');\n'
    '    var empty = document.getElementById(\'tokEmpty\');\n'
    '    var series = d.series_daily || [];\n'
    '    if (!svg) return;\n'
    '    if (!series.length) {\n'
    '      svg.innerHTML = \'\';\n'
    '      if (empty) { empty.style.display = \'block\'; empty.textContent = T(\'opc.governance.tokens.empty\'); }\n'
    '      return;\n'
    '    }\n'
    '    if (empty) empty.style.display = \'none\';\n'
    '    var W = 760, H = 240, PL = 44, PR = 20, PT = 16, PB = 30;\n'
    '    var iw = W - PL - PR, ih = H - PT - PB, n = series.length;\n'
    '    var isCost = TOK_ACTIVE === \'cost\';\n'
    '    var maxV = 0.01;\n'
    '    series.forEach(function (s) { var v = isCost ? (s.cost_usd || 0) : (s.tokens || 0); if (v > maxV) maxV = v; });\n'
    '    var yMax = Math.max(1, maxV * 1.2);\n'
    '    function x(i) { return n === 1 ? PL + iw / 2 : PL + (iw * i) / (n - 1); }\n'
    '    function y(v) { return PT + ih - (v / yMax) * ih; }\n'
    '    var pts = [], areaPts = [], dots = \'\';\n'
    '    series.forEach(function (s, i) {\n'
    '      var v = isCost ? (s.cost_usd || 0) : (s.tokens || 0);\n'
    '      var px = x(i).toFixed(1), py = y(v).toFixed(1);\n'
    '      pts.push(px + \',\' + py);\n'
    '      areaPts.push([px, py]);\n'
    '      dots += \'<circle class="trend-dot" cx="\' + px + \'" cy="\' + py + \'" r="2.5"/>\';\n'
    '    });\n'
    '    var area = \'M\' + PL + \',\' + (PT + ih) + \' L\' + areaPts.map(function (p) { return p[0] + \',\' + p[1]; }).join(\' L\') + \' L\' + areaPts[areaPts.length - 1][0] + \',\' + (PT + ih) + \' Z\';\n'
    '    var gx = \'\';\n'
    '    for (var i = 0; i < n; i += Math.max(1, Math.ceil(n / 6))) {\n'
    '      gx += \'<text class="trend-axis-t" x="\' + x(i) + \'" y="\' + (H - 10) + \'" text-anchor="middle">\' + (series[i].date || \'\').slice(5) + \'</text>\';\n'
    '    }\n'
    '    var gy = \'\', hgrid = \'\';\n'
    '    for (var j = 0; j <= 4; j++) {\n'
    '      var tv = yMax * (j / 4);\n'
    '      var yy = PT + ih - (j / 4) * ih;\n'
    '      gy += \'<text class="trend-axis-t" x="\' + (PL - 8) + \'" y="\' + (yy + 3) + \'" text-anchor="end">\' + (isCost ? (tv >= 1 ? tv.toFixed(0) : tv.toFixed(2)) : fmtInt(tv)) + \'</text>\';\n'
    '      hgrid += \'<line x1="\' + PL + \'" y1="\' + yy + \'" x2="\' + (W - PR) + \'" y2="\' + yy + \'" stroke="var(--border)" stroke-width="1" stroke-dasharray="2 4"/>\';\n'
    '    }\n'
    '    var lineCls = isCost ? \'trend-line-cost\' : \'trend-line-tok\';\n'
    '    svg.innerHTML = hgrid + gx + gy + \'<path class="trend-area-tok" d="\' + area + \'"/>\' + \'<path class="\' + lineCls + \'" d="M\' + pts.join(\' \') + \'"/>\' + dots;\n'
    '  }\n'
    '  function setTokMetric(key) {\n'
    '    TOK_ACTIVE = key;\n'
    '    document.querySelectorAll(\'#tokTabs .ttab\').forEach(function (b) {\n'
    '      b.setAttribute(\'aria-selected\', b.getAttribute(\'data-metric\') === key ? \'true\' : \'false\');\n'
    '    });\n'
    '    if (DATA) drawTokTrend(DATA);\n'
    '  }\n'
    '  document.getElementById(\'tokTabs\').addEventListener(\'click\', function (e) {\n'
    '    var b = e.target.closest ? e.target.closest(\'.ttab\') : null;\n'
    '    if (b) setTokMetric(b.getAttribute(\'data-metric\'));\n'
    '  });\n'
)

# ================= 变换：governance.html =================

# 旧区块/旧功能的确定性标记（company-site 源与 opc-os 部署副本结构一致，均适用）
_MARK_TRAFFIC = '<!-- ===== 0822-t1b 网站访问趋势'
_MARK_MESSAGES = '<!-- ===== 0822-t1e 留言/咨询明细'
_MARK_ACQ_JS = '  // ===== 引流效果（0820-k t_de577480）'
_MARK_MSG_JS = '  // ===== 留言/咨询明细（0822-t1e'
_MARK_BOOT = '\n  load().then(render)'
_MARK_NOTE = '<div class="note">'
_MARK_ASIDE = '</aside>'
_CSS_MSG_START = '/* 0822-t1e: 留言/咨询 KPI 卡可点击'
_CSS_ACQ_END = '.acq-ghost .acq-layer { background: var(--border); color: var(--muted); }'


def _strip_legacy_html(html):
    """删除 网站访问趋势 / 引流效果 / 留言明细抽屉 三个 HTML 区块 + 口径行 noteLi4a。"""
    # 1. traffic + acquisition 区块（两区块相邻，整体截至 <div class="note">）
    i = html.find(_MARK_TRAFFIC)
    j = html.find(_MARK_NOTE)
    if i != -1 and j != -1 and i < j:
        html = html[:i] + html[j:]
    # 2. 留言明细浮层 + 抽屉（唯一 </aside> 收尾）
    m0 = html.find(_MARK_MESSAGES)
    m1 = html.find(_MARK_ASIDE)
    if m0 != -1 and m1 != -1 and m0 < m1:
        html = html[:m0] + html[m1 + len(_MARK_ASIDE):]
    # 3. 口径行 noteLi4a（趋势路径说明，随区块删除）
    html = re.sub(r'\n\s*<li><span data-i18n="opc\.governance\.noteLi4a">.*?</li>', '', html, flags=re.S)
    return html


def _strip_legacy_css(html):
    """清理旧样式：trend-src / kpi.clickable+spin / 登录浮层+抽屉 / acq-* 全族。"""
    # trend-src（仅流量区块用）
    html = re.sub(r'\n\.trend-src \{[^}]*\}\n', '\n', html)
    # clickable/spin/msk/drawer/acq 连续样式区 → 原位注入 token 模块 CSS
    c0 = html.find(_CSS_MSG_START)
    c1 = html.find(_CSS_ACQ_END)
    if c0 != -1 and c1 != -1 and c0 < c1:
        end = html.find('\n', c1)
        html = html[:c0] + TOKEN_CSS + html[end + 1:]
    # 640px 断点里的 .acq-kpis 规则
    html = html.replace('  .acq-kpis { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }\n', '')
    # 注释同步（避免「引流/访问」字样残留）
    html = html.replace(
        '/* 0821-uiux：960 档已删——.kpis/.acq-kpis 中间档走 auto-fit 自适应，.compare 收列并入下方 640 档 */',
        '/* 0821-uiux：960 档已删——.kpis 中间档走 auto-fit 自适应，.compare 收列并入下方 640 档 */')
    html = html.replace(
        '/* 0822-t1b: 网站访问趋势——指标切换 tabs + 口径行（SVG 复用 trendSvg 模式） */',
        '/* 0826-os-3: token 消耗趋势——指标切换 tabs（SVG 复用 trendSvg 模式） */')
    return html


def _strip_legacy_js(html):
    """删除 引流/访问趋势/留言明细 三块 JS（含 applyI18n 钩子、render 引导、bootstrap 调用），
    注入 token 模块 JS。"""
    # 1. applyI18n 钩子：TRENDS/msgState 重渲染 → renderTok
    html = html.replace(
        "    // 0822-t1b: 访问趋势 KPI/图/口径行同为 JS 内联生成，语言切换后需按新 dict 重渲染\n"
        "    if (TRENDS) renderTrends(TRENDS);\n"
        "    // 0822-t1e: 明细抽屉动态区（标题含 total、字段标签）随语言包刷新\n"
        "    if (msgState) msgRender();\n",
        "    // 0826-os-3: token 消耗模块动态区为 JS 内联生成，语言切换后需按新 dict 重渲染\n"
        "    if (DATA) renderTok(DATA);\n")
    # 2. render() 增加 renderTok 调用
    html = html.replace(
        "    renderKpis(data);\n    renderMembers(data);\n    renderCompare(data);\n    renderTrend(data);\n  }",
        "    renderKpis(data);\n    renderMembers(data);\n    renderCompare(data);\n    renderTrend(data);\n"
        "    renderTok(data);\n  }")
    # 3. 引流 + 访问趋势 JS 整块（引流注释 → 留言注释 之间）删除
    j0 = html.find(_MARK_ACQ_JS)
    j1 = html.find(_MARK_MSG_JS)
    if j0 != -1 and j1 != -1 and j0 < j1:
        html = html[:j0] + html[j1:]
    # 4. 留言明细 JS 整块（留言注释 → bootstrap 之间）→ 原位注入 token 模块 JS
    #    （保留 '\n  load().then(render)' 前缀及其 .then/.catch 续链）
    j2 = html.find(_MARK_MSG_JS)
    j3 = html.find(_MARK_BOOT)
    if j2 != -1 and j3 != -1 and j2 < j3:
        html = html[:j2] + TOKEN_JS + html[j3:]
    # 5. 底部 loadAcq/loadTrends bootstrap 调用删除（token 模块由 render() 驱动）
    html = html.replace(
        "\n  // 引流区块独立触发: 失败静默保持空态, 不影响主数据加载\n"
        "  loadAcq().then(renderAcq).catch(function () { /* §6 空态即默认首帧 */ });\n"
        "\n"
        "  // 访问趋势独立触发: 失败 → 显式空态「数据采集中」，不影响主数据\n"
        "  loadTrends().then(renderTrends).catch(function () { renderTrends(null); });\n",
        "\n")
    return html


def _strip_opc_zh(html):
    """OPC_ZH 兜底：删 acquisition/trends/messages 三键 + noteLi4a，注入 tokens 键（幂等）。"""
    html = re.sub(r'\n      "noteLi4a": "[^"]*",', '', html)
    for key in ('"acquisition"', '"trends"', '"messages"'):
        pat = re.compile(r'\n      ' + key + r': \{\n.*?\n      \},\n', re.S)
        html = pat.sub('\n', html, count=1)
    if '      "tokens": ' not in html:   # 幂等：已有 tokens 键则跳过注入
        html = html.replace(
            '      "noteTitle": "数据口径",',
            '      "tokens": ' + json.dumps(TOKENS_I18N['zh'], ensure_ascii=False) + ',\n'
            '      "noteTitle": "数据口径",')
    return html


def transform_governance_html(html):
    """governance.html 完整变换：删旧三块 + 注入 token 模块 + OPC_ZH 键更新 + __I18N_VER 递增。"""
    before = html
    html = _strip_legacy_html(html)
    html = _strip_legacy_css(html)
    html = _strip_legacy_js(html)
    html = _strip_opc_zh(html)
    # 注入 token 模块 section（旧流量/引流区块位置：<div class="note"> 之前）
    if _MARK_TRAFFIC not in html and 'id="secTokens"' not in html:
        html = html.replace(_MARK_NOTE, TOKEN_SECTION_HTML + '  ' + _MARK_NOTE, 1)
    # __I18N_VER 递增（语言包内容变更，防缓存）
    m = re.search(r'window\.__I18N_VER = (\d+);', html)
    if m:
        html = html.replace(m.group(0), 'window.__I18N_VER = %d;' % (int(m.group(1)) + 1), 1)
    # 收尾：合并删除遗留的连续空行（HTML/JS 语义无关，仅整洁）
    html = re.sub(r'\n{3,}', '\n\n', html)
    return html


def transform_locale(content, filename):
    """locale JSON：删 governance.trends/acquisition/messages 键，加 governance.tokens 键（幂等）。

    未命中 governance 命名空间或 JSON 损坏时原样返回。
    """
    try:
        data = json.loads(content)
    except Exception:
        return content
    gov = (data.get('opc') or {}).get('governance')
    if not isinstance(gov, dict):
        return content
    changed = False
    for key in ('trends', 'acquisition', 'messages'):
        if key in gov:
            del gov[key]
            changed = True
    if 'tokens' not in gov:
        lang = os.path.basename(filename)[:2]
        gov['tokens'] = TOKENS_I18N.get(lang, TOKENS_I18N['en'])
        changed = True
    if not changed:
        return content
    return json.dumps(data, ensure_ascii=False, indent=2) + '\n'


if __name__ == '__main__':
    import sys
    # CLI：governance_tokens.py <governance.html 路径>  → 原地变换（用于生成部署产物）
    if len(sys.argv) > 1:
        p = sys.argv[1]
        with open(p, encoding='utf-8') as f:
            src = f.read()
        out = transform_governance_html(src)
        with open(p, 'w', encoding='utf-8') as f:
            f.write(out)
        print('[governance_tokens] 已变换: %s (%d → %d 字符)' % (p, len(src), len(out)))
