#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
telegram-delivery-watchdog —— telegram 投递链路健康看门狗
================================================================
检测两类异常：
  A. 日志错误统计（滑动窗口）：/home/gavin/.hermes/logs/gateway.log{,.N} + errors.log{,.N}
     匹配行：行首时间戳 ∈ 窗口 且 行内含 telegram(忽略大小写) 且 行内含
     ConnectError | Timed out | TimedOut | blocked_config（忽略大小写）
  B. jobs.json blocked_config：全 profile 扫描，enabled job 的 last_status / last_error
     含 blocked_config → 告警（disabled 一次性 job 的历史残留不告警）

契约（no_agent cron 模式，每 30min）：
  - 正常态 stdout 为空 → cron 静默（不投递）
  - 异常态 stdout 非空 → cron 投递 telegram（deliver=telegram:8126814736）
  - 去重：同类型告警在 WD_DEDUP_H 小时内不重复；24h 计数超 WD_ERR24H_ESC 升级线时跳过去重
  - 恢复：曾告警且回落至阈值下 → 输出一条恢复行

阈值（env 覆盖，便于测试）：
  WD_ERR24H_MAX   24h 滑动窗口错误行数上限（默认 5，验收线 <5 次/日）
  WD_ERR15M_MAX   15min 滑动窗口上限（默认 10）
  WD_ERR24H_ESC   24h 升级线（默认 50，超线且错误数明显增长时忽略去重强制告警；
                  仅绝对超线不告警——历史故障残留滑出窗口时错误数单调下降，不应轰炸）
  WD_DEDUP_H      同类型去重窗口小时（默认 2）
  WD_STATE_FILE   状态文件（默认 /home/gavin/.hermes/opc/telegram-delivery-watchdog-state.json）
  WD_LOG_DIR      日志目录（默认 /home/gavin/.hermes/logs）
  WD_JOBS         额外 jobs.json 路径（逗号分隔，默认扫描 /home/gavin/.hermes/cron/jobs.json + profiles/*/cron/jobs.json）
  WD_BUS_SCRIPT   告警总线脚本（默认 /home/gavin/.hermes/scripts/opc-alert-bus.py，测试可指向临时脚本/目录）
  WD_NOW          测试用覆盖当前时间（YYYY-MM-DD HH:MM:SS）
"""
import glob
import json
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta

# ---------- 告警总线（0827 整改 ALERT-LOOP：输出告警同步写总线，定稿 schema 9 字段） ----------
# WD_BUS_SCRIPT env 覆盖（参照 OPC_ALERT_DIR 模式）：默认生产路径兜底，测试隔离用临时脚本
BUS_SCRIPT = os.environ.get("WD_BUS_SCRIPT", "/home/gavin/.hermes/scripts/opc-alert-bus.py")


def _bus_append(severity, type_, title, evidence):
    """写一条告警总线（失败静默——总线故障不影响本脚本 stdout 契约）。"""
    try:
        subprocess.run(
            [sys.executable, BUS_SCRIPT, "append",
             "--source", "telegram-watchdog",
             "--severity", severity,
             "--type", type_,
             "--title", title,
             "--evidence", str(evidence)[:1500]],
            capture_output=True, text=True, timeout=15)
    except Exception:
        pass

# ---------- 配置 ----------
NOW = datetime.now()
if os.environ.get("WD_NOW"):
    NOW = datetime.strptime(os.environ["WD_NOW"], "%Y-%m-%d %H:%M:%S")

ERR24H_MAX = int(os.environ.get("WD_ERR24H_MAX", "5"))
ERR15M_MAX = int(os.environ.get("WD_ERR15M_MAX", "10"))
ERR24H_ESC = int(os.environ.get("WD_ERR24H_ESC", "50"))
DEDUP_H = float(os.environ.get("WD_DEDUP_H", "2"))
LOG_DIR = os.environ.get("WD_LOG_DIR", "/home/gavin/.hermes/logs")
STATE_FILE = os.environ.get("WD_STATE_FILE", "/home/gavin/.hermes/opc/telegram-delivery-watchdog-state.json")
EXTRA_JOBS = [p for p in os.environ.get("WD_JOBS", "").split(",") if p.strip()]

TS_RE = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})")
ERR_RE = re.compile(r"ConnectError|Timed\s*out|TimedOut|blocked_config", re.IGNORECASE)
TG_RE = re.compile(r"telegram", re.IGNORECASE)

W24 = timedelta(hours=24)
W15 = timedelta(minutes=15)

# ---------- A. 日志错误统计 ----------
def ts_parse(line):
    m = TS_RE.match(line)
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None

def scan_logs():
    """返回 (err24h_count, err15m_count, by_type, hourly, samples)"""
    files = []
    for base in ("gateway.log", "errors.log"):
        for suf in ("", ".1", ".2", ".3"):
            p = os.path.join(LOG_DIR, base + suf)
            if os.path.exists(p):
                files.append(p)
    err24 = 0
    err15 = 0
    by_type = {}
    hourly = {}
    samples = []
    cutoff24 = NOW - W24
    cutoff15 = NOW - W15
    for f in files:
        try:
            with open(f, "rb") as fh:
                for raw in fh:
                    line = raw.decode("utf-8", errors="replace")
                    if "telegram" not in line.lower():
                        continue
                    if not ERR_RE.search(line):
                        continue
                    ts = ts_parse(line)
                    if ts is None:
                        continue  # 续行/堆栈行，跳过（避免重复计数）
                    if ts > NOW or ts < cutoff24:
                        continue
                    err24 += 1
                    # 类型分类
                    low = line.lower()
                    if "blocked_config" in low:
                        t = "blocked_config"
                    elif "connecterror" in low:
                        t = "ConnectError"
                    elif "timed out" in low or "timedout" in low:
                        t = "Timed out"
                    else:
                        t = "other"
                    by_type[t] = by_type.get(t, 0) + 1
                    if ts >= cutoff15:
                        err15 += 1
                    hourly.setdefault(ts.strftime("%m-%d %H"), 0)
                    hourly[ts.strftime("%m-%d %H")] += 1
                    if len(samples) < 3:
                        samples.append(line.strip()[:220])
        except OSError:
            continue
    return err24, err15, by_type, hourly, samples

# ---------- B. jobs.json blocked_config 检测 ----------
def scan_blocked_config():
    """返回 enabled job 含 blocked_config 痕迹的列表"""
    files = [p for p in EXTRA_JOBS]
    files.append("/home/gavin/.hermes/cron/jobs.json")
    files += sorted(glob.glob("/home/gavin/.hermes/profiles/*/cron/jobs.json"))
    hits = []
    seen = set()
    for f in files:
        if not os.path.exists(f) or f in seen:
            continue
        seen.add(f)
        try:
            d = json.load(open(f))
        except (OSError, ValueError):
            continue
        jobs = d.get("jobs", d) if isinstance(d, dict) else d
        if isinstance(jobs, dict):
            jobs = jobs.values()
        for job in jobs:
            if not isinstance(job, dict):
                continue
            if not job.get("enabled", True):
                continue  # disabled 一次性 job 的历史残留不告警
            ls = str(job.get("last_status", ""))
            le = str(job.get("last_error", ""))
            if "blocked_config" in ls or "blocked_config" in le:
                hits.append({
                    "file": f,
                    "id": str(job.get("id", "?"))[:12],
                    "name": job.get("name", "?"),
                    "deliver": job.get("deliver"),
                    "last_status": ls[:150],
                    "last_error": le[:300],
                    # 该 job 最近一次运行时间（blocked_config 发生时刻）；"T" 分隔兼容
                    "last_run": str(job.get("last_run_at", "")).replace("T", " ")[:19],
                })
    return hits

# ---------- B2. 链路活性检测（0827 P0 处置新增） ----------
# 背景：blocked_config 是 gateway 判定 telegram 未连接时的投递阻断，cron 只在
#   pre-dispatch 打一条 WARNING（errors.log 里那行不含 "blocked_config" 字样），
#   jobs.json 的 last_status 会残留到该 job 下一次运行才刷新（日更 job = 最长 24h）。
#   链路恢复后若只看 jobs.json，看门狗会持续误报到 job 重跑。
# 方案：对每个 blocked_config 命中 job，取 gateway.log 最近一条链路活性记录
#   （轮询健康 / 响应投递成功）的时间；若活性时间 > 该 job 的 last_run_at
#   （即 job 被 block 之后链路曾恢复）→ 判定为历史残留，不告警；否则告警。
#   新故障的网络错误由 A 检测（err24 增长 → 打破去重）兜底，B 不重复报。
BC_ACTIVE_RE = re.compile(r"polling confirmed healthy|response ready", re.IGNORECASE)


def last_link_active_ts():
    """gateway.log 中最近一条 telegram 链路活性记录的时间戳（datetime 或 None）。"""
    latest = None
    f = os.path.join(LOG_DIR, "gateway.log")
    if not os.path.exists(f):
        return None
    try:
        with open(f, "rb") as fh:
            for raw in fh:
                line = raw.decode("utf-8", errors="replace")
                if "telegram" not in line.lower():
                    continue
                if not BC_ACTIVE_RE.search(line):
                    continue
                ts = ts_parse(line)
                if ts is not None and (latest is None or ts > latest):
                    latest = ts
    except OSError:
        return None
    return latest


# ---------- 状态读写（原子） ----------
def load_state():
    try:
        with open(STATE_FILE) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}

def save_state(st):
    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(STATE_FILE) or ".")
        with os.fdopen(fd, "w") as fh:
            json.dump(st, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, STATE_FILE)
    except OSError:
        pass  # 状态写失败不致命（下次重试）

# ---------- 主逻辑 ----------
def main():
    out = []
    state = load_state()
    now_iso = NOW.strftime("%Y-%m-%d %H:%M:%S")
    last_log_alert = state.get("last_log_alert_ts")
    last_bc_alert = state.get("last_bc_alert_ts")
    was_log_alert = state.get("was_log_alert", False)
    was_bc_alert = state.get("was_bc_alert", False)
    last_log_alert_count = state.get("last_log_alert_count", 0)
    dedup_delta = timedelta(hours=DEDUP_H)

    def parse_ts(s):
        if not s:
            return None
        try:
            return datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return None

    # --- A 日志窗口 ---
    err24, err15, by_type, hourly, samples = scan_logs()
    log_alert = err24 > ERR24H_MAX or err15 > ERR15M_MAX
    # 升级：超升级线 且 错误数明显增长（>上次告警时 1.5 倍 且 绝对增量 ≥20 行）→ 故障恶化，打破去重
    growing = err24 > last_log_alert_count * 1.5 + 20
    escalated = err24 > ERR24H_ESC and growing
    last_la = parse_ts(last_log_alert)
    # 0827 P0 处置（对齐注释意图）：历史故障残留滑出窗口时 err24 单调下降/持平，
    # 此时不重复告警（原逻辑 2h 去重窗过后对静止错误仍每 2h 轰炸一次）。
    # 错误数一旦增长（>上次告警数）立即打破去重，无漏报。
    suppress = last_la is not None and (
        (NOW - last_la) < dedup_delta or err24 <= last_log_alert_count
    ) and not escalated

    if log_alert:
        if suppress:
            # 静默：去重窗口内且未升级
            pass
        else:
            out.append(f"[telegram-delivery-watchdog] {now_iso} — telegram 投递链路异常")
            out.append(f"  24h 窗口错误 {err24} 行（阈值 {ERR24H_MAX}）| 15min 窗口 {err15} 行（阈值 {ERR15M_MAX}）")
            if by_type:
                dist = " / ".join(f"{k} {v}" for k, v in sorted(by_type.items(), key=lambda x: -x[1]))
                out.append(f"  类型分布：{dist}")
            top_h = sorted(hourly.items(), key=lambda x: -x[1])[:3]
            if top_h:
                out.append(f"  最密集时段：{' | '.join(f'{h}:00 {v}行' if h.endswith('00') else f'{h} {v}行' for h, v in top_h)}")
            if samples:
                out.append("  最近错误样例：")
                for s in samples:
                    out.append(f"    {s}")
            state["last_log_alert_ts"] = now_iso
            state["last_log_alert_count"] = err24
            state["was_log_alert"] = True
            # 总线：telegram 投递链断 → P0（定稿判定表）
            _bus_append("P0", "tg-log-errors", "telegram 投递链路异常",
                        "\n".join(out[-6:]))
    elif was_log_alert:
        out.append(f"[telegram-delivery-watchdog] {now_iso} — telegram 投递链路已恢复（24h 窗口 {err24} 行，低于阈值 {ERR24H_MAX}）")
        state["was_log_alert"] = False
        # O2 恢复确认后清 state：清掉告警基线，避免旧 count（如 1814）令
        # `err24 <= last_log_alert_count` 恒成立 → 恢复后的新故障被静默压制
        state.pop("last_log_alert_ts", None)
        state.pop("last_log_alert_count", None)
        # 总线：恢复通知 → P2 信息留痕
        _bus_append("P2", "tg-log-recovered", "telegram 投递链路已恢复",
                    f"24h 窗口 {err24} 行（阈值 {ERR24H_MAX}）")

    # --- B blocked_config ---
    bc_hits = scan_blocked_config()
    # 0827 P0 处置：对每个命中 job，若 gateway.log 最近活性记录时间 > 该 job 的
    # last_run_at（job 被 block 之后链路曾恢复）→ 判定为历史残留（last_status
    # 尚未被下一次运行刷新），不告警。链路持续坏时无新活性 → 照常告警，不漏报。
    last_active = last_link_active_ts()
    bc_stale = bool(bc_hits) and any(
        h.get("last_run") and last_active is not None
        and last_active > parse_ts(h["last_run"])
        for h in bc_hits
    )
    last_ba = parse_ts(last_bc_alert)
    bc_suppress = last_ba is not None and (NOW - last_ba) < dedup_delta
    if bc_hits and not bc_stale and not bc_suppress:
        out.append(f"[telegram-delivery-watchdog] {now_iso} — jobs.json 出现 blocked_config（deliver=telegram 的启用 job 投递被阻断）")
        for h in bc_hits:
            out.append(f"  job {h['id']}「{h['name']}」deliver={h['deliver']} last_status={h['last_status']}")
            out.append(f"    error: {h['last_error']}")
        state["last_bc_alert_ts"] = now_iso
        state["was_bc_alert"] = True
        # 总线：投递被阻断 → P0（定稿判定表）
        _bus_append("P0", "tg-blocked-config", "jobs.json blocked_config",
                    "\n".join(out[-8:]))
    elif not bc_hits and was_bc_alert:
        out.append(f"[telegram-delivery-watchdog] {now_iso} — blocked_config 已清除（enabled job 全部恢复正常）")
        state["was_bc_alert"] = False
        # O2 恢复确认后清 state：清掉 last_bc_alert_ts，避免 2h 去重窗吞掉恢复后的新故障
        state.pop("last_bc_alert_ts", None)
        # 总线：恢复通知 → P2 信息留痕
        _bus_append("P2", "tg-blocked-recovered", "blocked_config 已清除",
                    "enabled job 全部恢复正常")
    elif bc_stale and was_bc_alert:
        out.append(f"[telegram-delivery-watchdog] {now_iso} — blocked_config 残留已判定为历史故障（链路活性正常：job 被 block 后 gateway.log 已有轮询/投递成功记录；job 的 last_status 将在下次运行时刷新）")
        state["was_bc_alert"] = False
        # O2 恢复确认后清 state：与上同，避免去重窗吞掉恢复后的新故障
        state.pop("last_bc_alert_ts", None)
        # 总线：恢复通知 → P2 信息留痕
        _bus_append("P2", "tg-blocked-recovered", "blocked_config 残留判定为历史故障",
                    "链路活性正常（job 被 block 后已有轮询/投递成功记录），last_status 待下次运行刷新")

    save_state(state)
    if out:
        sys.stdout.write("\n".join(out) + "\n")
    # 正常态：stdout 为空 → cron 静默
    return 0

if __name__ == "__main__":
    sys.exit(main())
