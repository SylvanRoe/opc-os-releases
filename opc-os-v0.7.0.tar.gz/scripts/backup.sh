#!/bin/bash
# OPC OS — 数据导出/备份脚本（复用 mrd_backup.sh 模式：成功静默，失败输出错误）
# 用法: scripts/backup.sh [--keep N] [--out <目录>] [--data-dir <数据目录>]
#   默认: 备份到 <仓库>/backups/<日期>/，保留最近 14 份
# 备份内容（7 文件集，D5 扩展，吸收 GAP-6 P1-1 代码部分）:
#   核心 4 文件（缺一 = 中止）:
#     kanban.db（任务/事件留痕）+ status.json + token-stats.json + state.json
#   配置类 3 文件（缺 = 警告继续，新部署可能尚无）:
#     gateway.config.json（网关运行时配置）+ bus-state.json（数据总线水位线）
#     + govern-state.json（治理状态）
# 数据源: --data-dir 指定本地数据目录；未给时尝试从 docker 容器 opc-os-collector 复制（旧形态兼容）
# 路径 env 参数化（installation-guide §14 红线 7）:
#   OPC_DATA_DIR        数据目录兜底（默认空；等价 --data-dir）
#   OPC_GATEWAY_CONFIG  网关配置路径（默认 <data-dir>/llm-gateway/gateway.config.json，
#                       生产兜底 ~/.hermes/opc/llm-gateway/gateway.config.json）
set -e
export PATH=/usr/local/bin:/usr/bin:/bin

KEEP=14
BACKUP_ROOT="$(cd "$(dirname "$0")/.." && pwd)/backups"
DATA_DIR="${OPC_DATA_DIR:-}"

while [ $# -gt 0 ]; do
  case "$1" in
    --keep) KEEP="$2"; shift 2 ;;
    --out)  BACKUP_ROOT="$2"; shift 2 ;;
    --data-dir) DATA_DIR="$2"; shift 2 ;;
    *) echo "未知参数: $1"; exit 2 ;;
  esac
done

DEST="$BACKUP_ROOT/$(date +%F)"
mkdir -p "$DEST"

CORE_FILES="kanban.db status.json token-stats.json state.json"
CFG_FILES="gateway.config.json bus-state.json govern-state.json"

# 网关配置路径解析（生产兜底 <data-dir>/llm-gateway/gateway.config.json；OPC_GATEWAY_CONFIG 可覆盖）
resolve_gateway_config() {
  if [ -n "$OPC_GATEWAY_CONFIG" ]; then
    echo "$OPC_GATEWAY_CONFIG"
  elif [ -n "$DATA_DIR" ]; then
    echo "$DATA_DIR/llm-gateway/gateway.config.json"
  else
    echo "$HOME/.hermes/opc/llm-gateway/gateway.config.json"
  fi
}

# 数据源解析：优先 --data-dir；否则 docker 容器
SRC=""
if [ -n "$DATA_DIR" ]; then
  SRC="$DATA_DIR"
  echo "[opc-os] 从本地数据目录 $SRC 复制"
  missing=""
  for f in $CORE_FILES; do
    if [ -f "$SRC/$f" ]; then
      cp "$SRC/$f" "$DEST/"
      echo "  备份 $f"
    else
      missing="$missing $f"
    fi
  done
  if [ -n "$missing" ]; then
    # 核心文件缺失 = 失败即清理本次已复制的部分文件，避免不完整备份被误当完整
    for f in $CORE_FILES; do
      rm -f "$DEST/$f"
    done
    rmdir "$DEST" 2>/dev/null || true
    echo "⚠️ OPC OS 备份失败: --data-dir 数据目录缺少核心文件:$missing（数据不完整，备份中止）" >&2
    exit 1
  fi
  # 配置类 3 文件（缺 = 警告继续，新部署可能尚无）
  for f in $CFG_FILES; do
    src_path=""
    if [ "$f" = "gateway.config.json" ]; then
      src_path="$(resolve_gateway_config)"
    else
      src_path="$SRC/$f"
    fi
    if [ -f "$src_path" ]; then
      cp "$src_path" "$DEST/$f"
      echo "  备份 $f"
    else
      echo "  ⚠️  $f 不存在（$src_path，跳过——新部署可能尚无）"
    fi
  done
  echo "完成: $DEST"
elif docker ps --format '{{.Names}}' 2>/dev/null | grep -q '^opc-os-collector$'; then
  echo "[opc-os] 从容器 opc-os-collector:/data 复制"
  for f in $CORE_FILES; do
    docker cp "opc-os-collector:/data/$f" "$DEST/" 2>/dev/null && echo "  备份 $f" || echo "  ⚠️  $f 不存在（跳过）"
  done
  # 容器形态同样补配置类（bus-state.json / govern-state.json 在 /data）
  for f in bus-state.json govern-state.json; do
    docker cp "opc-os-collector:/data/$f" "$DEST/" 2>/dev/null && echo "  备份 $f" || echo "  ⚠️  $f 不存在（跳过）"
  done
  # 网关配置在宿主 <data-dir>/llm-gateway/（容器形态默认 ~/.hermes/opc/llm-gateway/）
  gw="$(resolve_gateway_config)"
  if [ -f "$gw" ]; then
    cp "$gw" "$DEST/gateway.config.json"
    echo "  备份 gateway.config.json"
  else
    echo "  ⚠️  gateway.config.json 不存在（$gw，跳过）"
  fi
  echo "完成: $DEST"
else
  echo "⚠️ OPC OS 备份失败: 未找到数据源（容器 opc-os-collector 未运行，且未指定 --data-dir / OPC_DATA_DIR）"
  exit 1
fi

# 清理超过 KEEP 天的旧备份
find "$BACKUP_ROOT" -maxdepth 1 -type d -name '????-??-??' -mtime +"$KEEP" -exec rm -rf {} + 2>/dev/null || true
exit 0
