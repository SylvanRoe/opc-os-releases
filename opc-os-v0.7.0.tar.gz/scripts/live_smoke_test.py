#!/usr/bin/env python3
"""opc-govern 守护进程主循环冒烟测试：真实进程 + 注入 FAIL 事件 → ≤30s 自动派修；重启不重放。"""
import json
import os
import signal
import sqlite3
import subprocess
import sys
import time

WS = os.path.dirname(os.path.abspath(__file__))
REAL_DB = '/home/gavin/.hermes/kanban/boards/opc/kanban.db'
TEST_DB = os.path.join(WS, 'live-test-kanban.db')
TEST_STATE = os.path.join(WS, 'live-test-govern-state.json')
GOVERN = os.path.join(WS, 'opc-govern.py')
PY = '/home/gavin/.hermes/hermes-agent/venv/bin/python3'

PASS = FAIL = 0


def check(name, cond, extra=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f'  ✅ {name}')
    else:
        FAIL += 1
        print(f'  ❌ {name} {extra}')


def reset_db():
    for f in (TEST_DB, TEST_DB + '-wal', TEST_DB + '-shm'):
        if os.path.exists(f):
            os.remove(f)
    src = sqlite3.connect(REAL_DB)
    dst = sqlite3.connect(TEST_DB)
    with dst:
        src.backup(dst)
    src.close()
    dst.close()
    for f in (TEST_STATE, TEST_STATE + '.govern-tmp'):
        if os.path.exists(f):
            os.remove(f)


def start_govern():
    env = dict(os.environ)
    env['OPC_GOVERN_KANBAN_DB'] = TEST_DB
    env['OPC_GOVERN_STATE_FILE'] = TEST_STATE
    env['OPC_GOVERN_POLL_SECONDS'] = '1.0'
    env['OPC_GOVERN_SCAN_SECONDS'] = '3'
    return subprocess.Popen([PY, GOVERN], env=env,
                            stdout=open(os.path.join(WS, 'live-test.log'), 'w'),
                            stderr=subprocess.STDOUT)


def inject_fail_review():
    """注入一张验收卡 + 蔡婉 FAIL block（等价 kanban_create + kanban_block）。返回卡 id。"""
    con = sqlite3.connect(TEST_DB, timeout=10)
    now = int(time.time())
    con.execute('BEGIN IMMEDIATE')
    tid = 't_' + os.urandom(4).hex()
    con.execute(
        "INSERT INTO tasks (id, title, body, assignee, status, priority, created_by, "
        "created_at, workspace_kind, workspace_path, branch_name, project_id, tenant, "
        "idempotency_key, max_runtime_seconds, skills, max_retries, model_override, "
        "provider_override, reasoning_effort, goal_mode, goal_max_turns, session_id) "
        "VALUES (?, ?, ?, 'ada', 'running', 0, 'worker', ?, 'scratch', NULL, NULL, NULL, NULL, "
        "NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL)",
        (tid, '【0823-govlive】【验收】守护进程冒烟（测试）', '【验收 · 只读】测试清单。', now))
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "VALUES (?, NULL, 'created', ?, ?)",
        (tid, json.dumps({'assignee': 'ada', 'status': 'running', 'parents': [],
                          'tenant': None, 'workspace_kind': 'scratch',
                          'workspace_path': None, 'branch_name': None,
                          'project_id': None, 'skills': None, 'goal_mode': None,
                          'model_override': None, 'provider_override': None},
                         ensure_ascii=False), now))
    con.execute(
        "UPDATE tasks SET status='blocked', block_kind='needs_input' WHERE id=?", (tid,))
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "VALUES (?, NULL, 'blocked', ?, ?)",
        (tid, json.dumps({'reason': '【验收不通】冒烟 FAIL：清单项 3 未达标，请修复',
                          'kind': 'needs_input', 'recurrences': 1,
                          'source_status': 'running'}, ensure_ascii=False), now))
    con.commit()
    con.close()
    return tid


def count_cards(pat):
    con = sqlite3.connect(f'file:{TEST_DB}?mode=ro', uri=True)
    try:
        n = con.execute("SELECT COUNT(*) FROM tasks WHERE title LIKE ?", (f'%{pat}%',)).fetchone()[0]
        return n
    finally:
        con.close()


def main():
    reset_db()
    print('== 守护进程冒烟：首启校准 + 事件驱动 R1 ==')
    proc = start_govern()
    time.sleep(3)  # 首启校准
    # 注入 FAIL（事件发生在 watermark 之后 → 事件路径触发）
    rv = inject_fail_review()
    t0 = time.time()
    fix_seen = False
    while time.time() - t0 < 30:
        # 用 govlive 专属模式计数（首扫会对真实 i18n-d 卡 t_e2861b06 派修的链卡也算进
        # 【govern-fix】，故不能按通用前缀判）；govlive 链 = 验收+修复+复验 3 张
        if count_cards('govlive') >= 3:
            fix_seen = True
            break
        time.sleep(1)
    elapsed = time.time() - t0
    check(f'R1 ≤30s 自动生成修复卡+复验卡（{elapsed:.1f}s）', fix_seen, f'elapsed={elapsed:.1f}s')
    check('共 3 张（验收+修复+复验）', count_cards('govlive') == 3, f'n={count_cards("govlive")}')
    # 修复卡 assignee=make / 复验卡 assignee=ada 且父=修复卡
    con = sqlite3.connect(f'file:{TEST_DB}?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    fix_t = con.execute("SELECT assignee, status FROM tasks WHERE title LIKE '%govlive%' "
                        "AND title LIKE '%修复%'").fetchone()
    rr_t = con.execute("SELECT assignee, status, id FROM tasks WHERE title LIKE '%govlive%' "
                       "AND title LIKE '%复验%'").fetchone()
    con.close()
    check('修复卡 assignee=make + ready', fix_t and fix_t['assignee'] == 'make'
          and fix_t['status'] == 'ready', f'{dict(fix_t) if fix_t else None}')
    if rr_t:
        con = sqlite3.connect(f'file:{TEST_DB}?mode=ro', uri=True)
        pars = [r[0] for r in con.execute(
            'SELECT parent_id FROM task_links WHERE child_id=?', (rr_t['id'],))]
        con.close()
        check('复验卡 assignee=ada + 父=修复卡', rr_t['assignee'] == 'ada' and len(pars) == 1,
              f"assignee={rr_t['assignee']} pars={pars}")

    print('\n== 重启：水位线不重放 ==')
    proc.terminate()
    proc.wait(timeout=10)
    time.sleep(1)
    proc2 = start_govern()
    time.sleep(3)
    check('重启后不重复派卡（仍 3 张）', count_cards('govlive') == 3,
          f'n={count_cards("govlive")}')
    # 扫描兜底也幂等（重启后 scan 已跑过）
    time.sleep(4)
    check('重启后扫描幂等（仍 3 张）', count_cards('govlive') == 3,
          f'n={count_cards("govlive")}')
    proc2.terminate()
    proc2.wait(timeout=10)

    print('\n== 守护进程冒烟：复验 done → R2 自动收口 ==')
    proc3 = start_govern()
    time.sleep(3)
    con = sqlite3.connect(TEST_DB, timeout=10)
    now = int(time.time())
    con.execute('BEGIN IMMEDIATE')
    con.execute("UPDATE tasks SET status='done', completed_at=? WHERE title LIKE '%govlive%' "
                "AND title LIKE '%修复%'", (now,))
    con.execute("UPDATE tasks SET status='done', completed_at=? WHERE title LIKE '%govlive%' "
                "AND title LIKE '%复验%'", (now,))
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "SELECT id, NULL, 'completed', ?, ? FROM tasks WHERE title LIKE '%govlive%' "
        "AND title LIKE '%复验%'",
        (json.dumps({'result_len': 0, 'summary': '冒烟复验 ✅ 通过'}, ensure_ascii=False), now))
    con.commit()
    con.close()
    t0 = time.time()
    closed = False
    while time.time() - t0 < 30:
        con = sqlite3.connect(f'file:{TEST_DB}?mode=ro', uri=True)
        st = con.execute("SELECT status FROM tasks WHERE title LIKE '%govlive%' "
                         "AND title LIKE '%验收%' AND title NOT LIKE '%修复%' "
                         "AND title NOT LIKE '%复验%'").fetchone()
        con.close()
        if st and st[0] == 'done':
            closed = True
            break
        time.sleep(1)
    elapsed = time.time() - t0
    check(f'复验 done → 验收卡自动收口（{elapsed:.1f}s）', closed, f'elapsed={elapsed:.1f}s')
    proc3.terminate()
    proc3.wait(timeout=10)

    print(f'\n========== 冒烟结果: {PASS} 通过 / {FAIL} 失败 ==========')
    sys.exit(1 if FAIL else 0)


if __name__ == '__main__':
    main()
