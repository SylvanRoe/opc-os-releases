#!/usr/bin/env python3
"""OPC OS — 脱敏 Demo 数据生成器

生成一套「演示团队」的完整脱敏数据，让部署实例开箱即可跑通全链路
（kanban 快照 → opc_collect.py → status.json → 仪表盘；token-stats 管道同理）。

不交付任何 OPC 真实内部数据（红线）：
  - 成员名 = 演示名（Demo CEO / Demo Dev ...），仅保留 9 个技术 id 槽位
    （zhuangzi/make/anran/linjing/wenwen/qianli/panming/ada/iris）供前端 canvas 布局用
  - 任务/决策/活动 = 虚构示例，无真实客户/线索/财务内容
  - token 数值 = 示例量级（单位：百万 token），非真实消耗

产物（写入 <hermes_home> 即数据源根，demo 模式由 collector 读取）：
  1. kanban.db            —— tasks/task_runs/task_events 完整生命周期留痕（派活→完成→验收）
  2. state.json           —— team 名册（9 演示成员 + CEO）+ metrics
  3. <profiles>/<p>/state.db —— sessions 表（每成员若干会话，含 estimated_cost_usd）
  4. <profiles>/<p>/cron/usage_audit.jsonl —— cron 用量行
  5. <profiles>/<p>/cron/output/<job>/<ts>.md —— cron 运行痕迹（job 名匹配 CRON_MEMBER）
  6. cache/delegation/live/deleg_*/manifest.json —— delegate 派活痕迹

用法: python3 gen_demo_data.py [--config <path>] [--fresh] --demo
      --demo  显式开关（31c）：演示数据与初始化互斥——仅显式 --demo 才生成；
              卷内已有 init-state.json（已初始化）时拒绝（避免覆盖客户团队）
      --fresh 清空目标数据源后重新生成（默认增量幂等，已存在则跳过）
"""
import json
import os
import sys
import sqlite3
import datetime
import random
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib_config import get_cfg

CFG = get_cfg()
P = CFG['paths']
HOME = P['hermes_home']
OPC_DIR = P['opc_dir']
KANBAN_DB = P['kanban_db']
DEMO_KANBAN_DB = P.get('demo_kanban_db') or ''
STATE_JSON = os.path.join(OPC_DIR, 'state.json')

# 9 个技术 id 槽位（前端 canvas MEMBER_STATES 固定布局，必须保留）
SLOTS = ['zhuangzi', 'make', 'anran', 'linjing', 'wenwen', 'qianli', 'panming', 'ada', 'iris']

# 演示名册（脱敏）：name_zh = 演示名，name_en = 英文演示名，role = 职能
DEMO_ROSTER = [
    # (id, name_zh, name_en, role)
    ('zhuangzi', '演示CEO', 'Demo CEO', 'CEO/主控'),
    ('make', '演示开发', 'Demo Dev', '开发/产品'),
    ('anran', '演示运维', 'Demo Ops', '运维'),
    ('linjing', '演示营销', 'Demo Mkt', '营销/内容'),
    ('wenwen', '演示客服', 'Demo CS', '客服'),
    ('qianli', '演示财务', 'Demo Fin', '财务'),
    ('panming', '演示情报', 'Demo Intel', '竞品情报'),
    ('ada', '演示测试', 'Demo QA', '测试/验收'),
    ('iris', '演示设计', 'Demo UX', 'UI/UX 设计'),
]

# 演示任务池（虚构，无真实 OPC 内容）
DEMO_TASKS = [
    ('完成季度产品路线图初稿', 'zhuangzi', 'done'),
    ('实现用户反馈收集接口', 'make', 'done'),
    ('巡检服务健康与备份', 'anran', 'done'),
    ('撰写新功能发布文案', 'linjing', 'done'),
    ('处理客户咨询工单', 'wenwen', 'done'),
    ('核对月度费用台账', 'qianli', 'done'),
    ('扫描竞品动态简报', 'panming', 'done'),
    ('验收发布文案质量', 'ada', 'done'),
    ('设计新版仪表盘视觉稿', 'iris', 'done'),
    ('【验收】发布文案质量验收', 'ada', 'done'),
    ('优化数据采集频率配置', 'make', 'running'),
    ('【验收】采集频率优化验收', 'ada', 'todo'),
    ('整理客户反馈需求池', 'wenwen', 'todo'),
]


def now_ts():
    return time.time()


def mkdirs(p):
    os.makedirs(os.path.dirname(p), exist_ok=True)


def gen_kanban_db():
    """生成演示 kanban.db（schema 与真实 Hermes kanban 一致，含完整生命周期留痕）。"""
    if os.path.exists(KANBAN_DB):
        # 幂等：已存在则跳过（--fresh 由调用方删库）
        print(f'[demo] kanban.db 已存在，跳过（--fresh 可重建）: {KANBAN_DB}')
        return
    mkdirs(KANBAN_DB)
    con = sqlite3.connect(KANBAN_DB)
    cur = con.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY, title TEXT, body TEXT, assignee TEXT, status TEXT,
        priority INTEGER, created_by TEXT, created_at INTEGER, started_at INTEGER,
        completed_at INTEGER, workspace_kind TEXT, workspace_path TEXT,
        branch_name TEXT, project_id TEXT, claim_lock TEXT, claim_expires INTEGER,
        tenant TEXT, result TEXT, idempotency_key TEXT, consecutive_failures INTEGER,
        worker_pid INTEGER, last_failure_error TEXT, max_runtime_seconds INTEGER,
        last_heartbeat_at INTEGER, current_run_id INTEGER, workflow_template_id TEXT,
        current_step_key TEXT, skills TEXT, model_override TEXT, provider_override TEXT,
        reasoning_effort TEXT, max_retries INTEGER, goal_mode INTEGER, goal_max_turns INTEGER,
        session_id TEXT, block_kind TEXT, block_recurrences INTEGER)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS task_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, profile TEXT, step_key TEXT,
        status TEXT, claim_lock TEXT, claim_expires INTEGER, worker_pid INTEGER,
        max_runtime_seconds INTEGER, last_heartbeat_at INTEGER, started_at INTEGER,
        ended_at INTEGER, outcome TEXT, summary TEXT, metadata TEXT, error TEXT)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS task_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, run_id INTEGER,
        kind TEXT, payload TEXT, created_at INTEGER)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS task_links (
        parent_id TEXT, child_id TEXT)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS task_comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, author TEXT,
        body TEXT, created_at INTEGER)''')

    base = now_ts() - 3 * 86400
    assignee_of = {t[1] for t in DEMO_TASKS}
    for i, (title, assignee, status) in enumerate(DEMO_TASKS):
        tid = f't_demo_{i:03d}'
        created = base + i * 3600
        started = created + 300
        completed = started + 3600 if status == 'done' else None
        cur.execute(
            'INSERT INTO tasks (id, title, body, assignee, status, priority, created_by,'
            ' created_at, started_at, completed_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
            (tid, title, f'演示任务（脱敏）: {title}', assignee, status, 50,
             'demo', created, started, completed))
        # 事件留痕：created → claimed → (running) → completed / blocked
        cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                    (tid, None, 'created', '{}', created))
        cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                    (tid, None, 'claimed', '{}', started))
        if status == 'running':
            cur.execute('INSERT INTO task_runs (task_id, profile, status, started_at, outcome) VALUES (?,?,?,?,?)',
                        (tid, assignee, 'running', started, None))
            cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                        (tid, 1, 'heartbeat', '{}', now_ts()))
        elif status == 'done':
            cur.execute('INSERT INTO task_runs (task_id, profile, status, started_at, ended_at, outcome) VALUES (?,?,?,?,?,?)',
                        (tid, assignee, 'done', started, completed, 'completed'))
            cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                        (tid, 1, 'completed', '{}', completed))
    # 验收卡 FAIL 样例：一条 blocked 事件（reason 含「不通过」→ token_stats 验收 FAIL 归因）
    cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                ('t_demo_009', 1, 'blocked',
                 json.dumps({'reason': '发布文案验收不通过：需补充渠道数据'}), base + 7200))

    con.commit()
    con.close()
    print(f'[demo] kanban.db 生成: {KANBAN_DB}（{len(DEMO_TASKS)} 任务 + 生命周期事件留痕）')


def gen_state_json():
    """生成演示 state.json（team 名册 + metrics + 虚构决策留痕）。"""
    if os.path.exists(STATE_JSON):
        print(f'[demo] state.json 已存在，跳过: {STATE_JSON}')
        return
    team = []
    for pid, zh, en, role in DEMO_ROSTER:
        if pid == 'zhuangzi':
            continue  # CEO 单独放 company.ceo
        team.append({
            'role': role, 'name_zh': zh, 'name_en': en, 'gender': '—',
            'duty': '演示职责（脱敏）', 'capability': '演示能力（脱敏）',
            'acceptance': '演示验收基线（脱敏）',
        })
    state = {
        'company': {
            'name': 'Demo Team（OPC OS 演示实例）',
            'operator': 'AI 成员团队 + 人类负责人',
            'ceo': {'name_zh': '演示CEO', 'name_en': 'Demo CEO', 'gender': '—',
                    'role': 'CEO/主控'},
            'vision': 'OPC OS 演示：AI 原生团队的治理操作系统',
            'governance': '人财物由负责人拍板；事由 CEO 自主',
        },
        'team': team,
        'customers': [],
        'leads': [],
        'requirements': [],
        'revenue': [],
        'decisions': [
            {'date': datetime.date.today().isoformat(),
             'decision': '（演示数据）OPC OS 部署实例初始化：启用演示团队名册与脱敏数据。',
             'rationale': '演示用途，无真实业务内容。',
             'decided_by': 'ai', 'status': 'active'},
        ],
        'metrics': {
            'demo_instances': 1,
            'demo_data': True,
            'updated_at': datetime.datetime.now().isoformat(),
        },
        'tasks': [
            {'kanban': 't_demo_005', 'title': '处理客户咨询工单', 'status': 'done'},
            {'kanban': 't_demo_010', 'title': '优化数据采集频率配置', 'status': 'in_progress'},
        ],
    }
    mkdirs(STATE_JSON)
    with open(STATE_JSON, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    print(f'[demo] state.json 生成: {STATE_JSON}')


def gen_profile_state_db():
    """生成各成员演示 state.db（sessions 表：会话 token/成本示例）。"""
    random.seed(42)
    for pid, zh, en, role in DEMO_ROSTER:
        dbp = os.path.join(HOME, 'profiles', pid, 'state.db')
        if os.path.exists(dbp):
            print(f'[demo] {pid} state.db 已存在，跳过')
            continue
        mkdirs(dbp)
        con = sqlite3.connect(dbp)
        cur = con.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, profile_name TEXT, started_at REAL,
            input_tokens INTEGER, output_tokens INTEGER, cache_read_tokens INTEGER,
            cache_write_tokens INTEGER, reasoning_tokens INTEGER,
            estimated_cost_usd REAL, actual_cost_usd REAL)''')
        now = now_ts()
        for i in range(6):  # 每成员 6 个会话（近 3 天）
            started = now - random.randint(0, 3) * 86400 - i * 3600
            inp = random.randint(8000, 400000)
            outp = random.randint(2000, 120000)
            cr = random.randint(0, 500000)
            cw = random.randint(0, 60000)
            cost = round((inp + outp) * 0.0000004, 4)
            cur.execute(
                'INSERT INTO sessions (profile_name, started_at, input_tokens, output_tokens,'
                ' cache_read_tokens, cache_write_tokens, reasoning_tokens,'
                ' estimated_cost_usd, actual_cost_usd) VALUES (?,?,?,?,?,?,?,?,0)',
                (pid, started, inp, outp, cr, cw, random.randint(0, 20000), cost))
        con.commit()
        con.close()
        print(f'[demo] {pid} state.db 生成（6 会话）')


def gen_usage_audit():
    """生成各成员 cron usage_audit.jsonl（示例用量行）。"""
    random.seed(7)
    for pid, zh, en, role in DEMO_ROSTER:
        audit = os.path.join(HOME, 'profiles', pid, 'cron', 'usage_audit.jsonl')
        if os.path.exists(audit):
            print(f'[demo] {pid} usage_audit 已存在，跳过')
            continue
        mkdirs(audit)
        now = now_ts()
        lines = []
        for i in range(8):
            ts = now - i * 3600
            iso = datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
            lines.append(json.dumps({
                'ts': iso,
                'total_tokens': random.randint(5000, 90000),
                'runs': 1,
            }))
        with open(audit, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        print(f'[demo] {pid} usage_audit.jsonl 生成（8 行）')


def gen_cron_output():
    """生成各成员 cron output 痕迹（job 名匹配 CRON_MEMBER → 活动流可解析）。"""
    now = now_ts()
    # 显式 job 分配：覆盖 CRON_MEMBER 全部键（每成员 1-2 个 job）
    job_assign = {
        'zhuangzi': ['opc-daily-report', 'opc-weekly-review', 'zhuangzi-mainloop'],
        'make': ['make-mainloop'],
        'anran': ['anran-inspect', 'anran-mainloop', 'mrd-daily-backup'],
        'linjing': ['four-platform-monitor', 'juejin-article-track', 'linjing-mainloop'],
        'wenwen': ['wenwen-mainloop'],
        'qianli': ['qianli-mainloop'],
        'panming': ['panming-mainloop'],
        'ada': ['ada-mainloop'],
        'iris': ['iris-mainloop'],
    }
    for pid, zh, en, role in DEMO_ROSTER:
        for job in job_assign.get(pid, [f'{pid}-mainloop']):
            outdir = os.path.join(HOME, 'profiles', pid, 'cron', 'output',
                                  f'job_{abs(hash(job)) % 100000}')
            ts = datetime.datetime.fromtimestamp(now - 1800, tz=datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')
            fpath = os.path.join(outdir, f'{ts}.md')
            if os.path.exists(fpath):
                continue
            mkdirs(fpath)
            content = (
                f'# Cron Job: {job}\n\n'
                f'**Status:** ok\n\n'
                f'## Response\n\n（演示数据）{zh} 完成例行工作，脱敏输出。\n'
            )
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
        print(f'[demo] {pid} cron output 痕迹生成')


def gen_delegation():
    """生成 delegate 派活痕迹（manifest.json，goal 文本含成员名 → 活动流 involved）。"""
    now = now_ts()
    random.seed(11)
    for i, (pid, zh, en, role) in enumerate(DEMO_ROSTER[1:], 1):
        ddir = os.path.join(HOME, 'cache', 'delegation', 'live', f'deleg_demo_{i:02d}')
        mf = os.path.join(ddir, 'manifest.json')
        if os.path.exists(mf):
            continue
        mkdirs(mf)
        goal = f'你是{zh}。请完成一项演示协作任务：整理本周工作摘要并形成简报。'
        manifest = {
            'id': f'deleg_demo_{i:02d}',
            'goal': goal,
            'created_at': now - random.randint(600, 3600),
            'status': 'completed',
            'tasks': [{'id': f'dt_{i}', 'goal': goal, 'status': 'completed'}],
        }
        with open(mf, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(f'[demo] delegation 痕迹生成（{len(DEMO_ROSTER) - 1} 条）')


def gen_demo_kanban_demo_board():
    """生成 kanban_demo（访客体验隔离板）演示数据：tasks（与 hermes 真实 schema 对齐）+ task_events
    生命周期留痕 + 结果文件，让 opc-bus 30b demo 状态机开箱可跑（demo_id 提取 → dispatched/running/
    completed 全链路；done 卡带结果文件才计 completed）。"""
    if not DEMO_KANBAN_DB:
        return
    if os.path.exists(DEMO_KANBAN_DB):
        print(f'[demo] demo kanban.db 已存在，跳过: {DEMO_KANBAN_DB}')
        return
    mkdirs(DEMO_KANBAN_DB)
    con = sqlite3.connect(DEMO_KANBAN_DB)
    cur = con.cursor()
    # 与 hermes kanban 真实 schema 对齐（bus 只读查询所需列全集）
    cur.execute('''CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT, assignee TEXT,
        status TEXT NOT NULL, priority INTEGER DEFAULT 0, created_by TEXT,
        created_at INTEGER NOT NULL, started_at INTEGER, completed_at INTEGER,
        workspace_kind TEXT NOT NULL DEFAULT 'scratch', workspace_path TEXT,
        branch_name TEXT, project_id TEXT, claim_lock TEXT, claim_expires INTEGER,
        tenant TEXT, result TEXT, idempotency_key TEXT,
        consecutive_failures INTEGER NOT NULL DEFAULT 0, worker_pid INTEGER,
        last_failure_error TEXT, max_runtime_seconds INTEGER, last_heartbeat_at INTEGER,
        current_run_id INTEGER, workflow_template_id TEXT, current_step_key TEXT,
        skills TEXT, model_override TEXT, provider_override TEXT, reasoning_effort TEXT,
        max_retries INTEGER, goal_mode INTEGER NOT NULL DEFAULT 0, goal_max_turns INTEGER,
        session_id TEXT, block_kind TEXT, block_recurrences INTEGER NOT NULL DEFAULT 0)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS task_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, run_id INTEGER,
        kind TEXT NOT NULL, payload TEXT, created_at INTEGER NOT NULL)''')
    base = now_ts() - 3600
    # 4 个演示访客任务（demo_id 走真实建卡格式（…）/ body demo_id: 行，bus 可提取；状态混合：
    # 2 done 带结果文件 + 1 running + 1 todo，开箱即见 dispatched/running/completed 全状态）
    seeds = [
        ('t_demo_d1', '【demo】V2EX 热帖（ddemo_1）', 'ddemo_1', 'v2ex_hot', 'done', 0),
        ('t_demo_d2', '【demo】广州天气（ddemo_2）', 'ddemo_2', 'gz_weather', 'done', 0),
        ('t_demo_d3', '【demo】牛来票房（ddemo_3）', 'ddemo_3', 'niulai_boxoffice', 'running', 0),
        ('t_demo_d4', '【demo】广州周边旅行（ddemo_4）', 'ddemo_4', 'gz_trip', 'todo', 0),
    ]
    res_dir = os.path.join(OPC_DIR, 'demo', 'results')
    for i, (tid, title, demo_id, preset, status, _p) in enumerate(seeds):
        created = base - i * 1800
        started = created + 60 if status != 'todo' else None
        completed = None
        if status == 'done':
            assert started is not None
            completed = started + 900
        body = (f'这是透明办公室访客体验任务（demo），由庄子派活。请认真完成并回传报告。\n\n'
                f'demo_id: {demo_id}\n访客请求: 演示预设 {preset}（脱敏）\n\n'
                '执行约束: 只查询外部公开信息; 完成后把 markdown 报告写到结果目录。')
        cur.execute(
            'INSERT INTO tasks (id, title, body, assignee, status, priority, created_by,'
            ' created_at, started_at, completed_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
            (tid, title, body, 'panming', status, 0, 'zhuangzi', created, started, completed))
        cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                    (tid, None, 'created', '{}', created))
        if started:
            cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                        (tid, None, 'claimed', '{}', started))
            cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                        (tid, None, 'spawned', '{}', started))
        if status == 'done':
            cur.execute('INSERT INTO task_events (task_id, run_id, kind, payload, created_at) VALUES (?,?,?,?,?)',
                        (tid, None, 'completed', '{}', completed))
            mkdirs(os.path.join(res_dir, f'{demo_id}.md'))
            with open(os.path.join(res_dir, f'{demo_id}.md'), 'w', encoding='utf-8') as f:
                f.write(f'# {title}\n\n（脱敏演示结果）\n\n数据来源：公开数据源（演示）。\n')
    con.commit()
    con.close()
    # 同步 presets.json（与 opc-api DEMO_TASKS 同构，bus 的 _load_demo_presets 据此解析 task_id；
    # 容器内 opc-api 未部署时也能自洽）
    presets = {
        'v2ex_hot': {'name': 'V2EX 热帖', 'prompt': '帮我收集一下 v2ex 十个热帖（标题+链接+热度）'},
        'gz_weather': {'name': '广州天气', 'prompt': '帮我查一下广州未来 15 天的天气（脱敏演示）'},
        'gz_trip': {'name': '广州周边旅行', 'prompt': '给我一个广州周边旅行的计划（2-3 天行程）（脱敏演示）'},
        'niulai_boxoffice': {'name': '牛来票房', 'prompt': '帮我看看《牛来》这个电影的实时票房（脱敏演示）'},
    }
    presets_path = os.path.join(OPC_DIR, 'demo', 'presets.json')
    if not os.path.exists(presets_path):
        mkdirs(presets_path)
        with open(presets_path, 'w', encoding='utf-8') as f:
            json.dump(presets, f, ensure_ascii=False, indent=2)
        print(f'[demo] presets.json 同步: {presets_path}')
    print(f'[demo] kanban-demo.db 生成: {DEMO_KANBAN_DB}（{len(seeds)} 任务 + 生命周期事件 + 结果文件）')


def _safe_home_write(desc, fn):
    """31c：宿主痕迹写入尽力而为——self 形态 bind 宿主 :ro 写不进时跳过不致命。"""
    try:
        fn()
    except OSError as e:
        print(f'[demo] 跳过 {desc}（宿主只读/不可写: {e}）', file=sys.stderr)


def main():
    # 31c：演示数据显式化——无 --demo 拒绝生成（首启默认欢迎态，不再自动 demo）
    if '--demo' not in sys.argv:
        print('[demo] 演示数据需显式 --demo 开关（31c：与初始化互斥，演示/测试用），跳过')
        return 0
    # 与初始化互斥：卷内已有 init-state.json（已初始化客户团队）→ 拒绝覆盖
    init_state = os.path.join(OPC_DIR, 'init-state.json')
    if os.path.exists(init_state):
        try:
            st = json.load(open(init_state, encoding='utf-8'))
            if st.get('status') == 'initialized':
                print(f'[demo] 拒绝：{init_state} 已初始化（{st.get("company", "?")}），'
                      f'演示数据与初始化互斥。如需演示请先清空数据卷或删除 init-state.json。')
                return 2
        except Exception:
            pass

    fresh = '--fresh' in sys.argv
    if fresh:
        for p in (KANBAN_DB, STATE_JSON, DEMO_KANBAN_DB):
            if p and os.path.exists(p):
                os.remove(p)
                print(f'[demo] 已删除旧数据: {p}')
    gen_kanban_db()
    gen_state_json()
    # 31c：宿主痕迹（profiles state.db / usage_audit / cron output / delegation）是
    # 演示用「尽力而为」——self 形态 bind 宿主 .hermes 只读（:ro）时写不进属正常，
    # 跳过不致命（卷内 kanban.db/state.json 已生成，透明办公室可正常展示）。
    # 卷内产物必须成功（上面两个 + demo board + init-state），失败仍由 set -e 兜住。
    _safe_home_write('profiles state.db 痕迹', gen_profile_state_db)
    _safe_home_write('usage_audit 痕迹', gen_usage_audit)
    _safe_home_write('cron output 痕迹', gen_cron_output)
    _safe_home_write('delegation 痕迹', gen_delegation)
    gen_demo_kanban_demo_board()
    # 31c：demo 也是「初始化」的一种（演示用）——写 init-state.json 标记 initialized，
    # 否则 customer 形态 entrypoint 会视为未初始化 → 欢迎态盖掉 demo。与 opc-init 互斥：
    # opc-init 重跑走已有产物覆盖确认+备份（31b 逻辑）。
    demo_init = {
        'status': 'initialized',
        'initialized_at': datetime.datetime.now().isoformat(),
        'template': 'demo',
        'company': 'Demo Team（OPC OS 演示实例）',
        'generated_by': 'gen-demo-data --demo',
    }
    init_path = os.path.join(OPC_DIR, 'init-state.json')
    if not os.path.exists(init_path):
        with open(init_path, 'w', encoding='utf-8') as f:
            json.dump(demo_init, f, ensure_ascii=False, indent=2)
        print(f'[demo] init-state.json 写入: {init_path}（status=initialized，演示用）')
    print('[demo] 完成：脱敏演示数据就绪（不包含任何真实业务数据）')


if __name__ == '__main__':
    sys.exit(main())   # 31d: 互斥拒绝 return 2 须 sys.exit 传播（脚本化调用区分拒绝/成功）
