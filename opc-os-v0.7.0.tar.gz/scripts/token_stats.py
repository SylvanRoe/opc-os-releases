#!/usr/bin/env python3
"""OPC OS — token-stats 数据管道 v2（per-profile 归因，参数化版）

聚合全部 AI 成员 token 消耗 + 成本 + kanban 产出/验收归因 → token-stats.json。

零本机硬编码：路径 / 成员名册 / 角色表全部从 config.json 读取（见 lib_config.py）。
换机器部署 = 改 config.json 的 paths + roster 即可，脚本本身不动。

数据源（全本地，不打任何外部 API，红线：不混入外部行情）：
  1. <hermes_home>/profiles/<p>/state.db sessions 表 —— 成员会话用量（成本唯一来源）
  2. 共享 state.db（profile_name IS NULL）—— default 桶（未归因会话）
  3. <hermes_home>/profiles/<p>/cron/usage_audit.jsonl —— cron 用量（无成本，只计 token）
  4. kanban.db —— 任务产出（done by assignee）/ 返工卡 / 验收卡流转

口径要点：
  - 会话不双计：per-profile 只用 profile 自己的 state.db；共享库只取 profile_name IS NULL 行。
  - tokens = 会话 token（input+output+cache_read+cache_write）+ cron audit token。
  - 成本 = sessions.estimated_cost_usd（无计价的 provider 成本为 0）。
  - 验收卡 = 标题含【验收】/[验收] 标记的卡；验收 FAIL = 该卡 task_events 有 blocked 事件
    且 reason 含 FAIL/缺陷/未过/未通过/不通过。
  - 返工卡 = status=done 且标题含「返工」、非验收卡、非「返工双轨」，按标题去重。

幂等：可重复跑，覆盖写 JSON（generated_at 除外）。
用法: python3 token_stats.py [--config <path>]
"""
import sqlite3
import json
import sys
import datetime
import os
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib_config import get_cfg

CFG = get_cfg()
P = CFG['paths']

# ---- 路径（config.json 驱动）----
HERMES_HOME = P['hermes_home']
PROFILES_DIR = os.path.join(HERMES_HOME, 'profiles')
SHARED_STATE_DB = P['state_db']
KANBAN_DB = P['kanban_db']
OUT_JSON = P['token_stats_out']
PUBLISH_COPY = P.get('publish_copy') or ''
DOC_PATH = P.get('doc_path') or ''
GENERATOR = 'token_stats.py v2 (OPC OS)'

# ---- 成员名册（config.json roster；可配，换团队改配置）----
PROFILE_ROSTER = collections.OrderedDict()
for pid, meta in (CFG.get('roster') or {}).items():
    if meta:
        PROFILE_ROSTER[pid] = {
            'name_zh': meta.get('name_zh', pid),
            'name_en': meta.get('name_en', pid),
            'role': meta.get('role', ''),
        }
if not PROFILE_ROSTER:
    # 兜底：由 name_id/name_en/roles 构建（兼容只配旧节的 config）
    name_en = CFG.get('name_en', {})
    roles = CFG.get('roles', {})
    for zh, pid in (CFG.get('name_id') or {}).items():
        PROFILE_ROSTER[pid] = {
            'name_zh': zh,
            'name_en': name_en.get(pid, pid),
            'role': roles.get(zh, ''),
        }

ROLE_EN = CFG.get('role_en', {})

# 本地时区（Asia/Shanghai，+08:00）
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo('Asia/Shanghai')
except Exception:
    TZ = datetime.timezone(datetime.timedelta(hours=8))


def local_today0_ts():
    """本地今日 00:00 的 unix 秒。"""
    now = datetime.datetime.now(TZ)
    return datetime.datetime(now.year, now.month, now.day, tzinfo=TZ).timestamp()


def parse_audit_ts(ts_str):
    """usage_audit 的 ts 形如 '2026-08-17T02:59:37.595Z'（UTC）→ unix 秒"""
    s = ts_str.strip()
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    return datetime.datetime.fromisoformat(s).timestamp()


def profile_state_db(profile):
    return os.path.join(PROFILES_DIR, profile, 'state.db')


def session_usage(db_path, t0, profile_filter=None):
    """单库 sessions 聚合。t0 为窗口起点（None 表示全量）。"""
    if not db_path or not os.path.exists(db_path):
        return dict(sessions=0, input=0, output=0, cache_read=0, cache_write=0, reasoning=0, cost=0.0)
    try:
        db = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=5)
    except Exception:
        return dict(sessions=0, input=0, output=0, cache_read=0, cache_write=0, reasoning=0, cost=0.0)
    where = ''
    args = ()
    if profile_filter == 'default':
        where = ' WHERE profile_name IS NULL'
    if t0 is not None:
        where += (' WHERE ' if not where else ' AND ') + ' started_at>=?'
        args = (t0,)
    try:
        r = db.execute(
            "SELECT COUNT(*),"
            " COALESCE(SUM(input_tokens),0), COALESCE(SUM(output_tokens),0),"
            " COALESCE(SUM(cache_read_tokens),0), COALESCE(SUM(cache_write_tokens),0),"
            " COALESCE(SUM(reasoning_tokens),0), COALESCE(SUM(estimated_cost_usd),0)"
            f" FROM sessions{where}", args).fetchone()
    except Exception:
        r = (0, 0, 0, 0, 0, 0, 0.0)
    db.close()
    return dict(sessions=int(r[0]), input=int(r[1]), output=int(r[2]),
                cache_read=int(r[3]), cache_write=int(r[4]), reasoning=int(r[5]),
                cost=float(r[6]))


def cron_usage(audit_path, t0):
    """单个 usage_audit.jsonl 聚合。t0 为窗口起点（None 表示全量）。返回 (runs, tokens)。"""
    runs = 0
    tokens = 0
    try:
        for line in open(audit_path):
            try:
                d = json.loads(line)
            except Exception:
                continue
            ts = d.get('ts')
            if ts:
                if t0 is not None and parse_audit_ts(ts) < t0:
                    continue
            elif t0 is not None:
                continue
            tokens += int(d.get('total_tokens') or 0)
            runs += 1
    except FileNotFoundError:
        pass
    return runs, tokens


def _payload_reason(payload):
    """blocked 事件 payload 是 JSON 字符串 → 取 reason 字段"""
    if isinstance(payload, dict):
        return str(payload.get('reason', ''))
    try:
        d = json.loads(payload)
        return str(d.get('reason', '')) if isinstance(d, dict) else ''
    except Exception:
        return ''


def kanban_attribution():
    """kanban.db 归因：产出任务数 / 验收卡 done / 返工卡（去重）/ 验收 FAIL 批次。"""
    REVIEW_PRED = "(title LIKE '%【验收】%' OR instr(title, '[验收]') > 0)"
    empty = dict(total_tasks=0, done_total=0, done_by={},
                 review_total=0, review_done_by={},
                 review_done=0, review_fail_batches=0, rework_by={})
    try:
        db = sqlite3.connect(KANBAN_DB)
    except Exception:
        return empty
    try:
        total_tasks = db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        done_total = db.execute("SELECT COUNT(*) FROM tasks WHERE status='done'").fetchone()[0]
        done_by = dict(db.execute(
            "SELECT assignee, COUNT(*) FROM tasks WHERE status='done' GROUP BY assignee").fetchall())
        review_done_by = dict(db.execute(
            f"SELECT assignee, COUNT(*) FROM tasks WHERE status='done' AND {REVIEW_PRED} GROUP BY assignee").fetchall())
        review_total = db.execute(f"SELECT COUNT(*) FROM tasks WHERE {REVIEW_PRED}").fetchone()[0]
        rework_by = collections.Counter()
        for title, assignee in db.execute(
                "SELECT DISTINCT title, assignee FROM tasks"
                " WHERE status='done' AND title LIKE '%返工%'"
                "   AND title NOT LIKE '%【验收】%' AND instr(title, '[验收]') = 0"
                "   AND title NOT LIKE '%返工双轨%'").fetchall():
            rework_by[assignee] += 1
        fail_kw = ('FAIL', '缺陷', '未过', '未通过', '不通过')
        review_cards = [r[0] for r in db.execute(
            f"SELECT id FROM tasks WHERE {REVIEW_PRED} AND status='done'").fetchall()]
        n_fail = 0
        for cid in review_cards:
            evs = db.execute(
                "SELECT payload FROM task_events WHERE task_id=? AND kind='blocked'", (cid,)).fetchall()
            joined = ' | '.join(_payload_reason(p) for (p,) in evs)
            if any(k in joined for k in fail_kw):
                n_fail += 1
    except Exception:
        return empty
    finally:
        db.close()
    return dict(total_tasks=total_tasks, done_total=done_total, done_by=done_by,
                review_total=review_total, review_done_by=review_done_by,
                review_done=len(review_cards), review_fail_batches=n_fail,
                rework_by=dict(rework_by))


def daily_series(days=30):
    """近 N 天日序列：token/成本/会话（本地日，+08:00）。"""
    today = datetime.datetime.now(TZ).date()
    start = datetime.datetime(today.year, today.month, today.day, tzinfo=TZ) - datetime.timedelta(days=days - 1)
    start_ts = start.timestamp()
    day = collections.defaultdict(lambda: {'tokens': 0, 'cost': 0.0, 'sessions': 0})

    start_str = start.strftime('%Y-%m-%d')
    session_dbs = [profile_state_db(p) for p in PROFILE_ROSTER]
    # 日序列与 total/today 口径一致：仅 OPC 成员，不含未归因 default 桶
    for dbp in session_dbs:
        if not dbp or not os.path.exists(dbp):
            continue
        try:
            db = sqlite3.connect(f'file:{dbp}?mode=ro', uri=True, timeout=5)
        except Exception:
            continue
        try:
            rows = db.execute(
                "SELECT strftime('%Y-%m-%d', started_at, 'unixepoch', '+8 hours'), COUNT(*),"
                " COALESCE(SUM(input_tokens),0), COALESCE(SUM(output_tokens),0),"
                " COALESCE(SUM(cache_read_tokens),0), COALESCE(SUM(cache_write_tokens),0),"
                " COALESCE(SUM(estimated_cost_usd),0)"
                " FROM sessions WHERE started_at>=? GROUP BY 1",
                (start_ts,)).fetchall()
        except Exception:
            rows = []
        db.close()
        for d, n, inp, outp, cr, cw, cost in rows:
            if d < start_str:
                continue
            day[d]['tokens'] += inp + outp + cr + cw
            day[d]['cost'] += cost
            day[d]['sessions'] += n

    for p in PROFILE_ROSTER:
        audit = os.path.join(PROFILES_DIR, p, 'cron', 'usage_audit.jsonl')
        if not os.path.exists(audit):
            continue
        try:
            for line in open(audit):
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                ts = d.get('ts')
                if not ts:
                    continue
                ts_unix = parse_audit_ts(ts)
                if ts_unix < start_ts:
                    continue
                dd = datetime.datetime.fromtimestamp(ts_unix, TZ).strftime('%Y-%m-%d')
                day[dd]['tokens'] += int(d.get('total_tokens') or 0)
        except FileNotFoundError:
            pass

    out = []
    for i in range(days):
        d = (start + datetime.timedelta(days=i)).strftime('%Y-%m-%d')
        v = day[d]
        out.append({'date': d, 'tokens': int(v['tokens']), 'cost_usd': round(v['cost'], 4),
                    'sessions': int(v['sessions'])})
    return out


def main():
    t0 = local_today0_ts()

    profiles = collections.OrderedDict()
    s_total_tok = s_total_cost = 0
    s_total_cnt = 0
    c_total_tok = c_total_runs = 0
    s_today_tok = s_today_cost = 0
    s_today_cnt = 0
    c_today_tok = c_today_runs = 0

    for p, meta in PROFILE_ROSTER.items():
        dbp = profile_state_db(p)
        s_all = session_usage(dbp, None)
        s_day = session_usage(dbp, t0)
        audit = os.path.join(PROFILES_DIR, p, 'cron', 'usage_audit.jsonl')
        c_all_runs, c_all_tok = cron_usage(audit, None)
        c_day_runs, c_day_tok = cron_usage(audit, t0)

        tok_all = s_all['input'] + s_all['output'] + s_all['cache_read'] + s_all['cache_write']
        tok_day = s_day['input'] + s_day['output'] + s_day['cache_read'] + s_day['cache_write']

        profiles[p] = {
            'name_zh': meta['name_zh'],
            'name_en': meta['name_en'],
            'role': meta['role'],
            'role_en': ROLE_EN.get(meta['role'], meta['role']),
            'member': True,
            'sessions': s_all['sessions'],
            'tokens': {
                'input': s_all['input'], 'output': s_all['output'],
                'cache_read': s_all['cache_read'], 'cache_write': s_all['cache_write'],
                'reasoning': s_all['reasoning'], 'total': tok_all,
            },
            'cost_usd': round(s_all['cost'], 4),
            'cron': {'runs': c_all_runs, 'tokens': c_all_tok},
        }
        s_total_tok += tok_all
        s_total_cost += s_all['cost']
        s_total_cnt += s_all['sessions']
        c_total_tok += c_all_tok
        c_total_runs += c_all_runs
        s_today_tok += tok_day
        s_today_cost += s_day['cost']
        s_today_cnt += s_day['sessions']
        c_today_tok += c_day_tok
        c_today_runs += c_day_runs

    # default 桶（共享库 NULL profile）—— 仅保留审计，不参与 total/today 聚合
    d_all = session_usage(SHARED_STATE_DB, None, profile_filter='default')
    d_day = session_usage(SHARED_STATE_DB, t0, profile_filter='default')
    tok_all_d = d_all['input'] + d_all['output'] + d_all['cache_read'] + d_all['cache_write']
    tok_day_d = d_day['input'] + d_day['output'] + d_day['cache_read'] + d_day['cache_write']
    profiles['_default'] = {
        'name_zh': '（未归因）', 'name_en': 'default', 'role': '主 profile / 未归因会话',
        'role_en': 'Main profile / unattributed sessions',
        'member': False,
        'sessions': d_all['sessions'],
        'tokens': {
            'input': d_all['input'], 'output': d_all['output'],
            'cache_read': d_all['cache_read'], 'cache_write': d_all['cache_write'],
            'reasoning': d_all['reasoning'], 'total': tok_all_d,
        },
        'cost_usd': round(d_all['cost'], 4),
        'cron': {'runs': 0, 'tokens': 0},
        'today': {
            'sessions': d_day['sessions'],
            'tokens': tok_day_d,
            'cost_usd': round(d_day['cost'], 4),
        },
    }
    # 口径：total / today 仅统计 OPC 成员（member=true），未归因会话不纳入官网展示口径

    # ---- kanban 归因 ----
    k = kanban_attribution()
    for p in PROFILE_ROSTER:
        done = k['done_by'].get(p, 0)
        review_done = k['review_done_by'].get(p, 0)
        tasks_done = done - review_done
        rework = k['rework_by'].get(p, 0)
        pass_rate = None
        if tasks_done > 0:
            pass_rate = round(1 - rework / tasks_done, 4)
        profiles[p]['kanban'] = {
            'done_total': done,
            'tasks_done': tasks_done,
            'review_done': review_done,
            'rework_done': rework,
            'pass_rate': pass_rate,
        }

    review_pass_rate = None
    if k['review_done'] > 0:
        review_pass_rate = round(1 - k['review_fail_batches'] / k['review_done'], 4)
    kanban = {
        'total_tasks': k['total_tasks'],
        'done': k['done_total'],
        'review_cards_total': k['review_total'],
        'review_cards_done': k['review_done'],
        'review_fail_batches': k['review_fail_batches'],
        'acceptance_pass_rate': review_pass_rate,
        'rework_done_total': sum(k['rework_by'].values()),
        'source': '<data-volume>/kanban.db',   # 相对描述，不暴露部署机器绝对路径
    }

    # ---- 输出 ----
    out = {
        'generated_at': datetime.datetime.now(TZ).isoformat(timespec='seconds'),
        'today': {
            'tokens': int(s_today_tok + c_today_tok),
            'cost_usd': round(s_today_cost, 2),
            'sessions': int(s_today_cnt),
            'cron_runs': int(c_today_runs),
        },
        'total': {
            'tokens': int(s_total_tok + c_total_tok),
            'cost_usd': round(s_total_cost, 2),
            'sessions': int(s_total_cnt),
            'cron_runs': int(c_total_runs),
        },
        'profiles': profiles,
        'kanban': kanban,
        'series_daily': daily_series(30),
        'note': {
            'total_tokens_scope': '仅 OPC 成员（member=true），不含未归因的 _default 主 profile 会话',
            'today_tokens_scope': '仅 OPC 成员当天 00:00 Asia/Shanghai 之后的 sessions + cron usage_audit',
            'default_bucket': '保留在 profiles._default 供审计，不参与 total/today/series_daily 聚合',
            'effective_members': [p for p in profiles if profiles[p].get('member')],
        },
        'attribution': {
            'generator': GENERATOR,
            'sources': [
                '<profiles>/state.db sessions',
                '<hermes_home>/state.db (profile_name IS NULL)',
                '<profiles>/cron/usage_audit.jsonl',
                '<data-volume>/kanban.db',
            ],
            'red_line': '仅团队内部数据；外部行情不混入 per-profile 归因',
            'doc': DOC_PATH,
        },
    }

    os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
    with open(OUT_JSON, 'w') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
        f.write('\n')
    print(json.dumps({'generated_at': out['generated_at'], 'today': out['today'], 'total': out['total']},
                     ensure_ascii=False))

    # ---- 同步发布副本（可空 = 不复制）----
    if PUBLISH_COPY:
        try:
            os.makedirs(os.path.dirname(PUBLISH_COPY), exist_ok=True)
            with open(OUT_JSON, encoding='utf-8') as src_f, \
                    open(PUBLISH_COPY, 'w', encoding='utf-8') as dst_f:
                dst_f.write(src_f.read())
            print(f'副本已同步: {PUBLISH_COPY}')
        except Exception as e:
            print(f'警告: 发布副本同步失败 ({e})，请手动 cp {OUT_JSON} → {PUBLISH_COPY}', file=sys.stderr)


if __name__ == '__main__':
    main()
