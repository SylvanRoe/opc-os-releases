#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
opc-os bump_version.py — 发布纪律落地工具（版本制度 v2.0 §3 发布流程 · T3 交付）

一次命令完成一次合规发版，顺序严格遵守 asset-versioning.md §8.3 铁律：
  ① 前置门（smoke + doctor，PASS 才继续）→ ② 三源一致校验 → ③ CHANGELOG 条目
  → ④ VERSION 常量 → ⑤ annotated git tag → ⑥ 提示 push（或 --push 自动）。

用法：
  python3 scripts/bump_version.py --patch  -m "修复 xxx"
  python3 scripts/bump_version.py --minor  -m "新增 xxx" --type Added --compat "原地增量升级"
  python3 scripts/bump_version.py --major  -m "破坏性重构" --type Breaking --compat "需迁移流程"
  python3 scripts/bump_version.py --patch  -m "..." --dry-run          # 只打印动作不落盘
  python3 scripts/bump_version.py --patch  -m "..." --push             # 打 tag 后自动 push
  python3 scripts/bump_version.py --patch  -m "..." --no-gates         # 跳过 smoke/doctor（仅紧急）
  python3 scripts/bump_version.py --patch  -m "..." --gate-cmd "bash /tmp/ok.sh"

版本号（§1）：semver vX.Y.Z，0.x 阶段 MAJOR 位锁定为 0（§1.3），破坏性走 --minor。
幂等（红线）：同一版本 tag 已存在 / CHANGELOG 已有条目 → 拒绝，不覆盖不重建。

红灯：本工具默认在**生产仓真实落盘**（改 CHANGELOG/VERSION/文档头标 + commit + tag）。
  dry-run 请用 --dry-run；要自动推送远端才加 --push（默认只打本地 tag 并提示 push）。
  生产仓绝不产生假 tag —— 单元测试/演练请在临时 git 仓（--repo / --gate-cmd 自定）。
"""

import argparse
import datetime
import json
import os
import re
import shlex
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import check_version as cv  # noqa: E402

SEMVER_RE = re.compile(r"^v?([0-9]+)\.([0-9]+)\.([0-9]+)$")
CARD_RE = re.compile(r"^##\s*\[v([0-9]+\.[0-9]+\.[0-9]+)\]\s*")
UNREL_RE = re.compile(r"^##\s*\[Unreleased\]\s*$")

# 文档头标联动（§2.3 文档并入代码版本：头标「适用版本：vX.Y.Z」）
DOCS = [
    {"path": "docs/installation-guide.md", "lang": "zh"},
    {"path": "delivery-checklist.md",     "lang": "zh"},
    {"path": "README.md",                 "lang": "en"},
    {"path": "README_CN.md",              "lang": "zh"},
]
# 头部版本行匹配（仅文件头 25 行内，避免误伤正文）
HEAD_LINE_RE = re.compile(r"^(?P<pre>>\s*)(?P<label>版本|适用版本|Applies to)(?P<colon>\s*[:：]\s*)(?P<ver>v?\d+(?:\.\d+)+)")
HEAD_BOUND = 25

TYPE_DEFAULTS = {"patch": "Fixed", "minor": "Added", "major": "Breaking"}
COMPAT_DEFAULTS = {"patch": "无", "minor": "原地增量升级", "major": "需迁移流程"}
IMPACT_DEFAULT = "opc-os 服务/脚本、docs/installation-guide.md、delivery-checklist.md、README"


class BumpError(Exception):
    """发布流程中止，携带人类可读原因。"""


def _find_repo(repo_arg):
    if repo_arg:
        cand = os.path.abspath(repo_arg)
        if os.path.isdir(os.path.join(cand, ".git")):
            return cand
        raise BumpError(f"--repo 指向非 git 仓库: {cand}")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    d = os.path.dirname(script_dir)
    if os.path.isdir(os.path.join(d, ".git")):
        return d
    if os.path.isdir(os.path.join(os.getcwd(), ".git")):
        return os.getcwd()
    raise BumpError("未定位 git 仓库（脚本须位于 <repo>/scripts/ 或 --repo 指定）")


def _git(repo, *args, check=True):
    p = subprocess.run(["git", "-C", repo] + list(args),
                       capture_output=True, text=True, timeout=30)
    if check and p.returncode != 0:
        raise BumpError(f"git {' '.join(args)} 失败: {p.stderr.strip() or p.stdout.strip()}")
    return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()


def current_version(repo):
    vf = os.path.join(repo, "VERSION")
    if not os.path.isfile(vf):
        raise BumpError(f"VERSION 文件不存在: {vf}（版本单一来源，见 §2.1）")
    with open(vf, encoding="utf-8") as f:
        v = f.read().strip()
    if not SEMVER_RE.match(v):
        raise BumpError(f"VERSION 非法（须 vX.Y.Z 三段）: {v!r}")
    return v


def next_version(cur, kind):
    m = SEMVER_RE.match(cur)
    maj, minr, pat = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if kind == "patch":
        return f"{maj}.{minr}.{pat + 1}"
    if kind == "minor":
        return f"{maj}.{minr + 1}.0"
    # major
    if maj == 0:
        raise BumpError("0.x 阶段 MAJOR 位锁定为 0（§1.3）：破坏性变更请走 --minor，或用 --major 前先确认")
    return f"{maj + 1}.0.0"


def _run_gates(repo, gate_cmds):
    """前置门：顺序执行 gate 命令，任一非零 → 中止。"""
    if not gate_cmds:
        return
    for cmd in gate_cmds:
        print(f"  [gate] {cmd}")
        p = subprocess.run(cmd, shell=True, cwd=repo,
                           capture_output=True, text=True, timeout=600)
        if p.returncode != 0:
            tail = "\n".join((p.stdout or "").strip().splitlines()[-6:])
            if not tail:
                tail = "\n".join((p.stderr or "").strip().splitlines()[-6:])
            raise BumpError(
                f"前置门 FAIL（exit={p.returncode}）：{cmd}\n"
                f"--- 输出尾部 ---\n{tail}\n"
                "发布中止：未过 smoke/doctor 不发版（§8.1），修复后重跑。")


def _gen_changelog_entry(ver, version_type, summary, impact, compat, source_card):
    date = datetime.date.today().isoformat()
    src = f"（来源卡号：{source_card}）" if source_card else ""
    lines = [
        "",
        f"## [v{ver}] - {date}",
        f"### {version_type}",
        f"- {summary}{src}",
        "### 影响面",
        f"- {impact}",
        "### 兼容性说明",
        f"- {compat}",
    ]
    return "\n".join(lines)


def _update_doc_headers(repo, new_ver):
    """联动更新 4 个文档头部版本行（§2.3）。返回更新文件列表。"""
    changed = []
    tag = f"v{new_ver}"
    for doc in DOCS:
        p = os.path.join(repo, doc["path"])
        if not os.path.isfile(p):
            continue
        with open(p, encoding="utf-8") as f:
            raw = f.read()
        lines = raw.splitlines()
        hit = False
        for i in range(min(HEAD_BOUND, len(lines))):
            m = HEAD_LINE_RE.match(lines[i])
            if m is None:
                continue
            label = m.group("label")
            # 统一头标：中文「适用版本：vX.Y.Z」，英文「Applies to: vX.Y.Z」。
            # 用 re.sub 只替换标签+版本号段，保留 ver 之后的说明文字（如「（客户形态…）」）。
            if doc["lang"] == "en" or label == "Applies to":
                lines[i] = HEAD_LINE_RE.sub(lambda mo: f"{mo.group('pre')}Applies to: {tag}", lines[i])
            else:
                lines[i] = HEAD_LINE_RE.sub(lambda mo: f"{mo.group('pre')}适用版本：{tag}", lines[i])
            hit = True
            break
        if hit:
            new_raw = "\n".join(lines)
            if new_raw != raw:
                with open(p, "w", encoding="utf-8") as f:
                    f.write(new_raw)
                changed.append(doc["path"])
    return changed


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="opc-os 合规发版工具（VERSION 单一来源 + CHANGELOG 条目 + annotated tag，三源一次同步）",
        epilog="顺序：前置门 smoke/doctor → 三源一致 → CHANGELOG 条目 → VERSION 常量 → git tag → push（--push）。",
    )
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--patch", action="store_true", help="补丁版（+1 PATCH，客户动作=无）")
    g.add_argument("--minor", action="store_true", help="次版本（+1 MINOR，客户动作=原地增量升级）")
    g.add_argument("--major", action="store_true", help="主版本（+1 MAJOR，客户动作=需迁移流程；0.x 阶段被拒，走 --minor）")
    ap.add_argument("-m", "--message", required=True, help="变更摘要（一句话可判定，写入 CHANGELOG 条目）")
    ap.add_argument("--type", choices=["Added", "Fixed", "Changed", "Breaking"],
                    help="CHANGELOG 条目类型（默认：patch→Fixed / minor→Added / major→Breaking）")
    ap.add_argument("--impact", default=IMPACT_DEFAULT, help="影响面（受影响组件/仓库/文档），默认自动推断")
    ap.add_argument("--compat", help="客户升级动作（无 / 原地增量升级 / 需迁移流程），默认按 bump 类型推测")
    ap.add_argument("--source-card", default=None, help="来源卡号（如 t_xxxx / G-YYYY-MM-DD-NNN），可选")
    ap.add_argument("--no-gates", action="store_true", help="跳过 smoke/doctor 前置门（仅紧急/离线用，会打印 WARN）")
    ap.add_argument("--gate-cmd", action="append", default=[], metavar="CMD",
                    help="自定义前置门命令（可多次；默认 scripts/smoke_test.sh + scripts/opc-os-doctor.py）")
    ap.add_argument("--dry-run", action="store_true", help="只打印将执行的动作，不落盘不改 git")
    ap.add_argument("--push", action="store_true", help="打 tag 后自动 push tag + 分支（默认只打本地 tag 并提示 push）")
    ap.add_argument("--no-docs", action="store_true", help="跳过 4 个文档头标版本联动更新")
    ap.add_argument("--no-commit", action="store_true", help="改动文件不自动 commit（默认自动 commit + 打 tag）")
    ap.add_argument("--repo", default=None, help="仓库根路径（默认脚本位置上溯 / cwd）")
    args = ap.parse_args(argv)

    kind = "patch" if args.patch else ("minor" if args.minor else "major")

    try:
        repo = _find_repo(args.repo)
        cur = current_version(repo)
        new = next_version(cur, kind)
        vtype = args.type or TYPE_DEFAULTS[kind]
        compat = args.compat or COMPAT_DEFAULTS[kind]
        impact = args.impact
        tag = f"v{new}"

        print(f"仓库: {repo}")
        print(f"当前版本: {cur}  →  目标版本: {new}  ({kind.upper()}, 类型 {vtype})")

        # ① 幂等（红线）：目标版本 tag 已存在 / CHANGELOG 已有条目 → 拒绝，不覆盖不重建。
        #    先于前置门/三源校验，避免对"已在历史"的目标版本浪费 gate 且报漂移而非幂等。
        code, tags, _ = _git(repo, "tag", "--list", tag, check=False)
        if code == 0 and tags:
            raise BumpError(f"tag {tag} 已存在，拒绝覆盖（幂等红线）。目标版本已在历史，请改用更高版本。")
        if _changelog_has_version(repo, new):
            raise BumpError(f"CHANGELOG 已有 [v{new}] 条目，拒绝重建（幂等红线）。目标版本已在历史，请改用更高版本。")

        # ② 前置门 smoke/doctor（§3.1 步骤 4 / §8.1：未过不发版）
        if not args.no_gates:
            gates = args.gate_cmd or [
                "bash scripts/smoke_test.sh",
                "python3 scripts/opc-os-doctor.py",
            ]
            print("[前置门] 运行 smoke + doctor ...")
            _run_gates(repo, gates)
        else:
            print("[前置门] ⚠ --no-gates 跳过 smoke/doctor（仅供紧急/离线，正常发版不得跳过）")

        # ③ 三源当前一致性（§2.2 / §6.2：不一致禁止发版）
        r = cv.check_three_source(repo=repo)
        if not r["consistent"]:
            raise BumpError(
                "三源不一致，禁止发版（先治理，§2.2/§7）：\n" + cv.human_report(r))
        print("[三源] 当前一致 ✓ " + " == ".join(str(s["value"]) for s in r["sources"]))

        entry = _gen_changelog_entry(new, vtype, args.message, impact, compat, args.source_card)
        actions = [
            ("CHANGELOG 条目", f"插入 [Unreleased] 之下 → [v{new}]"),
            ("VERSION 常量", f"{cur} → {new}"),
        ]
        doc_files = [] if args.no_docs else [d["path"] for d in DOCS if os.path.isfile(os.path.join(repo, d["path"]))]
        if doc_files and not args.no_docs:
            actions.append(("文档头标联动", ", ".join(doc_files)))
        actions.append(("git commit", f"release(opc-os): v{new} <摘要>（兼容：{compat}）"))
        actions.append(("git tag", f"-a {tag}"))
        actions.append(("push" if args.push else "提示 push", f"git push origin {tag}" + ("" if args.push else "  # 未 --push 请确认后手动")))

        if args.dry_run:
            print("\n[dry-run] 将执行以下动作（不落盘、不改 git）：")
            for name, desc in actions:
                print(f"  · {name}: {desc}")
            print(f"\n[dry-run] 完整 CHANGELOG 条目：\n{entry}")
            return 0

        # ③ CHANGELOG 条目（先条目）
        _write_changelog(repo, entry)
        print(f"[CHANGELOG] 已插入 [v{new}] 条目")

        # ④ VERSION 常量（后常量）
        with open(os.path.join(repo, "VERSION"), "w", encoding="utf-8") as f:
            f.write(new + "\n")
        print(f"[VERSION] {cur} → {new}")

        # 文档头标联动
        if not args.no_docs:
            changed = _update_doc_headers(repo, new)
            if changed:
                print(f"[文档头标] 已同步: {', '.join(changed)}")

        # ⑤ commit → ⑥ tag → push
        if args.no_commit:
            print("[commit] ⚠ --no-commit：改动已落盘未提交，请手动 commit 后打 tag")
            return 0
        _git(repo, "add", "-A")
        cm = f"release(opc-os): v{new} - {args.message}（兼容：{compat}）"
        _git(repo, "commit", "-m", cm)
        print(f"[commit] {cm}")
        _git(repo, "tag", "-a", tag, "-m", f"{tag}: {args.message}（兼容：{compat}）")
        print(f"[tag] {tag}（annotated）")

        # 三源自检：新版本三源应一致
        r2 = cv.check_three_source(repo=repo, check=new)
        print("[三源自检] " + ("一致 ✓" if r2["consistent"] else "⚠ 异常 " + json.dumps(r2["sources"], ensure_ascii=False)))

        if args.push:
            _git(repo, "push", "origin", tag)
            cur_branch = _git(repo, "rev-parse", "--abbrev-ref", "HEAD")[1]
            if cur_branch and cur_branch != "HEAD":
                _git(repo, "push", "origin", cur_branch)
            print(f"[push] origin/{tag}" + (f" + origin/{cur_branch}" if cur_branch and cur_branch != "HEAD" else ""))
        else:
            print(f"\n[提示] 已打本地 tag {tag}，未 push。确认无误后执行：")
            print(f"  git push origin {tag}")
            cur_branch = _git(repo, "rev-parse", "--abbrev-ref", "HEAD")[1]
            if cur_branch and cur_branch != "HEAD":
                print(f"  git push origin {cur_branch}")
        return 0

    except BumpError as e:
        print(f"\n❌ 发布中止：{e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n中断。", file=sys.stderr)
        return 130


def _changelog_has_version(repo, ver):
    """CHANGELOG 是否已存在 [vver] 条目标题。"""
    cl = os.path.join(repo, "CHANGELOG.md")
    if not os.path.isfile(cl):
        return False
    with open(cl, encoding="utf-8") as f:
        for line in f:
            m = CARD_RE.match(line)
            if m and m.group(1) == ver:
                return True
    return False


def _write_changelog(repo, entry_text):
    cl = os.path.join(repo, "CHANGELOG.md")
    with open(cl, encoding="utf-8") as f:
        text = f.read()
    lines = text.splitlines()
    unrel_idx = None
    first_release_idx = None
    for i, ln in enumerate(lines):
        if unrel_idx is None and UNREL_RE.match(ln):
            unrel_idx = i
        elif unrel_idx is not None and CARD_RE.match(ln):
            first_release_idx = i
            break
    if unrel_idx is None:
        raise BumpError("CHANGELOG 缺少 [Unreleased] 段（§3.2 规范）")
    if first_release_idx is None:
        first_release_idx = len(lines)
    entry_lines = entry_text.splitlines()
    # 去掉条目首空行（插入点已在段尾有换行）
    while entry_lines and entry_lines[0].strip() == "":
        entry_lines.pop(0)
    newlines = lines[:first_release_idx] + entry_lines + lines[first_release_idx:]
    with open(cl, "w", encoding="utf-8") as f:
        f.write("\n".join(newlines) + "\n")


if __name__ == "__main__":
    sys.exit(main())
