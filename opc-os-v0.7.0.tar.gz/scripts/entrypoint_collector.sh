#!/bin/bash
# OPC OS — collector 容器入口
# 流程（31c 双形态）：
#   self（默认，OPC 官网线上）：bind 宿主 .hermes → 卷空时生成 demo 数据 → 首跑采集+token 归因 → crond 守护
#   customer：profiles 卷内自持 → 首启检测 /data/init-state.json：
#     - 无该文件 = 未初始化 → 生成欢迎态（status.json 标记 uninitialized，透明办公室显示引导页，非软件 demo）
#     - 有且 initialized → 正常采集（collector 读卷内 profiles / 卷内 config）
# 守护红线：容器内 crond 常驻（busybox），采集失败输出到日志供 docker logs 排查
set -e

DATA_DIR=/data
CRON_SCHED="*/1 * * * *"
MODE="${OPC_OS_MODE:-self}"

echo "[opc-os] collector 启动 $(date -Is) (mode=$MODE)"

# 0. 配置来源：customer 形态已初始化 → 读卷内 init 生成的 config（客户团队 profiles/全卷内 paths）；
#    否则用镜像内置 config（self 形态 bind 宿主 / 欢迎态占位）。
CONFIG_FILE=/app/config/config.json
if [ "$MODE" = "customer" ] && [ -f "$DATA_DIR/config/config.json" ]; then
  CONFIG_FILE="$DATA_DIR/config/config.json"
  echo "[opc-os] 使用卷内客户 config: $CONFIG_FILE"
fi

# 1. 首启检测
#    self：卷空 → 生成脱敏 demo 数据（红线：demo 全虚构；31c 起 gen_demo_data 需显式 --demo 开关）
#    customer：无 init-state.json → 欢迎态（不生成 demo）；有且 initialized → 正常采集
if [ "$MODE" = "customer" ]; then
  if [ -f "$DATA_DIR/init-state.json" ]; then
    INIT_STATUS=$(python3 -c "import json;print(json.load(open('$DATA_DIR/init-state.json')).get('status',''))" 2>/dev/null || echo "")
    if [ "$INIT_STATUS" = "initialized" ]; then
      echo "[opc-os] customer 已初始化 → 正常采集（collector 读卷内 profiles）"
    else
      echo "[opc-os] customer init-state.json 状态异常（$INIT_STATUS）→ 生成欢迎态"
      python3 /app/scripts/gen_welcome_state.py
      INIT_STATUS="welcome"
    fi
  else
    echo "[opc-os] customer 未初始化（无 init-state.json）→ 生成欢迎态（透明办公室显示引导页，非软件 demo）"
    python3 /app/scripts/gen_welcome_state.py
    INIT_STATUS="welcome"
  fi

  if [ "$INIT_STATUS" = "welcome" ]; then
    # 欢迎态：等待初始化（docker compose run --rm init 生成 init-state.json 后重启容器生效）。
    # 31c 修复边界：init-state.json 存在但 status≠initialized（损坏/中断）时也必须等待——
    # 否则 while [ ! -f ] 立即退出 → docker restart 无限重启循环。
    echo "[opc-os] 欢迎态守护中，等待初始化（docker compose run --rm init --template <行业> --name <公司名>）..."
    while true; do
      if [ -f "$DATA_DIR/init-state.json" ]; then
        S=$(python3 -c "import json;print(json.load(open('$DATA_DIR/init-state.json')).get('status',''))" 2>/dev/null || echo "")
        if [ "$S" = "initialized" ]; then
          echo "[opc-os] init-state.json 已 initialized，容器重启后进入正常采集"
          exit 0   # 退出 → docker restart 策略拉起 → 重新走 entrypoint → 正常采集
        fi
        echo "[opc-os] init-state.json 存在但状态=${S:-空}，继续等待（重跑 init 修复）..."
      fi
      sleep 30
    done
  fi
else
  # self 形态：现状不变（卷空 → demo；有数据 → 跳过）
  if [ ! -f "$DATA_DIR/kanban.db" ] && [ ! -f "$DATA_DIR/state.json" ]; then
    echo "[opc-os] 数据卷为空 → 生成脱敏 demo 数据"
    python3 /app/scripts/gen_demo_data.py --fresh --demo
  else
    echo "[opc-os] 数据卷已有数据，跳过 demo 初始化（真实/既有数据模式）"
  fi
fi

# 2. 首跑采集 + token 归因（生成 status.json / token-stats.json 供 web 读取）
python3 /app/scripts/opc_collect.py && echo "[opc-os] status.json 首跑完成" || echo "[opc-os] ⚠️ opc_collect.py 首跑失败（重试将由 cron 兜底）"
python3 /app/scripts/token_stats.py >/dev/null && echo "[opc-os] token-stats.json 首跑完成" || echo "[opc-os] ⚠️ token_stats.py 首跑失败（重试将由 cron 兜底）"
# [0825-e] LLM 网关透明度数据同步（self 形态读 bind 宿主 llm-gateway 产物；customer 形态无 → available=false 空态）
python3 /app/scripts/llm_gateway_sync.py --src /data/hermes-home/opc/llm-gateway --out /data/llm-gateway.json \
  && echo "[opc-os] llm-gateway.json 首跑完成" || echo "[opc-os] ⚠️ llm_gateway_sync.py 首跑失败（重试将由 cron 兜底）"

# 3. crond 守护：每 1 分钟增量采集（与宿主 1min collector cron 对齐；opc_collect.py 成功静默；token_stats 输出重定向到日志）
mkdir -p /var/log/opcos
{
  echo "# OPC OS collector cron"
  # 注意：alpine python3 在 /usr/bin，cron 环境 PATH=/usr/bin:/bin，直接写 python3
  echo "$CRON_SCHED cd /app && OPC_OS_CONFIG=$CONFIG_FILE python3 /app/scripts/opc_collect.py >> /var/log/opcos/collect.log 2>&1; OPC_OS_CONFIG=$CONFIG_FILE python3 /app/scripts/token_stats.py >> /var/log/opcos/tokenstats.log 2>&1"
  # [0825-e] LLM 网关透明度同步：每 5 分钟把宿主 llm-gateway 产物合入 /data/llm-gateway.json
  echo "*/5 * * * * OPC_OS_CONFIG=$CONFIG_FILE python3 /app/scripts/llm_gateway_sync.py --src /data/hermes-home/opc/llm-gateway --out /data/llm-gateway.json >> /var/log/opcos/llm-gateway-sync.log 2>&1"
} | crontab -

# 3.5. 启动数据总线守护（27e：bus 并入 collector 容器，Gavin 拍板 #3）
#     opc-bus.py 1s 增量轮询 kanban.db task_events（水位线）→ 秒级刷新 status.json kanban 段，
#     复用 /app/scripts/opc_collect.py 的 collect_kanban（human_waiting 口径唯一实现）。
#     容器内守护 = 现有 busybox crond 等效应（红线「容器内 pm2 或等效」）；
#     bus 挂由「容器退出 + docker restart 策略」拉起，bus-state.json 水位线持久化 → 重启不重放。
echo "[opc-os] opc-bus 启动（1s 轮询 kanban.db → status.json kanban 段）"
OPC_OS_CONFIG=$CONFIG_FILE python3 /app/scripts/opc-bus.py >> /var/log/opcos/bus.log 2>&1 &
BUS_PID=$!

# 4. 以 root 跑 crond 前台（容器主进程；alpine busybox crond 需 -f 前台）
echo "[opc-os] crond 启动，采集计划: $CRON_SCHED"
crond -f -l 2 &
CROND_PID=$!

# 兜底保活：任一守护（crond / opc-bus）意外退出则容器退出（交给 docker restart 策略拉起）
echo "[opc-os] 双守护就绪: crond=$CROND_PID opc-bus=$BUS_PID"
while true; do
  kill -0 "$CROND_PID" 2>/dev/null || { echo "[opc-os] crond 退出 (pid $CROND_PID)，容器退出"; exit 1; }
  kill -0 "$BUS_PID" 2>/dev/null || { echo "[opc-os] opc-bus 退出 (pid $BUS_PID)，容器退出"; exit 1; }
  sleep 5
done
