#!/usr/bin/env python3
"""opc-govern 规则引擎验收测试（gov-3 自验，独立拷贝库，不碰正式板）。

场景对照卡片「验收（蔡婉）」：
1. 模拟验收 FAIL → ≤30s 自动生成修复卡(make)+复验卡(ada, parents=[修复卡])，验收卡仍 blocked
2. 模拟复验通过 → 复验卡 done → 父验收卡自动 done + 事件留痕
3. 防误伤：普通 blocked(needs_input) 卡不被自动收口/派修；G 卡不受影响
4. 幂等：同 FAIL 批次不重复派卡；重启后水位线不重放
5. legacy：庄子手工建的复验链（i18n-d 真实数据）也能收口
"""
import json
import os
import shutil
import sqlite3
import sys
import time

WS = os.path.dirname(os.path.abspath(__file__))
REAL_DB = '/home/gavin/.hermes/kanban/boards/opc/kanban.db'
TEST_DB = os.path.join(WS, 'test-kanban.db')
TEST_STATE = os.path.join(WS, 'test-govern-state.json')

# 必须在 import 前设置环境（模块级 CFG）
os.environ['OPC_GOVERN_KANBAN_DB'] = TEST_DB
os.environ['OPC_GOVERN_STATE_FILE'] = TEST_STATE
os.environ['OPC_GOVERN_POLL_SECONDS'] = '0.5'
os.environ['OPC_GOVERN_SCAN_SECONDS'] = '15'

sys.path.insert(0, WS)
import importlib.util
_spec = importlib.util.spec_from_file_location('opc_govern', os.path.join(WS, 'opc-govern.py'))
gov = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(gov)

PASS = 0
FAIL = 0


def check(name, cond, extra=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f'  ✅ {name}')
    else:
        FAIL += 1
        print(f'  ❌ {name} {extra}')


def reset_db():
    """一致性快照拷贝（sqlite3.backup 含 WAL 内容；shutil.copy 在活动 WAL 库上会得到损坏快照）。"""
    if os.path.exists(TEST_DB):
        os.remove(TEST_DB)
    src = sqlite3.connect(REAL_DB)
    try:
        dst = sqlite3.connect(TEST_DB)
        try:
            with dst:
                src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    for f in (TEST_STATE, TEST_STATE + '.govern-tmp'):
        if os.path.exists(f):
            os.remove(f)
    gov._invalidate_tk_cache()  # gov-7c：reset 后 task_kind 合并缓存须失效（防旧库映射残留）


def ro(db=TEST_DB):
    con = sqlite3.connect(f'file:{db}?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    return con


def get_task(db, tid):
    con = ro(db)
    try:
        r = con.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone()
        return dict(r) if r else None
    finally:
        con.close()


def events_of(db, tid):
    con = ro(db)
    try:
        return [dict(r) for r in con.execute(
            'SELECT id, kind, payload FROM task_events WHERE task_id=? ORDER BY id', (tid,))]
    finally:
        con.close()


def block_card(db, tid, reason, kind='needs_input', source_status='running'):
    """模拟 kanban_block(needs_input, reason) 的 SQL 等价。"""
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute('BEGIN IMMEDIATE')
        con.execute(
            "UPDATE tasks SET status='blocked', claim_lock=NULL, claim_expires=NULL, "
            "worker_pid=NULL, block_kind=?, block_recurrences=1 WHERE id=? "
            "AND status IN ('running','ready')", (kind, tid))
        con.execute(
            "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
            "VALUES (?, NULL, 'blocked', ?, ?)",
            (tid, json.dumps({'reason': reason, 'kind': kind,
                              'recurrences': 1, 'source_status': source_status},
                             ensure_ascii=False), int(time.time())))
        con.commit()
    finally:
        con.close()


def complete_card(db, tid, summary):
    """模拟 kanban_complete(summary) 的 SQL 等价。"""
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute('BEGIN IMMEDIATE')
        con.execute(
            "UPDATE tasks SET status='done', result=?, completed_at=?, claim_lock=NULL, "
            "claim_expires=NULL, worker_pid=NULL, block_kind=NULL, block_recurrences=0 "
            "WHERE id=? AND status IN ('running','ready','blocked','review')",
            (summary, int(time.time()), tid))
        con.execute(
            "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
            "VALUES (?, NULL, 'completed', ?, ?)",
            (tid, json.dumps({'result_len': 0, 'summary': summary}, ensure_ascii=False),
             int(time.time())))
        con.commit()
    finally:
        con.close()


def fresh_state():
    return {'watermark': 0, 'processed_blocks': set(), 'closed_reviews': set(), 'chains': {}}


def make_review_card(db, title='【0823-govtest】【验收】端到端验收（测试）', assignee='ada',
                     body=None):
    """模拟蔡婉验收卡（kanban_create 等价 SQL + created 事件）。返回卡 id。"""
    if body is None:
        body = '【验收 · 只读不改代码】测试验收清单。'
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute('BEGIN IMMEDIATE')
        tid = 't_' + os.urandom(4).hex()
        con.execute(
            "INSERT INTO tasks (id, title, body, assignee, status, priority, created_by, "
            "created_at, workspace_kind, workspace_path, branch_name, project_id, tenant, "
            "idempotency_key, max_runtime_seconds, skills, max_retries, model_override, "
            "provider_override, reasoning_effort, goal_mode, goal_max_turns, session_id) "
            "VALUES (?, ?, ?, ?, 'ready', 0, 'worker', ?, 'scratch', NULL, NULL, NULL, NULL, "
            "NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL)",
            (tid, title, body, assignee, int(time.time())))
        con.execute(
            "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
            "VALUES (?, NULL, 'created', ?, ?)",
            (tid, json.dumps({'assignee': assignee, 'status': 'ready', 'parents': [],
                              'tenant': None, 'workspace_kind': 'scratch',
                              'workspace_path': None, 'branch_name': None,
                              'project_id': None, 'skills': None, 'goal_mode': None,
                              'model_override': None, 'provider_override': None},
                             ensure_ascii=False), int(time.time())))
        con.commit()
        return tid
    finally:
        con.close()


def link_child(db, parent_id, child_id):
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute("INSERT OR IGNORE INTO task_links (parent_id, child_id) VALUES (?, ?)",
                    (parent_id, child_id))
        con.commit()
    finally:
        con.close()


def main():
    print('== 场景 1：R1 验收 FAIL → 自动派修 ==')
    reset_db()
    rv = make_review_card(TEST_DB, '【0823-govtest-1】【验收】模拟验收 FAIL（测试）')
    block_card(TEST_DB, rv, '【验收不通】10 项清单 9 项达标，键完整性 FAIL：xx 键缺失。修复指引：补键并部署。')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv))
    rv_now = get_task(TEST_DB, rv)
    check('验收卡仍 blocked 留档', rv_now['status'] == 'blocked',
          f"status={rv_now['status']}")
    # 找新建的修复卡/复验卡
    con = ro(TEST_DB)
    rows = con.execute(
        "SELECT id, title, assignee, status, body FROM tasks "
        "WHERE title LIKE '%govtest-1%' AND id != ?", (rv,)).fetchall()
    con.close()
    fix = [r for r in rows if '修复' in r['title'] and '复验' not in r['title']]
    rereview = [r for r in rows if '复验' in r['title']]
    check('自动生成修复卡(1张)', len(fix) == 1, f'got {len(fix)}')
    check('修复卡 assignee=make', bool(fix) and fix[0]['assignee'] == 'make')
    check('修复卡 status=ready(立即派发)', bool(fix) and fix[0]['status'] == 'ready')
    check('自动生成复验卡(1张)', len(rereview) == 1, f'got {len(rereview)}')
    check('复验卡 assignee=ada', bool(rereview) and rereview[0]['assignee'] == 'ada')
    if fix and rereview:
        # 复验卡 parents=[修复卡]
        con = ro(TEST_DB)
        pars = [r['parent_id'] for r in con.execute(
            'SELECT parent_id FROM task_links WHERE child_id=?', (rereview[0]['id'],))]
        con.close()
        check('复验卡 parents=[修复卡]', pars == [fix[0]['id']], f'pars={pars}')
        # 复验卡 status=todo（父未 done，门控）
        check('复验卡 status=todo(父门控)', rereview[0]['status'] == 'todo')
        # body 结构化标记
        check('修复卡 body 含 govern-review 标记',
              bool(fix) and f'govern-review: {rv}' in fix[0]['body'])
        check('复验卡 body 含 govern-review 标记',
              bool(rereview) and f'govern-review: {rv}' in rereview[0]['body'])
        check('修复卡 body 含 FAIL 项清单段（0825-retro-6）',
              bool(fix) and '原 FAIL 项清单' in fix[0]['body'])
        check('复验卡 body 含 FAIL 项清单段（0825-retro-6）',
              bool(rereview) and '原 FAIL 项清单' in rereview[0]['body'])
        check('修复卡 body 含初验卡 id', bool(fix) and f'初验卡：{rv}' in fix[0]['body'])
        check('复验卡 body 含初验卡 id', bool(rereview) and f'初验卡：{rv}' in rereview[0]['body'])
        check('复验卡 FAIL 清单含 reason 兜底', bool(rereview)
              and '键完整性 FAIL' in rereview[0]['body'])
    # 验收卡评论留痕
    con = ro(TEST_DB)
    comments = [r['body'] for r in con.execute(
        'SELECT body FROM task_comments WHERE task_id=?', (rv,))]
    con.close()
    check('验收卡有 R1 留痕评论', any('opc-govern R1' in c for c in comments))
    check('state.processed_blocks 记录该 block', len(state['processed_blocks']) == 1)
    evs = events_of(TEST_DB, rv)
    check('created/completed 事件审计完整',
          any(e['kind'] == 'created' for e in evs))

    print('\n== 场景 1b：幂等 —— 同 FAIL 批次不重复派卡 ==')
    before = len([r for r in rows]) if False else None
    con = ro(TEST_DB)
    n_before = con.execute(
        "SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-1%'").fetchone()['c']
    con.close()
    # 重新触发同一 block 事件（如重启重放/扫描重判）
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv))
    con = ro(TEST_DB)
    n_after = con.execute(
        "SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-1%'").fetchone()['c']
    con.close()
    check('重复触发不新增卡', n_before == n_after, f'{n_before} -> {n_after}')

    print('\n== 场景 2：R2 复验 done → 自动收口 ==')
    # 复用场景1的链：修复卡 done → 复验卡 promote(done)
    con = ro(TEST_DB)
    frow = con.execute(
        "SELECT id FROM tasks WHERE title LIKE '%govtest-1%修复%'").fetchone()
    rrow = con.execute(
        "SELECT id FROM tasks WHERE title LIKE '%govtest-1%复验%'").fetchone()
    con.close()
    fix_id, rr_id = frow['id'], rrow['id']
    complete_card(TEST_DB, fix_id, '[govtest-fix] 修复完成')
    # 复验卡由 dispatcher promote → done（模拟）
    con = sqlite3.connect(TEST_DB, timeout=10)
    con.execute("UPDATE tasks SET status='done', completed_at=? WHERE id=?",
                (int(time.time()), rr_id))
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "VALUES (?, NULL, 'promoted', NULL, ?), (?, NULL, 'completed', ?, ?)",
        (rr_id, int(time.time()), rr_id,
         json.dumps({'result_len': 0, 'summary': '[govtest-复验] ✅ 通过，全项达标'},
                    ensure_ascii=False), int(time.time())))
    con.commit()
    con.close()
    gov._r2_consider(ro(TEST_DB), state, get_task(TEST_DB, rr_id))
    rv_now = get_task(TEST_DB, rv)
    check('验收卡自动 done（收口）', rv_now['status'] == 'done',
          f"status={rv_now['status']}")
    check('验收卡 block_kind 已清空', rv_now['block_kind'] is None)
    check('验收卡 completed_at 已写', rv_now['completed_at'] is not None)
    evs = events_of(TEST_DB, rv)
    completed = [e for e in evs if e['kind'] == 'completed']
    check('验收卡有 completed 事件留痕', len(completed) >= 1)
    if completed:
        pl = json.loads(completed[-1]['payload'] or '{}')
        check('completed 事件 summary 含 R2 依据', 'opc-govern R2' in (pl.get('summary') or ''))
    con = ro(TEST_DB)
    comments = [r['body'] for r in con.execute(
        'SELECT body FROM task_comments WHERE task_id=?', (rv,))]
    con.close()
    check('验收卡有 R2 收口评论', any('opc-govern R2' in c for c in comments))

    print('\n== 场景 1c：原 FAIL 项清单提取（0825-retro-6，蔡婉报告 **P1-x** 格式） ==')
    reset_db()
    rvc = make_review_card(TEST_DB, '【0823-govtest-1c】【验收】FAIL 清单提取（测试）', 'ada')
    # 蔡婉验收报告评论（真实格式：**P1-1 标题** / **P2-x 标题** 严重度行）
    con = sqlite3.connect(TEST_DB, timeout=10)
    con.execute(
        "INSERT INTO task_comments (task_id, author, body, created_at) VALUES (?,?,?,?)",
        (rvc, 'ada',
         '## 验收结论：不通过（整体打回）— 2 项缺口\n\n'
         '**通过项（其余全绿）**：测试全过。\n\n'
         '**缺口（按严重度）**：\n\n'
         '**P1-1 install.sh 首装校验段竞态中止（违反验收项 2）**\n'
         '- L203 head 提前关管道 SIGPIPE 竞态\n\n'
         '**P2-1 deploy-guide 缺 key 导出步骤（违反验收项 5）**\n'
         '- 照做即报 No usable credentials',
         int(time.time())))
    con.commit()
    con.close()
    block_card(TEST_DB, rvc, '【验收不通过】2 缺口：P1 首装校验竞态；P2 key 导出缺失',
               kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rvc))
    con = ro(TEST_DB)
    frow = con.execute("SELECT id, body FROM tasks WHERE title LIKE '%govtest-1c%修复%'").fetchone()
    rrow = con.execute("SELECT id, body FROM tasks WHERE title LIKE '%govtest-1c%复验%'").fetchone()
    con.close()
    check('修复卡生成', bool(frow))
    check('复验卡生成', bool(rrow))
    if frow and rrow:
        check('修复卡 FAIL 清单提取 P1-1（严重度行）',
              'P1-1 install.sh 首装校验段竞态中止' in frow['body'])
        check('修复卡 FAIL 清单提取 P2-1',
              'P2-1 deploy-guide 缺 key 导出步骤' in frow['body'])
        check('复验卡 FAIL 清单提取 P1-1',
              'P1-1 install.sh 首装校验段竞态中止' in rrow['body'])
        check('复验卡 FAIL 清单提取 P2-1',
              'P2-1 deploy-guide 缺 key 导出步骤' in rrow['body'])
        check('复验卡初验卡 id 固化', f'初验卡：{rvc}' in rrow['body'])
        check('复验卡清单不含验收卡规则行噪声',
              'request_changes 打回' not in rrow['body'])
        # 幂等命中时复用同批卡，不重复建
        gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rvc))
        con = ro(TEST_DB)
        n = con.execute("SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-1c%'").fetchone()['c']
        con.close()
        check('同 FAIL 批次幂等不重复建卡', n == 3, f'cards={n}')

    print('\n== 场景 3：防误伤 ==')
    reset_db()
    # 3a. 普通 blocked(needs_input) 卡（无验收标记，字段 NULL + 文本无标记）→ 不派修
    ordinary = make_review_card(TEST_DB, '【0823-govtest-3a】普通任务（无任何标记）', 'make',
                                body='普通任务 body，纯业务描述。')
    block_card(TEST_DB, ordinary, '需要等外部资源 FAIL，稍后重试', kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, ordinary))
    con = ro(TEST_DB)
    n = con.execute("SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-3a%'").fetchone()['c']
    con.close()
    check('普通 blocked 卡不自动派修', n == 1, f'cards={n}')
    check('普通 blocked 卡不被收口', get_task(TEST_DB, ordinary)['status'] == 'blocked')
    # 3b. G 卡（assignee=gavin + 验收标记 + FAIL reason）→ 不受影响
    gcard = make_review_card(TEST_DB, '【0823-govtest-3b】【验收】G 卡拍板（测试）', 'gavin')
    block_card(TEST_DB, gcard, '【验收不通】等待 Gavin 拍板 FAIL', kind='needs_input')
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, gcard))
    con = ro(TEST_DB)
    n = con.execute("SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-3b%'").fetchone()['c']
    con.close()
    check('G 卡不自动派修', n == 1, f'cards={n}')
    check('G 卡保持 blocked', get_task(TEST_DB, gcard)['status'] == 'blocked')
    # 3c. 验收卡 blocked 但 reason 无 FAIL 关键词 → 不派修
    rv2 = make_review_card(TEST_DB, '【0823-govtest-3c】【验收】依赖等待（测试）', 'ada')
    block_card(TEST_DB, rv2, '【依赖】等待上游卡 done 后继续', kind='needs_input')
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv2))
    con = ro(TEST_DB)
    n = con.execute("SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-3c%'").fetchone()['c']
    con.close()
    check('reason 无 FAIL 关键词不派修', n == 1, f'cards={n}')
    # 3d. 验收卡 done 后（非 blocked）不触发 R2（模拟复验卡 done 但验收卡已被人工 done）
    reset_db()
    rv3 = make_review_card(TEST_DB, '【0823-govtest-3d】【验收】人工已收口（测试）', 'ada')
    block_card(TEST_DB, rv3, '【验收不通】FAIL：xx', kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv3))
    con = ro(TEST_DB)
    frow = con.execute("SELECT id FROM tasks WHERE title LIKE '%govtest-3d%修复%'").fetchone()
    rrow = con.execute("SELECT id FROM tasks WHERE title LIKE '%govtest-3d%复验%'").fetchone()
    con.close()
    complete_card(TEST_DB, frow['id'], 'fix done')
    complete_card(TEST_DB, rrow['id'], '复验 done')
    # 人工把验收卡 done 了（模拟庄子抢先收口）
    con = sqlite3.connect(TEST_DB, timeout=10)
    con.execute("UPDATE tasks SET status='done', completed_at=? WHERE id=?", (int(time.time()), rv3))
    con.commit()
    con.close()
    gov._r2_consider(ro(TEST_DB), state, get_task(TEST_DB, rrow['id']))
    n_completed = len([e for e in events_of(TEST_DB, rv3) if e['kind'] == 'completed'])
    check('验收卡已 done 时 R2 不重复收口（不新增 completed 事件）',
          n_completed == 0, f'completed_events={n_completed}')

    print('\n== 场景 4：重启后水位线不重放（事件路径） ==')
    reset_db()
    # 建一个全新的验收卡 + FAIL（事件在"首启校准"之前）→ 首启不重放
    rv4 = make_review_card(TEST_DB, '【0823-govtest-4】【验收】重启幂等（测试）', 'ada')
    block_card(TEST_DB, rv4, '【验收不通】FAIL：重启测试', kind='needs_input')
    # 模拟首启：水位线校准到 MAX(id)，不重放
    rows, max_id = gov.poll_events(TEST_DB, 0)
    watermark = int(max_id)
    state = fresh_state()
    state['watermark'] = watermark
    # 事件路径（只处理 watermark 之后的新事件 → 无事件）
    rows, max_id = gov.poll_events(TEST_DB, watermark)
    check('首启后无新事件（不重放历史 FAIL）', len(rows) == 0, f'rows={len(rows)}')
    # 但全表扫描会兜底处理（设计行为：扫描发现 blocked FAIL 验收卡 → 派修）
    gov.scan_r1(ro(TEST_DB), state)
    con = ro(TEST_DB)
    n = con.execute("SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-4%'").fetchone()['c']
    titles = [r['title'] for r in con.execute(
        "SELECT title FROM tasks WHERE title LIKE '%govtest-4%'")]
    con.close()
    print(f'    [debug] govtest-4 cards={n}: {titles}')
    check('全表扫描兜底派修（1 修复 + 1 复验 + 原卡）', n == 3, f'cards={n}')
    # 再跑一次扫描 → 幂等不重复
    gov.scan_r1(ro(TEST_DB), state)
    con = ro(TEST_DB)
    n = con.execute("SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-4%'").fetchone()['c']
    con.close()
    check('扫描幂等（再次扫描不新增卡）', n == 3, f'cards={n}')

    print('\n== 场景 5：legacy 手工链收口（i18n-d 真实数据） ==')
    reset_db()
    state = fresh_state()
    # 生产 i18n-d 验收卡 t_e2861b06 已于 07:49 被庄子人工收口（D1 原则首用）→ 副本漂移为 done。
    # 重建「复验已 PASS、验收卡仍 blocked 待收口」场景：置回 blocked + 追加 blocked 事件
    # （复验卡 t_2f90fb9f done、修复卡 t_10baff02 done 保持原样）。
    con = sqlite3.connect(TEST_DB, timeout=10)
    con.execute('BEGIN IMMEDIATE')
    con.execute("UPDATE tasks SET status='blocked', block_kind='needs_input', "
                "block_recurrences=1 WHERE id='t_e2861b06'")
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "VALUES ('t_e2861b06', NULL, 'blocked', ?, ?)",
        (json.dumps({'reason': '【验收不通过】i18n 5 语言 11 项清单 10 项达标，语言包完整性 '
                     'FAIL：tr/pl 语言包 team.m1-m9 段被写为扁平键',
                     'kind': 'needs_input', 'recurrences': 1, 'source_status': 'ready'},
                    ensure_ascii=False), int(time.time())))
    con.commit()
    con.close()
    # 真实链：t_e2861b06 blocked(验收 FAIL) / t_10baff02 done(修复) / t_2f90fb9f done(复验，父=修复)
    gov.scan_r2(ro(TEST_DB), state)
    legacy = get_task(TEST_DB, 't_e2861b06')
    check('i18n-d 验收卡自动收口 done', legacy['status'] == 'done',
          f"status={legacy['status']}")
    evs = events_of(TEST_DB, 't_e2861b06')
    completed = [e for e in evs if e['kind'] == 'completed']
    check('i18n-d 收口有 completed 事件留痕', len(completed) >= 1)
    if completed:
        pl = json.loads(completed[-1]['payload'] or '{}')
        check('i18n-d 收口 summary 含 R2 依据', 'opc-govern R2' in (pl.get('summary') or ''))
    # 二次扫描幂等
    gov.scan_r2(ro(TEST_DB), state)
    check('i18n-d 收口后二次扫描不重复', get_task(TEST_DB, 't_e2861b06')['status'] == 'done')

    print('\n== 场景 6：二轮 FAIL（复验卡 FAIL → 新一轮派修，关联原验收卡） ==')
    reset_db()
    rv6 = make_review_card(TEST_DB, '【0823-govtest-6】【验收】二轮 FAIL（测试）', 'ada')
    block_card(TEST_DB, rv6, '【验收不通】FAIL：首轮缺陷', kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv6))
    con = ro(TEST_DB)
    f1 = con.execute("SELECT id FROM tasks WHERE title LIKE '%govtest-6%修复%'").fetchone()['id']
    r1 = con.execute("SELECT id FROM tasks WHERE title LIKE '%govtest-6%复验%'").fetchone()['id']
    con.close()
    complete_card(TEST_DB, f1, 'fix1 done')
    # 蔡婉复验 FAIL：复验卡先被 dispatcher promote 到 ready（父 done）→ claimed → block
    con = sqlite3.connect(TEST_DB, timeout=10)
    con.execute("UPDATE tasks SET status='ready' WHERE id=?", (r1,))
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "VALUES (?, NULL, 'promoted', NULL, ?)", (r1, int(time.time())))
    con.commit()
    con.close()
    block_card(TEST_DB, r1, '【验收不通】复验 FAIL：修复不彻底', kind='needs_input')
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, r1))
    con = ro(TEST_DB)
    rows6 = con.execute(
        "SELECT id, title FROM tasks WHERE title LIKE '%govtest-6%' AND "
        "title LIKE '%复验%' ORDER BY id").fetchall()
    n_fix2 = con.execute(
        "SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govtest-6%修复%'").fetchone()['c']
    con.close()
    check('二轮生成新修复卡(共2张)', n_fix2 == 2, f'fixes={n_fix2}')
    check('二轮生成新复验卡(共2张)', len(rows6) == 2, f'rereviews={len(rows6)}')
    # 新复验卡 body 的 govern-review 指向原验收卡（二轮卡=创建序最后一张）
    con = ro(TEST_DB)
    rr2 = con.execute(
        "SELECT body FROM tasks WHERE title LIKE '%govtest-6%复验%' "
        "ORDER BY created_at DESC, rowid DESC LIMIT 1").fetchone()['body']
    con.close()
    check('二轮复验卡关联原验收卡', f'govern-review: {rv6}' in rr2)
    check('二轮复验卡含原 FAIL 项清单段（0825-retro-6）', '原 FAIL 项清单' in rr2)
    check('二轮复验卡 FAIL 清单含本轮 reason 兜底', '修复不彻底' in rr2)
    check('二轮复验卡含初验卡 id', f'初验卡：{rv6}' in rr2)
    # 二轮复验 done → 收口原验收卡（按 created_at 取最新复验卡，其父即二轮修复卡）
    con = ro(TEST_DB)
    rr2_id = con.execute(
        "SELECT id FROM tasks WHERE title LIKE '%govtest-6%复验%' "
        "ORDER BY created_at DESC LIMIT 1").fetchone()['id']
    f2_id = con.execute(
        "SELECT parent_id FROM task_links WHERE child_id=?",
        (rr2_id,)).fetchone()['parent_id']
    con.close()
    complete_card(TEST_DB, f2_id, 'fix2 done')
    con = sqlite3.connect(TEST_DB, timeout=10)
    con.execute("UPDATE tasks SET status='done', completed_at=? WHERE id=?", (int(time.time()), rr2_id))
    con.execute(
        "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
        "VALUES (?, NULL, 'completed', ?, ?)",
        (rr2_id, json.dumps({'result_len': 0, 'summary': '复验2 ✅ 通过'},
                            ensure_ascii=False), int(time.time())))
    con.commit()
    con.close()
    gov._r2_consider(ro(TEST_DB), state, get_task(TEST_DB, rr2_id))
    check('二轮复验通过 → 原验收卡自动收口', get_task(TEST_DB, rv6)['status'] == 'done')

    print('\n== 场景 7：已复验通过的验收卡（首扫顺序）→ R1 不派修 + R2 收口 ==')
    reset_db()
    state = fresh_state()
    # 真实 i18n-d 链：验收卡 blocked FAIL，但复验卡已 done（复验通过，只是没人收口）
    con = ro(TEST_DB)
    n_fix_before = con.execute(
        "SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govern-fix%'").fetchone()['c']
    con.close()
    # 模拟主循环扫描顺序：先 R2 后 R1
    gov.scan_r2(ro(TEST_DB), state)
    gov.scan_r1(ro(TEST_DB), state)
    check('已复验通过的验收卡被 R2 收口 done',
          get_task(TEST_DB, 't_e2861b06')['status'] == 'done')
    con = ro(TEST_DB)
    n_fix_after = con.execute(
        "SELECT COUNT(*) c FROM tasks WHERE title LIKE '%govern-fix%'").fetchone()['c']
    con.close()
    check('R1 不派新轮（govern-fix 卡数不变）', n_fix_before == n_fix_after,
          f'{n_fix_before} -> {n_fix_after}')
    check('R2 收口事件留痕',
          any(e['kind'] == 'completed' for e in events_of(TEST_DB, 't_e2861b06')))

    print('\n== 场景 8：无配置/空串回退内建默认（生产 pm2 直跑路径回归） ==')
    # 生产 pm2 直跑无 OPC_GOVERN_* env、宿主无 config.json → lib_config DEFAULT.govern
    # 空串占位 → load_cfg 必须解析为内建默认，否则 db='' 首启校准崩溃（08-23 实踩无限重启）
    _saved_env = {}
    for k in ('OPC_GOVERN_KANBAN_DB', 'OPC_GOVERN_STATE_FILE', 'OPC_GOVERN_POLL_SECONDS',
              'OPC_GOVERN_SCAN_SECONDS', 'OPC_GOVERN_FIX_ASSIGNEE', 'OPC_GOVERN_REREVIEW_ASSIGNEE'):
        _saved_env[k] = os.environ.pop(k, None)
    _orig_get_cfg = gov.get_cfg
    gov.get_cfg = lambda: {'govern': {'kanban_db': '', 'state_file': '', 'author': ''}}
    try:
        c = gov.load_cfg()
        check('空串 kanban_db 回退内建默认', c['kanban_db'].endswith('kanban.db'), c['kanban_db'])
        check('空串 state_file 回退内建默认', c['state_file'].endswith('govern-state.json'),
              c['state_file'])
    finally:
        gov.get_cfg = _orig_get_cfg
        for k, v in _saved_env.items():
            if v is not None:
                os.environ[k] = v

    print(f'\n========== 结果: {PASS} 通过 / {FAIL} 失败 ==========')
    sys.exit(1 if FAIL else 0)


if __name__ == '__main__':
    main()
