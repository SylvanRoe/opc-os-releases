#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""t_c8c26dcb 验证：受控降载感知（ports_open 剔除 + P2 受控降载中 总线留痕）
全部状态/总线写入重定向到临时目录，不触碰生产 selfheal_state.json / bus.jsonl。
"""
import json
import os
import sys
import tempfile

import importlib.util

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS_DIR = os.path.dirname(_TEST_DIR)   # 生产: ~/.hermes/scripts/.system-health/.. ; 产品包: scripts/.system-health/..
sys.path.insert(0, _SCRIPTS_DIR)
_spec = importlib.util.spec_from_file_location("system_monitor", os.path.join(_SCRIPTS_DIR, "system-monitor.py"))
sm = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sm)

tmp = tempfile.mkdtemp(prefix="sysmon-test-")
state_file = os.path.join(tmp, "selfheal_state.json")
bus_dir = os.path.join(tmp, "alerts")
os.makedirs(bus_dir, exist_ok=True)
# 总线脚本指向同目录 opc-alert-bus.py（尊重 OPC_ALERT_DIR → 临时总线，零污染生产）
os.environ["OPC_BUS_SCRIPT"] = os.path.join(_SCRIPTS_DIR, "opc-alert-bus.py")
os.environ["OPC_ALERT_DIR"] = bus_dir  # _bus_append 子进程继承 → 写临时总线

sm.SELFHEAL_STATE = state_file


def set_state(stopped):
    with open(state_file, "w") as f:
        json.dump({"stopped": stopped}, f)


def fake_run_ss(listening_ports):
    def _fake(cmd):
        if cmd.startswith("ss -tln"):
            return " ".join(listening_ports)
        return ""
    return _fake


fails = []
def check(name, got, want):
    ok = got == want
    print(f"{'PASS' if ok else 'FAIL'} {name}: got={got} want={want}")
    if not ok:
        fails.append(name)


# ---------- 1. ports_open: 降载登记 → 端口剔除 ----------
MON = ["3000", "3031", "3032", "3033", "3034", "3200", "18080"]
down = [p for p in MON if p not in ("3000", "3033", "3034", "18080")]  # 3031,3032,3200 未监听

# 1a. 无降载登记 → 三个端口照常报 (回归红线)
set_state({})
sm.run = fake_run_ss(("3000", "3033", "3034", "18080"))
check("1a 未登记降载 → 3031/3032/3200 照报", sm.ports_open(), ["3031", "3032", "3200"])

# 1b. 仅 opcos-mrdr 登记 → 3031 剔除
set_state({"opcos-mrdr": "2026-08-27 22:30:00"})
check("1b mrdr 登记 → 3031 剔除", sm.ports_open(), ["3032", "3200"])

# 1c. mrdr+knock 登记 → 3031/3032 剔除
set_state({"opcos-mrdr": "t", "opcos-knock": "t"})
check("1c mrdr+knock 登记 → 3031/3032 剔除", sm.ports_open(), ["3200"])

# 1d. 全部 5 服务登记 → 全部剔除, 空列表
set_state({"opcos-mrdr": "t", "opcos-mrd-host": "t", "opcos-collector": "t", "opcos-govern": "t", "opcos-knock": "t"})
check("1d 全登记 → 无 dead 端口", sm.ports_open(), [])

# 1e. 无受控端口的服务(collector/govern)登记 → 不影响端口报告
set_state({"opcos-collector": "t", "opcos-govern": "t"})
check("1e collector/govern 登记 → 端口照报", sm.ports_open(), ["3031", "3032", "3200"])

# 1f. 端口实际在监听 + 未登记 → 不报 (无假报)
set_state({})
sm.run = fake_run_ss(("3000", "3031", "3032", "3033", "3034", "3200", "18080"))
check("1f 全监听无登记 → 空", sm.ports_open(), [])

# ---------- 2. self_heal: 降载触发 → P2 受控降载中 总线留痕 (status=resolved) ----------
real_temp = sm.temp
real_mem = sm.mem
real_tmp_use = sm.tmp_use
real_bus_append = sm._bus_append
bus_file = os.path.join(bus_dir, "bus.jsonl")


def read_bus():
    if not os.path.exists(bus_file):
        return []
    return [json.loads(l) for l in open(bus_file, encoding="utf-8") if l.strip()]


# 2a. 过热路径: temp=90 → 停 5 服务 → P2 degrade
set_state({})
sm.temp = lambda: 90
sm.mem = lambda: (16000000, 8000000, 50)
sm.tmp_use = lambda: 30
sm.run = lambda cmd: "ok" if cmd.startswith("sudo -n systemctl stop") else ""
w, a = [], []
sm.self_heal(w, a)
bus = read_bus()
deg = [e for e in bus if e.get("type") == "degrade"]
ok = len(deg) == 1 and deg[0]["severity"] == "P2" and deg[0]["status"] == "resolved" \
    and "受控降载中: 过热已停" in deg[0]["title"] and "opcos-mrdr" in deg[0]["title"]
check("2a 过热降载 → P2 degrade resolved 总线条目", (len(deg), deg[0]["title"] if deg else None) if not ok else "PASS", "PASS")
if not ok and deg:
    print("   title:", deg[0]["title"], "| status:", deg[0]["status"], "| severity:", deg[0]["severity"])
st = json.load(open(state_file))
check("2a 登记 5 服务到 selfheal_state", sorted(st["stopped"].keys()), sorted(sm.HEAL_STOP_SERVICES))
# 清理: 避免 heal_restore 干扰 2b
set_state({})

# 2b. 内存路径: mem<10% → 停 3 docker + 5 systemd → P2 degrade 含全部 8 个
sm.temp = lambda: 60
sm.mem = lambda: (16000000, 1000000, 6)
sm.tmp_use = lambda: 30
sm.run = lambda cmd: "ok" if ("systemctl stop" in cmd or "docker stop" in cmd) else ""
w, a = [], []
sm.self_heal(w, a)
bus = read_bus()
deg = [e for e in bus if e.get("type") == "degrade"]
ok = len(deg) == 2 and any("内存高压已停" in e["title"] for e in deg)
if ok:
    e = [e for e in deg if "内存高压已停" in e["title"]][0]
    ok = e["severity"] == "P2" and e["status"] == "resolved" and "opcos31dr-web" in e["title"] and "opcos-mrdr" in e["title"]
check("2b 内存降载 → P2 degrade 含 docker+systemd 8 服务", (len(deg), [e["title"] for e in deg]) if not ok else "PASS", "PASS")

# 2c. 无降载条件 → 不写 degrade 条目
sm.temp = lambda: 60
sm.mem = lambda: (16000000, 8000000, 50)
sm.run = lambda cmd: ""
w, a = [], []
sm.self_heal(w, a)
deg_n = len([e for e in read_bus() if e.get("type") == "degrade"])
check("2c 无降载触发 → degrade 条数不变(2)", deg_n, 2)

# 2d. 回归: 降载登记期间 ports_open 剔除 knock 端口 + pm2_dead(service-down 侧)同步剔除
set_state({"opcos-knock": "t"})
sm.run = fake_run_ss(("3000", "3033", "3034", "18080"))
check("2d 登记后 ports_open 剔除 knock 端口", sm.ports_open(), ["3031", "3200"])


def fake_run_units(inactive_units):
    def _fake(cmd):
        if cmd.startswith("systemctl is-active"):
            return "\n".join("inactive" if u in inactive_units else "active"
                             for u in sm.OPCOS_UNITS)
        return ""
    return _fake


# 2e. 真故障(无登记) → pm2_dead 照报 (回归红线)
set_state({})
sm.run = fake_run_units({"opcos-knock"})
check("2e 未登记真故障 → pm2_dead 照报", sm.pm2_dead(), ["opcos-knock(inactive)"])

# 2f. 降载登记 → pm2_dead 剔除 (service-down 侧闭环)
set_state({"opcos-knock": "t"})
sm.run = fake_run_units({"opcos-knock"})
check("2f 登记降载 → pm2_dead 不报", sm.pm2_dead(), [])

# ---------- 3. R3 修复回归 (t_f9843ec9): run() 空输出但 rc=0 → 登记+留痕仍发生 ----------
# 旧缺陷: systemctl stop/start 成功静默(stdout 空) → `if run(...)` 恒 False
# → _mark_heal_stop 从不执行、P2 degrade 总线 0 条、action 未记录 (L295/L321/L340/L369 同病)。
# 修复: run() 返回 RunResult(str 子类, bool=rc==0)。RunResult("",0)=真实静默成功语义,
#        RunResult("",1)=真实静默失败语义。
def fake_run_real_semantics(rc):
    return lambda cmd: sm.RunResult("", rc)

# 3a. 静默成功(rc=0, 输出空) → 5 服务登记 + 1 条 P2 degrade + 5 条 action (ada 场景 A)
set_state({})
sm.temp = lambda: 90
sm.mem = lambda: (16000000, 8000000, 50)
sm.tmp_use = lambda: 30
sm.run = fake_run_real_semantics(0)
w, a = [], []
sm.self_heal(w, a)
st = json.load(open(state_file))
check("3a 静默成功(rc=0 空输出) → 5 服务登记", sorted(st["stopped"].keys()), sorted(sm.HEAL_STOP_SERVICES))
deg3a = [e for e in read_bus() if e.get("type") == "degrade"]
ok3a = len(deg3a) == 3 and deg3a[-1]["severity"] == "P2" and "受控降载" in deg3a[-1]["title"]
check("3a 静默成功 → 第3条 P2 degrade 留痕", ok3a, True)
check("3a 静默成功 → 5 条 action 记录", len(a), 5)

# 3b. 静默失败(rc=1, 输出空) → 不登记、不动作、degrade 条数不变
set_state({})
sm.run = fake_run_real_semantics(1)
w, a = [], []
sm.self_heal(w, a)
st = json.load(open(state_file))
check("3b 静默失败(rc=1) → 不登记", sorted(st["stopped"].keys()), [])
check("3b 静默失败(rc=1) → 无 action", a, [])
deg_n = len([e for e in read_bus() if e.get("type") == "degrade"])
check("3b 静默失败(rc=1) → degrade 条数不变(3)", deg_n, 3)

# 恢复生产函数 (防止污染后续真实运行)
sm.temp = real_temp
sm.mem = real_mem
sm.tmp_use = real_tmp_use
sm._bus_append = real_bus_append
sm.run = None

print("\n" + ("ALL PASS ✅" if not fails else f"FAILED: {fails} ❌"))
sys.exit(1 if fails else 0)
