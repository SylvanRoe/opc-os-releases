#!/bin/sh
# OPC OS — web 容器入口：种子数据初始化 + 启动 nginx
# 共享卷 /usr/share/nginx/html/opc/data 为空时，把镜像内置 demo 种子复制进去，
# 保证全新机器 compose up 后仪表盘立即可见（collector 首跑会再覆盖为最新数据）。
# [31c] customer 形态：不复制 demo 种子（首启欢迎态由 collector 的 gen_welcome_state.py 生成，
#       status.json 标记 uninitialized → 透明办公室显示引导页而非软件 demo）；
#       轮询等待卷内 status.json 出现（collector 写欢迎态或正常态后即达）。
set -e

TARGET=/usr/share/nginx/html/opc/data
SEED=/seed/opc/data
MODE="${OPC_OS_MODE:-self}"

if [ ! -d "$TARGET" ]; then
  mkdir -p "$TARGET"
fi

if [ "$MODE" = "customer" ]; then
  # customer 形态：绝不复制 demo 种子；等 collector 生成 status.json（欢迎态/正常态）
  echo "[opc-os] customer 形态：不复制 demo 种子，等待 collector 生成 status.json ..."
  i=0
  while [ ! -f "$TARGET/status.json" ] && [ $i -lt 60 ]; do
    sleep 1
    i=$((i+1))
  done
  if [ -f "$TARGET/status.json" ]; then
    echo "[opc-os] status.json 已就绪（$([ -f "$TARGET/token-stats.json" ] && echo '含' || echo '缺') token-stats.json）"
  else
    echo "[opc-os] ⚠️ 60s 内未等到 status.json（collector 可能未就绪）；nginx 将先行启动"
  fi
else
  # self 形态（现状）：卷空复制 demo 种子
  if [ -f "$TARGET/status.json" ] && [ -f "$TARGET/token-stats.json" ]; then
    echo "[opc-os] 数据卷已有 status.json/token-stats.json，跳过种子复制"
  else
    echo "[opc-os] 复制 demo 种子数据 → $TARGET"
    cp -f "$SEED/status.json" "$TARGET/" 2>/dev/null || true
    cp -f "$SEED/token-stats.json" "$TARGET/" 2>/dev/null || true
  fi
fi

# 0821-wb-cors: WORKBENCH_API 环境变量(可选) → 注入 workbench.html 的 API base
# 不设置(默认)则保持 https://mrd.hermes.cc.cd 零变化; 设置后替换默认值为部署方后端,
# 如 WORKBENCH_API=http://192.168.1.5:3000 docker compose up -d
# 锚点匹配 window.OPC_WORKBENCH_API || '<任意>' → 幂等, 重启时随新值更新
if [ -n "${WORKBENCH_API:-}" ]; then
  ESC=$(printf '%s' "$WORKBENCH_API" | sed -e 's/\\/\\\\/g' -e 's/&/\\\&/g' -e 's/#/\\#/g')
  echo "[opc-os] 注入 WORKBENCH_API → /opc/workbench.html API base: $WORKBENCH_API"
  sed -i "s#(window.OPC_WORKBENCH_API || '[^']*')#(window.OPC_WORKBENCH_API || '$ESC')#" \
    /usr/share/nginx/html/opc/workbench.html
fi

# nginx 前台启动（容器主进程；守护由 docker restart 策略负责）
echo "[opc-os] nginx 启动"
exec nginx -g 'daemon off;'
