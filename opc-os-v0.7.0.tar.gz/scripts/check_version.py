#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
opc-os check_version.py — 三源一致性校验（版本制度 v2.0 §2.2 落地 · T3 交付）

对比三源：
  1. 仓根 VERSION 文件         —— opc-os 版本单一来源（asset-versioning.md §2.1；
                                 VERSION 文件自 v0.6.0 起为权威载体，opc_init.py --version
                                 / check-update / upgrade 全部读取）
  2. git 最新合规 tag vX.Y.Z   —— annotated tag，指向发布 commit
  3. CHANGELOG.md 顶条         —— [Unreleased] 之下首个 "## [vX.Y.Z]" 已发布条目

一致 → exit 0；漂移 → exit 1 + 输出差异明细。独立命令，也可被 bump_version.py 复用。

版本合规（asset-versioning.md §1.1）：^v?([0-9]+)\\.([0-9]+)\\.([0-9]+)$
  拒绝形态：缺段（v0.1/v0.2）、非数字段、预发布/构建元数据后缀。

用法：
  python3 scripts/check_version.py                # 人类可读报告
  python3 scripts/check_version.py --repo PATH    # 指定仓库路径（默认自动探测）
  python3 scripts/check_version.py --json         # 机器可读 JSON
  python3 scripts/check_version.py --check 0.6.0  # 额外校验给定版本 = 三源（用于 bump 前置）

退出码：0=三源一致 / 1=漂移或非法 / 2=环境无法判定（git 仓缺失 / 无法读文件）。

红线：本工具只读，不写任何文件、不改任何 git 状态。dry-run / bump 均以此为准。
"""

import argparse
import json
import os
import re
import subprocess
import sys

SEMVER_RE = re.compile(r"^v?([0-9]+)\.([0-9]+)\.([0-9]+)$")
NGX = re.compile(r"^##\s*\[v([0-9]+\.[0-9]+\.[0-9]+)\]\s*")


def _find_repo(repo_arg):
    """定位仓库根：显式 --repo > 从脚本路径逐级上溯 > cwd。返回 repo 根或 None。"""
    if repo_arg:
        cand = os.path.abspath(repo_arg)
        if os.path.isdir(os.path.join(cand, ".git")):
            return cand
        return None
    script_dir = os.path.dirname(os.path.abspath(__file__))
    for d in (script_dir, os.getcwd()):
        if os.path.isdir(os.path.join(d, ".git")):
            return d
        # 从脚本路径上溯（scripts/..）
        up = os.path.dirname(script_dir)
        while up and up != os.path.dirname(up):
            if os.path.isdir(os.path.join(up, ".git")):
                return up
            up = os.path.dirname(up)
    return None


def _git(repo, *args):
    """运行 git 子命令，返回 (exit_code, stdout, stderr)。"""
    try:
        p = subprocess.run(
            ["git", "-C", repo] + list(args),
            capture_output=True, text=True, timeout=15,
        )
        return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()
    except (subprocess.SubprocessError, FileNotFoundError) as e:
        return 2, "", str(e)


def read_version_file(repo):
    """读仓根 VERSION 文件（单一来源）。返回 (值, 错误)；文件缺→(None, err)。"""
    vf = os.path.join(repo, "VERSION")
    if not os.path.isfile(vf):
        return None, f"VERSION 文件不存在: {vf}"
    try:
        with open(vf, encoding="utf-8") as f:
            return f.read().strip(), None
    except OSError as e:
        return None, f"读取 VERSION 失败: {e}"


def latest_compliant_tag(repo):
    """git 最新合规 tag（语义值最大者）。返回 str 或 None（无合规 tag）。"""
    code, out, err = _git(repo, "tag", "--list", "v*", "--sort=-v:refname")
    if code != 0:
        return None
    for t in out.splitlines():
        if SEMVER_RE.match(t.strip()):
            return t.strip()
    return None


def changelog_top_version(repo):
    """CHANGELOG.md 顶条 = 首个 '## [vX.Y.Z]' 标题（跳过 [Unreleased] 与历史处置节）。"""
    cl = os.path.join(repo, "CHANGELOG.md")
    if not os.path.isfile(cl):
        return None, f"CHANGELOG 不存在: {cl}"
    try:
        with open(cl, encoding="utf-8") as f:
            for line in f:
                m = NGX.match(line)
                if m:
                    return m.group(1), None
        return None, "CHANGELOG 无合规版本条目标题"
    except OSError as e:
        return None, f"读取 CHANGELOG 失败: {e}"


def semver_value(v):
    """剥离 v 前缀，返回 (major, minor, patch) 元组；非法形态返回 None。"""
    if not v:
        return None
    m = SEMVER_RE.match(v.strip())
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)))


def _eq(a, b):
    """三源语义相等（剥离 v 逐段比较）。"""
    va, vb = semver_value(a), semver_value(b)
    if va is None or vb is None:
        return False
    return va == vb


def check_three_source(repo=None, check=None):
    """
    三源一致性校验核心。返回 dict：
      {repo, version_file, git_tag, changelog_top, consistent, sources: [...], errors}
    """
    repo, err = _find_repo(repo), None
    if not repo:
        return {"repo": None, "consistent": False, "errors": ["未定位 git 仓库"], "sources": []}

    vf, vf_err = read_version_file(repo)
    tag = latest_compliant_tag(repo)
    top, top_err = changelog_top_version(repo)

    sources = [
        {"name": "VERSION 文件", "value": vf, "ok": vf is not None and semver_value(vf) is not None,
         "note": vf_err or ("合规" if semver_value(vf) else "非法格式")},
        {"name": "git tag", "value": tag, "ok": tag is not None,
         "note": None if tag else "无合规 vX.Y.Z tag"},
        {"name": "CHANGELOG 顶条", "value": top, "ok": top is not None,
         "note": top_err or ("合规" if semver_value(top) else "非法格式")},
    ]

    present = [s["value"] for s in sources if s["value"] is not None]
    consistent = False
    if len(present) == 3 and all(semver_value(p) is not None for p in present):
        consistent = all(_eq(present[0], p) for p in present[1:])

    result = {
        "repo": repo,
        "version_file": vf,
        "git_tag": tag,
        "changelog_top": top,
        "consistent": consistent,
        "sources": sources,
        "errors": [s["note"] for s in sources if s.get("note") and not s["ok"]],
    }

    # --check 附加：给定版本是否 = 三源
    if check is not None:
        result["check_target"] = check
        result["check_match"] = all(_eq(check, p) for p in present) if len(present) == 3 else False
    return result


def human_report(r):
    lines = []
    lines.append(f"三源一致性检查 · {r.get('repo') or '(未定位仓库)'}")
    for s in r["sources"]:
        mark = "✓" if s["ok"] else "✗"
        lines.append(f"  {mark} {s['name']}: {s['value'] or '(缺失/非法)'}  {s.get('note') or ''}")
    if r["consistent"]:
        lines.append("  ✅ 三源一致：" + " == ".join(str(s["value"]) for s in r["sources"]))
    else:
        vals = [s["value"] or "∅" for s in r["sources"]]
        lines.append("  ❌ 三源漂移：" + " ? ".join(vals))
        lines.append("    → 漂移（缺口）见上；治理后重跑。规范 asset-versioning.md §2.2/§7。")
    if r.get("check_target") is not None:
        t = r["check_target"]
        lines.append(f"  目标版本 {t}: " + ("匹配三源 ✓" if r.get("check_match") else "不匹配三源 ✗"))
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="opc-os 三源一致性校验（VERSION 文件 / git tag / CHANGELOG 顶条）",
        epilog="退出码：0=一致 / 1=漂移或非法 / 2=环境无法判定",
    )
    ap.add_argument("--repo", default=None, help="仓库根路径（默认自动探测脚本位置/当前目录）")
    ap.add_argument("--json", action="store_true", help="输出机器可读 JSON")
    ap.add_argument("--check", default=None, metavar="VERSION",
                    help="额外校验给定版本（如 0.6.0 / v0.6.0）是否 = 三源（bump 前置用）")
    args = ap.parse_args(argv)

    r = check_three_source(repo=args.repo, check=args.check)
    if not r.get("repo"):
        out = r if args.json else human_report(r)
        print(json.dumps(out, ensure_ascii=False, indent=2) if args.json else out)
        return 2

    if args.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print(human_report(r))

    if r["consistent"]:
        if args.check is not None and not r.get("check_match"):
            return 1
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
