#!/usr/bin/env python3
"""opc-govern 规则级验收测试（gov-7b：task_kind 字段判定）。

Gavin 拍板补充（2026-08-23）：govern 读字段逻辑必须有规则级测试（测试先行）——
措辞偏差不静默失效、skip_log 可见性、幂等防重、字段优先不误伤、未标兜底。
7d（蔡婉）会复跑本测试集验收。

与 test_govern.py 的区别：**完全合成库**（自建 schema，零生产数据依赖），
单独覆盖 gov-7b 的 5 个规则场景 + R2 字段路径 + 回归（疑似验收卡兜底）。

运行：python3 scripts/test_govern_taskkind.py   （独立运行，退出码 0=全绿）
"""
import json
import os
import shutil
import sqlite3
import sys
import time

WS = os.path.dirname(os.path.abspath(__file__))
TEST_DB = os.path.join(WS, 'test-taskkind-kanban.db')
TEST_STATE = os.path.join(WS, 'test-taskkind-state.json')

# 必须在 import 前设置环境（模块级 CFG 在 import 时固化）
os.environ['OPC_GOVERN_KANBAN_DB'] = TEST_DB
os.environ['OPC_GOVERN_STATE_FILE'] = TEST_STATE
os.environ['OPC_GOVERN_POLL_SECONDS'] = '0.5'
os.environ['OPC_GOVERN_SCAN_SECONDS'] = '15'

sys.path.insert(0, WS)
import importlib.util
_spec = importlib.util.spec_from_file_location('opc_govern_tk', os.path.join(WS, 'opc-govern.py'))
gov = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(gov)

PASS = 0
FAIL = 0


def check(name, cond, extra=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f'  ✅ {name}')
    else:
        FAIL += 1
        print(f'  ❌ {name} {extra}')


# ─────────────────────────── 合成库（零生产数据依赖） ───────────────────────────

SCHEMA = """
CREATE TABLE tasks (
    id TEXT PRIMARY KEY, title TEXT, body TEXT, assignee TEXT, status TEXT,
    priority INTEGER DEFAULT 0, created_by TEXT, created_at INTEGER,
    started_at INTEGER, completed_at INTEGER, workspace_kind TEXT, workspace_path TEXT,
    branch_name TEXT, project_id TEXT, claim_lock TEXT, claim_expires INTEGER,
    tenant TEXT, result TEXT, idempotency_key TEXT, consecutive_failures INTEGER DEFAULT 0,
    worker_pid INTEGER, last_failure_error TEXT, max_runtime_seconds INTEGER,
    last_heartbeat_at INTEGER, current_run_id INTEGER, workflow_template_id TEXT,
    current_step_key TEXT, skills TEXT, model_override TEXT, provider_override TEXT,
    reasoning_effort TEXT, max_retries INTEGER, goal_mode INTEGER DEFAULT 0,
    goal_max_turns INTEGER, session_id TEXT, block_kind TEXT,
    block_recurrences INTEGER DEFAULT 0, task_kind TEXT
);
CREATE TABLE task_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, run_id INTEGER,
    kind TEXT, payload TEXT, created_at INTEGER
);
CREATE TABLE task_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, author TEXT,
    body TEXT, created_at INTEGER
);
CREATE TABLE task_links (parent_id TEXT, child_id TEXT);
CREATE TABLE task_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, profile TEXT, step_key TEXT,
    status TEXT, claim_lock TEXT, claim_expires INTEGER, worker_pid INTEGER,
    max_runtime_seconds INTEGER, last_heartbeat_at INTEGER, started_at INTEGER,
    ended_at INTEGER, outcome TEXT, summary TEXT, metadata TEXT, error TEXT
);
"""


def reset_db():
    for f in (TEST_DB, TEST_DB + '-wal', TEST_DB + '-shm', TEST_STATE,
              TEST_STATE + '.govern-tmp'):
        if os.path.exists(f):
            os.remove(f)
    con = sqlite3.connect(TEST_DB)
    try:
        con.executescript(SCHEMA)
    finally:
        con.close()
    # gov-7c：task_kind 合并映射有模块级缓存（生产每轮扫描前失效；测试直调判定函数
    # 不走扫描循环 → reset 后必须手动失效，否则新库的 task_kind 列读不到（曾致 4 项误判）
    gov._invalidate_tk_cache()


def ro(db=TEST_DB):
    con = sqlite3.connect(f'file:{db}?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    return con


def get_task(db, tid):
    con = ro(db)
    try:
        r = con.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone()
        return dict(r) if r else None
    finally:
        con.close()


def fresh_state():
    return {'watermark': 0, 'processed_blocks': set(), 'closed_reviews': set(),
            'chains': {}, 'skip_log': []}


def make_card(db, title, assignee='ada', status='ready', task_kind=None, body=None):
    """合成建卡：task_kind 显式可控（NULL=未标，reviw/ops/... = 字段标记）。"""
    tid = 't_' + os.urandom(4).hex()
    if body is None:
        body = ('【验收 · 只读不改代码】测试验收清单。' if task_kind == 'review'
                else '普通任务 body，纯业务描述无任何标记。')
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute('BEGIN IMMEDIATE')
        con.execute(
            "INSERT INTO tasks (id, title, body, assignee, status, priority, created_by, "
            "created_at, workspace_kind, workspace_path, branch_name, project_id, tenant, "
            "idempotency_key, max_runtime_seconds, skills, max_retries, model_override, "
            "provider_override, reasoning_effort, goal_mode, goal_max_turns, session_id, "
            "task_kind) VALUES (?, ?, ?, ?, ?, 0, 'worker', ?, 'scratch', NULL, NULL, NULL, "
            "NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, ?)",
            (tid, title, body, assignee, status, int(time.time()), task_kind))
        con.execute(
            "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
            "VALUES (?, NULL, 'created', ?, ?)",
            (tid, json.dumps({'assignee': assignee, 'status': status, 'parents': [],
                              'tenant': None, 'workspace_kind': 'scratch',
                              'workspace_path': None, 'branch_name': None,
                              'project_id': None, 'skills': None, 'goal_mode': None,
                              'model_override': None, 'provider_override': None,
                              'task_kind': task_kind}, ensure_ascii=False),
             int(time.time())))
        con.commit()
        gov._invalidate_tk_cache()  # gov-7c：新卡 task_kind 入库后失效合并缓存
        return tid
    finally:
        con.close()


def block_card(db, tid, reason, kind='needs_input'):
    """模拟 kanban_block(needs_input, reason) 的 SQL 等价。"""
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute('BEGIN IMMEDIATE')
        con.execute(
            "UPDATE tasks SET status='blocked', claim_lock=NULL, claim_expires=NULL, "
            "worker_pid=NULL, block_kind=?, block_recurrences=1 WHERE id=? "
            "AND status IN ('running','ready')", (kind, tid))
        con.execute(
            "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
            "VALUES (?, NULL, 'blocked', ?, ?)",
            (tid, json.dumps({'reason': reason, 'kind': kind, 'recurrences': 1,
                              'source_status': 'ready'}, ensure_ascii=False),
             int(time.time())))
        con.commit()
    finally:
        con.close()


def complete_card(db, tid, summary):
    """模拟 kanban_complete(summary) 的 SQL 等价。"""
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute('BEGIN IMMEDIATE')
        con.execute(
            "UPDATE tasks SET status='done', result=?, completed_at=?, claim_lock=NULL, "
            "claim_expires=NULL, worker_pid=NULL, block_kind=NULL, block_recurrences=0 "
            "WHERE id=? AND status IN ('running','ready','blocked','review')",
            (summary, int(time.time()), tid))
        con.execute(
            "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
            "VALUES (?, NULL, 'completed', ?, ?)",
            (tid, json.dumps({'result_len': 0, 'summary': summary}, ensure_ascii=False),
             int(time.time())))
        con.commit()
    finally:
        con.close()


def link_child(db, parent_id, child_id):
    con = sqlite3.connect(db, timeout=10)
    try:
        con.execute("INSERT OR IGNORE INTO task_links (parent_id, child_id) VALUES (?, ?)",
                    (parent_id, child_id))
        con.commit()
    finally:
        con.close()


def count_by_title(db, pattern):
    con = ro(db)
    try:
        return con.execute(
            "SELECT COUNT(*) c FROM tasks WHERE title LIKE ?", (pattern,)).fetchone()['c']
    finally:
        con.close()


def skip_reasons(state, task_id):
    return [e['reason'] for e in state.get('skip_log', [])
            if e.get('task_id') == task_id]


def main():
    # ═══════════════ 场景 1：措辞偏差不静默失效（Gavin 1）+ 建卡写字段 + 幂等（Gavin 3）+ R2 字段路径 ═══════════════
    print('== 场景 1：task_kind=review + blocked(FAIL)，title/body 无任何「验收」字样 → 必派修 ==')
    reset_db()
    rv = make_card(TEST_DB, '【0823-govtest-7b-1】业务卡片（字段=review，无验收字样）',
                   task_kind='review',
                   body='纯业务描述，不含验收/govern-review 标记。')
    block_card(TEST_DB, rv, '【验收不通】键完整性 FAIL：xx 键缺失。修复指引：补键并部署。')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv))
    check('验收卡保持 blocked 留档', get_task(TEST_DB, rv)['status'] == 'blocked')
    con = ro(TEST_DB)
    rows = con.execute(
        "SELECT id, title, assignee, status, task_kind FROM tasks "
        "WHERE id != ? AND (title LIKE '%7b-1%' OR id IN (SELECT child_id FROM task_links))",
        (rv,)).fetchall()
    con.close()
    fix = [r for r in rows if 'govern-fix' in r['title']]
    rr = [r for r in rows if 'govern-复验' in r['title']]
    check('措辞偏差不静默失效：必派修（修复卡 1 张）', len(fix) == 1, f'got {len(fix)}')
    check('修复卡 task_kind=fix（字段写入）', bool(fix) and fix[0]['task_kind'] == 'fix',
          f"task_kind={fix[0]['task_kind'] if fix else None}")
    check('修复卡 assignee=make / status=ready', bool(fix) and fix[0]['assignee'] == 'make'
          and fix[0]['status'] == 'ready')
    check('复验卡 1 张且 task_kind=review（字段写入）',
          len(rr) == 1 and rr[0]['task_kind'] == 'review', f"got {len(rr)}")
    # 修复卡 created 事件 payload 带 task_kind
    if fix:
        con = ro(TEST_DB)
        ev = con.execute(
            "SELECT payload FROM task_events WHERE task_id=? AND kind='created' ORDER BY id",
            (fix[0]['id'],)).fetchall()
        con.close()
        pls = [json.loads(e['payload'] or '{}') for e in ev]
        check('修复卡 created 事件透传 task_kind=fix',
              any(p.get('task_kind') == 'fix' for p in pls))
    # 幂等防重（Gavin 3）：同一 blocked 卡二次扫描 → 不新增卡
    n_before = count_by_title(TEST_DB, '%7b-1%')
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv))
    n_after = count_by_title(TEST_DB, '%7b-1%')
    check('幂等防重：二次扫描只派一轮（卡数不变）', n_before == n_after,
          f'{n_before} -> {n_after}')
    check('幂等命中留痕', any('幂等' in r for r in skip_reasons(state, rv)))
    # R2 字段路径端到端：父卡 task_kind=review 无文本标记也能被收口
    f_id = fix[0]['id'] if fix else None
    rr_id = rr[0]['id'] if rr else None
    if f_id and rr_id:
        complete_card(TEST_DB, f_id, '[govtest-7b-1] 修复完成')
        con = sqlite3.connect(TEST_DB, timeout=10)
        con.execute("UPDATE tasks SET status='done', completed_at=? WHERE id=?",
                    (int(time.time()), rr_id))
        con.execute(
            "INSERT INTO task_events (task_id, run_id, kind, payload, created_at) "
            "VALUES (?, NULL, 'completed', ?, ?)",
            (rr_id, json.dumps({'result_len': 0, 'summary': '[复验] ✅ 通过'},
                               ensure_ascii=False), int(time.time())))
        con.commit()
        con.close()
        gov._r2_consider(ro(TEST_DB), state, get_task(TEST_DB, rr_id))
        check('R2 字段路径：父卡 task_kind=review（无验收字样）自动收口 done',
              get_task(TEST_DB, rv)['status'] == 'done')

    # ═══════════════ 场景 2：skip_log 可见性（Gavin 2）——task_kind=review 但 reason 无 FAIL 词 ═══════════════
    print('\n== 场景 2：task_kind=review + reason 无 FAIL 词 → skip_log「无 FAIL 词」，不派修 ==')
    reset_db()
    rv2 = make_card(TEST_DB, '【0823-govtest-7b-2】业务卡片（字段=review，reason 无 FAIL）',
                    task_kind='review')
    block_card(TEST_DB, rv2, '【依赖】等待上游资源就绪后继续', kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv2))
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv2))  # 二次（去重验证）
    check('无 FAIL 词不派修', count_by_title(TEST_DB, '%7b-2%') == 1)
    reasons = skip_reasons(state, rv2)
    check('skip_log 可见性：留痕含「无 FAIL 词」', any('无 FAIL 词' in r for r in reasons),
          f'reasons={reasons}')
    check('skip_log 去重：同 (task,stage,reason) 只记一条',
          sum(1 for r in reasons if '无 FAIL 词' in r) == 1, f'got {len(reasons)}')

    # ═══════════════ 场景 3：字段优先不误伤（Gavin 4）——task_kind=ops + title 含「验收」+ FAIL ═══════════════
    print('\n== 场景 3：task_kind=ops + title 含「验收」+ blocked FAIL → 不派修 + 留痕 ==')
    reset_db()
    rv3 = make_card(TEST_DB, '【0823-govtest-7b-3】【验收】某功能验收（字段=ops 不应误伤）',
                    task_kind='ops')
    block_card(TEST_DB, rv3, '【验收不通】FAIL：功能 xxx 不合格', kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv3))
    check('字段优先不误伤：task_kind=ops 不派修（title 含验收也无效）',
          count_by_title(TEST_DB, '%7b-3%') == 1)
    reasons = skip_reasons(state, rv3)
    check('skip_log 留痕「字段判定非验收卡（task_kind=ops）」',
          any('字段判定非验收卡（task_kind=ops）' in r for r in reasons),
          f'reasons={reasons}')

    # ═══════════════ 场景 4：未标兜底（Gavin 5）——task_kind=NULL + title 含「验收」 ═══════════════
    print('\n== 场景 4：task_kind=NULL + title 含「验收」→ 文本兜底识别 + 留痕「未标类型」 ==')
    reset_db()
    rv4 = make_card(TEST_DB, '【0823-govtest-7b-4】【验收】未标类型验收（文本兜底）',
                    task_kind=None)
    block_card(TEST_DB, rv4, '【验收不通】FAIL：yyy 项不达标', kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv4))
    check('未标类型：文本兜底识别并派修', count_by_title(TEST_DB, '%7b-4%') == 3,
          f'cards={count_by_title(TEST_DB, "%7b-4%")}')  # 原卡+修复+复验
    reasons = skip_reasons(state, rv4)
    check('skip_log 留痕「未标类型，文本兜底判定」',
          any('未标类型，文本兜底判定' in r for r in reasons), f'reasons={reasons}')
    n_before = count_by_title(TEST_DB, '%7b-4%')
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv4))
    check('未标兜底派修后幂等（二次扫描不重复）',
          count_by_title(TEST_DB, '%7b-4%') == n_before)

    # ═══════════════ 场景 4b：回归——疑似验收卡兜底（gov-6 路径保留） ═══════════════
    print('\n== 场景 4b：回归——NULL + 无验收标记 + FAIL reason → 疑似验收卡留痕不派修 ==')
    reset_db()
    rv4b = make_card(TEST_DB, '【0823-govtest-7b-4b】普通任务（无任何标记）', task_kind=None)
    block_card(TEST_DB, rv4b, '需要外部资源 FAIL，稍后重试', kind='needs_input')
    state = fresh_state()
    gov._r1_consider(ro(TEST_DB), state, get_task(TEST_DB, rv4b))
    check('疑似验收卡兜底：不派修', count_by_title(TEST_DB, '%7b-4b%') == 1)
    reasons = skip_reasons(state, rv4b)
    check('疑似验收卡留痕可见', any('疑似验收卡未确认' in r for r in reasons),
          f'reasons={reasons}')

    # ═══════════════ 场景 5：R2 字段优先不误伤 ═══════════════
    print('\n== 场景 5：R2——父验收卡 task_kind=ops（title 含验收）→ 不收口 + 留痕 ==')
    reset_db()
    p = make_card(TEST_DB, '【0823-govtest-7b-5】【验收】父卡（字段=ops）',
                  task_kind='ops', status='blocked')
    f = make_card(TEST_DB, '【govern-fix】修复卡', assignee='make', task_kind='fix',
                  status='done')
    r = make_card(TEST_DB, '【govern-复验】复验卡', task_kind='review', status='done',
                  body=f'govern-review: {p}\ngovern-role: rereview\n复验通过。')
    link_child(TEST_DB, f, r)
    state = fresh_state()
    gov._r2_consider(ro(TEST_DB), state, get_task(TEST_DB, r))
    check('R2 字段优先不误伤：父卡 task_kind=ops 保持 blocked',
          get_task(TEST_DB, p)['status'] == 'blocked')
    reasons = skip_reasons(state, r)
    check('R2 留痕「字段判定非验收卡（task_kind=ops）」',
          any('字段判定非验收卡（task_kind=ops）' in x for x in reasons),
          f'reasons={reasons}')

    # ═══════════════ 场景 6：R2 未标兜底路径 ═══════════════
    print('\n== 场景 6：R2——父验收卡 task_kind=NULL（title 含验收）→ 文本兜底收口 + 留痕 ==')
    reset_db()
    p6 = make_card(TEST_DB, '【0823-govtest-7b-6】【验收】未标类型父卡',
                   task_kind=None, status='blocked')
    f6 = make_card(TEST_DB, '【govern-fix】修复卡6', assignee='make', task_kind='fix',
                   status='done')
    r6 = make_card(TEST_DB, '【govern-复验】复验卡6', task_kind='review', status='done',
                   body=f'govern-review: {p6}\ngovern-role: rereview\n复验通过。')
    link_child(TEST_DB, f6, r6)
    state = fresh_state()
    gov._r2_consider(ro(TEST_DB), state, get_task(TEST_DB, r6))
    check('R2 未标兜底：父卡自动收口 done', get_task(TEST_DB, p6)['status'] == 'done')
    reasons = skip_reasons(state, r6)
    check('R2 留痕「未标类型，文本兜底判定」',
          any('未标类型，文本兜底判定' in x for x in reasons), f'reasons={reasons}')

    # 清理测试文件
    for f in (TEST_DB, TEST_DB + '-wal', TEST_DB + '-shm', TEST_STATE,
              TEST_STATE + '.govern-tmp'):
        if os.path.exists(f):
            os.remove(f)

    print(f'\n========== 结果: {PASS} 通过 / {FAIL} 失败 ==========')
    sys.exit(1 if FAIL else 0)


if __name__ == '__main__':
    main()
