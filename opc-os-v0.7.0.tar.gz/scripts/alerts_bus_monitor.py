#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
alerts_bus_monitor —— OPC 告警路由 cron 的 monitor_script（t_x2 交付物）
=========================================================================
方案：/home/gavin/.hermes/opc/reports/2026-08-27-alert-auto-loop.md

职责（每 5min tick，make profile opc-alert-router cron 的 monitor 模式）：
  读告警总线 status=new 条目 → 输出「未处理告警指纹集合」稳定摘要。
  - 无 new 且不在汇总窗口 → stdout 空 → monitor hash 不变 → 0 token 静默
  - 有新告警 → 摘要变化 → MONITOR CHANGE DETECTED → 路由 agent 醒来分级建卡
  - 未处理告警 age>2h → 行尾 [STALE>2h] 标记 → 唤醒 agent 自监控
    （防路由 agent 静默挂：2h 无路由 = 异常信号）
  - 每日 18:50 汇总窗口（18:48-18:59）→ 输出 # daily-summary-window
    → 唤醒 agent 生成当日告警汇总文件（供 19:00 日报引用）

hash 稳定性红线（monitor 机制核心）：
  - 输出不含时间戳/随机序/易变字段；同一批告警未变化时输出逐字节一致
  - 同 fingerprint 多条 → 取最新一条代表；按 fingerprint 排序
  - STALE 为二元标记（2h 后一直 stale），不输出具体 age
  - 汇总窗口标记为固定字符串（同日内稳定，跨日变化属预期）

测试钩子：环境变量 OPC_NOW='YYYY-MM-DD HH:MM:SS' 可覆盖当前时间（验收用）。
"""
import json
import os
import sys
from datetime import datetime

BUS_FILE = "/home/gavin/.hermes/opc/alerts/bus.jsonl"
STALE_HOURS = 2.0
SUMMARY_WINDOW_START = (18, 48)   # 窗口起点（含）
SUMMARY_WINDOW_END = (19, 0)      # 窗口终点（不含）


def _now() -> datetime:
    ov = os.environ.get("OPC_NOW")
    if ov:
        try:
            return datetime.strptime(ov, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            pass
    return datetime.now()


def _parse_ts(s):
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def _load_new():
    if not os.path.exists(BUS_FILE):
        return []
    rows = []
    try:
        with open(BUS_FILE, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if r.get("status") == "new":
                    rows.append(r)
    except OSError:
        return []
    return rows


def main():
    now = _now()
    rows = _load_new()

    # 每日汇总窗口：无 new 也要唤醒 agent 生成汇总（19:00 日报依赖）
    in_window = SUMMARY_WINDOW_START <= (now.hour, now.minute) < SUMMARY_WINDOW_END
    if not rows:
        if in_window:
            print(f"# daily-summary-window {now.strftime('%Y-%m-%d')}")
        return 0

    # 按 fingerprint 聚合 → 取最新条目代表（hash 稳定性）
    by_fp = {}
    for r in rows:
        fp = r.get("fingerprint")
        if not fp:
            fp = f"{r.get('source', '?')}:{r.get('type', '?')}:{now.strftime('%Y-%m-%d')}"
        cur = by_fp.get(fp)
        r_ts = _parse_ts(r.get("ts")) or datetime.min
        cur_ts = _parse_ts(cur.get("ts")) or datetime.min if cur else datetime.min
        if cur is None or r_ts > cur_ts:
            by_fp[fp] = r

    lines = [f"# alerts-bus unhandled ({len(by_fp)})"]
    for fp in sorted(by_fp):
        r = by_fp[fp]
        ts = _parse_ts(r.get("ts"))
        stale = ""
        if ts and (now - ts).total_seconds() > STALE_HOURS * 3600:
            stale = " [STALE>2h]"
        title = (r.get("title") or "").replace("|", "/").replace("\n", " ").strip()
        sev = r.get("severity", "P1")
        lines.append(f"{fp} | {sev} | {title}{stale}")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
