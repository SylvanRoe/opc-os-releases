#!/usr/bin/env python3
"""OPC OS — 共享配置加载器

opc_collect.py / token_stats.py 的参数化基座：所有本机路径、profile 名册、
CRON_MEMBER 映射、角色/英文名表统一从 config.json 读取，零硬编码。

配置来源（优先级从高到低）：
  1. CLI --config <path>
  2. 环境变量 OPC_OS_CONFIG（容器内由 docker-compose environment 注入；
     customer 形态 entrypoint_collector.sh 会把 OPC_OS_CONFIG 切到卷内
     /data/config/config.json —— opc-init 生成的客户 config，paths 全指卷内）
  3. 脚本所在目录的 ../config/config.json（部署包内自动发现）
  4. 内建默认值（= 原 opc_collect.py / token_stats.py 的本机硬编码，兼容直跑）

31c paths 语义确认（customer 形态）：
  - opc-init 生成的 config.json paths 全部指向卷内 /data（hermes_home=/data/hermes-home、
    opc_dir=/data、kanban_db=/data/kanban.db、out_status=/data/status.json 等，
    见 scripts/opc_init.py gen_config()；31b 已验证 lib_config 兼容全过）。
  - 容器内 DEFAULT 的宿主硬编码（~/.hermes 等）只在「无 config.json 直跑」时兜底；
    有 config.json 时 paths 深层合并、客户 config 全字段覆盖 → 无硬编码残留。
  - self 形态（bind 宿主 .hermes → /data/hermes-home）与 customer 形态（卷内自持）
    共用同一套 paths 语义：hermes_home 指向的 profiles/ 由 collector 读取。

config.json 顶层结构（collector 节）：
{
  "collector": {
    "profiles": ["zhuangzi", ...],                     # 成员 profile 列表
    "cron_member": {"<jobname>": ["<中文名>", "<动作>", "<描述>"], ...},
    "name_id":    {"<中文名>": "<profile id>", ...},
    "name_en":    {"<profile id>": "<英文名>", ...},
    "roles":      {"<中文名>": "<中文角色>", ...},
    "role_en":    {"<中文角色>": "<英文角色>", ...},
    "paths": {
      "hermes_home":      "<数据源根目录>",   # 含 profiles/ 与共享 state.db
      "opc_dir":          "<state.json 所在目录>",
      "kanban_db":        "<正式 kanban.db 路径>",
      "demo_kanban_db":   "<demo kanban.db 路径（可空）>",
      "out_status":       "<status.json 输出路径>",
      "out_status_secondary": "<第二输出路径（可空，原双路径输出用）>",
      "state_db":         "<共享 state.db 路径（token_stats 用）>",
      "token_stats_out":  "<token-stats.json 输出路径>",
      "publish_copy":     "<发布副本路径（可空）>",
      "usage_audit_dir":  "<cron usage_audit 目录（可空，默认 <hermes_home>/profiles/<p>/cron/usage_audit.jsonl）>"
    },
    "running_since": "2026-08-12"                      # 运行天数起点（status.json running_days）
  },
  "bus": {                                              # 27e：数据总线守护配置（opc-bus.py 读取）
    "poll_seconds": 1.0,                                # 轮询间隔秒（Gavin 拍板 #2）
    "kanban_db": "<kanban.db 路径，默认 paths.kanban_db>",
    "status_out": "<status.json 输出路径，默认 paths.out_status；字符串或数组>",
    "status_out_secondary": "<第二输出路径，默认 paths.out_status_secondary，可空>",
    "bus_state_file": "<水位线文件，默认 <paths.opc_dir>/bus-state.json>",
    "skip_kinds": ["heartbeat"]                         # 忽略的事件 kind 列表
  },
  "govern": {                                           # 0823：治理规则引擎守护配置（opc-govern.py 读取）
    "poll_seconds": 2.0,                                # 事件轮询间隔秒
    "scan_seconds": 15.0,                               # 定时全表扫描间隔秒（0=禁用）
    "kanban_db": "<kanban.db 路径，默认 paths.kanban_db>",
    "state_file": "<水位线/已处理记录文件，默认 <paths.opc_dir>/govern-state.json>",
    "review_mark": "【验收】",                           # 验收卡约定标记（title/body 命中即算）
    "rereview_mark": "复验",                             # 复验卡标题标记（legacy 回退用）
    "fail_keywords": ["验收不通", "验收未通过", "验收不合格", "FAIL", "未通过", "fail"],
    "r1_enabled": true,                                 # R1 验收 FAIL 自动派修（D2 拍板全自动）
    "r2_enabled": true,                                 # R2 复验 done 自动收口（D1 拍板自动）
    "fix_assignee": "make",                             # R1 修复卡 assignee
    "rereview_assignee": "ada",                         # R1 复验卡 assignee
    "blocked_kinds": ["needs_input", ""],               # 参与 R1 的 block kind（""=legacy 无类型）
    "author": "opc-govern"                              # 评论/事件作者名
  }
}
"""
import json
import os

# 内建默认 = 原脚本本机硬编码（兼容直跑模式；部署容器必须显式配 config.json）
# 脱敏红线：默认名册一律用「演示X / Demo X」演示名（与 config/config.json 口径一致），
# 禁止写真名——无 config.json 直跑时 DEFAULT_NAME=name_id 首项会直接进输出。
DEFAULT = {
    'profiles': ['zhuangzi', 'make', 'anran', 'linjing', 'wenwen', 'qianli',
                 'panming', 'ada', 'iris'],
    'cron_member': {
        'opc-daily-report': ('演示CEO', 'meet', '日报汇总'),
        'opc-weekly-review': ('演示CEO', 'meet', '周报复盘'),
        'zhuangzi-mainloop': ('演示CEO', 'meet', '经营决策派活'),
        'make-mainloop': ('演示开发', 'work', '领活写代码'),
        'anran-inspect': ('演示运维', 'monitor', '生命线巡检'),
        'anran-mainloop': ('演示运维', 'monitor', '故障处理'),
        'mrd-daily-backup': ('演示运维', 'work', '数据备份'),
        'four-platform-monitor': ('演示营销', 'monitor', '渠道推广监控'),
        'juejin-article-track': ('演示营销', 'write', '内容数据追踪'),
        'linjing-mainloop': ('演示营销', 'write', '推广研判复盘'),
        'wenwen-mainloop': ('演示客服', 'talk', '客户线索跟进'),
        'qianli-mainloop': ('演示财务', 'work', '记账对账'),
        'panming-mainloop': ('演示情报', 'monitor', '竞品情报'),
        'ada-mainloop': ('演示测试', 'work', '测试验收'),
        'iris-mainloop': ('演示设计', 'work', '设计走查'),
    },
    'name_id': {'演示CEO': 'zhuangzi', '演示开发': 'make', '演示运维': 'anran',
                '演示营销': 'linjing', '演示客服': 'wenwen', '演示财务': 'qianli',
                '演示情报': 'panming', '演示测试': 'ada', '演示设计': 'iris'},
    'name_en': {'zhuangzi': 'Demo CEO', 'make': 'Demo Dev', 'anran': 'Demo Ops',
                'linjing': 'Demo Mkt', 'wenwen': 'Demo CS', 'qianli': 'Demo Fin',
                'panming': 'Demo Intel', 'ada': 'Demo QA', 'iris': 'Demo UX'},
    'roles': {'演示CEO': 'CEO/主控', '演示开发': '开发/产品', '演示运维': '运维',
              '演示营销': '营销/内容', '演示客服': '客服', '演示财务': '财务',
              '演示情报': '竞品情报', '演示测试': '测试/验收', '演示设计': 'UI/UX 设计'},
    'role_en': {
        'CEO/主控': 'CEO / Chief', 'CEO': 'CEO',
        '开发/产品': 'Dev / Product', '开发': 'Dev',
        '运维': 'Ops', '营销/内容': 'Marketing / Content', '营销': 'Marketing',
        '客服': 'Support', '财务': 'Finance',
        '竞品情报': 'Intel', '竞品': 'Intel',
        '测试': 'QA', '测试/验收': 'QA',
        'UI/UX设计': 'UI/UX', 'UI/UX 设计': 'UI/UX', 'UI/UX': 'UI/UX',
    },
    'paths': {
        'hermes_home': os.path.expanduser('~/.hermes'),
        'opc_dir': os.path.expanduser('~/.hermes/opc'),
        'kanban_db': os.path.expanduser('~/.hermes/kanban/boards/opc/kanban.db'),
        'demo_kanban_db': os.path.expanduser('~/.hermes/kanban/boards/demo/kanban.db'),
        'out_status': os.path.expanduser(
            '~/hermes_space/marketingdashboard/public/company/opc/status.json'),
        'out_status_secondary': os.path.expanduser(
            '~/hermes_space/marketingdashboard/dist/company/opc/status.json'),
        'state_db': os.path.expanduser('~/.hermes/state.db'),
        'token_stats_out': os.path.expanduser('~/.hermes/opc/token-stats.json'),
        'publish_copy': os.path.expanduser(
            '~/hermes_space/company-site/opc/token-stats.json'),
        'usage_audit_dir': '',
    },
    'running_since': '2026-08-12',
    # 0823 gov-3：治理规则引擎默认（opc-govern.py 读取；宿主直跑即本机路径）
    'govern': {
        'poll_seconds': 2.0,
        'scan_seconds': 15.0,
        'kanban_db': '',  # 空 → paths.kanban_db
        'state_file': '',  # 空 → <paths.opc_dir>/govern-state.json
        'review_mark': '【验收】',
        'rereview_mark': '复验',
        'fail_keywords': ['验收不通', '验收未通过', '验收不合格', 'FAIL', '未通过', 'fail'],
        'r1_enabled': True,
        'r2_enabled': True,
        'r4_enabled': True,  # R4 高风险动作审批校验（吸收-2a，2026-08-23）
        'fix_assignee': 'make',
        'rereview_assignee': 'ada',
        'blocked_kinds': ['needs_input', ''],
        'author': 'opc-govern',
    },
}


def find_config():
    """返回配置路径（存在才返回），否则 None。"""
    for cand in (os.environ.get('OPC_OS_CONFIG'),
                 os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              '..', 'config', 'config.json')):
        if cand and os.path.exists(cand):
            return cand
    return None


def load_config():
    """加载并合并配置。返回 dict（collector 节展开后的扁平结构）。

    合并语义：普通键完全替换（config.json 是权威）；仅 paths 深层合并
    （允许用户只覆盖部分路径，未覆盖子键沿用默认）。
    """
    merged = json.loads(json.dumps(DEFAULT))  # deep copy
    cfg_path = find_config()
    if cfg_path:
        try:
            with open(cfg_path, encoding='utf-8') as f:
                raw = json.load(f)
            coll = raw.get('collector', raw)  # 兼容顶层直接是 collector 结构
            for k, v in coll.items():
                if k == 'paths' and isinstance(v, dict) and isinstance(merged.get('paths'), dict):
                    merged['paths'].update(v)
                else:
                    merged[k] = v
            # 27e：顶层 bus 段（数据总线守护配置）透传进 merged——collector 循环只展开 collector 节，
            # bus 是顶层兄弟键，需显式透传，否则 opc-bus.py / opc_collect.py 读不到（回退默认值）。
            if 'bus' in raw and isinstance(raw['bus'], dict):
                merged['bus'] = raw['bus']
            # 0823：顶层 govern 段（治理规则引擎守护配置）同理透传（opc-govern.py 读取）。
            if 'govern' in raw and isinstance(raw['govern'], dict):
                merged['govern'] = raw['govern']
        except Exception as e:
            print(f'[opc-os] 警告: config.json 加载失败 ({cfg_path}): {e}；使用内建默认', file=__import__('sys').stderr)
    return merged


_CACHE = None


def get_cfg():
    """进程级缓存单例。"""
    global _CACHE
    if _CACHE is None:
        _CACHE = load_config()
    return _CACHE


if __name__ == '__main__':
    import sys
    cfg = get_cfg()
    print('config source:', find_config() or '(builtin default)')
    print('profiles:', cfg['profiles'])
    print('paths:', json.dumps(cfg['paths'], ensure_ascii=False, indent=2))
