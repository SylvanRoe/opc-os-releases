#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""opc-os 升级机制自测（t_640159de 交付物，2026-08-27）

覆盖 DoD 前置 4 项：
  1. check-update：mock 远端（OPC_UPDATE_CHECK_URL 指向本地 mock）→ 检测新版 →
     update-available.json 生成 + alert-bus 落点；远端不可达 → 静默退出 0
  2. upgrade：临时目录模拟 git 形态部署 → --to 本地 mock tag 升级 → smoke 全绿 →
     upgrade.log 正确；注入冒烟失败（OPC_UPGRADE_CHECK_DRY=1）→ 自动回滚 → 数据一致
  3. backup 扩展：--data-dir 造 7 文件 → 备份含 7 文件；缺核心文件 → 非 0 退出；
     缺配置文件 → 警告继续
  4. opc_init.py --version 仍正常输出（从 VERSION 文件读取）

注意：全部在临时目录执行，零污染生产（参照 test_alert_bus.py 模式）。
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

_WS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.normpath(os.path.join(_WS, ".."))

PASS = 0
FAIL = 0
TMP: str = ""


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ {name} {extra}")


def run(args, env=None, cwd=None):
    """运行子进程，返回 CompletedProcess。"""
    e = dict(os.environ)
    if env:
        e.update(env)
    return subprocess.run(args, capture_output=True, text=True, env=e, cwd=cwd)


def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


# ============================================================ mock git 部署
def make_mock_repo(base, ver_old="0.5.0", ver_new="0.6.0"):
    """构造 git 形态部署 mock：
    - 初始 VERSION=ver_old + 脚本骨架 → commit → tag v<ver_old>
    - VERSION 改 ver_new → commit → tag v<ver_new>
    返回 (repo_dir, data_dir)。
    """
    repo = os.path.join(base, "repo")
    scripts = os.path.join(repo, "scripts")
    for d in (scripts,):
        os.makedirs(d, exist_ok=True)
    write(os.path.join(repo, "VERSION"), ver_old + "\n")
    # 脚本骨架（stub：install-services 幂等成功、smoke 全绿）
    write(os.path.join(scripts, "opc-bus.py"), "#!/usr/bin/env python3\nprint('mock opc-bus')\n")
    write(os.path.join(scripts, "install-services.sh"),
          "#!/bin/bash\n# mock install-services（幂等成功）\nexit 0\n")
    write(os.path.join(scripts, "smoke_test.sh"),
          "#!/bin/bash\n# mock smoke（全绿）\necho '37/37 ALL GREEN'\nexit 0\n")
    # 真实脚本拷贝（升级机制本体重放 mock 仓内自测）
    for f in ("opc-os-upgrade.sh", "opc-os-check-update.py", "backup.sh"):
        shutil.copy(os.path.join(_WS, f), os.path.join(scripts, f))
    for f in ("opc-os-upgrade.sh", "install-services.sh", "smoke_test.sh"):
        os.chmod(os.path.join(scripts, f), 0o755)

    def git(*args):
        r = subprocess.run(["git", "-C", repo] + list(args),
                           capture_output=True, text=True)
        assert r.returncode == 0, f"git {' '.join(args)} 失败: {r.stderr}"

    git("init", "-q", "-b", "main")
    git("config", "user.email", "test@opc.local")
    git("config", "user.name", "test")
    git("add", "-A")
    git("commit", "-qm", f"v{ver_old}")
    git("tag", f"v{ver_old}")
    # 升级版
    write(os.path.join(repo, "VERSION"), ver_new + "\n")
    git("add", "-A")
    git("commit", "-qm", f"v{ver_new}")
    git("tag", f"v{ver_new}")

    # 数据目录（7 文件集）
    data = os.path.join(base, "data")
    for f in ("kanban.db", "status.json", "token-stats.json", "state.json",
              "gateway.config.json", "bus-state.json", "govern-state.json"):
        write(os.path.join(data, f), f"mock-{f}-data\n")
    # 网关配置在生产形态在 <data>/llm-gateway/ 下 —— backup.sh 会按此解析
    write(os.path.join(data, "llm-gateway", "gateway.config.json"), "mock-gateway-config\n")
    return repo, data


def deploy_at(repo, ver):
    """模拟已部署的旧版本：checkout 到 v<ver> tag（mock 仓 HEAD 默认在新版）。"""
    r = subprocess.run(["git", "-C", repo, "checkout", "-q", f"v{ver}"],
                       capture_output=True, text=True)
    assert r.returncode == 0, f"checkout v{ver} 失败: {r.stderr}"


def base_env(repo, state, data, **extra):
    env = {
        "OPC_OS_REPO": repo,
        "OPC_OS_STATE_DIR": state,
        "OPC_ALERT_DIR": os.path.join(state, "alerts"),
    }
    if data:
        env["OPC_DATA_DIR"] = data
    env.update(extra)
    return env


# ============================================================ 测试 1：check-update
def test_check_update():
    print("1) check-update：mock 远端 → 检测新版 → 双落点通知")
    base = os.path.join(TMP, "t1")
    repo, data = make_mock_repo(base)
    # 注意：make_mock_repo 里 VERSION 已是 0.6.0（新版）——为测"检测到更新"，
    # 把本地 VERSION 降回 0.5.0（模拟已部署旧版）
    write(os.path.join(repo, "VERSION"), "0.5.0\n")
    state = os.path.join(base, "state")
    mock_api = os.path.join(base, "mock-latest.json")
    write(mock_api, json.dumps(
        {"tag_name": "v0.6.0", "body": "升级机制核心：版本检查/通知/安全升级/回滚"}))
    env = base_env(repo, state, data, OPC_UPDATE_CHECK_URL="file://" + mock_api)
    r = run([sys.executable, os.path.join(_WS, "opc-os-check-update.py"),
             "--force", "--json"], env=env)
    check("退出码 0", r.returncode == 0, r.stderr)
    out = json.loads(r.stdout.strip().splitlines()[-1])
    check("update_available=true", out.get("update_available") is True, r.stdout)
    check("current=0.5.0", out.get("current") == "0.5.0", r.stdout)
    check("latest=0.6.0", out.get("latest") == "0.6.0", r.stdout)
    ua = os.path.join(state, "update-available.json")
    check("update-available.json 生成", os.path.exists(ua))
    if os.path.exists(ua):
        u = json.load(open(ua, encoding="utf-8"))
        check("schema 字段齐全", all(k in u for k in
              ("current", "latest", "changelog_summary", "detected_at")), str(u))
        check("changelog_summary 有内容", bool(u.get("changelog_summary")))
    # alert-bus 落点（OPC_ALERT_DIR 指向临时目录）
    bus = os.path.join(state, "alerts", "bus.jsonl")
    check("alert-bus 落点生成", os.path.exists(bus))
    if os.path.exists(bus):
        lines = [json.loads(l) for l in open(bus, encoding="utf-8") if l.strip()]
        hit = [x for x in lines if x.get("type") == "upgrade-available"]
        check("alert-bus 含 upgrade-available", len(hit) == 1, str(hit))
        if hit:
            check("alert-bus schema 含 current/latest",
                  "current" in hit[0].get("evidence", "") or hit[0]["title"])

    print("1b) check-update：远端不可达 → 静默退出 0")
    state2 = os.path.join(base, "state-offline")
    env2 = base_env(repo, state2, data, OPC_UPDATE_CHECK_URL="file:///nonexistent/xx.json")
    r2 = run([sys.executable, os.path.join(_WS, "opc-os-check-update.py"),
              "--force", "--json"], env=env2)
    check("退出码 0（静默）", r2.returncode == 0, r2.stderr)
    out2 = json.loads(r2.stdout.strip().splitlines()[-1])
    check("update_available=false（离线）", out2.get("update_available") is False)
    check("不生成 update-available.json", not os.path.exists(os.path.join(state2, "update-available.json")))
    check("last-check.json 记录", os.path.exists(os.path.join(state2, "last-check.json")))


# ============================================================ 测试 2：upgrade
def test_upgrade():
    print("2) upgrade：临时 git 形态部署 → --to 升级 → smoke 全绿 → upgrade.log")
    base = os.path.join(TMP, "t2")
    repo, data = make_mock_repo(base)
    deploy_at(repo, "0.5.0")   # 模拟已部署 0.5.0（HEAD 指向 v0.5.0）
    state = os.path.join(base, "state")
    env = base_env(repo, state, data, OPC_SMOKE_SKIP_SYSTEMCTL="1")
    up = os.path.join(repo, "scripts", "opc-os-upgrade.sh")
    r = run(["bash", up, "--to", "0.6.0"], env=env)
    check("升级退出码 0", r.returncode == 0, r.stderr + r.stdout)
    with open(os.path.join(repo, "VERSION")) as f:
        check("VERSION 已到 0.6.0", f.read().strip() == "0.6.0")
    log = os.path.join(state, "upgrade.log")
    check("upgrade.log 生成", os.path.exists(log))
    if os.path.exists(log):
        line = open(log, encoding="utf-8").read().strip().splitlines()[-1]
        entry = json.loads(line)
        check("upgrade.log 字段 {ts,from,to,result}",
              all(k in entry for k in ("ts", "from", "to", "result")), line)
        check("from=0.5.0 to=0.6.0 result=ok",
              entry.get("from") == "0.5.0" and entry.get("to") == "0.6.0"
              and entry.get("result") == "ok", line)
    # 数据一致：备份目录含 7 文件
    bdir = os.path.join(state, "backups")
    dates = [d for d in os.listdir(bdir) if d[:4].isdigit()] if os.path.isdir(bdir) else []
    check("备份目录存在", len(dates) >= 1, str(dates))
    if dates:
        files = set(os.listdir(os.path.join(bdir, sorted(dates)[-1])))
        check("备份含核心 4 + 配置 3 = 7 文件",
              len(files) == 7 and "kanban.db" in files and "gateway.config.json" in files
              and "bus-state.json" in files and "govern-state.json" in files, str(files))

    print("2b) 注入冒烟失败 → 自动回滚 → 数据一致")
    base2 = os.path.join(TMP, "t2b")
    repo2, data2 = make_mock_repo(base2)
    deploy_at(repo2, "0.5.0")
    state2 = os.path.join(base2, "state")
    # 模拟升级过程中数据目录被改过（升级前备份了旧值）
    write(os.path.join(data2, "kanban.db"), "newer-data-written-during-upgrade\n")
    env2 = base_env(repo2, state2, data2, OPC_UPGRADE_CHECK_DRY="1",
                    OPC_SMOKE_SKIP_SYSTEMCTL="1")
    r2 = run(["bash", os.path.join(repo2, "scripts", "opc-os-upgrade.sh"),
              "--to", "0.6.0"], env=env2)
    check("冒烟失败 → 非 0 退出", r2.returncode != 0, f"rc={r2.returncode}")
    with open(os.path.join(repo2, "VERSION")) as f:
        check("VERSION 回滚回 0.5.0", f.read().strip() == "0.5.0")
    head = subprocess.run(["git", "-C", repo2, "rev-parse", "--short", "HEAD"],
                          capture_output=True, text=True).stdout.strip()
    tags = subprocess.run(["git", "-C", repo2, "tag", "--points-at", head],
                          capture_output=True, text=True).stdout.strip()
    check("HEAD 回滚到 v0.5.0", "v0.5.0" in tags, f"head={head} tags={tags}")
    with open(os.path.join(data2, "kanban.db")) as f:
        content = f.read()
        check("数据一致（kanban.db 内容未破坏）", "mock-kanban.db-data" in content
              or "newer-data" in content)
    log2 = os.path.join(state2, "upgrade.log")
    check("回滚不写成功 upgrade.log", not os.path.exists(log2)
          or json.loads(open(log2).read().strip().splitlines()[-1]).get("result") != "ok")

    print("2c) --dry-run：前置检查通过不落变更")
    base3 = os.path.join(TMP, "t2c")
    repo3, data3 = make_mock_repo(base3)
    deploy_at(repo3, "0.5.0")
    state3 = os.path.join(base3, "state")
    env3 = base_env(repo3, state3, data3, OPC_SMOKE_SKIP_SYSTEMCTL="1")
    r3 = run(["bash", os.path.join(repo3, "scripts", "opc-os-upgrade.sh"),
              "--to", "0.6.0", "--dry-run"], env=env3)
    check("dry-run 退出码 0", r3.returncode == 0, r3.stderr + r3.stdout)
    with open(os.path.join(repo3, "VERSION")) as f:
        check("dry-run 未改 VERSION（仍 0.5.0）", f.read().strip() == "0.5.0")
    check("dry-run 无 upgrade.log", not os.path.exists(os.path.join(state3, "upgrade.log")))


# ============================================================ 测试 3：backup 扩展
def test_backup():
    print("3) backup 扩展：7 文件集 / 缺核心中止 / 缺配置警告继续")
    base = os.path.join(TMP, "t3")
    data = os.path.join(base, "data")
    for f in ("kanban.db", "status.json", "token-stats.json", "state.json",
              "gateway.config.json", "bus-state.json", "govern-state.json"):
        write(os.path.join(data, f), f"mock-{f}\n")
    write(os.path.join(data, "llm-gateway", "gateway.config.json"), "gw\n")
    out = os.path.join(base, "backups")
    r = run(["bash", os.path.join(_WS, "backup.sh"),
             "--data-dir", data, "--out", out])
    check("7 文件备份退出码 0", r.returncode == 0, r.stderr)
    dates = [d for d in os.listdir(out) if d[:4].isdigit()]
    files = set(os.listdir(os.path.join(out, sorted(dates)[-1]))) if dates else set()
    check("备份含 7 文件", len(files) == 7, str(files))
    check("含 gateway.config.json", "gateway.config.json" in files)
    check("含 bus-state.json / govern-state.json",
          "bus-state.json" in files and "govern-state.json" in files)

    print("3b) 缺核心文件 → 非 0 退出 + 不残留半备份")
    data2 = os.path.join(base, "data2")
    for f in ("kanban.db", "status.json", "token-stats.json", "state.json"):
        write(os.path.join(data2, f), "x\n")
    os.remove(os.path.join(data2, "kanban.db"))   # 缺核心
    out2 = os.path.join(base, "backups2")
    r2 = run(["bash", os.path.join(_WS, "backup.sh"),
              "--data-dir", data2, "--out", out2])
    check("缺核心 → 非 0 退出", r2.returncode != 0, f"rc={r2.returncode}")
    today = os.path.join(out2, __import__("datetime").date.today().isoformat())
    check("半备份已清理", not os.path.exists(today) or not os.listdir(today))

    print("3c) 缺配置类文件 → 警告继续（退出 0）")
    data3 = os.path.join(base, "data3")
    for f in ("kanban.db", "status.json", "token-stats.json", "state.json"):
        write(os.path.join(data3, f), "x\n")
    out3 = os.path.join(base, "backups3")
    r3 = run(["bash", os.path.join(_WS, "backup.sh"),
              "--data-dir", data3, "--out", out3])
    check("缺配置 → 退出 0 继续", r3.returncode == 0, r3.stderr)
    dates3 = [d for d in os.listdir(out3) if d[:4].isdigit()]
    files3 = set(os.listdir(os.path.join(out3, sorted(dates3)[-1]))) if dates3 else set()
    check("备份含核心 4 文件", len(files3) == 4, str(files3))


# ============================================================ 测试 4：opc_init --version
def test_opc_init_version():
    print("4) opc_init.py --version（VERSION 文件读取）")
    r = run([sys.executable, os.path.join(REPO, "scripts", "opc_init.py"), "--version"])
    check("退出码 0", r.returncode == 0, r.stderr)
    check("输出含 0.6.0（VERSION 文件值）", "0.6.0" in r.stdout, r.stdout)
    check("输出格式 opc-init vX.Y.Z",
          r.stdout.strip().startswith("opc-init 0.6.0"), r.stdout)


# ============================================================ 测试 5：每日检查 cron 间隔（D3 契约）
def test_check_cron():
    print("5) install-services.sh 每日版本检查 cron 间隔（D3：interval env 可配）")
    # 从安装脚本里抽取 update_check_cron 函数，交给 bash 求值（真实产物）
    with open(os.path.join(_WS, "install-services.sh"), encoding="utf-8") as f:
        text = f.read()
    start = text.index("update_check_cron() {")
    end = text.index("}", text.index("esac", start)) + 1
    body = text[start:end]

    def val(inv):
        env = dict(os.environ)
        env.pop("OPC_UPDATE_CHECK_CRON", None)
        if inv is None:
            env.pop("OPC_UPDATE_CHECK_INTERVAL", None)
        else:
            env["OPC_UPDATE_CHECK_INTERVAL"] = inv
        r = subprocess.run(
            ["bash", "-c", body + "\nupdate_check_cron"],
            capture_output=True, text=True, env=env)
        return r.stdout.strip(), r.returncode

    cases = [
        ("默认(未设) → 每日 04:30", None, "30 4 * * *"),
        ("daily → 30 4 * * *", "daily", "30 4 * * *"),
        ("hourly → 15 * * * *", "hourly", "15 * * * *"),
        ("6h → 每 6 小时", "6h", "0 */6 * * *"),
        ("2d → 每 2 天 04:30", "2d", "30 4 */2 * *"),
        ("raw cron 透传", "0 3 * * 1", "0 3 * * 1"),
    ]
    for name, inv, want in cases:
        got, rc = val(inv)
        check(name, rc == 0 and got == want, f"got={got!r} rc={rc}")


def main():
    global TMP
    TMP = tempfile.mkdtemp(prefix="opc-os-upgrade-test-")
    print(f"测试目录: {TMP}")
    test_check_update()
    print()
    test_upgrade()
    print()
    test_backup()
    print()
    test_opc_init_version()
    print()
    test_check_cron()

    print(f"\n结果: {PASS} 通过 / {FAIL} 失败")
    if FAIL:
        print(f"临时目录保留: {TMP}")
    else:
        shutil.rmtree(TMP, ignore_errors=True)
        print("临时目录已清理")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
