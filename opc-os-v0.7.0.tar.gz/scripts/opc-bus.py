#!/usr/bin/env python3
"""OPC OS — 数据总线守护进程（里程碑 27e 打包版 + 27f + 29a + 30b，轨 A）

增量轮询 kanban.db task_events（水位线）→ 发现状态迁移事件 → 全量重算 status.json 的 kanban 段
（复用 opc_collect.collect_kanban，human_waiting 口径唯一实现，零漂移）→ 原子写（tmp + os.replace，
防 SSE fs.watch 半截读）。status.json 其他段原样保留，另写段级 sources 元数据。

27f（2026-08-22，三源一致性）：bus 与 collect 同口径——kanban 维度实时活动反映到 activities 段
与 members 段（复用 opc_collect.collect_kanban_work/done + build_members）。

29a（2026-08-22，bus 接管 kanban 驱动全状态）：refresh_status 由「merge 现有 display 活动」升级为
「与 collect main 逐行同构的全量重建」——collect_cron + collect_delegate + collect_kanban_done +
collect_kanban_work → epoch 倒序 → build_members（原始 epoch 活动）+ activity_items（前 60 展示）。
弃用 27f 的 merge_kanban_activities：其 'HH:MM' 字符串排序在跨午夜时把「昨日凌晨」记录排到
「昨日深夜」之上（实测 林静 action 漂移 done/monitor、活动流集合漂移），与 collect 的 epoch 排序
口径不一致；全量重建输入/输出与 collect 完全同源，零漂移（性能实测 ~150ms/次，事件驱动下可忽略）。
merge_kanban_activities/_act_ts 保留在 opc_collect.py（29b 裁剪）。

30b（2026-08-22，demo 板第二水位线 + demo 状态机接管，Gavin 拍板「bus 是系统底层架构、公共能力、
是轮子，不需要隔离；场景/数据可隔离，能力不隔离」）：新增 demo 板（独立隔离板）并行轮询——
独立水位线 demo_watermark 存 bus-state.json（与 kanban_watermark 平行；首启校准 MAX(id) 不重放历史），
demo 板非 heartbeat 事件到达 → refresh_demo_status() 全量重建 demo/status.json（<opc_dir>/demo/，
与 opc-api 的 DEMO_DIR 同构，tasks/history/presets 契约零改动，opc-api 零改）。状态机由 bus 接管：
worker 不再直写内部状态文件，只写报告文件 results/{demo_id}.md；dispatch 脚本建卡 body 中
「更新 status.json 改 running/completed」两步指令已移除，reconcile() 保留作 bus 挂掉的分钟级兜底。
红线：bus 不改 kanban.db schema / 不加触发器 / 不改 human_waiting 口径 / 不加 SSE 端点；
demo 板绝不与正式板混写。

30c（2026-08-22，demo 进度条与看板不同步修复，Gavin 实测 P0，30b 收尾遗漏）：30b 接管 demo
状态机时只接管了 demo/status.json（进度条源，事件驱动 ≤1s），漏了 status.json 的 kanban_demo
段（demo 看板源，仍由 collector 全量刷新）→ 窗口内进度条有 running、看板无 running 卡。
修复：①refresh_demo_status() 重建 demo/status.json 后同步重建各 status.json 副本的
kanban_demo 段（复用 collect_kanban 同口径零漂移，失败只 log 不阻塞 demo 水位线）；
②refresh_status() 正式板事件也顺带保鲜 kanban_demo 段（双保险）；③opc_collect.py
协调段对 kanban_demo 让位（existing 缺段回退全量兜底值）。
容器部署（D2）：本 fork 已按 30c 逻辑同步（bus A1/A2/A3 + collect 协调让位），py_compile
通过；容器镜像重建/重启部署动作超出本卡范围，按 opc-os 现有流程另行执行生效。

设计文档：~/.hermes/opc/opc-data-bus-design.md v1.2（§4 架构 + §4.2 伪码 + §4.3 同口径 + §5 打包边界，
Gavin 2026-08-21 拍板 ×4）：
- 轮询间隔 1s（拍板 #2）
- skip_kinds 事件不触发全量业务重算但心跳新鲜化须重算 members（3c-D1 修复）：非 skip 事件 → 全量刷新；
  heartbeat 事件 → 同样走 refresh_status（collect_kanban 每次全量查 task_runs 最新
  last_heartbeat_at，build_members 据此翻转 working/idle——新 spawned 的 running 卡首条心跳
  晚于 spawned 事件写入会被误判 idle+任务挂起，心跳到达必须重算才能点亮；events 记为 0）
- 水位线持久化 bus-state.json：重启不重放、不漏事件
- 首启（无 bus-state.json）：水位线校准到当前 MAX(id) + 主动刷新一次 kanban 段
  （status.json 由 opc_collect 10min 全量维护，首启时已是最新快照，无需重放历史事件）
- 红线：不改 kanban.db schema / 不加触发器 / 不拦截写路径 / 不加 SSE 端点 / 不改 human_waiting 口径

零硬编码：bus 段配置从 config.json 读取（与 opc_collect.py 参数化同风格，见 lib_config.py）——
  顶层 "bus" 段（缺省回退到 collector.paths，本地直跑兼容）：
    bus.poll_seconds         轮询间隔秒（默认 1.0；环境变量 OPC_BUS_POLL_SECONDS 可覆盖）
    bus.kanban_db            轮询的 kanban.db（默认 paths.kanban_db）
    bus.demo_kanban_db       轮询的 demo 板 kanban.db（默认 paths.demo_kanban_db；空则禁用 demo 轮询）
    bus.status_out           输出 status.json 路径：字符串或数组（默认 paths.out_status）
    bus.status_out_secondary 第二输出路径，可空（默认 paths.out_status_secondary）
    bus.bus_state_file       水位线文件（默认 <paths.opc_dir>/bus-state.json）
    bus.skip_kinds           跳过的事件 kind 列表（默认 ["heartbeat"]）
换机器/换团队 = 改 config.json 即可，脚本零改动。

27c 协调协议（段级写协调，与 opc_collect.py 配对）：bus 只写 status.json 的 kanban 段 +
sources.kanban 元数据；collect（10min 全量兜底）写其余段；两写方均原子写，段不重叠 → 最后写者胜，
不引入 fcntl.flock；collect 全量写盘后把 bus 水位线同步为当前 MAX(id)（只前进不回退，防重放双写）。
"""
import json
import os
import re
import sqlite3
import sys
import time
import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib_config import get_cfg  # noqa: E402  与 opc_collect.py 共享同一份 config.json（写协调同源）
from opc_collect import (collect_kanban, collect_cron, collect_delegate,  # noqa: E402
                         collect_kanban_done, collect_kanban_work,  # 29a: 与 collect main 同构的全量重建
                         build_members, activity_items, _name_of, _ceo_id,
                         server_time_payload)  # 0825-f 修复(P1): bus 段级写同源刷新 server_time

CFG = get_cfg()
P = CFG['paths']
B = CFG.get('bus') or {}  # config.json 顶层 bus 段（lib_config 展开后为扁平键）

KANBAN_DB = B.get('kanban_db') or P['kanban_db']
# 30b: demo 板（独立隔离板，mode=ro 只读；未配置 → demo 轮询禁用，bus 行为与旧版完全一致）
DEMO_KANBAN_DB = B.get('demo_kanban_db') or P.get('demo_kanban_db') or ''
# status_out 支持字符串或数组（多副本双写同款能力）；未配置回退 paths.out_status(+secondary)
_status_out = B.get('status_out') or P['out_status']
STATUS_OUT = [s for s in (_status_out if isinstance(_status_out, list) else [_status_out]) if s]
_secondary = B.get('status_out_secondary', P.get('out_status_secondary') or '')
if _secondary and _secondary not in STATUS_OUT:
    STATUS_OUT.append(_secondary)
BUS_STATE = B.get('bus_state_file') or os.path.join(P['opc_dir'], 'bus-state.json')
POLL_SECONDS = float(os.environ.get('OPC_BUS_POLL_SECONDS', B.get('poll_seconds', 1.0)))
SKIP_KINDS = list(B.get('skip_kinds') or ['heartbeat'])

_demo_err_ts = 0.0  # demo 轮询错误日志限流（同因连打只记首次，60s 内不重复刷屏）

# ── 30b: demo 数据目录与 opc-api 的 DEMO_DIR 同构（<opc_dir>/demo；宿主 ~/.hermes/opc/demo，容器 /data/demo）──
DEMO_DIR = os.path.join(P['opc_dir'], 'demo')
DEMO_STATUS_OUT = os.path.join(DEMO_DIR, 'status.json')
DEMO_RES_DIR = os.path.join(DEMO_DIR, 'results')
DEMO_PRESETS_FILE = os.path.join(DEMO_DIR, 'presets.json')
DEMO_HISTORY_MAX = 50

# demo 板 kanban 状态 → status.json demo 语义（与 opc-api demoStreamDiff 契约一致：
# queued/dispatched/running/completed/failed；created/dispatched 需 kanban_task_id 存在）
_DEMO_STATUS_MAP = {
    'todo': 'dispatched',
    'ready': 'dispatched',
    'claimed': 'running',
    'running': 'running',
    'done': 'completed',
    'blocked': 'failed',
    'failed': 'failed',
}


def log(msg):
    print('[%s] %s' % (datetime.datetime.now().strftime('%H:%M:%S'), msg), flush=True)


def load_state():
    """读水位线状态；文件缺失/损坏 → {}（触发首启校准）。"""
    try:
        with open(BUS_STATE, encoding='utf-8') as fh:
            s = json.load(fh)
        return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def save_state(kanban_watermark, demo_watermark=None):
    """水位线原子落盘（tmp + os.replace），bus 重启后从该处续读。

    30b: kanban_watermark 与 demo_watermark 双水位线平行持久化（旧文件只有
    kanban_watermark → demo_watermark 缺省触发首启校准，天然兼容）。
    tmp 后缀用 .bus-tmp（与 collect 的 .tmp 区分，防 10min 水位线同步与 1s 落盘撞名：
    collect 只写 kanban_watermark，若覆盖掉 bus 双键版本会丢 demo_watermark）。
    """
    tmp = BUS_STATE + '.bus-tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump({'kanban_watermark': kanban_watermark,
                   'demo_watermark': demo_watermark}, fh)
    os.replace(tmp, BUS_STATE)


def poll(db, watermark, skip_kinds):
    """只读连接拉取：①非 skip_kinds 新事件（触发判定，任务指定 SQL）；②当前 MAX(id)（水位线推进）。"""
    con = sqlite3.connect(f'file:{db}?mode=ro', uri=True, timeout=5)
    try:
        placeholders = ','.join('?' * len(skip_kinds))
        sql = ('SELECT id, task_id, kind, created_at FROM task_events '
               f'WHERE id > ? AND kind NOT IN ({placeholders}) ORDER BY id')
        rows = con.execute(sql, (watermark, *skip_kinds)).fetchall()
        max_id = con.execute('SELECT COALESCE(MAX(id), 0) FROM task_events').fetchone()[0]
    finally:
        con.close()
    return rows, max_id


def atomic_write(path, obj):
    """tmp + os.replace 原子写：SSE fs.watch 只会看到完整文件，杜绝半截读。

    tmp 后缀用 .bus-tmp：与 opc_collect / opc_demo_dispatch 的 '.tmp' 区分，
    防多写方（bus 1s / collect 10min / dispatch 分钟级）对同一文件撞名互删 tmp
    导致偶发 ENOENT（30b 实测：dispatch save_status 与 bus atomic_write 同名 .tmp 竞态）。
    """
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    tmp = path + '.bus-tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


_last_st_refresh = 0.0


def refresh_server_time():
    """0825-f 修复(P1): 空转期（无 kanban 事件/心跳）按节流保鲜 server_time。

    前端时钟校准源必须恒新鲜——bus 只在事件/心跳时走 refresh_status 全量写，
    空闲期若什么都不做, server_time 会退回到 collect 1m 全量写节奏（实测 80~122s），
    页面时钟再次滞后。此函数只更新 server_time 一个字段（不重算任何段），
    3s 节流防止空转时高频整写/SSE 广播刷屏。多副本（STATUS_OUT）全部同步。
    """
    global _last_st_refresh
    now = time.time()
    if now - _last_st_refresh < 3.0:
        return False
    _last_st_refresh = now
    written = 0
    for out in STATUS_OUT:
        try:
            with open(out, encoding='utf-8') as fh:
                status = json.load(fh)
        except Exception:
            continue  # 读不到（collect 正在写/文件暂缺）→ 跳过本文件，下一轮重试
        status['server_time'] = server_time_payload()
        atomic_write(out, status)
        written += 1
    return written > 0


def refresh_status(last_id, n_events):
    """重算 status.json kanban 段 + members/activities 段 + 段级 sources 元数据。

    29a（bus 接管 kanban 驱动全状态，2026-08-22）：与 collect main 逐行同构的全量重建——
    collect_cron/collect_delegate/collect_kanban_done/collect_kanban_work 四个采集函数
    （全部复用 opc_collect 现成实现，零新代码）→ epoch 倒序 → build_members（原始 epoch 活动，
    与 collect 完全同输入同函数）+ activity_items（前 60 展示）。kanban running 任务实时反映到
    members（status=active+action=work，多 running 取最近开工），任务 done 后 ≤1.5s 归位。
    弃用 27f 的 merge_kanban_activities（'HH:MM' 字符串排序跨午夜漂移，29a 实测修正）。
    state.json 读失败时跳过 members 重算（只刷 kanban+activities），下一轮重试，静默容错。
    其余段原样保留（多副本双写）。

    返回 True 表示至少一个文件成功写入（水位线可推进）；全部失败（如 collect 写窗口撞上）
    返回 False，由主循环不推进水位线、下一轮重试同一批事件。
    """
    now_iso = datetime.datetime.now().isoformat()
    # ── 29a: 全量重建 activities（与 collect main 同构，100% 口径零漂移）──
    activities = []
    collect_cron(activities)
    collect_delegate(activities)
    collect_kanban_done(activities)
    collect_kanban_work(activities)
    activities.sort(key=lambda a: -a['ts'])
    new_kanban = collect_kanban(KANBAN_DB)  # 全量重算 kanban 段（v1 策略：SQL 毫秒级，无性能问题）
    # ── 29a: members 段全量重算依赖团队名册；读失败则本轮只刷 kanban+activities ──
    team = None
    try:
        with open(os.path.join(P['opc_dir'], 'state.json'), encoding='utf-8') as fh:
            state = json.load(fh)
        team = list(state.get('team', []))
        ceo = state.get('company', {}).get('ceo', {})
        if ceo:
            ceo_name = ceo.get('name_zh') or _name_of(_ceo_id())
            team.insert(0, {'name_zh': ceo_name, 'role': 'CEO/主控'})
    except Exception:
        pass  # state.json 读失败：跳过 members 重算（只刷 kanban+activities），下一轮重试
    written = 0
    for out in STATUS_OUT:
        try:
            with open(out, encoding='utf-8') as fh:
                status = json.load(fh)
        except Exception:
            continue  # 读不到（collect 正在写/文件暂缺）→ 跳过本文件，靠后续事件补写
        if team is not None:
            status['members'] = build_members(team, activities, new_kanban)
        status['activities'] = activity_items(activities)
        status['kanban'] = new_kanban
        if DEMO_KANBAN_DB:  # 30c: 正式板事件也同步保鲜看板段（双保险；demo 未配置跳过）
            status['kanban_demo'] = collect_kanban(DEMO_KANBAN_DB)
        sources = status.get('sources')
        if not isinstance(sources, dict):
            sources = {}
        sources['kanban'] = {'ts': now_iso, 'watermark': last_id, 'events': n_events}
        status['sources'] = sources
        # 0825-f 修复(P1): bus 1s 高频写也刷新 server_time（与 collect 同源同口径）——
        # 旧设计只由 collect 全量写刷新（1m cron），前端每次刷新用陈旧 server_time
        # 重校准 → 页面时钟恒滞后于真实服务器时间（验收 FAIL 根因）
        status['server_time'] = server_time_payload()
        atomic_write(out, status)
        written += 1
    return written > 0


# ────────────────────────────── 30b: demo 板状态机接管 ──────────────────────────────

def _iso(epoch):
    """epoch 秒 → UTC ISO 字符串（bus 统一格式 +00:00，与 dispatch 脚本 now_iso 一致）。"""
    if not epoch:
        return None
    return datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc).isoformat()


def _demo_id_from_task(title, body):
    """从建卡 body（'demo_id: xxx'，优先）或标题（【demo】名称（demo_id），回退）提取 demo_id；
    非 demo 卡返回 None（隔离验证卡等，bus 跳过不污染 tasks/history）。"""
    if body:
        m = re.search(r'^demo_id:\s*(\S+)\s*$', body, re.MULTILINE)
        if m:
            return m.group(1)
    if title:
        m = re.search(r'（([^）]+)）', title)
        if m:
            return m.group(1)
    return None


def _load_demo_presets():
    """读 presets.json（opc-api 启动时同步的单一事实源）→ {name: task_id} 反向表。
    读失败 → {}（新任务 task_id 回退 'unknown'，历史任务走 old_t.task_id 保留）。"""
    try:
        with open(DEMO_PRESETS_FILE, encoding='utf-8') as fh:
            presets = json.load(fh)
        if not isinstance(presets, dict):
            return {}
        return {str(v.get('name', '')).strip(): k for k, v in presets.items()
                if isinstance(v, dict) and v.get('name')}
    except Exception:
        return {}


def _resolve_demo_task_id(old_t, title, presets_by_name):
    """demo 任务 task_id（预设 task_id）：历史条目保留旧值（口径稳定），新卡按标题预设名匹配，
    匹配不到 → 'unknown'。"""
    old = old_t.get('task_id')
    if old:
        return old
    if title:
        m = re.match(r'^【[^】]+】\s*([^（]+?)\s*（', title)
        if m:
            name = m.group(1).strip()
            if name in presets_by_name:
                return presets_by_name[name]
    return 'unknown'


def refresh_demo_status(last_id, n_events):
    """demo 板事件到达时全量重建 demo/status.json（30b，bus 接管 demo 状态机）。

    读 demo 板 tasks（mode=ro）→ kanban 语义映射到 demo 语义（tasks/history 结构兼容
    opc-api demoReadStatus/demoStreamDiff，零改 index.cjs）：
      todo/ready → dispatched（含 kanban_task_id）
      claimed/running → running + started_at=claimed 事件时间（tasks.started_at 即 claimed 时间）
      done → completed + finished_at=done 事件时间 + 结果文件 results/{demo_id}.md 存在性校验
             （文件不存在不算 completed，置 running 下轮重查）
      blocked/failed → failed + error（last_failure_error 或事件 kind）
      archived → 跳过（与旧口径一致，不进 tasks/history）
    保留现有 status.json 其他段（presets 等）与无卡条目（建卡前 queued / 建卡失败 failed）：
    全量重建不覆盖 board 之外的状态。history 归位：按 demo_id 去重、created_at 兜底回退
    started_at/finished_at、最近 50 条。原子写（tmp + os.replace）。
    失败静默容错：demo status.json 损坏 → 跳过下轮重试；demo 板读库失败 → 返回 False 不劣化。

    返回 True 表示写入成功（水位线可推进）。
    """
    if not DEMO_KANBAN_DB:
        return True  # demo 未配置：直接视为成功（水位线照推），不写不报错
    try:
        with open(DEMO_STATUS_OUT, encoding='utf-8') as fh:
            old = json.load(fh)
        if not isinstance(old, dict):
            old = {}
    except FileNotFoundError:
        old = {}  # 首启：文件还不存在 → 空基直接重建
    except Exception:
        return False  # 损坏/半截读 → 跳过本文件，下轮重试（不劣化）
    old_tasks = old.get('tasks')
    old_tasks = old_tasks if isinstance(old_tasks, dict) else {}

    presets_by_name = _load_demo_presets()
    try:
        con = sqlite3.connect(f'file:{DEMO_KANBAN_DB}?mode=ro', uri=True, timeout=5)
        try:
            rows = con.execute(
                'SELECT id, title, body, status, created_at, started_at, completed_at, '
                'last_failure_error FROM tasks').fetchall()
        finally:
            con.close()
    except Exception as e:
        log(f'demo board 读库失败（未初始化?）: {e}')
        return False

    new_tasks = {}
    for tid, title, body, kb_status, created_ts, started_ts, completed_ts, lfe in rows:
        if kb_status == 'archived':
            continue
        demo_id = _demo_id_from_task(title or '', body or '')
        if not demo_id:
            continue
        old_t = old_tasks.get(demo_id) or {}
        t = {
            'task_id': _resolve_demo_task_id(old_t, title or '', presets_by_name),
            'status': _DEMO_STATUS_MAP.get(kb_status, old_t.get('status', 'dispatched')),
            'kanban_task_id': tid,
        }
        if old_t.get('ip'):  # ip 是 API 侧缓存判定字段（同 IP + 同任务 + inflight 命中），必须保留
            t['ip'] = old_t['ip']
        t['created_at'] = old_t.get('created_at') or _iso(created_ts)
        if started_ts:
            t['started_at'] = _iso(started_ts)  # 语义: claimed 事件时间（tasks.started_at 即 claimed 时间）
        elif old_t.get('started_at'):
            t['started_at'] = old_t['started_at']
        if kb_status == 'done':
            if os.path.exists(os.path.join(DEMO_RES_DIR, f'{demo_id}.md')):
                t['status'] = 'completed'
                t['finished_at'] = _iso(completed_ts) or old_t.get('finished_at')
            else:
                t['status'] = 'running'  # 结果文件未落地：不算 completed，下轮重查（worker 先写报告再完成）
        elif t['status'] == 'failed':
            t['finished_at'] = _iso(completed_ts) or old_t.get('finished_at') or _iso(started_ts)
            t['error'] = (lfe or f'kanban 任务 {kb_status}')
        new_tasks[demo_id] = t

    # 保留 board 之外的条目（建卡前 queued / 建卡失败 failed，无 kanban_task_id）：重建不覆盖
    for did, t in old_tasks.items():
        if did not in new_tasks and not t.get('kanban_task_id'):
            new_tasks[did] = t

    # history 归位：终态（completed/failed）按 demo_id 去重、created_at 兜底回退、最近 50 条
    hist = []
    for did, t in new_tasks.items():
        st = t.get('status')
        if st not in ('completed', 'failed'):
            continue
        hist.append({
            'demo_id': did,
            'task_id': t.get('task_id'),
            'status': st,
            'created_at': t.get('created_at') or t.get('started_at') or t.get('finished_at'),
            'finished_at': t.get('finished_at'),
        })
    hist.sort(key=lambda h: str(h.get('created_at') or ''), reverse=True)
    hist = hist[:DEMO_HISTORY_MAX]

    out = dict(old)
    out['tasks'] = new_tasks
    out['history'] = hist
    sources = out.get('sources')
    if not isinstance(sources, dict):
        sources = {}
    sources['demo'] = {'ts': datetime.datetime.now().isoformat(),
                       'watermark': last_id, 'events': n_events}
    out['sources'] = sources
    atomic_write(DEMO_STATUS_OUT, out)
    # ── 30c: 同步重建各 status.json 副本的 kanban_demo 段（demo 看板源，与进度条秒级一致）──
    # Gavin 实测 P0（30b 收尾遗漏）：30b 只接管 demo/status.json，status.json kanban_demo 段
    # 仍由 collector 全量刷新 → 最长 1min 窗口内进度条有 running、看板无 running 卡。这里在
    # demo 板事件驱动重建链末端补写 kanban_demo 段（复用 collect_kanban 同口径零漂移）。
    # 单副本读/写失败（collect 写窗口撞上）跳过，下轮 demo 事件重试；demo 水位线照常推进。
    try:
        kd = collect_kanban(DEMO_KANBAN_DB)
        for _out in STATUS_OUT:
            try:
                with open(_out, encoding='utf-8') as fh:
                    st = json.load(fh)
                st['kanban_demo'] = kd
                atomic_write(_out, st)
            except Exception:
                pass
    except Exception as e:
        log(f'kanban_demo 段重建失败（不阻塞 demo 水位线）: {e}')
    return True


def main():
    log(f'opc-bus start (poll={POLL_SECONDS}s, db={KANBAN_DB}, out={len(STATUS_OUT)} file(s), '
        f'skip={SKIP_KINDS}, state={BUS_STATE}, demo_db={DEMO_KANBAN_DB or "(disabled)"})')
    state = load_state()
    watermark = state.get('kanban_watermark')
    if watermark is None:
        # 首启校准：水位线跳到当前 MAX(id)，不重放历史事件；并主动刷新一次 kanban 段 + sources 元数据
        _, max_id = poll(KANBAN_DB, 0, SKIP_KINDS)
        watermark = max_id
        save_state(watermark, state.get('demo_watermark'))
        if refresh_status(watermark, 0):
            log(f'first run: watermark calibrated to {watermark}, kanban segment stamped (no replay)')
        else:
            log(f'first run: watermark calibrated to {watermark}, stamp deferred (status.json busy)')
    else:
        log(f'resume: watermark={watermark} (no replay)')

    # ── 30b: demo 板独立水位线（与 kanban_watermark 平行；首启校准 MAX(id) 不重放历史）──
    demo_watermark = state.get('demo_watermark')
    if DEMO_KANBAN_DB:
        if demo_watermark is None:
            try:
                _, dmax = poll(DEMO_KANBAN_DB, 0, SKIP_KINDS)
                demo_watermark = dmax
                save_state(watermark, demo_watermark)
                if refresh_demo_status(demo_watermark, 0):
                    log(f'demo first run: demo_watermark calibrated to {demo_watermark}, '
                        'demo status rebuilt (no replay)')
                else:
                    log(f'demo first run: demo_watermark calibrated to {demo_watermark}, '
                        'demo rebuild deferred')
            except Exception as e:
                log(f'demo board unavailable at start: {e} (retry in loop)')
        else:
            log(f'demo resume: demo_watermark={demo_watermark} (no replay)')

    while True:
        try:
            rows, max_id = poll(KANBAN_DB, watermark, SKIP_KINDS)
            if rows:
                last_id = rows[-1][0]
                if refresh_status(last_id, len(rows)):
                    watermark = last_id
                    save_state(watermark, demo_watermark)
                    log(f'events {len(rows)} (id {rows[0][0]}..{last_id}) -> kanban refreshed, watermark={watermark}')
                # refresh 失败：不推进水位线，下一轮重试同一批事件
            elif max_id > watermark:
                # 只有 skip_kinds 类新增（3c-D1 修复）：心跳新鲜化同样可能翻转 members 状态——
                # 新 spawned 的 running 卡首条心跳晚于 spawned 事件写入 → 曾被误判 idle+任务挂起，
                # 心跳到达后必须重算才能点亮 working。心跳也走 refresh_status（内部 collect_kanban
                # 每次全量查询 task_runs 最新 last_heartbeat_at，build_members 据此判定新鲜度）。
                # events 记为 0（无业务事件，纯心跳推进水位线）。
                if refresh_status(max_id, 0):
                    watermark = max_id
                    save_state(watermark, demo_watermark)
                    log(f'heartbeat-only (..{max_id}) -> status refreshed, watermark={watermark}')
                # refresh 失败：不推进水位线，下一轮重试同一批事件
            else:
                # 无新事件也无心跳推进：空转期仍须保鲜 server_time（0825-f 修复 P1——
                # 否则校准源退回到 collect 1m 全量写节奏，页面时钟重滞后；轻量写 + 3s 节流）
                refresh_server_time()
        except Exception as e:
            log(f'error(kanban): {e}')  # 静默容错（看门狗模式）：bus 挂/失败不劣化，collect 10min 兜底照旧

        if DEMO_KANBAN_DB:
            try:
                if demo_watermark is None:
                    # 启动时 demo 板不可用 → 循环内重试校准（同一批事件不重放）
                    _, dmax = poll(DEMO_KANBAN_DB, 0, SKIP_KINDS)
                    demo_watermark = dmax
                    save_state(watermark, demo_watermark)
                    refresh_demo_status(demo_watermark, 0)
                else:
                    drows, dmax = poll(DEMO_KANBAN_DB, demo_watermark, SKIP_KINDS)
                    if drows:
                        dlast = drows[-1][0]
                        if refresh_demo_status(dlast, len(drows)):
                            demo_watermark = dlast
                            save_state(watermark, demo_watermark)
                            log(f'demo events {len(drows)} (id {drows[0][0]}..{dlast}) '
                                f'-> demo status rebuilt, demo_watermark={demo_watermark}')
                        # demo rebuild 失败：不推进水位线，下一轮重试同一批事件
                    elif dmax > demo_watermark:
                        # 只有 skip_kinds 类新增：推进水位线但不触发重算
                        demo_watermark = dmax
                        save_state(watermark, demo_watermark)
            except Exception as e:
                global _demo_err_ts
                _now = time.time()
                if _now - _demo_err_ts >= 60:  # 限流：demo 板读失败/未初始化 → 静默容错，60s 内不刷屏
                    _demo_err_ts = _now
                    log(f'error(demo): {e}')

        time.sleep(POLL_SECONDS)


if __name__ == '__main__':
    main()
