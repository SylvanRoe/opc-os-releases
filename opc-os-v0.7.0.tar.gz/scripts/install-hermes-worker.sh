#!/usr/bin/env bash
# =============================================================================
# install-hermes-worker.sh — 客户 Hermes 运行时安装脚本（0825-init 交付物）
#
# 职责：在客户宿主机安装 hermes-agent fork（锁定 tag 的验证版本）+ 把
# opc-init 生成的 hermes-home（profiles 骨架）接入该 Hermes 实例：
#   - 安装 fork（来源二选一：GITHUB_TOKEN 拉私有仓 / --source 本地源码包）
#   - HERMES_HOME 指向客户 hermes-home（opc-init 输出目录下的 hermes-home/）
#   - 为每个 profile 用官方 `hermes config set` 写配置
#     （model.default=统一模型名 hermes-opc-v1、model.provider=custom:hermes-opc、
#      base_url=网关地址、model.api_key=${GATEWAY_CLIENT_TOKEN}（读自 llm.env）、
#      model.reasoning_echo=true（网关上游 kimi thinking 要求多轮回传 reasoning_content）、
#      custom_providers[].name=hermes-opc（0826-fix：custom: 前缀必须配 custom_providers 块，
#      否则 Hermes 报 Unknown provider 'custom:hermes-opc'）、
#      fallback_providers=[]、timezone）
#     —— 红线：config.yaml 一律官方命令写，不手写/不 sed
#   - key 只进 llm.env（chmod 600），网关 GATEWAY_ENV_FILE 引用；网关 client token
#     经官方 `hermes config set model.api_key '${GATEWAY_CLIENT_TOKEN}'` 写入 profile
#     config.yaml（${...} 引用、无明文落盘；token 由 llm.env 注入环境，轮换只改 llm.env）
#   - 幂等：重复执行不重复安装；换 tag 重跑可升级
#   - 完成校验：hermes --version + profiles 列表可读 + 网关连通性（/v1/models）
#
# 用法：
#   GITHUB_TOKEN=<pat> ./install-hermes-worker.sh \
#       --hermes-home /opt/opc-os/hermes-home \
#       --gateway-url http://127.0.0.1:18080/v1
#   或本地源码包：
#   ./install-hermes-worker.sh --source /path/to/hermes-agent-fork \
#       --hermes-home /opt/opc-os/hermes-home
#
# 红线（创始人定，违反即验收不通过）：
#   1. config.yaml 一律官方 `hermes config set`，不手写/不 sed 改写
#   2. 不依赖单点 fallback（fallback_providers 保持空，熔断归网关）
#   3. 无明文 key 落盘（key 只进 llm.env，chmod 600）
#   4. 客户产物零 OPC 真实身份（本脚本/产物不含 OPC 团队信息）
# =============================================================================
set -euo pipefail

FORK_REPO="${FORK_REPO:-theBigGavin/hermes-agent-fork}"
# 锁定 tag = 客户装的就是我们验证过的版本。v0.20.5-opc.1 = 官方 v0.20.5 快照 +
# OPC 定制层（kanban task_kind/reopen/decompose、mcp TTL 等，fork main HEAD，
# 2026-08-25 打标）；换 tag 重跑脚本即升级。
DEFAULT_TAG="v0.20.5-opc.1"
DEFAULT_GATEWAY_URL="http://127.0.0.1:18080/v1"
DEFAULT_INSTALL_DIR="${HOME}/.opc-os/hermes-agent"

usage() {
  cat <<'EOF'
用法: install-hermes-worker.sh [选项]

  --tag <tag>              安装 fork 的 tag（默认 v0.20.5-opc.1；换 tag 重跑 = 升级）
  --source <路径>          本地源码包路径（替代 GITHUB_TOKEN 网络拉取）
  --hermes-home <路径>     客户 hermes-home（opc-init 输出目录下的 hermes-home/，
                           默认 <install-dir 同级>/hermes-home）
  --install-dir <路径>     fork 安装目录（默认 ~/.opc-os/hermes-agent）
  --gateway-url <url>      网关地址（默认 http://127.0.0.1:18080/v1）
  --llm-env <路径>         客户 key 文件 llm.env（默认 hermes-home 父目录/llm.env，
                           即 opc-init 输出根目录；chmod 600）
  --force                  已安装时强制重装（默认已安装则跳过安装、仅校正配置）
  -h, --help               显示本帮助

环境变量:
  GITHUB_TOKEN            拉取私有 fork 仓库用（--source 未提供时必填）
  FORK_REPO               覆盖 fork 仓库地址（默认 theBigGavin/hermes-agent-fork；
                          可指向自建镜像/自有仓）
EOF
}

TAG="$DEFAULT_TAG"
SOURCE=""
HERMES_HOME=""
INSTALL_DIR=""
GATEWAY_URL="$DEFAULT_GATEWAY_URL"
LLM_ENV=""
FORCE=0

while [ $# -gt 0 ]; do
  case "$1" in
    --tag) TAG="$2"; shift 2 ;;
    --source) SOURCE="$2"; shift 2 ;;
    --hermes-home) HERMES_HOME="$2"; shift 2 ;;
    --install-dir) INSTALL_DIR="$2"; shift 2 ;;
    --gateway-url) GATEWAY_URL="$2"; shift 2 ;;
    --llm-env) LLM_ENV="$2"; shift 2 ;;
    --force) FORCE=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "未知参数: $1" >&2; usage; exit 2 ;;
  esac
done

[ -z "$INSTALL_DIR" ] && INSTALL_DIR="$DEFAULT_INSTALL_DIR"
if [ -z "$HERMES_HOME" ]; then
  # 默认取 opc-init 输出目录下的 hermes-home/（install-dir 同级目录的 hermes-home）
  HERMES_HOME="$(dirname "$INSTALL_DIR")/hermes-home"
fi
if [ -z "$LLM_ENV" ]; then
  LLM_ENV="$(dirname "$HERMES_HOME")/llm.env"
fi

echo "== install-hermes-worker =="
echo "  fork tag     : $TAG"
echo "  install dir  : $INSTALL_DIR"
echo "  HERMES_HOME  : $HERMES_HOME"
echo "  gateway url  : $GATEWAY_URL"
echo "  llm.env      : $LLM_ENV"

# ---------------------------------------------------------------- 0) 前置检查
command -v git >/dev/null 2>&1 || { echo "[ERR] 缺少 git" >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "[ERR] 缺少 python3" >&2; exit 1; }
if [ ! -d "$HERMES_HOME/profiles" ]; then
  echo "[ERR] HERMES_HOME 下没有 profiles/（$HERMES_HOME/profiles）——请先运行 opc-init 生成 hermes-home 骨架" >&2
  exit 1
fi

# ---------------------------------------------------------------- 1) 安装 fork
ALREADY_INSTALLED=0
if [ -x "$INSTALL_DIR/venv/bin/hermes" ]; then
  ALREADY_INSTALLED=1
  CUR_TAG="$(cd "$INSTALL_DIR" && git describe --tags --exact-match 2>/dev/null || echo 'untagged')"
  echo "  检测到已安装（tag=$CUR_TAG）"
  if [ "$FORCE" = "1" ]; then
    echo "  --force：重装"
    ALREADY_INSTALLED=0
  elif [ "$CUR_TAG" != "$TAG" ]; then
    echo "  已装 tag($CUR_TAG) != 目标 tag($TAG)：升级（重新拉取 + 切换 tag）"
    ALREADY_INSTALLED=0
  else
    echo "  已是最新目标 tag，跳过安装"
  fi
fi

if [ "$ALREADY_INSTALLED" = "0" ]; then
  if [ -n "$SOURCE" ]; then
    echo "  从本地源码包安装: $SOURCE"
    [ -f "$SOURCE/venv/bin/hermes" ] || [ -f "$SOURCE/pyproject.toml" ] || { echo "[ERR] $SOURCE 不是 hermes-agent 源码目录" >&2; exit 1; }
    mkdir -p "$(dirname "$INSTALL_DIR")"
    rm -rf "$INSTALL_DIR"
    cp -a "$SOURCE" "$INSTALL_DIR"
    # 本地源码包可能含 venv 等运行时产物，剔除重建
    rm -rf "$INSTALL_DIR/venv" "$INSTALL_DIR/.git" 2>/dev/null || true
    # 打本地快照 tag（源码包无远端历史）：幂等重跑时 git describe 能匹配 --tag，跳过重装
    (cd "$INSTALL_DIR" \
      && git init -q \
      && git add -A 2>/dev/null \
      && git -c user.email=opc@local -c user.name=opc commit -qm "opc-os source snapshot" 2>/dev/null \
      && git tag "$TAG" 2>/dev/null) || true
  else
    [ -n "${GITHUB_TOKEN:-}" ] || { echo "[ERR] 未提供 --source 且无 GITHUB_TOKEN（拉取私有 fork 需要）" >&2; exit 1; }
    echo "  从私有 fork 拉取: $FORK_REPO @ $TAG"
    mkdir -p "$(dirname "$INSTALL_DIR")"
    rm -rf "$INSTALL_DIR"
    git clone -q "https://x-access-token:${GITHUB_TOKEN}@github.com/${FORK_REPO}.git" "$INSTALL_DIR"
    (cd "$INSTALL_DIR" && git fetch -q --tags origin && git checkout -q "$TAG")
  fi

  echo "  创建 venv + 安装依赖（pip install -e .，核心依赖）"
  python3 -m venv "$INSTALL_DIR/venv"
  "$INSTALL_DIR/venv/bin/pip" install -q --upgrade pip
  (cd "$INSTALL_DIR" && "$INSTALL_DIR/venv/bin/pip" install -q -e .)
fi

HERMES="$INSTALL_DIR/venv/bin/hermes"
[ -x "$HERMES" ] || { echo "[ERR] hermes 可执行文件缺失: $HERMES" >&2; exit 1; }

# ---------------------------------------------------------------- 2) 为每个 profile 写配置（官方 hermes config set）
echo "  写 profile 配置（官方 hermes config set，网关模式）"
PROFILE_DIRS=$(find "$HERMES_HOME/profiles" -maxdepth 1 -mindepth 1 -type d 2>/dev/null | sort)
if [ -z "$PROFILE_DIRS" ]; then
  echo "[WARN] HERMES_HOME/profiles 下无 profile 目录，跳过配置写入"
fi

for pdir in $PROFILE_DIRS; do
  pid=$(basename "$pdir")
  # 读 opc-init 骨架里的 model/provider（网关模式 = hermes-opc-v1 / custom:hermes-opc），缺省兜底
  MODEL="hermes-opc-v1"
  PROVIDER="custom:hermes-opc"
  if [ -f "$pdir/config.yaml" ]; then
    M=$(grep -E '^\s+default:' "$pdir/config.yaml" | head -1 | awk '{print $2}' | tr -d '"'"'"'')
    P=$(grep -E '^\s+provider:' "$pdir/config.yaml" | head -1 | awk '{print $2}' | tr -d '"'"'"'')
    [ -n "$M" ] && MODEL="$M"
    [ -n "$P" ] && PROVIDER="$P"
  fi

  # 网关 client token（0825-init-2）：/v1/* Bearer 鉴权，从 llm.env 读取同一值
  GW_TOKEN=""
  if [ -f "$LLM_ENV" ]; then
    GW_TOKEN=$(grep -E '^GATEWAY_CLIENT_TOKEN=' "$LLM_ENV" | head -1 | cut -d= -f2- | tr -d '"'"'"'')
  fi

  # 红线 1：一律官方命令写，不手写/不 sed
  export HERMES_HOME
  "$HERMES" --profile "$pid" config set model.default "$MODEL" >/dev/null
  "$HERMES" --profile "$pid" config set model.provider "$PROVIDER" >/dev/null
  "$HERMES" --profile "$pid" config set model.base_url "$GATEWAY_URL" >/dev/null
  # reasoning_echo（0826-fix）：网关上游含 kimi/deepseek thinking 模型时，多轮对话
  # 必须回传 assistant 消息的 reasoning_content，否则 kimi 拒绝 HTTP 400
  # （"The reasoning_content in the thinking mode must be passed back to the API"）。
  # 网关模式统一走官方 opt-in：model.reasoning_echo=true。
  "$HERMES" --profile "$pid" config set model.reasoning_echo true >/dev/null
  # 0826-fix：custom:hermes-opc 必须配 custom_providers 块（name/base_url/key_env）才能
  # 被解析器识别——裸 hermes-opc 或缺块都会报 Unknown provider（zhuangzi 线上同构）。
  "$HERMES" --profile "$pid" config set custom_providers \
    "[{\"name\":\"hermes-opc\",\"base_url\":\"$GATEWAY_URL\",\"key_env\":\"GATEWAY_CLIENT_TOKEN\"}]" >/dev/null
  if [ -n "$GW_TOKEN" ]; then
    # api_key 用 ${...} 引用（红线 3：无明文 key 落盘；token 由 llm.env 注入环境，
    # 轮换只改 llm.env，config 无需重写）
    "$HERMES" --profile "$pid" config set model.api_key '${GATEWAY_CLIENT_TOKEN}' >/dev/null
  fi
  "$HERMES" --profile "$pid" config set fallback_providers '[]' >/dev/null
  "$HERMES" --profile "$pid" config set timezone Asia/Shanghai >/dev/null
  echo "    ✓ $pid (model=$MODEL provider=$PROVIDER base_url=$GATEWAY_URL api_key=$( [ -n "$GW_TOKEN" ] && echo 'set' || echo 'unset' ))"
done

# ---------------------------------------------------------------- 3) llm.env 检查（key/token 注入说明）
if [ -f "$LLM_ENV" ]; then
  chmod 600 "$LLM_ENV"
  if grep -qE '^(DEEPSEEK_API_KEY|OPC_LLM_API_KEY)=' "$LLM_ENV" && ! grep -qE '^(DEEPSEEK_API_KEY|OPC_LLM_API_KEY)=\s*$' "$LLM_ENV"; then
    echo "  llm.env 已含 key（chmod 600 ✅）：$LLM_ENV"
  else
    echo "  [WARN] llm.env 存在但 key 为空——请在 $LLM_ENV 填入客户 provider key（BYOK，可选）"
    echo "         （网关 GATEWAY_ENV_FILE 引用此文件；红线：key 不落盘 config.yaml/profiles）"
  fi
  if grep -qE '^GATEWAY_CLIENT_TOKEN=\S+' "$LLM_ENV"; then
    echo "  llm.env 已含网关 client token（/v1/* 鉴权，已写入各 profile model.api_key ✅）"
  else
    echo "  [WARN] llm.env 缺少 GATEWAY_CLIENT_TOKEN——网关启用 token 鉴权后 Hermes 无法访问；"
    echo "         请运行 opc-init --gateway 重新生成（自动写入随机 token）或手动补一行"
  fi
else
  echo "  [WARN] 未找到 llm.env（$LLM_ENV）——请创建并填入客户 provider key + GATEWAY_CLIENT_TOKEN（chmod 600）"
  echo "         示例: DEEPSEEK_API_KEY=sk-xxx"
  echo "               GATEWAY_CLIENT_TOKEN=<网关 client token>"
fi

# ---------------------------------------------------------------- 4) 完成校验
echo "== 校验 =="
V=$("$HERMES" --version 2>&1 | head -1 || true)
echo "  hermes --version : $V"

echo "  profiles 可读性  :"
export HERMES_HOME
"$HERMES" profile list 2>/dev/null | sed 's/^/    /' | head -20 || true

echo "  网关连通性（$GATEWAY_URL/models）:"
if command -v curl >/dev/null 2>&1; then
  GW_TOKEN=""
  if [ -f "$LLM_ENV" ]; then
    GW_TOKEN=$(grep -E '^GATEWAY_CLIENT_TOKEN=' "$LLM_ENV" | head -1 | cut -d= -f2- | tr -d '"'"'"'')
  fi
  AUTH_HEADER=""
  [ -n "$GW_TOKEN" ] && AUTH_HEADER="-H \"Authorization: Bearer $GW_TOKEN\""
  CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 $AUTH_HEADER "$GATEWAY_URL/models" 2>/dev/null || echo '000')
  echo "    HTTP $CODE"
  if [ "$CODE" = "200" ]; then
    echo "  ✅ 全部就绪：客户 Hermes 已接入网关（统一模型名 hermes-opc-v1，熔断自动切换/月度预算由网关负责）"
  elif [ "$CODE" = "401" ]; then
    echo "  ⚠️  网关返回 401（client token 鉴权）——请确认 llm.env 的 GATEWAY_CLIENT_TOKEN 与网关一致"
  else
    echo "  ⚠️  网关未就绪（HTTP $CODE）——请先启动 llm-gateway 容器/进程；其余安装已完成"
  fi
else
  echo "    （无 curl，跳过连通性检查）"
fi

echo "== 完成 =="
echo "  启动客户端（model.api_key 已写入 profile 配置 = 网关 client token，直接启动）："
echo "    HERMES_HOME=$HERMES_HOME $HERMES --profile <成员id>"
echo "  （若网关未启用 client token 鉴权，无需任何 key 即可访问）"
