#!/bin/bash
# singbox-watchdog v2.1 — 自愈版代理看门狗（修复 0827 误重启：telegram 瞬态 retrying 即重启 gateway，打断运行中数据任务）
# 变更点 vs v2（t_e8adb3e9 产物）：
#   · gateway 重启条件加持续窗口：telegram 非 connected 需持续 ≥ GW_RETRY_WINDOW 秒（默认 300s=5min，可配置）
#     → watchdog 自记首次观察时间戳（.singbox-watchdog.tgdown），瞬态 retrying 仅记录不动作
#   · 重启前检查运行中 cron/worker：executions.db 近 RUNNING_JOB_WINDOW 秒（默认 600s）内 started 的
#     running/unknown 执行数 > 0 → 推迟重启（下轮 timer 复查），日志留痕
#   · telegram state=fatal（配置类错误）不重启，仅告警
#   · 保留：阶梯自愈（L1 SIGHUP → L2 restart → L3 熔断）、熔断 30min/≥3 次、gateway 15min 最小间隔、告警去重
# 告警：stdout 只在状态变化时输出（兼容 no_agent cron 模式）；全量落日志。
set -u

SCRIPT_DIR="${SCRIPT_DIR:-/home/gavin/.hermes/scripts}"
LOG_FILE="${LOG_FILE:-/home/gavin/.hermes/logs/singbox-watchdog.log}"
STATE_FILE="$SCRIPT_DIR/.singbox-watchdog.state"          # 告警去重：ok/unreachable/meltdown/...
FAIL_FILE="$SCRIPT_DIR/.singbox-watchdog.fails"           # 连续失败计数
RESTART_HIST="$SCRIPT_DIR/.singbox-watchdog.restarts"     # 完整重启时间戳（epoch 一行）
GW_FILE="$SCRIPT_DIR/.singbox-watchdog.gw"                # 最近 gateway 重启时间戳
TG_DOWN_FILE="$SCRIPT_DIR/.singbox-watchdog.tgdown"       # v2.1: telegram 非 connected 首次观察时间戳
GW_MIN_GAP=900            # gateway 重启最小间隔 15min
GW_RETRY_WINDOW="${GW_RETRY_WINDOW:-300}"     # v2.1: telegram 持续非 connected ≥5min 才重启 gateway（可配置）
RUNNING_JOB_WINDOW="${RUNNING_JOB_WINDOW:-600}"  # v2.1: executions.db 近 10min running/unknown 视为运行中
MELT_WINDOW=1800          # 熔断窗口 30min
MELT_MAX=3                # 窗口内完整重启上限
MELT_COOLDOWN=900         # 熔断冷却 15min
PROXY_URL="http://127.0.0.1:7890"
CHECK_URL="https://api.telegram.org"
GW_STATE_JSON="${GW_STATE_JSON:-/home/gavin/.hermes/gateway_state.json}"
EXECUTIONS_DB="${EXECUTIONS_DB:-/home/gavin/.hermes/cron/executions.db}"
DRY_RUN="${DRY_RUN:-0}"           # 1 = 不真重启（stub 测试用）
PROBE_FORCE_OK="${PROBE_FORCE_OK:-0}"  # 1 = 探活恒真（stub 测试用）
PYTHON="${PYTHON:-/usr/bin/python3}"
NOW="$(date +%s)"

log() { echo "$(date '+%F %T') $*" >> "$LOG_FILE"; }

probe() {
  [ "$PROBE_FORCE_OK" = "1" ] && return 0
  local code
  code="$(curl -sS -m 8 -x "$PROXY_URL" -o /dev/null -w '%{http_code}' "$CHECK_URL" 2>/dev/null)"
  [ "$code" = "302" ]
}

count_recent() {  # $1=hist file, $2=window_secs → count
  local hist="$1" win="$2" n=0
  [ -f "$hist" ] || { echo 0; return; }
  while read -r ts; do
    [ $(( NOW - ts )) -lt "$win" ] && n=$(( n + 1 ))
  done < "$hist"
  echo "$n"
}

record_action() { echo "$NOW" >> "$1"; }

alert() { # $1 = message; $2 = dedup key
  local prev=""
  [ -f "$STATE_FILE" ] && prev="$(cat "$STATE_FILE" 2>/dev/null)"
  if [ "$prev" != "$2" ]; then
    echo "$(date '+%F %T') $1"
    echo "$2" > "$STATE_FILE"
  fi
}

# v2.1: 运行中 cron/worker 计数（executions.db 近 RUNNING_JOB_WINDOW 秒内 started 的 running/unknown）
running_jobs() {
  [ -f "$EXECUTIONS_DB" ] || { echo 0; return; }
  sqlite3 -cmd ".timeout 3000" "$EXECUTIONS_DB" \
    "SELECT COUNT(*) FROM executions WHERE status IN ('running','unknown') AND julianday(started_at) >= julianday('now','-${RUNNING_JOB_WINDOW} seconds');" 2>/dev/null || echo 0
}

# v2.1: 提取 telegram 平台 state（json 解析失败 → 空串，调用方按保守处理）
tg_state() {
  "$PYTHON" - "$GW_STATE_JSON" <<'PYEOF' 2>/dev/null
import json, sys
try:
    d = json.load(open(sys.argv[1]))
    print(d.get("platforms", {}).get("telegram", {}).get("state", ""))
except Exception:
    pass
PYEOF
}

# v2.1: gateway telegram 联动检查（仅 proxy 健康时调用）
# 规则：telegram 非 connected 持续 ≥ GW_RETRY_WINDOW 秒 → 无运行中 job → 距上次 gateway 重启 ≥ GW_MIN_GAP → 重启
# 瞬态非 connected 仅记录；fatal 不重启；运行中 job 推迟。
check_gateway() {
  # 守卫：文件必须新鲜（30min 内写过，即最近有生命周期转换）；过期文件=adapter 自身重连循环在跑，不干预
  [ -f "$GW_STATE_JSON" ] || { alert "sing-box 代理正常, Telegram 可投递" ok; return 0; }
  if [ $(( NOW - $(stat -c %Y "$GW_STATE_JSON") )) -ge 1800 ]; then
    alert "sing-box 代理正常, Telegram 可投递" ok
    return 0
  fi

  local tstate t_start elapsed jobs last_gw
  tstate="$(tg_state)"
  case "$tstate" in
    connected)
      if [ -f "$TG_DOWN_FILE" ]; then
        log "gateway telegram recovered to connected (was down since $(date -d @"$(cat "$TG_DOWN_FILE")" '+%T' 2>/dev/null || cat "$TG_DOWN_FILE"))"
        rm -f "$TG_DOWN_FILE"
      fi
      alert "sing-box 代理正常, Telegram 可投递" ok
      ;;
    fatal)
      log "gateway telegram state=fatal (permanent config error) — restart will not help, no action"
      alert "⚠ hermes-gateway telegram 状态 fatal（配置类错误，重启无益）——需人工检查" gw-fatal
      ;;
    "")
      log "gateway telegram state unknown (json parse failed) — no action"
      ;;
    retrying|disconnected|error)
      if [ ! -f "$TG_DOWN_FILE" ]; then
        echo "$NOW" > "$TG_DOWN_FILE"
        log "gateway telegram state=$tstate (first observation, waiting ${GW_RETRY_WINDOW}s window before any action)"
        alert "⚠ hermes-gateway telegram 状态 $tstate（瞬态观察，持续 ≥${GW_RETRY_WINDOW}s 且无运行中任务才重启）" gw-down
        return 0
      fi
      t_start="$(cat "$TG_DOWN_FILE")"
      elapsed=$(( NOW - t_start ))
      if [ "$elapsed" -lt "$GW_RETRY_WINDOW" ]; then
        log "gateway telegram state=$tstate for ${elapsed}s (< ${GW_RETRY_WINDOW}s window) — no action"
        return 0
      fi
      # 持续窗口已过 → 检查运行中 cron/worker
      jobs="$(running_jobs)"
      if [ "$jobs" -gt 0 ]; then
        log "gateway telegram state=$tstate sustained ${elapsed}s BUT ${jobs} running/unknown cron job(s) in last ${RUNNING_JOB_WINDOW}s → deferring restart (re-check next tick)"
        alert "⚠ hermes-gateway telegram 持续未连接 ${elapsed}s，但检测到 ${jobs} 个运行中任务 → 推迟重启" gw-deferred
        return 0
      fi
      last_gw="$(cat "$GW_FILE" 2>/dev/null || echo 0)"
      if [ $(( NOW - last_gw )) -le "$GW_MIN_GAP" ]; then
        log "gateway telegram state=$tstate sustained ${elapsed}s but within ${GW_MIN_GAP}s gap since last gateway restart — skip"
        return 0
      fi
      log "gateway telegram state=$tstate sustained ${elapsed}s (>= ${GW_RETRY_WINDOW}s) and no running jobs → restarting hermes-gateway"
      if [ "$DRY_RUN" = "1" ]; then
        log "[DRY-RUN] would run: systemctl --user restart hermes-gateway"
      else
        systemctl --user restart hermes-gateway
      fi
      record_action "$GW_FILE"
      rm -f "$TG_DOWN_FILE"
      alert "⚠ hermes-gateway telegram 持续未连接 ≥${GW_RETRY_WINDOW}s 且无运行中任务 → 已重启 gateway" gw-restarted
      ;;
  esac
}

# ---------- 1) 探活 ----------
if probe; then
  # 恢复/稳态
  if [ -f "$FAIL_FILE" ]; then
    log "proxy OK (recovered after $(( $(cat "$FAIL_FILE") )) failures)"
    rm -f "$FAIL_FILE"
  else
    log "proxy OK (steady)"
  fi
  # gateway 联动检查（v2.1：持续窗口 + 运行中 job 守卫 + fatal 不重启）
  check_gateway
  exit 0
fi

# ---------- 2) 失败处理 ----------
FAIL="$(cat "$FAIL_FILE" 2>/dev/null || echo 0)"
FAIL=$(( FAIL + 1 ))
echo "$FAIL" > "$FAIL_FILE"
log "probe FAIL #$FAIL ($(date '+%T'))"

if [ "$FAIL" -lt 2 ]; then
  exit 0   # 单次抖动不动作
fi

# L1: SIGHUP 热重载（强制重解析，PID 不变）
log "L1: SIGHUP reload (fail #$FAIL)"
SB_PID="$(pgrep -f 'sing-box run' | head -1)"
[ -n "$SB_PID" ] && kill -HUP "$SB_PID" 2>/dev/null
sleep 15
if probe; then
  log "recovered via SIGHUP"; rm -f "$FAIL_FILE"; alert "✅ sing-box 代理已恢复（SIGHUP 热重载）" recovered
  exit 0
fi

# L2: 完整重启
if [ "$(count_recent "$RESTART_HIST" "$MELT_WINDOW")" -ge "$MELT_MAX" ]; then
  # L3: 熔断 —— 链路级故障（wifi 掉线等），交给 wifi-watchdog；只探测不动作
  log "MELTDOWN: $(count_recent "$RESTART_HIST" "$MELT_WINDOW") restarts in ${MELT_WINDOW}s window; suppressing restarts"
  rm -f "$FAIL_FILE"   # 复位计数，冷却期内每轮只记日志
  alert "⚠ sing-box 连续重启触发熔断（链路级故障，疑似断网）——已停止重启，等待网络恢复；Telegram 投递中断" meltdown
  exit 0
fi

log "L2: systemctl restart sing-box (fail #$FAIL)"
if [ "$DRY_RUN" = "1" ]; then
  log "[DRY-RUN] would run: systemctl --user restart sing-box"
else
  systemctl --user restart sing-box
fi
record_action "$RESTART_HIST"
sleep 10
if probe; then
  log "recovered via restart"
  rm -f "$FAIL_FILE"
  alert "✅ sing-box 代理已恢复（restart）" recovered
  # 代理刚恢复 → 检查 gateway telegram 是否跟上（v2.1 同样受持续窗口约束）
  check_gateway
  exit 0
fi

# 重启后仍失败 → 熔断检查（不无限重启）
log "L2 restart failed to recover (fail #$FAIL)"
if [ "$(count_recent "$RESTART_HIST" "$MELT_WINDOW")" -ge "$MELT_MAX" ]; then
  log "MELTDOWN after restart attempt"
  rm -f "$FAIL_FILE"
  alert "⚠ sing-box 重启后仍未恢复，触发熔断（链路级故障）——等待网络自愈；Telegram 投递中断" meltdown
else
  # 未熔断：保留计数，下轮再试一次 L2
  echo "$FAIL" > "$FAIL_FILE"
fi
exit 0
