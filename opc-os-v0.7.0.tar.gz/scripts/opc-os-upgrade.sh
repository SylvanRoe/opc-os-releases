#!/bin/bash
# =============================================================================
# OPC-OS — 安全升级脚本（Gavin 0827「已部署客户安全升级」）
# =============================================================================
# 阶段化流程（任一步失败按策略处理，成功才继续）：
#   1. 前置检查：部署形态判定（git / rsync）、git 状态干净（本地改动告警，--force 跳过）、
#      磁盘空间、当前版本
#   2. 自动备份：调 backup.sh（扩展后 7 文件），备份失败 → 中止升级
#   3. 目标版本解析：默认 = check-update 最新版；--to 显式指定
#   4. 增量/全量判定：主版本号相同 → 增量（git fetch + checkout tag + install-services.sh
#      install 重跑 + 依赖检查）；主版本号不同 → 拒绝自动升级，输出全量重装指引
#      （opc-init 流程，数据保留说明），除非 --force
#   5. 冒烟验证：smoke_test.sh + systemctl is-active opcos-* 全 active
#   6. 失败自动回滚：checkout 前一个可用 tag + install-services 重跑 + 从备份恢复数据文件
#      （对齐 FORK.md 回退预案：回退只影响代码，数据用升级前备份恢复）
#   7. 成功留痕：<state-dir>/upgrade.log 追加一行 {ts, from, to, result}；清除 update-available.json
#   8. --rollback 手工回滚入口（回到上一 tag + 恢复备份）
#
# 参数： [--to vX.Y.Z] [--dry-run] [--rollback] [--force]
#   --dry-run  只执行阶段 1（前置检查）+ 目标解析，不实际升级（幂等预览）
#   --force    跳过 git 状态脏检查；允许主版本变化（全量升级，自动走 opc-init 重装）
#   --to       显式指定目标版本（git tag 名或裸版本号 v0.6.0 / 0.6.0 均可）
#   --rollback 手工回滚：回到上一个可用 tag + install-services 重跑 + 恢复备份
#
# 路径 env 参数化（D7 合入规范，installation-guide §14 红线 7）：
#   OPC_OS_REPO        —— opc-os 仓根（默认：本脚本上级）
#   OPC_OS_STATE_DIR   —— 升级状态目录（默认 ~/.opc-os；upgrade.log / update-available.json 落此）
#   OPC_DATA_DIR       —— opc-init 数据目录（backup.sh 同款 env；升级时传给 backup.sh --data-dir）
#   OPC_GATEWAY_CONFIG —— 网关配置路径（默认 <data-dir>/llm-gateway/gateway.config.json）
#   OPC_SMOKE_PORT     —— smoke_test.sh 端口（默认 8081）
#   OPC_UPGRADE_CHECK_DRY —— 内部测试开关：注入冒烟失败（test_upgrade_mechanism.py 用）
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${OPC_OS_REPO:-$(cd "$SCRIPT_DIR/.." && pwd)}"
STATE_DIR="${OPC_OS_STATE_DIR:-$HOME/.opc-os}"
UPGRADE_LOG="$STATE_DIR/upgrade.log"
UPDATE_AVAILABLE="$STATE_DIR/update-available.json"
DATA_DIR="${OPC_DATA_DIR:-}"
GATEWAY_CONFIG="${OPC_GATEWAY_CONFIG:-}"
SMOKE_PORT="${OPC_SMOKE_PORT:-8081}"

TO=""
MODE="upgrade"        # upgrade | rollback
DRY_RUN=0
FORCE=0

info() { echo "[opc-os-upgrade] $*"; }
warn() { echo "[opc-os-upgrade] ⚠️  $*" >&2; }
die()  { echo "[opc-os-upgrade] ❌ $*" >&2; exit 1; }

usage() {
  cat <<'EOF'
OPC-OS 安全升级脚本

用法:
  opc-os-upgrade.sh [--to vX.Y.Z] [--dry-run] [--force]   安全升级（阶段化 + 失败自动回滚）
  opc-os-upgrade.sh --rollback                            手工回滚到上一可用 tag + 恢复备份
  opc-os-upgrade.sh -h                                    帮助

选项:
  --to vX.Y.Z    显式指定目标版本（默认 = check-update 检测到的最新版）
  --dry-run      只做前置检查 + 目标解析，不实际升级
  --force        跳过 git 状态脏检查；允许主版本变化（全量重装，数据保留）
  --rollback     手工回滚入口（回到上一 tag + 恢复升级前备份）

环境变量（全部可选，默认仅生产兜底）:
  OPC_OS_REPO        opc-os 仓根（默认本脚本上级）
  OPC_OS_STATE_DIR   升级状态目录（默认 ~/.opc-os；upgrade.log / update-available.json）
  OPC_DATA_DIR       opc-init 数据目录（备份数据源；未设则要求 --data-dir 形态显式传参）
  OPC_GATEWAY_CONFIG 网关配置路径（默认 <data-dir>/llm-gateway/gateway.config.json）
  OPC_SMOKE_PORT     smoke_test.sh 端口（默认 8081）
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --to) TO="${2:-}"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    --force) FORCE=1; shift ;;
    --rollback) MODE="rollback"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "未知参数: $1（-h 看用法）" ;;
  esac
done

read_current_version() {
  if [ -f "$REPO_DIR/VERSION" ]; then
    tr -d ' \t\r\n' < "$REPO_DIR/VERSION"
  else
    # 旧部署包无 VERSION 文件：从 opc_init.py 兜底提取（兼容升级路径）
    grep -oE "VERSION\s*=\s*'[0-9]+\.[0-9]+\.[0-9]+'" "$SCRIPT_DIR/opc_init.py" \
      | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" | head -1
  fi
}

# ---------- 前置检查（阶段 1） ----------
preflight() {
  info "阶段 1/7 前置检查"
  # 部署形态判定
  if [ -d "$REPO_DIR/.git" ]; then
    DEPLOY_MODE="git"
    info "  部署形态: git 仓（$REPO_DIR）"
  else
    DEPLOY_MODE="rsync"
    warn "  部署形态: 非 git 目录（rsync 拷贝）——无法自动增量升级/回滚，请用部署源重新同步（见 installation-guide §9）"
    return 1
  fi
  # git 状态干净
  if [ "$FORCE" -eq 0 ]; then
    dirty="$(git -C "$REPO_DIR" status --porcelain 2>/dev/null | grep -v '^??' || true)"
    if [ -n "$dirty" ]; then
      warn "  本地有未提交改动（git status 非干净）——升级会覆盖它们！用 --force 跳过本检查："
      echo "$dirty" | head -5 | sed 's/^/    /'
      return 1
    fi
  fi
  # 磁盘空间（至少 1G 可用）
  avail_kb="$(df -Pk "$REPO_DIR" 2>/dev/null | awk 'NR==2{print $4}')"
  if [ -n "$avail_kb" ] && [ "$avail_kb" -lt 1048576 ]; then
    warn "  磁盘可用空间不足 1G（$((avail_kb/1024))M）——升级需要暂存新旧两版"
    return 1
  fi
  # 当前版本
  CUR="$(read_current_version)"
  if [ -z "$CUR" ]; then
    warn "  无法读取当前版本（VERSION 文件缺失且 opc_init.py 无版本常量）"
    return 1
  fi
  info "  当前版本: $CUR"
  return 0
}

# ---------- 目标版本解析（阶段 3） ----------
resolve_target() {
  info "阶段 3/7 目标版本解析"
  if [ -n "$TO" ]; then
    # 显式 --to：v 前缀归一，校验 semver
    TARGET="${TO#v}"
    if ! echo "$TARGET" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+$'; then
      die "--to 版本格式非法（须 v0.6.0 或 0.6.0）: $TO"
    fi
    info "  目标版本（--to 显式）: $TARGET"
  elif [ -f "$UPDATE_AVAILABLE" ]; then
    TARGET="$(python3 -c "import json,sys;print(json.load(open('$UPDATE_AVAILABLE'))['latest'])" 2>/dev/null)"
    if [ -z "$TARGET" ]; then
      die "update-available.json 存在但 latest 字段无法解析——请先跑 check-update 或 --to 显式指定"
    fi
    info "  目标版本（check-update 检测）: $TARGET"
  else
    # 无 update-available.json：现场探测（git tag 最新 semver）
    TARGET="$(git -C "$REPO_DIR" tag --sort=-v:refname 2>/dev/null | grep -E '^v?[0-9]+\.[0-9]+\.[0-9]+$' | head -1)"
    [ -n "$TARGET" ] && TARGET="${TARGET#v}"
    if [ -z "$TARGET" ]; then
      die "无法解析目标版本（无 update-available.json 且 git tag 无 semver）——先跑 opc-os-check-update.py 或 --to 显式指定"
    fi
    info "  目标版本（git tag 探测）: $TARGET"
  fi
  return 0
}

# ---------- 备份（阶段 2） ----------
BK_DIR=""   # 全局：本次升级的备份目录（回滚时数据恢复用）
do_backup() {
  info "阶段 2/7 自动备份（backup.sh 7 文件集）"
  local backup_args=("--keep" "3" "--out" "$STATE_DIR/backups")
  if [ -n "$DATA_DIR" ]; then
    backup_args+=(--data-dir "$DATA_DIR")
  fi
  if ! "$SCRIPT_DIR/backup.sh" "${backup_args[@]}" >/dev/null 2>&1; then
    if [ -z "$DATA_DIR" ]; then
      warn "backup.sh 失败（未指定 OPC_DATA_DIR 时无数据源）——升级中止"
    else
      warn "backup.sh 失败（$DATA_DIR）——升级中止（备份先行红线）"
    fi
    return 1
  fi
  BK_DIR="$STATE_DIR/backups/$(date +%F)"
  info "  备份完成 → $BK_DIR/"
  return 0
}

# ---------- 冒烟验证（阶段 5） ----------
smoke_verify() {
  info "阶段 5/7 冒烟验证"
  local failed=0
  # 注入失败开关（自测用：test_upgrade_mechanism.py 模拟冒烟失败 → 验证自动回滚）
  if [ "${OPC_UPGRADE_CHECK_DRY:-0}" = "1" ]; then
    warn "  [测试注入] OPC_UPGRADE_CHECK_DRY=1 —— 模拟冒烟失败"
    return 1
  fi
  # smoke_test.sh（存在才跑；无 systemd 环境也可跑 HTTP 探活）
  if [ -x "$SCRIPT_DIR/smoke_test.sh" ]; then
    if ! "$SCRIPT_DIR/smoke_test.sh" "$SMOKE_PORT" >/dev/null 2>&1; then
      warn "  smoke_test.sh 未全绿（端口 $SMOKE_PORT）"
      failed=1
    else
      info "  smoke_test.sh 全绿（端口 $SMOKE_PORT）"
    fi
  fi
  # systemctl 检查（有 systemd 才查；opcos-* 全部 active）
  # OPC_SMOKE_SKIP_SYSTEMCTL=1 可跳过（无 systemd / CI 自测环境）
  if [ "${OPC_SMOKE_SKIP_SYSTEMCTL:-0}" = "1" ]; then
    info "  OPC_SMOKE_SKIP_SYSTEMCTL=1 —— 跳过 systemctl is-active 检查"
  elif [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
    local svc rc
    for svc in opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher; do
      rc="$(systemctl is-active "$svc" 2>/dev/null || echo unknown)"
      if [ "$rc" != "active" ]; then
        warn "  $svc 状态 = $rc（期望 active）"
        failed=1
      else
        info "  $svc active"
      fi
    done
  else
    info "  无 systemd 环境，跳过 opcos-* is-active 检查（以 smoke_test.sh 为准）"
  fi
  [ "$failed" -eq 0 ] && return 0
  return 1
}

# ---------- 回滚（阶段 6 / --rollback） ----------
rollback_to() {
  # rollback_to <from> <to> [backup_dir]：checkout 目标 tag + install-services 重跑 + 数据恢复
  local from="$1" to="$2" bkdir="${3:-}"
  info "  回滚: $from → $to"
  # 找目标 tag 对应的 semver tag 名（v 前缀归一）
  local tag
  tag="$(git -C "$REPO_DIR" tag -l "v$to" "$to" | head -1)"
  [ -z "$tag" ] && die "回滚失败: 找不到 tag $to"
  if ! git -C "$REPO_DIR" checkout -q "$tag" 2>/dev/null; then
    die "回滚失败: git checkout $tag 出错"
  fi
  info "  已 checkout $tag"
  # install-services 重跑（若部署数据目录可判定）
  if [ -n "$DATA_DIR" ] && [ -f "$DATA_DIR/config/config.native.json" ]; then
    "$SCRIPT_DIR/install-services.sh" install --out "$DATA_DIR" --opc-os "$REPO_DIR" >/dev/null 2>&1 \
      && info "  install-services 重跑完成" \
      || warn "  install-services 重跑失败（手工执行: scripts/install-services.sh install --out $DATA_DIR）"
  else
    warn "  未指定 OPC_DATA_DIR——跳过 install-services 重跑（手工执行）"
  fi
  # 数据文件恢复（从备份目录）
  if [ -n "$bkdir" ] && [ -d "$bkdir" ]; then
    local n=0 f
    for f in kanban.db status.json token-stats.json state.json \
             gateway.config.json bus-state.json govern-state.json; do
      if [ -f "$bkdir/$f" ] && [ -n "$DATA_DIR" ]; then
        cp "$bkdir/$f" "$DATA_DIR/$f" 2>/dev/null && n=$((n+1))
      elif [ -f "$bkdir/$f" ]; then
        # 无 DATA_DIR 时按部署形态推断（git 部署 → 网关配置在 <repo>/llm-gateway/）
        case "$f" in
          gateway.config.json) [ -f "$REPO_DIR/llm-gateway/gateway.config.json" ] && \
            cp "$bkdir/$f" "$REPO_DIR/llm-gateway/gateway.config.json" && n=$((n+1)) ;;
          *) warn "  数据文件 $f 未恢复（无 OPC_DATA_DIR 不知落点）" ;;
        esac
      fi
    done
    info "  已恢复 $n 个数据文件（来源 $bkdir）"
  fi
  return 0
}

rollback_mode() {
  info "== 手工回滚入口（--rollback）=="
  preflight || die "前置检查失败——不执行回滚"
  # 找上一可用 tag（当前 HEAD 之前的最近 semver tag）
  local cur_ver prev_tag
  cur_ver="$(read_current_version)"
  prev_tag="$(git -C "$REPO_DIR" tag --sort=-v:refname 2>/dev/null \
    | grep -E '^v?[0-9]+\.[0-9]+\.[0-9]+$' \
    | awk -v cv="$cur_ver" 'sub(/^v/,"") { if ($0 < cv) { print; exit } }')"
  [ -z "$prev_tag" ] && die "找不到上一可用 tag（当前 $cur_ver）"
  info "  当前 $cur_ver → 回滚到 $prev_tag"
  # 最近的备份目录
  local bkdir
  bkdir="$(ls -d "$STATE_DIR"/backups/????-??-?? 2>/dev/null | sort | tail -1)"
  rollback_to "$cur_ver" "$prev_tag" "$bkdir" || die "回滚失败"
  info "== 回滚完成（如需恢复更新通知请重跑 check-update）=="
  return 0
}

# =============================================================================
# 主流程
# =============================================================================
mkdir -p "$STATE_DIR"

if [ "$MODE" = "rollback" ]; then
  rollback_mode
  exit $?
fi

# 阶段 1：前置检查
preflight || die "前置检查未通过（--force 可跳过 git 状态/磁盘检查）"

# 阶段 3：目标解析（在备份前先解析，--dry-run 需要）
resolve_target || exit 1

if [ "$DRY_RUN" -eq 1 ]; then
  info "== dry-run：前置检查通过，目标版本 $TARGET（未执行任何变更）=="
  info "  当前: $CUR → 目标: $TARGET"
  if [ "${CUR%%.*}" != "${TARGET%%.*}" ]; then
    warn "  主版本不同（$CUR → $TARGET）——正式升级将拒绝自动执行，需 --force + opc-init 全量重装"
  fi
  exit 0
fi

# 阶段 2：备份（备份先行红线）
do_backup || exit 1

# 阶段 4：增量/全量判定 + 执行
MAJOR_CUR="${CUR%%.*}"
MAJOR_TGT="${TARGET%%.*}"
if [ "$MAJOR_CUR" != "$MAJOR_TGT" ] && [ "$FORCE" -eq 0 ]; then
  cat <<EOF
[opc-os-upgrade] ❌ 主版本变化（$CUR → $TARGET）：拒绝自动增量升级（D6 全量升级规范）

全量重装指引（数据保留）：
  1. 备份数据已自动完成（$STATE_DIR/backups/$(date +%F)/）
  2. 获取新版部署包（rsync 或 git pull 到新目录）
  3. 重跑 opc-init（--out 指定原数据目录，保留现有数据）：
       python3 scripts/opc_init.py --template <同款模板> --out $DATA_DIR --force
  4. 重跑 install-services.sh install（复用原数据目录）
  5. 冒烟验证: scripts/smoke_test.sh $SMOKE_PORT
如需强制自动升级（不推荐）：加 --force
EOF
  exit 1
fi

# 增量升级：git fetch + checkout tag + install-services install 重跑 + 依赖检查
info "阶段 4/7 增量升级（git 形态）: $CUR → $TARGET"
git -C "$REPO_DIR" fetch --tags origin >/dev/null 2>&1 \
  || warn "git fetch 失败（可能离线）——使用本地已有 tag"
TAG_NAME="$(git -C "$REPO_DIR" tag -l "v$TARGET" | head -1)"
[ -z "$TAG_NAME" ] && TAG_NAME="$(git -C "$REPO_DIR" tag -l "$TARGET" | head -1)"
[ -z "$TAG_NAME" ] && die "找不到 tag v$TARGET / $TARGET（git tag -l 确认）"

# checkout 前记录旧 HEAD（回滚锚点）
OLD_HEAD="$(git -C "$REPO_DIR" rev-parse HEAD)"

info "  git checkout $TAG_NAME"
if ! git -C "$REPO_DIR" checkout -q "$TAG_NAME" 2>/dev/null; then
  warn "  checkout 失败——自动回滚"
  rollback_to "$TARGET" "$CUR"
  exit 1
fi

# install-services install 重跑（幂等；缺 OPC_DATA_DIR 时跳过并告警）
if [ -n "$DATA_DIR" ] && [ -f "$DATA_DIR/config/config.native.json" ]; then
  info "  install-services.sh install 重跑（out=$DATA_DIR）"
  if ! "$SCRIPT_DIR/install-services.sh" install --out "$DATA_DIR" --opc-os "$REPO_DIR" >/dev/null 2>&1; then
    warn "  install-services 重跑失败——自动回滚"
    git -C "$REPO_DIR" checkout -q "$OLD_HEAD" 2>/dev/null || true
    rollback_to "$TARGET" "$CUR" "$BK_DIR"
    exit 1
  fi
else
  warn "  未指定 OPC_DATA_DIR——跳过 install-services 重跑（升级后手工执行 install）"
fi

# 依赖检查：升级后 VERSION 文件与核心脚本存在
if [ ! -f "$REPO_DIR/VERSION" ]; then
  warn "  升级后 VERSION 文件缺失——自动回滚"
  git -C "$REPO_DIR" checkout -q "$OLD_HEAD" 2>/dev/null || true
  rollback_to "$TARGET" "$CUR" "$BK_DIR"
  exit 1
fi
for f in scripts/opc-bus.py scripts/install-services.sh scripts/opc-os-check-update.py; do
  [ -f "$REPO_DIR/$f" ] || warn "  升级后缺少 $f（依赖不完整）"
done

# 阶段 5：冒烟验证
if ! smoke_verify; then
  warn "冒烟验证失败——自动回滚到 $CUR"
  rollback_to "$TARGET" "$CUR" "$BK_DIR"
  exit 1
fi

# 阶段 7：成功留痕
echo "{\"ts\":\"$(date +%Y-%m-%dT%H:%M:%S%z)\",\"from\":\"$CUR\",\"to\":\"$TARGET\",\"result\":\"ok\"}" >> "$UPGRADE_LOG"
[ -f "$UPDATE_AVAILABLE" ] && rm -f "$UPDATE_AVAILABLE"
info "== 升级完成: $CUR → $TARGET（upgrade.log 已留痕，update-available.json 已清除）=="
exit 0
