#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# OPC 统一系统监控（合并 system-health.sh 告警+自救 与 system-monitor.py 留底+网络+整点报）
# 由 cron 每 5 分钟调用（no_agent 纯脚本）。
# 行为：
#   - 每 5 分钟采集：负载/内存/swap/磁盘/tmp/温度/PM2死服务/端口/网络速率/TCP连接/探针
#   - 每次追加一条留底记录到 JSONL（历史可查验）
#   - 异常时：触发自救（清/tmp、截日志、停可杀服务），并输出告警
#   - 整点(:00)：输出「每小时汇总」（含负载/内存/磁盘/网络/探针）
#   - 非整点且无异常：静默（stdout 空）
#   - 非整点但有异常：输出告警（即时响应）
# 输出约定：cron no_agent 模式，stdout 非空才发给用户。

import json, os, time, subprocess, sqlite3, fcntl, sys
from datetime import datetime

# 环境变量参数化（Gavin 0827「公司即产品」，参照 opc-alert-bus.py OPC_ALERT_DIR 模式）：
# 所有路径默认值仅作生产兜底（零行为变化）；客户部署用 env 指向自己的目录，禁止改硬编码（§14 红线 7）。
# 硬编码真实用户 home：cron/worker 派生会话 HOME 可能被重定向到 profile home，
# expanduser 不可靠（0827 夜实测：worker 会话 HOME=/home/gavin/.hermes/profiles/anran/home）。
HOME = os.environ.get("OPC_HOME", "/home/gavin")
BASE = os.environ.get("OPC_SYSMON_DIR", f"{HOME}/.hermes/scripts/.system-health")
STATE = os.path.join(BASE, "net_state.json")
LOG = os.path.join(BASE, "sysmon.jsonl")
BOOT_MARK = os.path.join(BASE, ".last-boot-id")
SELFHEAL_STATE = os.path.join(BASE, "selfheal_state.json")
# 降载名单（2026-08-27 P0 教训后：降载必须可逆，见 heal_restore；受控降载中不算故障见 pm2_dead）
HEAL_STOP_SERVICES = ["opcos-mrdr", "opcos-mrd-host", "opcos-collector", "opcos-govern", "opcos-knock"]
# 降载服务→受控端口映射（受控降载停服时该端口不算故障，见 ports_open；无受控端口的服务不在此列）
HEAL_SERVICE_PORTS = {
    "opcos-mrdr": ["3031"],
    "opcos-mrd-host": ["3200"],
    "opcos-knock": ["3032"],
}
# 恢复阈值：温度回落到 80 以下且可用内存 >20% 才恢复（与降载阈值 <10% 构成 10pt 滞回防抖）
HEAL_RESTORE_TEMP = 80
HEAL_RESTORE_MEM_PCT = 20
LOG_TEXT = os.environ.get("OPC_SYSMON_LOG", f"{HOME}/.hermes/logs/system-health.log")
os.makedirs(BASE, exist_ok=True)


def log_line(msg):
    try:
        with open(LOG_TEXT, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass


class RunResult(str):
    """run() 返回值：str 子类（字符串用法完全兼容）+ rc 语义。

    R3 修复 (t_f9843ec9, 2026-08-28)：systemctl stop/start 成功时 stdout 为空，
    旧 bool=「stdout 非空」→ `if run("sudo -n systemctl stop ..."):` 恒 False
    → _mark_heal_stop 永不执行、P2 degrade 总线 0 条、action 不记录、
    heal_restore 恢复后也无登记可恢复（L295/L321/L340/L369 同病）。
    bool(x) 现 = rc==0（命令真实成功），与输出内容解耦。
    用法：读输出当 str；判成功用 truthiness。
    """
    def __new__(cls, s="", rc=0):
        obj = str.__new__(cls, s if s is not None else "")
        obj.rc = rc
        return obj

    def __bool__(self):
        return self.rc == 0


def run(cmd):
    """执行 shell 命令；返回 RunResult（str 兼容，bool=rc==0）。异常视为失败(rc=1)。"""
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
        return RunResult(p.stdout.strip(), p.returncode)
    except Exception:
        return RunResult("", 1)


# ---------- 采集 ----------
def loadavg():
    s = run("cut -d' ' -f1-3 /proc/loadavg")
    p = s.split()
    return [p[0], p[1], p[2]] if len(p) >= 3 else ["?", "?", "?"]


def mem():
    """用 /proc/meminfo 直读（不依赖 free 命令，避开 PATH 问题）。返回 (kB_total, kB_avail, pct)"""
    total, avail = 0, 0
    for line in open("/proc/meminfo").read().splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        v = v.strip().split()[0] if v.strip() else "0"
        if k == "MemTotal":
            try:
                total = int(v)
            except Exception:
                total = 0
        elif k == "MemAvailable":
            try:
                avail = int(v)
            except Exception:
                avail = 0
    pct = round((total - avail) / total * 100, 1) if total else 0
    return total, avail, pct


def swap():
    """/proc/meminfo 的 SwapTotal/SwapFree。返回 (kB_used, kB_total, pct)"""
    used, total = 0, 0
    for line in open("/proc/meminfo").read().splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        v = v.strip().split()[0] if v.strip() else "0"
        try:
            iv = int(v)
        except Exception:
            continue
        if k == "SwapTotal":
            total = iv
        elif k == "SwapFree":
            used = total - iv
    pct = round(used / total * 100, 1) if total else 0
    return used, total, pct


def temp():
    temps = []
    for z in ["/sys/class/thermal/thermal_zone0/temp", "/sys/class/thermal/thermal_zone1/temp",
              "/sys/class/thermal/thermal_zone2/temp", "/sys/class/thermal/thermal_zone3/temp"]:
        if os.path.exists(z):
            try:
                v = int(open(z).read().strip()) // 1000
                if v > 0:
                    temps.append(v)
            except Exception:
                pass
    return max(temps) if temps else 0


def disk_pct(path):
    s = os.statvfs(path)
    total = s.f_blocks * s.f_frsize
    free = s.f_bavail * s.f_frsize
    return round((total - free) / total * 100, 1) if total else 0


def tmp_use():
    return disk_pct("/tmp" if os.path.exists("/tmp") else "/")


def nproc():
    return int(run("nproc") or 1)


def net_rates():
    """读 /proc/net/dev，与上次状态比算速率(B/s)。返回 {iface:{rx,tx}, total_rx, total_tx}"""
    cur = {}
    for line in open("/proc/net/dev").read().splitlines()[2:]:
        if ":" not in line:
            continue
        part = line.split(":")
        iface = part[0].strip()
        if iface.startswith("lo"):
            continue
        f = part[1].split()
        try:
            cur[iface] = {"rx": int(f[0]), "tx": int(f[8])}
        except Exception:
            pass

    now = time.time()
    prev = {}
    if os.path.exists(STATE):
        try:
            prev = json.load(open(STATE))
        except Exception:
            prev = {}

    rates = {}
    for iface, c in cur.items():
        p = prev.get(iface, {})
        dt = now - prev.get("_ts", now)
        if dt > 0 and "rx" in p:
            rates[iface] = {
                "rx_bps": max(0, (c["rx"] - p["rx"]) / dt),
                "tx_bps": max(0, (c["tx"] - p["tx"]) / dt),
            }
        else:
            rates[iface] = {"rx_bps": 0, "tx_bps": 0}

    st = dict(cur)
    st["_ts"] = now
    try:
        json.dump(st, open(STATE, "w"))
    except Exception:
        pass

    total_rx = sum(r["rx_bps"] for r in rates.values())
    total_tx = sum(r["tx_bps"] for r in rates.values())
    return rates, total_rx, total_tx


def sockstat():
    s = run("cat /proc/net/sockstat")
    tcp = {"inuse": 0, "tw": 0}
    for line in s.splitlines():
        if line.startswith("TCP:"):
            parts = line.split()
            for i in range(len(parts) - 1):
                if parts[i] == "inuse":
                    tcp["inuse"] = int(parts[i + 1])
                elif parts[i] == "tw":
                    tcp["tw"] = int(parts[i + 1])
    return tcp


OPCOS_UNITS = ["opcos-api", "opcos-collector", "opcos-company", "opcos-dispatcher",
               "opcos-gateway", "opcos-govern", "opcos-knock", "opcos-mrd",
               "opcos-mrd-host", "opcos-mrdr"]


def pm2_dead():
    """2026-08-27 pm2 退役后: systemd opcos-* 核查替代 pm2 jlist（函数名保留兼容调用方）。
    返回非 active 的 unit 名列表(含状态), 全部 active 返回 []。
    2026-08-27 P0 修复: 受控降载（selfheal_state 登记）中的服务不算故障，从 dead 剔除——
    否则降载救火后下一轮巡检立刻报 P0，制造虚假告警。"""
    out = run("systemctl is-active " + " ".join(OPCOS_UNITS) + " 2>/dev/null")
    states = out.splitlines()
    dead = []
    for u, s in zip(OPCOS_UNITS, states):
        if s.strip() != "active":
            dead.append(f"{u}({s.strip() or '?'})")
    heal_stopped = set(_load_heal_state().get("stopped", {}))
    if heal_stopped:
        dead = [d for d in dead if not any(d.startswith(u + "(") for u in heal_stopped)]
    return dead


def ports_open():
    listening = run("ss -tln 2>/dev/null | grep -oE ':[0-9]+ ' | tr -d ': ' | sort -u")
    lp = set(listening.split())
    # 2026-08-27 补 3200(mrd-host)/18080(llm-gateway): 迁移后 11:18 空窗 25min 漏报教训
    dead = [p for p in ("3000", "3031", "3032", "3033", "3034", "3200", "18080") if p not in lp]
    # 2026-08-27 P0 降载感知: 受控降载(selfheal_state 登记)停掉的服务, 其端口不算故障——
    # 否则降载救火后下一轮巡检立刻报 port-down, 制造虚假告警(22:00-22:26 四连误报教训)
    heal_stopped = set(_load_heal_state().get("stopped", {}))
    if heal_stopped:
        degraded_ports = {p for svc in heal_stopped for p in HEAL_SERVICE_PORTS.get(svc, [])}
        if degraded_ports:
            dead = [p for p in dead if p not in degraded_ports]
    return dead


def probe_sites():
    import socket
    targets = [("www.hermes.cc.cd", 443), ("opc.hermes.cc.cd", 443), ("127.0.0.1", 18080)]
    results = {}
    for host, port in targets:
        ok = False
        try:
            s = socket.create_connection((host, port), timeout=3)
            s.close()
            ok = True
        except Exception:
            ok = False
        results[f"{host}:{port}"] = ok
    return results


def fmt_bytes(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def fmt_rate(bps):
    return fmt_bytes(bps) + "/s"


# ---------- 自救 ----------
def _load_heal_state():
    try:
        return json.load(open(SELFHEAL_STATE))
    except Exception:
        return {"stopped": {}}


def _save_heal_state(st):
    try:
        json.dump(st, open(SELFHEAL_STATE, "w"))
    except Exception:
        pass


def heal_restore(action_out):
    """降载恢复（2026-08-27 P0 修复）：受控降载必须可逆。
    内存/温度回落后，把降载时停掉的 opcos 服务 start 回来，否则 Restart=always
    不拉起显式 stop 的服务，降载就变成永久停机（22:00 内存自救停 5 服务后死透 25min+ 的教训）。
    滞回：降载 <10% 可用内存，恢复 >20% 才动作，防抖。"""
    st = _load_heal_state()
    stopped = st.get("stopped", {})
    if not stopped:
        return
    t = temp()
    mt, ma, _ = mem()
    if t >= HEAL_RESTORE_TEMP:
        return  # 仍过热，等下一轮
    if not (mt and ma / mt * 100 > HEAL_RESTORE_MEM_PCT):
        return  # 内存仍紧张，等下一轮
    for svc in list(stopped):
        cur = run(f"systemctl is-active {svc} 2>/dev/null").strip()
        if cur == "active":
            del stopped[svc]  # 已被外部恢复（重启/手动），清登记
            continue
        if run(f"sudo -n systemctl start {svc}"):
            action_out.append(f"降载恢复: start {svc}")
            del stopped[svc]
        else:
            action_out.append(f"⚠️ 降载恢复失败: {svc}({cur or '?'})，下轮重试")
    st["stopped"] = stopped
    _save_heal_state(st)


def _mark_heal_stop(svc):
    st = _load_heal_state()
    st.setdefault("stopped", {})[svc] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _save_heal_state(st)


def self_heal(warn_out, action_out):
    """异常时的自救动作。warn_out/action_out 是 list（就地追加）。"""
    # 先尝试恢复上次降载的服务（可逆原则）
    heal_restore(action_out)

    # 温度过高 → 停可杀服务（2026-08-27: pm2→systemd, sudo -n 因 opcos-* 是系统级 unit）
    t = temp()
    if t >= 88:
        warn_out.append(f"🔥 过热 {t}°C ≥ 88")
        stopped = []
        for svc in HEAL_STOP_SERVICES:
            if run(f"sudo -n systemctl stop {svc}"):
                action_out.append(f"过热降载: 停 systemd {svc}")
                _mark_heal_stop(svc)
                stopped.append(svc)
        if stopped:
            # P2 信息留痕（status=resolved 不进 read_new；降载闭环归因证据）
            _bus_append("P2", "degrade", f"受控降载中: 过热已停 {','.join(stopped)} (self-heal 自动恢复)",
                        f"过热 {t}°C ≥ 88, 停 {','.join(stopped)}")

    # 内存告急（可用 < 10%，用 kB 比例判断，不用换算）
    mtkb, makb, mp = mem()
    if mtkb and (makb / mtkb * 100) < 10:
        warn_out.append(f"⚠️ 内存告急: 可用 {makb//1024}MB/{mtkb//1024}MB ({makb/mtkb*100:.0f}%)")
        stopped = []
        for c in ["opcos31dr-opc-api", "opcos31dr-web", "opcos31dr-collector"]:
            if run(f"docker stop {c}"):
                action_out.append(f"内存自救: 停 docker {c}")
                stopped.append(c)
        for svc in HEAL_STOP_SERVICES:
            if run(f"sudo -n systemctl stop {svc}"):
                action_out.append(f"内存自救: 停 systemd {svc}")
                _mark_heal_stop(svc)
                stopped.append(svc)
        if stopped:
            # P2 信息留痕（status=resolved 不进 read_new；降载闭环归因证据）
            _bus_append("P2", "degrade", f"受控降载中: 内存高压已停 {','.join(stopped)} (self-heal 自动恢复)",
                        f"可用 {makb//1024}MB/{mtkb//1024}MB ({makb/mtkb*100:.0f}%)")
    elif mtkb and (makb / mtkb * 100) < 15:
        warn_out.append(f"⚠️ 内存紧张: 可用 {makb//1024}MB/{mtkb//1024}MB ({makb/mtkb*100:.0f}%)")

    # /tmp 满 → 清 chrome 残留
    if tmp_use() >= 80:
        warn_out.append(f"⚠️ /tmp {tmp_use()}% 满, 自动清理")
        active = run("ps aux | grep -oE '\\-\\-user-data-dir=[^ ]+' | sed 's/--user-data-dir=//' | sort -u").splitlines()
        import glob
        for pattern in ["/tmp/chrome-*", "/tmp/*-chrome-*", "/tmp/ada-*", "/tmp/cdp-*", "/tmp/puppeteer_*"]:
            for g in glob.glob(pattern):
                if g in active:
                    continue
                if run(f"rm -rf '{g}'") or not os.path.exists(g):
                    action_out.append(f"清理 /tmp: {g}")

    # 磁盘 / 满 → 截日志
    if disk_pct("/") >= 85:
        warn_out.append(f"⚠️ 根磁盘 {disk_pct('/')}% 满, 自动清日志")
        for c in run("docker ps -q 2>/dev/null").split():
            lp = run(f"docker inspect {c} --format '{{{{.LogPath}}}}'")
            if lp and os.path.exists(lp):
                if run(f"truncate -s 5M {lp}"):
                    action_out.append(f"截断 docker 日志: {c}")
        run("journalctl --vacuum-time=3d")

    # 负载过高：load5(5min 均值) > 2×核 = 持续高负载（满足"持续"语义）；
    # load1 > 3×核 = 瞬时严重尖峰（保留即时告警）。单采样 2-3× 的瞬时抖动不再误报。
    la = loadavg()
    try:
        l1, l5 = float(la[0]), float(la[1])
        cores = nproc()
        if l1 > cores * 3:
            warn_out.append(f"⚠️ 负载尖峰: load {la[0]} (核心 {cores}, >3×)")
        elif l5 > cores * 2:
            warn_out.append(f"⚠️ 持续高负载: load5 {la[1]} (核心 {cores}, 5min均值>2×)")
    except Exception:
        pass


# ---------- kanban 调度健康（生产板 gateway 内置 dispatcher） ----------
# 路径 env 参数化（OPC_* 覆盖，默认值生产路径兜底）；cron/gateway 派生环境 HOME 可能被重定向到 profile home，expanduser 不可靠
KANBAN_DB = os.environ.get("OPC_KANBAN_DB", f"{HOME}/.hermes/kanban/boards/opc/kanban.db")
KANBAN_LOCK = os.environ.get("OPC_KANBAN_LOCK", f"{HOME}/.hermes/kanban/.dispatcher.lock")
GATEWAY_LOG = os.environ.get("OPC_GATEWAY_LOG", f"{HOME}/.hermes/logs/gateway.log")
PROFILES_DIR = os.environ.get("OPC_PROFILES_DIR", f"{HOME}/.hermes/profiles")
XDG_RUNTIME_DIR_DEF = os.environ.get("OPC_XDG_RUNTIME_DIR", "/run/user/1000")
KANBAN_READY_STALE_H = 6        # ready 卡滞留告警阈值(小时)
KANBAN_STUCK_WINDOW_S = 1800    # 最近 N 秒内有 dispatcher stuck warning 视为调度受阻


def _dispatcher_lock_held():
    """flock 存活探测（零依赖、语义精确）：
    生产 dispatcher 单例锁 .dispatcher.lock 由 gateway 的 dispatcher watcher 启动时 flock 持有，
    进程退出时内核自动释放。探测：尝试非阻塞独占锁——加不上=有活进程持有=调度存活；
    能加上=无人持有=调度已停。探测后立即释放，不影响 gateway。
    返回 True(存活)/False(死亡)/None(探测失败)。"""
    try:
        fd = os.open(KANBAN_LOCK, os.O_RDWR | os.O_CREAT, 0o644)
    except Exception:
        return None
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(fd, fcntl.LOCK_UN)
            return False
        except OSError:
            return True
    finally:
        os.close(fd)


def _recent_dispatcher_stuck():
    """gateway.log 最近 KANBAN_STUCK_WINDOW_S 内是否有 'dispatcher stuck' warning。
    源码语义：ready 队列非空但连续 6 tick 0 spawn → 调度活着但派不动活（PATH/凭据/profile 健康问题）。
    返回告警行文本或空串。"""
    if not os.path.exists(GATEWAY_LOG):
        return ""
    try:
        with open(GATEWAY_LOG, errors="ignore") as f:
            lines = f.read().splitlines()
    except Exception:
        return ""
    for ln in reversed(lines[-3000:]):
        if "kanban dispatcher stuck" not in ln:
            continue
        try:
            t = datetime.strptime(ln.split(",")[0], "%Y-%m-%d %H:%M:%S")
            if (datetime.now() - t).total_seconds() < KANBAN_STUCK_WINDOW_S:
                return ln[:200]
        except Exception:
            pass
        break  # 只取最近一条
    return ""


def valid_profiles():
    """有效 spawnable profile = ~/.hermes/profiles/* 目录名 + default。
    dispatcher 只 spawn 真实存在的 profile，assignee 不在其内会永久滞留。"""
    profs = {"default"}
    try:
        for d in os.listdir(PROFILES_DIR):
            if os.path.isdir(os.path.join(PROFILES_DIR, d)):
                profs.add(d)
    except Exception:
        pass
    return profs


def kanban_ready_stale(db=KANBAN_DB, stale_h=KANBAN_READY_STALE_H):
    """opc 生产板 ready 卡滞留扫描：status='ready' 且进入 ready 已超 stale_h 小时。
    进入 ready 时间 = 最近一次 promoted/unblocked/status→ready 事件时间，无则回退 created_at。
    返回 [(task_id, assignee, title, since_ts, age_sec)]；DB 不可读时返回 [错误信息]。"""
    if not os.path.exists(db):
        return []
    try:
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT t.id, t.assignee, t.title, "
                "COALESCE((SELECT MAX(CASE WHEN e.kind IN ('promoted','unblocked') THEN e.created_at "
                "WHEN e.kind='status' AND json_extract(e.payload,'$.status')='ready' THEN e.created_at END) "
                "FROM task_events e WHERE e.task_id = t.id), t.created_at) AS since, t.created_at "
                "FROM tasks t WHERE t.status='ready'"
            )
            rows = cur.fetchall()
        finally:
            conn.close()
    except Exception as e:
        return [f"kanban DB 查询失败: {e}"]
    now = time.time()
    stale = []
    for tid, assignee, title, since, created_at in rows:
        ts = since or created_at or now
        age = now - ts
        if age > stale_h * 3600:
            stale.append((tid, assignee, (title or "")[:50], ts, age))
    return stale


# ---------- dispatcher-state 单一观测点（R-01/R-04，调度健康唯一事实源） ----------
# 由调度者（gateway 内置或外置 daemon）每 tick 原子写 dispatcher-state.json，
# 监控只读此文件 + 心跳新鲜度，不依赖任何进程日志；调度权交接对监控透明。
DISPATCHER_STATE = os.environ.get("OPC_DISPATCHER_STATE", f"{HOME}/.hermes/opc/dispatcher-state.json")
HERMES_CFG = os.environ.get("OPC_HERMES_CFG", f"{HOME}/.hermes/config.yaml")
DISPATCHER_UNIT = "opc-dispatcher.service"
HEARTBEAT_MULT = 2          # 心跳过期 = interval_seconds × 2
IDLE_BLOCKED_STALE_H = 24   # blocked 卡超时阈值(小时)：G 卡 blocked > 24h 视为板面停转待决策
IDLE_READY_STALE_H = 6      # ready 卡滞留阈值(小时)，与 KANBAN_READY_STALE_H 一致


def _read_dispatcher_state():
    """读 dispatcher-state.json。返回 (dict|None, err)。"""
    if not os.path.exists(DISPATCHER_STATE):
        return None, "dispatcher-state.json 缺失"
    try:
        with open(DISPATCHER_STATE, encoding="utf-8") as f:
            return json.load(f), None
    except Exception as e:
        return None, f"dispatcher-state.json 解析失败: {e}"


def _cfg_dispatch_in_gateway():
    """读 hermes 主 config.yaml 的 kanban.dispatch_in_gateway（gateway 内置调度开关）。
    返回 True/False；读不到返回 None。"""
    try:
        with open(HERMES_CFG, encoding="utf-8") as f:
            txt = f.read()
        # 只取 kanban: 段内首个 dispatch_in_gateway
        seg = txt.split("\nkanban:", 1)
        body = seg[1] if len(seg) > 1 else txt
        for ln in body.splitlines()[:80]:
            s = ln.strip()
            if s.startswith("dispatch_in_gateway:"):
                return s.split(":", 1)[1].strip().lower() == "true"
            if s and not s[0].isspace() and not s.startswith("#"):
                break  # 离开 kanban 段
    except Exception:
        pass
    return None


def _unit_active(unit):
    """systemctl --user is-active；cron 环境需 XDG_RUNTIME_DIR。返回 True/False/None。"""
    out = run(f"XDG_RUNTIME_DIR={XDG_RUNTIME_DIR_DEF} systemctl --user is-active {unit}")
    if out.strip() == "active":
        return True
    if out.strip() in ("inactive", "failed", "dead", "unknown"):
        return False
    return None


def _kanban_blocked_stale(db=KANBAN_DB, stale_h=IDLE_BLOCKED_STALE_H):
    """blocked 卡超时扫描：status='blocked' 且进入 blocked 已超 stale_h 小时。
    进入 blocked 时间 = 最近一次 blocked/unblocked→blocked/status→blocked 事件时间，无则回退 created_at。
    返回 [(task_id, assignee, title, since_ts, age_sec)]；DB 不可读返回 []。"""
    if not os.path.exists(db):
        return []
    try:
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT t.id, t.assignee, t.title, "
                "COALESCE((SELECT MAX(CASE WHEN e.kind='blocked' THEN e.created_at "
                "WHEN e.kind='status' AND json_extract(e.payload,'$.status')='blocked' THEN e.created_at END) "
                "FROM task_events e WHERE e.task_id = t.id), t.created_at) AS since, t.created_at "
                "FROM tasks t WHERE t.status='blocked'"
            )
            rows = cur.fetchall()
        finally:
            conn.close()
    except Exception:
        return []
    now = time.time()
    stale = []
    for tid, assignee, title, since, created_at in rows:
        ts = since or created_at or now
        age = now - ts
        if age > stale_h * 3600:
            stale.append((tid, assignee, (title or "")[:50], ts, age))
    return stale


def dispatcher_state_health():
    """dispatcher-state.json 单一观测点判定（R-04 监控缺口）：
    ① 心跳新鲜度：written_at 距今 > 2×interval_seconds → 调度停摆
    ② 错位 a：config dispatch_in_gateway=false 但持锁者是 gateway → 内置未按配置退出
    ③ 错位 b：config false（外置模式）但 opc-dispatcher.service 非 active → 生产 daemon 未运行
    ④ 错位 c：state 缺失且锁无人持有 → 无调度者（最高危）
    ⑤ 空转：ready/running 双空 且 blocked 超时卡（>24h）→ 板面停转待决策
    ⑥ 无效 assignee / stale ready：从 state.ready_queue 直接读（watchdog 已算好），不重复扫描 DB
    返回 (warns: list[str], rec: dict 留底字段)。"""
    SRC = f" [state: {DISPATCHER_STATE}]"
    warns, rec = [], {}
    st, err = _read_dispatcher_state()
    if st is None:
        rec["state"] = "missing"
        rec["state_err"] = err
        # 错位 c：state 缺失且锁无人持 → 无调度者
        lock = _dispatcher_lock_held()
        if lock is False:
            warns.append(f"⚠️ kanban 调度异常: dispatcher-state.json 缺失 且 dispatcher 锁无人持有（无调度者，最高危）{SRC}")
        elif lock is True:
            warns.append(f"⚠️ kanban 调度未知: dispatcher-state.json 缺失 但 dispatcher 锁被持有（调度者在跑但未写 state）{SRC}")
        else:
            warns.append(f"⚠️ kanban 调度未知: {err}{SRC}")
        rec["lock_held"] = lock
        return warns, rec

    rec["state"] = "ok"
    rec["schema"] = st.get("schema")
    now = time.time()
    written = st.get("written_at") or 0
    interval = st.get("interval_seconds") or 60
    age = now - written
    rec["heartbeat_age_s"] = round(age, 1)
    rec["tick"] = st.get("tick", {}).get("no")
    rec["lock_state"] = st.get("lock", {}).get("state")
    rec["holder_pid"] = st.get("pid")
    holder_proc = st.get("proc") or ""

    # ① 心跳新鲜度
    if age > interval * HEARTBEAT_MULT:
        warns.append(
            f"⚠️ kanban 调度停摆: state 心跳过期 {age/60:.0f}min "
            f"(last_tick={st.get('written_at_iso')}, interval={interval}s, tick={st.get('tick',{}).get('no')}){SRC}"
        )

    # ② 错位 a：内置未按配置退出
    cfg_gateway = _cfg_dispatch_in_gateway()
    rec["cfg_dispatch_in_gateway"] = cfg_gateway
    holder_is_gateway = "gateway" in holder_proc.lower()
    if cfg_gateway is False and holder_is_gateway:
        warns.append(
            f"⚠️ kanban 错位: config dispatch_in_gateway=false 但持锁者是 gateway "
            f"(pid={st.get('pid')}, proc={holder_proc[:80]}) → 内置调度未按配置退出{SRC}"
        )

    # ③ 错位 b：外置 daemon 应持锁但 unit 非 active
    unit = _unit_active(DISPATCHER_UNIT)
    rec["unit_active"] = unit
    if cfg_gateway is False and unit is False and not holder_is_gateway:
        warns.append(f"⚠️ kanban 错位: {DISPATCHER_UNIT} inactive（config 外置模式，生产 daemon 未运行）{SRC}")

    # ④ 错位 c：锁无人持有（state 显示非 held 且 flock 探测无持有者）
    if st.get("lock", {}).get("state") != "held" and _dispatcher_lock_held() is False:
        warns.append(f"⚠️ kanban 调度异常: dispatcher 锁未持有（无调度者，最高危）{SRC}")

    # ⑤ 空转：ready/running 双空 + blocked 超时卡
    q = st.get("queue", {}).get("opc", {}) or {}
    by_status = q.get("by_status") or {}
    ready_n = by_status.get("ready", 0)
    running_n = by_status.get("running", 0)
    rec["ready"] = ready_n
    rec["running"] = running_n
    blocked_stale = _kanban_blocked_stale()
    rec["blocked_stale_n"] = len(blocked_stale)
    if ready_n == 0 and running_n == 0 and blocked_stale:
        cards = " ".join(f"{tid}({assignee})" for tid, assignee, *_ in blocked_stale[:6])
        warns.append(
            f"⚠️ kanban 板面停转待决策: ready=0/running=0 且 blocked 超时卡 {len(blocked_stale)} 张"
            f"（G 卡 blocked>{IDLE_BLOCKED_STALE_H}h）: {cards}{SRC}"
        )

    # ⑥ 无效 assignee / stale ready：直接读 state.ready_queue（watchdog 算好）
    scan = q.get("scan") or {}
    rq = scan.get("ready_queue") or []
    invalid = [c for c in rq if c.get("valid") is False]
    stale_rq = [c for c in rq if (c.get("dwell_s") or 0) > IDLE_READY_STALE_H * 3600]
    rec["invalid_assignee"] = len(invalid)
    rec["ready_stale_n"] = len(stale_rq)
    if invalid:
        cards = " ".join(f"{c.get('id')}({c.get('assignee')})" for c in invalid[:8])
        warns.append(f"⚠️ kanban 无效 assignee {len(invalid)} 张: {cards}{SRC}")
    if stale_rq:
        cards = " ".join(f"{c.get('id')} {c.get('dwell_s',0)//3600}h" for c in stale_rq[:8])
        warns.append(f"⚠️ kanban ready 卡滞留 {len(stale_rq)} 张: {cards}{SRC}")

    return warns, rec


# ---------- dispatcher 环境自检（0827 事故固化：token / 401 窗口 / spawn 失败率） ----------
# 事故：外部 dispatcher daemon 裸进程启动缺 GATEWAY_CLIENT_TOKEN（unit 缺 EnvironmentFile），
#      worker 的 LLM provider=hermes-opc(18080) 全部 401 → 30+ crash / 13 卡 auto_blocked。
# 权威源=task_events（crashed+protocol_violation）；不扫 worker 日志文本——会话上下文会引用
#      401 文案（任务卡正文/grep 输出），文本扫描自指误报（0827 夜实测）。
W401_LOOKBACK_S = 86400        # 401 窗口回看：近 24h（无窗口时静默，有则告警）
W401_ALERT_MIN = 5             # 窗口内 failed 事件 ≥5 视为一次 401 窗口（单条噪音不告警）
W401_EPISODE_GAP_S = 1800      # 两次 failed 事件间隔 >30min 视为新 episode → 可再次告警
W401_STATE = os.path.join(BASE, "w401_state.json")   # {last_alert_ts}：每 episode 只告警一次，防刷屏
SPAWN_FAIL_RATIO = 0.30        # 近 1h spawn 失败率告警阈值（0827 事故峰值远超此线）


def _proc_environ_token(pid):
    """读 /proc/<pid>/environ：GATEWAY_CLIENT_TOKEN 存在且非空。True/False/None(不可读)。"""
    if not isinstance(pid, int) or pid <= 0:
        return None
    try:
        raw = open(f"/proc/{pid}/environ", "rb").read()
    except Exception:
        return None
    for kv in raw.split(b"\x00"):
        if b"=" not in kv:
            continue
        k, _, v = kv.partition(b"=")
        if k == b"GATEWAY_CLIENT_TOKEN" and v.strip():
            return True
    return False


def _fail_events(since_ts):
    """近 since_ts 秒 failed 事件数（crashed+protocol_violation）。返回 (n, first_ts, last_ts)。"""
    try:
        conn = sqlite3.connect(f"file:{KANBAN_DB}?mode=ro", uri=True, timeout=5)
        try:
            row = conn.execute(
                "SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM task_events "
                "WHERE kind IN ('crashed','protocol_violation') AND created_at > ?",
                (since_ts,)).fetchone()
        finally:
            conn.close()
    except Exception:
        return (0, None, None)
    if not row:
        return (0, None, None)
    return (int(row[0] or 0), row[1], row[2])


def _w401_state():
    try:
        with open(W401_STATE) as f:
            return json.load(f).get("last_alert_ts", 0)
    except Exception:
        return 0


def _w401_state_save(ts):
    try:
        with open(W401_STATE, "w") as f:
            json.dump({"last_alert_ts": ts}, f)
    except Exception:
        pass


def _spawn_failure_ratio(db=KANBAN_DB, window_s=3600):
    """近 1h spawn 失败率：(crashed+protocol_violation)/(spawned+同失败)。
    返回 (spawned, failed, ratio|None)；DB 不可读返回 (None, None, None)。"""
    if not os.path.exists(db):
        return (None, None, None)
    try:
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
        try:
            row = conn.execute(
                "SELECT "
                "SUM(CASE WHEN kind='spawned' THEN 1 ELSE 0 END), "
                "SUM(CASE WHEN kind IN ('crashed','protocol_violation') THEN 1 ELSE 0 END) "
                "FROM task_events WHERE created_at > ?", (time.time() - window_s,)).fetchone()
        finally:
            conn.close()
    except Exception:
        return (None, None, None)
    if not row:
        return (0, 0, None)
    spawned = int(row[0] or 0)
    failed = int(row[1] or 0)
    if spawned + failed == 0:
        return (spawned, failed, None)
    return (spawned, failed, failed / (spawned + failed))


def dispatcher_env_health():
    """dispatcher 环境自检（0827 事故固化）。返回 (warns, rec)。
    rec: {dpid, token_ok, fail24h, w401_last_ts, spawn_1h:{spawned, failed, ratio}}"""
    warns, rec = [], {}
    # 1) daemon environ token（state.json 的 pid=生产调度者）
    pid = None
    st, _ = _read_dispatcher_state()
    if st and isinstance(st.get("pid"), int):
        pid = st["pid"]
    rec["dpid"] = pid
    if pid:
        tok = _proc_environ_token(pid)
        rec["token_ok"] = tok
        if tok is False:
            warns.append(f"⚠️ dispatcher 环境缺 GATEWAY_CLIENT_TOKEN (pid {pid}) — 0827 401 事故同款根因；修复: systemctl --user restart opc-dispatcher")
        elif tok is None:
            warns.append(f"⚠️ dispatcher environ 不可读 (pid {pid})")
    else:
        rec["token_ok"] = None  # state 缺失由心跳检查覆盖，不重复告警
    # 2) 近 24h 401/崩溃窗口（≥5 次算一次窗口；新 episode 才告警，防刷屏）
    n_fail, t0, t1 = _fail_events(time.time() - W401_LOOKBACK_S)
    rec["fail24h"] = n_fail
    last_alert = _w401_state()
    is_new_episode = last_alert == 0 or (t1 is not None and (t1 - last_alert) > W401_EPISODE_GAP_S)
    if n_fail >= W401_ALERT_MIN and t1 and is_new_episode:
        rng = (f"{time.strftime('%m-%d %H:%M', time.localtime(t0))}~{time.strftime('%H:%M', time.localtime(t1))}"
               if t0 else "?")
        warns.append(f"⚠️ 近 24h 存在 401/崩溃窗口: failed 事件 {n_fail} 次 ({rng}) — 0827 同款；已恢复则忽略，持续则查 spawn 失败率")
        _w401_state_save(t1)
    rec["w401_last_ts"] = t1
    # 3) 近 1h spawn 失败率（持续事故探测器：事故期间每 tick 都超线）
    sp, fa, ratio = _spawn_failure_ratio()
    rec["spawn_1h"] = {"spawned": sp, "failed": fa, "ratio": round(ratio, 3) if ratio is not None else None}
    if ratio is not None and ratio > SPAWN_FAIL_RATIO:
        warns.append(f"⚠️ 近 1h worker spawn 失败率 {ratio*100:.0f}% ({fa}/{sp+fa}) > {SPAWN_FAIL_RATIO*100:.0f}% — 0827 401 同款；修复: systemctl --user restart opc-dispatcher + unblock 残留卡")
    return warns, rec


# ---------- 告警总线（0827 整改 ALERT-LOOP：输出告警同步写总线，定稿 schema 9 字段） ----------
BUS_SCRIPT = os.environ.get("OPC_BUS_SCRIPT", f"{HOME}/.hermes/scripts/opc-alert-bus.py")


def _bus_append(severity, type_, title, evidence):
    """写一条告警总线（失败静默——总线故障不影响监控主流程/stdout 契约）。"""
    try:
        subprocess.run(
            [sys.executable, BUS_SCRIPT, "append",
             "--source", "system-monitor",
             "--severity", severity,
             "--type", type_,
             "--title", title,
             "--evidence", str(evidence)[:1500]],
            capture_output=True, text=True, timeout=15)
    except Exception:
        pass


def _classify_warn(w, dead, mt, ma):
    """warn 文本 → (severity, type, title)。脚本打初步级别，路由 agent 最终判定（定稿判定表）。"""
    if "系统重启检测" in w:
        return "P0", "system-reboot", w
    if "调度停摆" in w or "锁未持有（无调度者" in w or "锁无人持有" in w:
        return "P0", "dispatcher-stall", w
    if "缺 GATEWAY_CLIENT_TOKEN" in w:
        return "P0", "dispatcher-token", w
    if "401/崩溃窗口" in w:
        return "P0", "dispatcher-w401", w
    if "spawn 失败率" in w:
        return "P0", "dispatcher-spawn-fail", w
    if "服务异常" in w:
        n = len(dead) if isinstance(dead, list) else 1
        return ("P0" if n >= 2 else "P1"), "service-down", w
    if "内存低" in w:
        pct = ((mt - ma) / mt * 100) if mt else 100  # 可用比例
        return ("P0" if pct < 10 else "P1"), "mem-low", w
    if "端口未监听" in w:
        return "P1", "port-down", w
    if "Swap 高" in w:
        return "P1", "swap-high", w
    if "ready 卡滞留" in w:
        return "P1", "ready-stale", w
    if "无效 assignee" in w:
        return "P1", "invalid-assignee", w
    if "板面停转" in w:
        return "P1", "board-stalled", w
    if "调度受阻" in w or "调度未知" in w or "锁探测失败" in w:
        return "P1", "dispatcher-unknown", w
    if "错位" in w:
        return "P1", "dispatcher-misaligned", w
    return "P1", "other", w


def main():
    la = loadavg()
    mt, ma, mp = mem()
    su, st, sp = swap()
    dp = disk_pct("/")
    tp = tmp_use()
    rates, rx, tx = net_rates()
    tc = sockstat()
    dead = pm2_dead()
    ports = ports_open()
    sites = probe_sites()
    ncores = nproc()
    now = datetime.now()

    warns = []
    actions = []

    # kanban 调度健康（dispatcher-state.json 单一观测点）：心跳/错位/空转/无效 assignee
    kb_state_warns, kb_state_rec = dispatcher_state_health()
    warns.extend(kb_state_warns)
    # dispatcher 环境自检（0827 事故固化）：token 存在性 / 24h 401 窗口 / spawn 失败率
    kb_env_warns, kb_env_rec = dispatcher_env_health()
    warns.extend(kb_env_warns)
    kb_lock = _dispatcher_lock_held()
    kb_stuck = _recent_dispatcher_stuck()
    if kb_lock is False:
        warns.append("⚠️ kanban 调度异常: 生产 dispatcher 锁无人持有 (gateway 未运行/调度已停)")
    elif kb_lock is None:
        warns.append("⚠️ kanban 调度未知: dispatcher 锁探测失败")
    if kb_stuck:
        warns.append(f"⚠️ kanban 调度受阻: {kb_stuck}")
    # ready 卡滞留扫描（DB 兜底；state 版由 dispatcher_state_health 的 ⑥ 提供）
    kb_stale = kanban_ready_stale()
    kb_stale_err = False
    if kb_stale and isinstance(kb_stale[0], str):
        warns.append(f"⚠️ {kb_stale[0]}")
        kb_stale_err = True
    elif kb_state_rec.get("ready_stale_n", 0) == 0:
        # state 版未报滞留时，用 DB 版交叉验证（防止 state.ready_queue 缺失漏报）
        profs = valid_profiles()
        for tid, assignee, title, since, age in kb_stale:
            flag = "" if assignee in profs else f" [assignee 无效: {assignee}]"
            warns.append(f"⚠️ ready 卡滞留 {age/3600:.0f}h: {tid} {title} (assignee={assignee}){flag}")
    kb_stale_n = len(kb_stale) if not kb_stale_err else None

    # 检测告警
    if dead:
        warns.append(f"⚠️ OPC-OS 服务异常(非 active): {','.join(dead)}")
    if ports:
        warns.append(f"⚠️ 端口未监听: {','.join(ports)}")
    if mp is not None and mt and (mt - ma) / mt * 100 < 15:
        warns.append(f"⚠️ 内存低: 可用 {ma//1024}MB/{mt//1024}MB")
    if sp >= 80:
        warns.append(f"⚠️ Swap 高: {su//1024}MB/{st//1024}MB")
    # 自救
    self_heal(warns, actions)

    # 重启检测：boot_id 与上次记录不同 → 系统重启过 → 告警并归因
    boot_id = run("cat /proc/sys/kernel/random/boot_id").strip()
    prev_boot = ""
    if os.path.exists(BOOT_MARK):
        try:
            prev_boot = open(BOOT_MARK).read().strip()
        except Exception:
            prev_boot = ""
    rebooted = False
    if prev_boot and prev_boot != boot_id:
        rebooted = True
        up = run("uptime -p") or "?"
        ww = run("grep -E 'FATAL|FUSE' /var/log/wifi-watchdog.log 2>/dev/null | tail -2").replace("\n", " | ")
        warns.append(f"🔄 系统重启检测: 新 boot {boot_id[:8]} (上次 {prev_boot[:8]}, {up})")
        if ww:
            warns.append(f"   wifi-watchdog 归因: {ww}")
        else:
            warns.append("   归因: 无 watchdog FATAL 记录（电源/硬件级重启或手动）")
    try:
        with open(BOOT_MARK, "w") as f:
            f.write(boot_id)
    except Exception:
        pass

    # 留底记录（始终追加）
    rec = {
        "ts": now.strftime("%Y-%m-%d %H:%M:%S"),
        "load1": la[0], "load5": la[1], "load15": la[2],
        "mem_used_pct": mp, "swap_used_pct": sp,
        "disk_pct": dp, "tmp_pct": tp,
        "net_rx_bps": round(rx, 1), "net_tx_bps": round(tx, 1),
        "tcp_inuse": tc["inuse"], "tcp_tw": tc["tw"],
        "pm2_dead": dead, "ports_closed": ports, "probe": sites,
        "reboot": rebooted, "boot_id": boot_id[:8],
        "kanban_lock": kb_lock, "kanban_stale": (len(kb_stale) if not kb_stale_err else None),
        "kb_state": kb_state_rec,
        "dispatcher_env": kb_env_rec,
        "warns": warns, "actions": actions,
    }
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception as e:
        log_line(f"sysmon write_err: {e}")

    # ---------- 输出决策 ----------
    out = ""
    # 1. 有异常 → 即时告警（无论是否整点）
    if warns:
        out += f"🖥️ 系统告警 {now.strftime('%m-%d %H:%M')}\n" + "\n".join(warns) + "\n"
        if actions:
            out += "\n🛠️ 自救:\n" + "\n".join(actions) + "\n"
        log_line("ALERT: " + " | ".join(warns + actions))
        # 告警总线：每条 warn 同步写总线（脚本打初步级别，路由 agent 最终判定）
        for w in warns:
            sev, typ, ttl = _classify_warn(w, dead, mt, ma)
            _bus_append(sev, typ, ttl, w)
        if actions:
            # 自救已完成项 → P2 信息留痕（定稿 P2 判定表）
            _bus_append("P2", "self-heal", "自救已完成", " | ".join(actions))

    # 2. 整点 → 追加每小时汇总
    if now.minute == 0:
        ok = sum(1 for v in sites.values() if v)
        site_txt = " ".join(f"{h.split(':')[0]}:{'✓' if v else '✗'}" for h, v in sites.items())
        head = "【OPC 系统监控·整点】" if not out else ""  # 有告警时合并
        summary = (
            f"【OPC 系统监控 {now.strftime('%m-%d %H:%M')}】\n"
            f"负载: {' '.join(la)} | 内存: {mp}% | 磁盘/: {dp}% | /tmp: {tp}%\n"
            f"网络: ↑{fmt_rate(tx)} ↓{fmt_rate(rx)} | TCP:{tc['inuse']}(TW {tc['tw']})\n"
            f"探针: {site_txt} | 健康 {ok}/{len(sites)}\n"
            f"调度: {({True: '✓', False: '✗', None: '?'}[kb_lock])}{'·stuck' if kb_stuck else ''} | "
            f"state:{kb_state_rec.get('heartbeat_age_s', -1):.0f}s·tick{str(kb_state_rec.get('tick')) if kb_state_rec.get('tick') is not None else '?'} "
            f"| ready滞留: {len(kb_stale) if not kb_stale_err else '?'}\n"
            f"环境自检: token {({True: '✓', False: '✗', None: '?'}[kb_env_rec.get('token_ok')])} "
            f"| 24h失败:{kb_env_rec.get('fail24h', 0)} | 1h失败率:{kb_env_rec.get('spawn_1h', {}).get('ratio')}\n"
            f"留底: {LOG}"
        )
        # 整点即使有告警也合并成一条完整报告（避免分开刷屏）
        if out:
            out = out.rstrip() + "\n\n" + summary
        else:
            out = summary
        log_line("HOURLY: " + summary.replace("\n", " "))
        # 整点汇总 → P2 信息留痕（定稿 P2 判定表；不打扰、进日报）
        _bus_append("P2", "hourly-summary", "整点汇总", summary)

    if out:
        print(out)


if __name__ == "__main__":
    main()
