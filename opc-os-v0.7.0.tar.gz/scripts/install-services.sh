#!/bin/bash
# =============================================================================
# OPC-OS — 原生进程化安装/启停脚本（0826-osv-1，Gavin 拍板去 docker 化交付）
#
# 替代 docker-compose 的一键安装器：把 opc-init 产物 + opc-os 仓直接跑成
# 5 个原生进程（llm-gateway / opc-api / web / collector[opc-bus] / dispatcher），
# 依赖只有 node + python3（均已在环境自举阶段装好），不依赖 docker。
#
#   服务         启动方式                         端口
#   llm-gateway  node server.js                  18080（127.0.0.1 回环）
#   opc-api      node index.cjs                   3033
#   web          node scripts/web-serve.js         8081
#   collector    opc-bus.py 常驻 + 宿主机 crontab   （采集/归因/同步）
#   dispatcher   python3 -m kanban_dispatcher.cli  （弹性调度）
#
# 守护方式（自动选择）：
#   - 有 systemd（/run/systemd/system）→ 渲染 systemd/*.service.in 到
#     /etc/systemd/system/opcos-*.service 并 enable + restart（Gavin 首选）
#   - 无 systemd（如精简 LXC）→ 退化为 nohup+pidfile 守护脚本（本文件 start/stop/status）
#
# 用法:
#   scripts/install-services.sh install \
#       --out ~/opc-test [--opc-os <仓目录>] [--web-port 8081] [--api-port 3033] \
#       [--gateway-port 18080] [--tier small|medium|large] [--mem-mb N] [--cpus N] \
#       [--workbench-api http://<host>:3033] [--hermes-agent-src <fork 目录>] \
#       [--env-file <env 文件>] \
#       [--systemd|--no-systemd]
#   scripts/install-services.sh start|stop|status|restart [--out <目录>]
#   scripts/install-services.sh uninstall --out <目录>
#
# 幂等：install 可重复跑（重跑只补齐缺失项，不破坏已有数据/配置）。
# 红线：key 只进 <out>/llm.env（chmod 600，脚本不读写明文）；WORKBENCH_TOKEN
#       自动生成写 <out>/secrets.env（chmod 600）；本脚本输出零明文 key。
# =============================================================================
set -euo pipefail

# ---- 路径 ----
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# ---- 可配置项 ----
OUT=""                    # opc-init 输出目录（install 必填）
WEB_PORT=8081
API_PORT=3033
GATEWAY_PORT=18080
TIER=""                   # small|medium|large → KANBAN_DISPATCHER_TIER
CAP_MEM=""
CAP_CPUS=""
WORKBENCH_API=""
HERMES_AGENT_SRC="${HERMES_AGENT_SRC:-$HOME/.opc-os/hermes-agent}"
ENV_FILE=""               # systemd EnvironmentFile 来源；空=自动解析（secrets.env → ~/.hermes/.env）
SYSTEMD_MODE="auto"       # auto|force|none
CMD="install"

SERVICES="gateway api web collector dispatcher"

info()  { echo "[opc-os] $*"; }
warn()  { echo "[opc-os] ⚠️  $*" >&2; }
die()   { echo "[opc-os] ❌ $*" >&2; exit 1; }

usage() {
  cat <<'EOF'
OPC-OS 原生进程化安装/启停脚本

用法:
  install-services.sh install   [选项]          一键安装 + 启动 5 服务（默认子命令）
  install-services.sh start|stop|status|restart [--out <目录>]
  install-services.sh uninstall [--out <目录>]  停止 + 移除 systemd unit / crontab

选项:
  --out <目录>          opc-init 输出目录（必填；含 llm.env/config/kanban.db/hermes-home）
  --opc-os <目录>        opc-os 仓根目录（默认本脚本上级）
  --web-port N          透明办公室端口（默认 8081）
  --api-port N          opc-api 端口（默认 3033）
  --gateway-port N      llm-gateway 端口（默认 18080）
  --tier small|medium|large   弹性档位 → KANBAN_DISPATCHER_TIER（默认自动探测）
  --mem-mb N / --cpus N        显式容量覆盖（KANBAN_DISPATCHER_CAPACITY_*）
  --workbench-api URL   注入 workbench.html 的 API base（默认不注入）
  --hermes-agent-src <目录>    hermes fork 安装目录（默认 ~/.opc-os/hermes-agent）
  --env-file <路径>      systemd EnvironmentFile 来源（默认自动：<out>/secrets.env，其次 ~/.hermes/.env）
  --systemd / --no-systemd     强制/禁用 systemd 守护（默认自动检测）
EOF
}

# ---- 参数解析 ----
while [ $# -gt 0 ]; do
  case "$1" in
    install|start|stop|status|restart|uninstall) CMD="$1"; shift ;;
    --out) OUT="${2:-}"; shift 2 ;;
    --opc-os) REPO_DIR="$(cd "${2:-}" && pwd)"; shift 2 ;;
    --web-port) WEB_PORT="$2"; shift 2 ;;
    --api-port) API_PORT="$2"; shift 2 ;;
    --gateway-port) GATEWAY_PORT="$2"; shift 2 ;;
    --tier) TIER="$2"; shift 2 ;;
    --mem-mb) CAP_MEM="$2"; shift 2 ;;
    --cpus) CAP_CPUS="$2"; shift 2 ;;
    --workbench-api) WORKBENCH_API="$2"; shift 2 ;;
    --hermes-agent-src) HERMES_AGENT_SRC="$(cd "${2:-}" && pwd)"; shift 2 ;;
    --env-file) ENV_FILE="$(realpath -m "${2:-}")"; shift 2 ;;
    --systemd) SYSTEMD_MODE="force"; shift ;;
    --no-systemd) SYSTEMD_MODE="none"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "未知参数: $1（-h 看用法）" ;;
  esac
done

[ -n "$OUT" ] || die "缺少 --out <opc-init 输出目录>（install 必填）"
OUT="$(realpath -m "$OUT")"

NODE_BIN="$(command -v node || true)"
PYTHON_BIN="$(command -v python3 || true)"

systemd_available() {
  [ "$SYSTEMD_MODE" = "force" ] && return 0
  [ "$SYSTEMD_MODE" = "none" ] && return 1
  [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1
}

# ---- 生成原生 config（/data → <OUT> 路径重写，json 级安全替换）----
gen_native_config() {
  [ -f "$OUT/config/config.json" ] || die "$OUT/config/config.json 不存在（先跑 opc-init）"
  python3 - "$OUT" <<'PY'
import json, os, sys
out = sys.argv[1]
src = os.path.join(out, 'config', 'config.json')
dst = os.path.join(out, 'config', 'config.native.json')
data = json.load(open(src, encoding='utf-8'))
changes = []

def fix(v):
    if isinstance(v, str) and v.startswith('/data'):
        nv = out + v[len('/data'):]
        if nv != v:
            changes.append((v, nv))
        return nv
    return v

def walk(o):
    if isinstance(o, dict):
        return {k: walk(v) for k, v in o.items()}
    if isinstance(o, list):
        return [walk(x) for x in o]
    return fix(o)

new = walk(data)
json.dump(new, open(dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(f'[opc-os] 原生 config → {dst}（paths 重写 {len(changes)} 项）')
for old, nv in changes[:12]:
    print(f'          {old} → {nv}')
PY
}

# ---- 生成 dispatcher.yaml（/data/hermes-home → <OUT>/hermes-home）----
gen_dispatcher_cfg() {
  python3 - "$OUT" "$REPO_DIR" <<'PY'
import sys
out, repo = sys.argv[1], sys.argv[2]
src = f'{repo}/config/dispatcher.yaml'
dst = f'{out}/config/dispatcher.yaml'
text = open(src, encoding='utf-8').read()
new = text.replace('hermes_home: /data/hermes-home', f'hermes_home: {out}/hermes-home')
open(dst, 'w', encoding='utf-8').write(new)
print(f'[opc-os] dispatcher 配置 → {dst}')
PY
}

# ---- 每日版本检查的 cron 表达式计算（D3：间隔 env 可配）----
# 优先级：OPC_UPDATE_CHECK_CRON（原始 cron 表达式，显式覆盖）
#        > OPC_UPDATE_CHECK_INTERVAL（语义间隔：daily/hourly/Nh/Nd）
#        > 默认 daily（每日 04:30）
update_check_cron() {
  if [ -n "${OPC_UPDATE_CHECK_CRON:-}" ]; then
    echo "$OPC_UPDATE_CHECK_CRON"
    return 0
  fi
  local iv="${OPC_UPDATE_CHECK_INTERVAL:-daily}"
  case "$iv" in
    daily|day|1d|"") echo "30 4 * * *" ;;
    hourly|hour|1h)  echo "15 * * * *" ;;
    *d)              echo "30 4 */${iv%d} * *" ;;
    *h)              echo "0 */${iv%h} * * *" ;;
    *)               echo "$iv" ;;   # 无法识别的值被视为原始 cron 表达式透传
  esac
}

# ---- crontab 安装（幂等：先删旧块再写新块）----
install_crontab() {
  local m1="# >>> OPC-OS collector (install-services.sh) >>>"
  local m2="# <<< OPC-OS collector <<<"
  local tmp check_cron
  check_cron="$(update_check_cron)"
  tmp="$(mktemp)"
  crontab -l 2>/dev/null | sed "/^# >>> OPC-OS collector/,/^# <<< OPC-OS collector/d" > "$tmp" || true
  cat >> "$tmp" <<EOF
$m1
*/1 * * * * cd $REPO_DIR/scripts && OPC_OS_CONFIG=$OUT/config/config.native.json python3 opc_collect.py >> $OUT/logs/collect.log 2>&1; OPC_OS_CONFIG=$OUT/config/config.native.json python3 token_stats.py >> $OUT/logs/tokenstats.log 2>&1
*/5 * * * * cd $REPO_DIR/scripts && OPC_OS_CONFIG=$OUT/config/config.native.json python3 llm_gateway_sync.py --src $OUT/llm-gateway --out $OUT/llm-gateway.json >> $OUT/logs/llm-gateway-sync.log 2>&1
$check_cron cd $REPO_DIR/scripts && OPC_OS_REPO=$REPO_DIR OPC_OS_STATE_DIR=$HOME/.opc-os OPC_DATA_DIR=$OUT python3 opc-os-check-update.py --json >> $OUT/logs/check-update.log 2>&1
$m2
EOF
  crontab "$tmp"
  rm -f "$tmp"
  info "crontab 已安装（collector 每分钟采集归因 + 每 5 分钟网关同步 + 每日版本检查 [$check_cron]）"
}

remove_crontab() {
  local m1="# >>> OPC-OS collector (install-services.sh) >>>"
  local m2="# <<< OPC-OS collector <<<"
  local tmp
  tmp="$(mktemp)"
  crontab -l 2>/dev/null | sed "/^# >>> OPC-OS collector/,/^# <<< OPC-OS collector/d" > "$tmp" || true
  crontab "$tmp"
  rm -f "$tmp"
  info "crontab OPC-OS 块已移除"
}

# ---- systemd 渲染 + 启动 ----
# 解析 EnvironmentFile 来源（优先级：--env-file 显式 > <out>/secrets.env > ~/.hermes/.env）
resolve_env_file() {
  if [ -n "$ENV_FILE" ]; then
    [ -f "$ENV_FILE" ] || warn "指定的 --env-file 不存在: $ENV_FILE（unit 将保留该路径，服务可能缺 token）"
    return 0
  fi
  if [ -f "$OUT/secrets.env" ]; then
    ENV_FILE="$OUT/secrets.env"
    info "EnvironmentFile → $ENV_FILE（opc-init 生成，含 GATEWAY_CLIENT_TOKEN/WORKBENCH_TOKEN）"
    return 0
  fi
  if [ -f "$HOME/.hermes/.env" ]; then
    ENV_FILE="$HOME/.hermes/.env"
    info "EnvironmentFile → $ENV_FILE（生产 Hermes 主环境 env）"
    return 0
  fi
  ENV_FILE=""
  warn "未找到 secrets.env 或 ~/.hermes/.env —— 渲染时移除 EnvironmentFile 行（服务将无 token 注入，401 风险）"
  return 1
}

render_units() {
  local src unit
  resolve_env_file || true
  for src in "$REPO_DIR"/systemd/opcos-*.service.in; do
    [ -f "$src" ] || continue
    unit="/etc/systemd/system/$(basename "${src%.in}")"
    sed -e "s|@@OUT@@|$OUT|g" \
        -e "s|@@REPO@@|$REPO_DIR|g" \
        -e "s|@@NODE@@|$NODE_BIN|g" \
        -e "s|@@PYTHON@@|$PYTHON_BIN|g" \
        -e "s|@@USER@@|$USER|g" \
        -e "s|@@WEB_PORT@@|$WEB_PORT|g" \
        -e "s|@@API_PORT@@|$API_PORT|g" \
        -e "s|@@GATEWAY_PORT@@|$GATEWAY_PORT|g" \
        -e "s|@@HERMES_AGENT_SRC@@|$HERMES_AGENT_SRC|g" \
        -e "s|@@TIER@@|$TIER|g" \
        -e "s|@@CAP_MEM@@|$CAP_MEM|g" \
        -e "s|@@CAP_CPUS@@|$CAP_CPUS|g" \
        -e "s|@@ENV_FILE@@|$ENV_FILE|g" \
        -e "/^EnvironmentFile=$/d" \
        -e "/^Environment=KANBAN_DISPATCHER_TIER=$/d" \
        -e "/^Environment=KANBAN_DISPATCHER_CAPACITY_MEM_MB=$/d" \
        -e "/^Environment=KANBAN_DISPATCHER_CAPACITY_CPUS=$/d" \
        "$src" | sudo tee "$unit" >/dev/null
    info "写入 $unit"
  done
  sudo systemctl daemon-reload
}

systemd_cmd() { # systemd_cmd <enable|start|stop|restart|status>
  local act="$1"
  case "$act" in
    # start 语义 = enable + restart：已 active 的服务也要按最新渲染的 unit 重启
    start)   sudo systemctl enable opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher >/dev/null 2>&1
             sudo systemctl restart opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher ;;
    restart) sudo systemctl restart opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher ;;
    stop)    sudo systemctl disable --now opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher 2>/dev/null || sudo systemctl stop opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher ;;
    status)  sudo systemctl --no-pager --lines=8 status opcos-gateway opcos-api opcos-web opcos-collector opcos-dispatcher || true ;;
  esac
}

# ---- nohup+pidfile 守护（无 systemd 退化）----
# start_daemon <name> [--cwd DIR] <env VAR=val>... -- <cmd> [args...]
start_daemon() {
  local name="$1"; shift
  local pidfile="$OUT/run/$name.pid"
  local logfile="$OUT/logs/$name.log"
  local cwd="" envs=() cmd=() dash=0
  while [ $# -gt 0 ]; do
    case "$1" in
      --cwd) cwd="$2"; shift 2 ;;
      --) dash=1; shift ;;
      *)
        if [ "$dash" -eq 0 ]; then envs+=("$1"); else cmd+=("$1"); fi
        shift ;;
    esac
  done
  [ ${#cmd[@]} -gt 0 ] || die "start_daemon $name: 无命令"
  if [ -f "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
    info "$name 已在运行 (pid $(cat "$pidfile"))"
    return 0
  fi
  mkdir -p "$OUT/run" "$OUT/logs"
  if [ -n "$cwd" ]; then
    setsid env "${envs[@]}" bash -c 'cd "$0" && shift && exec "$@"' "$cwd" "${cmd[@]}" >> "$logfile" 2>&1 &
  else
    setsid env "${envs[@]}" "${cmd[@]}" >> "$logfile" 2>&1 &
  fi
  echo $! > "$pidfile"
  info "$name 启动 (pid $!, log $logfile)"
  sleep 1
  kill -0 "$(cat "$pidfile")" 2>/dev/null || { warn "$name 启动即退出——查看 $logfile"; return 1; }
}

stop_daemon() {
  local name="$1" pidfile="$OUT/run/$name.pid"
  if [ -f "$pidfile" ]; then
    local pid
    pid="$(cat "$pidfile")"
    if kill -0 "$pid" 2>/dev/null; then
      kill -- "-$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
      info "$name 已停止 (pid $pid)"
    fi
    rm -f "$pidfile"
  fi
}

daemon_status() {
  local name="$1" pidfile="$OUT/run/$name.pid"
  if [ -f "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
    echo "  ✓ $name 运行中 (pid $(cat "$pidfile"))"
  else
    echo "  ✗ $name 未运行"
  fi
}

# ---- 服务定义（systemd 用 unit；fallback 用 daemon）----
fallback_start() {
  start_daemon gateway --cwd "$REPO_DIR/llm-gateway" \
    NODE_ENV=production \
    GATEWAY_CONFIG="$OUT/llm-gateway/gateway.config.json" \
    GATEWAY_ENV_FILE="$OUT/llm.env" \
    TZ=Asia/Shanghai \
    -- "$NODE_BIN" server.js

  start_daemon api --cwd "$REPO_DIR/opc-api" \
    NODE_ENV=production \
    OPC_OS_DATA_DIR="$OUT" \
    PORT="$API_PORT" \
    KANBAN_DB_PATH="$OUT/kanban.db" \
    KANBAN_HERMES_BIN="$HERMES_AGENT_SRC/venv/bin/hermes" \
    KANBAN_PYTHON_BIN="$HERMES_AGENT_SRC/venv/bin/python" \
    OPC_REOPEN_RUNNER="$REPO_DIR/scripts/opc_kanban_reopen.py" \
    OPC_CORS_ORIGINS="http://127.0.0.1:$WEB_PORT" \
    WORKBENCH_TOKEN="$(grep '^WORKBENCH_TOKEN=' "$OUT/secrets.env" | cut -d= -f2-)" \
    TZ=Asia/Shanghai \
    -- "$NODE_BIN" index.cjs

  start_daemon web --cwd "$REPO_DIR" \
    PORT="$WEB_PORT" \
    WEB_ROOT="$REPO_DIR/web" \
    OPC_DATA_DIR="$OUT" \
    TZ=Asia/Shanghai \
    -- "$NODE_BIN" "$REPO_DIR/scripts/web-serve.js"

  start_daemon collector \
    OPC_OS_CONFIG="$OUT/config/config.native.json" \
    TZ=Asia/Shanghai \
    -- "$PYTHON_BIN" "$REPO_DIR/scripts/opc-bus.py"

  start_daemon dispatcher \
    PYTHONPATH="$REPO_DIR/vendor/kanban-dispatcher:$HERMES_AGENT_SRC" \
    HERMES_BIN="$HERMES_AGENT_SRC/venv/bin/hermes" \
    HERMES_HOME="$OUT/hermes-home" \
    HERMES_KANBAN_HOME="$OUT/hermes-home" \
    HERMES_KANBAN_DB="$OUT/kanban.db" \
    HERMES_KANBAN_BOARD=opc \
    HERMES_KANBAN_WORKSPACES_ROOT="$OUT/workspaces" \
    HERMES_KANBAN_ATTACHMENTS_ROOT="$OUT/attachments" \
    KANBAN_DISPATCHER_TIER="$TIER" \
    KANBAN_DISPATCHER_CAPACITY_MEM_MB="$CAP_MEM" \
    KANBAN_DISPATCHER_CAPACITY_CPUS="$CAP_CPUS" \
    GATEWAY_CLIENT_TOKEN="$(grep '^GATEWAY_CLIENT_TOKEN=' "$OUT/secrets.env" | cut -d= -f2-)" \
    TZ=Asia/Shanghai \
    -- "$HERMES_AGENT_SRC/venv/bin/python" -m kanban_dispatcher.cli --config "$OUT/config/dispatcher.yaml"
}

fallback_stop() {
  for s in dispatcher gateway api web collector; do stop_daemon "$s"; done
}

fallback_status() {
  for s in gateway api web collector dispatcher; do daemon_status "$s"; done
}

# ---- 子命令 ----
cmd_install() {
  # 0. 前置检查
  [ -d "$OUT" ] || die "输出目录不存在: $OUT（先运行 opc-init）"
  for f in llm.env config/config.json kanban.db init-state.json hermes-home/profiles; do
    [ -e "$OUT/$f" ] || die "$OUT 缺少 $f —— opc-init 产物不完整"
  done
  [ -n "$NODE_BIN" ] || die "node 未安装（环境自举见 installation-guide）"
  [ -n "$PYTHON_BIN" ] || die "python3 未安装"
  [ -x "$HERMES_AGENT_SRC/venv/bin/hermes" ] || die "fork venv 缺失: $HERMES_AGENT_SRC/venv/bin/hermes（先 install-hermes-worker.sh）"
  [ -d "$REPO_DIR/llm-gateway" ] && [ -d "$REPO_DIR/opc-api" ] && [ -d "$REPO_DIR/web" ] \
    && [ -d "$REPO_DIR/vendor/kanban-dispatcher" ] || die "opc-os 仓结构不完整: $REPO_DIR"

  info "OPC-OS 原生安装开始 (out=$OUT repo=$REPO_DIR)"
  info "端口: web=$WEB_PORT api=$API_PORT gateway=$GATEWAY_PORT  tier=${TIER:-auto}"

  # 1. 数据目录/日志目录
  mkdir -p "$OUT/logs" "$OUT/run" "$OUT/llm-gateway" "$OUT/workspaces" "$OUT/attachments"

  # 2. 原生 config（/data → OUT 重写）
  gen_native_config

  # 3. dispatcher 配置
  gen_dispatcher_cfg

  # 4. 网关数据目录（首次拷默认配置；events/ 落 <out>/llm-gateway）
  if [ ! -f "$OUT/llm-gateway/gateway.config.json" ]; then
    cp "$REPO_DIR/llm-gateway/gateway.config.json" "$OUT/llm-gateway/gateway.config.json"
    info "网关默认配置 → $OUT/llm-gateway/gateway.config.json（管理面板热改落此文件）"
  fi

  # 5. secrets（WORKBENCH_TOKEN 幂等生成，chmod 600）
  if [ ! -f "$OUT/secrets.env" ]; then
    umask 077
    GCT="$(grep '^GATEWAY_CLIENT_TOKEN=' "$OUT/llm.env" | cut -d= -f2- || true)"
    printf 'WORKBENCH_TOKEN=%s\nKANBAN_DB_PATH=%s\nGATEWAY_CLIENT_TOKEN=%s\n' \
      "$(openssl rand -hex 24)" "$OUT/kanban.db" "$GCT" > "$OUT/secrets.env"
    chmod 600 "$OUT/secrets.env"
    info "已生成 $OUT/secrets.env（WORKBENCH_TOKEN 随机 + GATEWAY_CLIENT_TOKEN 引用，仅工作台/调度用）"
  else
    # 幂等补丁：secrets.env 缺 GATEWAY_CLIENT_TOKEN 时补上（升级路径）
    if ! grep -q '^GATEWAY_CLIENT_TOKEN=' "$OUT/secrets.env"; then
      GCT="$(grep '^GATEWAY_CLIENT_TOKEN=' "$OUT/llm.env" | cut -d= -f2- || true)"
      printf 'GATEWAY_CLIENT_TOKEN=%s\n' "$GCT" >> "$OUT/secrets.env"
      chmod 600 "$OUT/secrets.env"
      info "secrets.env 已补 GATEWAY_CLIENT_TOKEN"
    fi
  fi

  # 5b. 成员交互 env wrapper（source 后即可 hermes -p <成员>；key 只从 llm.env 提取，不落明文）
  umask 077
  cat > "$OUT/env.sh" <<EOF
# OPC-OS 成员交互环境（install-services.sh 生成；用法: source $OUT/env.sh）
export HERMES_HOME=$OUT/hermes-home
export HERMES_KANBAN_HOME=$OUT/hermes-home
export HERMES_KANBAN_DB=$OUT/kanban.db
export HERMES_KANBAN_BOARD=opc
export GATEWAY_CLIENT_TOKEN=\$(grep '^GATEWAY_CLIENT_TOKEN=' $OUT/llm.env | cut -d= -f2-)
EOF
  chmod 600 "$OUT/env.sh"
  info "已生成 $OUT/env.sh（source 后直接 hermes -p <成员id>）"

  # 6. llm.env 权限核对（红线：key 只进这里）
  chmod 600 "$OUT/llm.env"

  # 7. WORKBENCH_API 注入（可选，幂等 sed）
  if [ -n "$WORKBENCH_API" ]; then
    ESC="$(printf '%s' "$WORKBENCH_API" | sed -e 's/\\/\\\\/g' -e 's/&/\\&/g' -e 's/#/\\#/g')"
    sed -i "s#(window.OPC_WORKBENCH_API || '[^']*')#(window.OPC_WORKBENCH_API || '$ESC')#" "$REPO_DIR/web/opc/workbench.html"
    info "WORKBENCH_API 注入 → $REPO_DIR/web/opc/workbench.html: $WORKBENCH_API"
  fi

  # 8. crontab
  install_crontab

  # 9. 启动
  if systemd_available; then
    info "检测到 systemd → 渲染 units + enable + restart"
    render_units
    systemd_cmd start
  else
    info "无 systemd → 退化为 nohup+pidfile 守护"
    fallback_start
  fi

  # 10. 摘要
  cat <<EOF

== OPC-OS 安装完成 ==
  透明办公室:  http://127.0.0.1:$WEB_PORT/opc/
  治理仪表盘:  http://127.0.0.1:$WEB_PORT/opc/governance.html
  工作台:      http://127.0.0.1:$WEB_PORT/opc/workbench.html
  状态 API:    http://127.0.0.1:$API_PORT/api/time
  网关:        http://127.0.0.1:$GATEWAY_PORT/v1/models

验证命令:
  curl -s http://127.0.0.1:$WEB_PORT/opc/data/status.json | head -c 300
  curl -s http://127.0.0.1:$WEB_PORT/healthz
  curl --oauth2-bearer "\$GATEWAY_CLIENT_TOKEN" http://127.0.0.1:\$GATEWAY_PORT/v1/models
  scripts/smoke_test.sh $WEB_PORT

管理:
  scripts/install-services.sh status --out $OUT
  scripts/install-services.sh restart --out $OUT
EOF
}

cmd_start() {
  if systemd_available; then systemd_cmd start; else fallback_start; fi
}

cmd_stop() {
  if systemd_available; then systemd_cmd stop; else fallback_stop; fi
}

cmd_restart() {
  cmd_stop
  sleep 2
  cmd_start
}

cmd_status() {
  echo "== OPC-OS 服务状态 (out=$OUT) =="
  if systemd_available; then
    systemd_cmd status
  else
    fallback_status
  fi
  echo "== crontab =="
  crontab -l 2>/dev/null | grep -A2 "OPC-OS collector" || echo "  （无 OPC-OS 采集任务）"
}

cmd_uninstall() {
  if systemd_available; then
    systemd_cmd stop
    for src in "$REPO_DIR"/systemd/opcos-*.service.in; do
      [ -f "$src" ] || continue
      sudo rm -f "/etc/systemd/system/$(basename "${src%.in}")"
    done
    sudo systemctl daemon-reload
    info "systemd units 已移除"
  else
    fallback_stop
  fi
  remove_crontab
  info "卸载完成（数据目录 $OUT 保留）"
}

case "$CMD" in
  install)   cmd_install ;;
  start)     cmd_start ;;
  stop)      cmd_stop ;;
  restart)   cmd_restart ;;
  status)    cmd_status ;;
  uninstall) cmd_uninstall ;;
esac
