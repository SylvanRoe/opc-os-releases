#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OPC OS — opc-init 初始化引擎（里程碑 31b）

按行业模板为「客户自己的 AI 办公室」生成全套初始化产物：
  config/config.json   —— collector 零改动直接读（profiles/roster/roles/cron_member/
                          name_id/name_en/role_en/paths 全部指向卷内 /data）
  profiles/<id>/       —— 每个成员一个骨架目录（SOUL.md/persona/角色定义/skill 清单/cron 注册）
  state.json           —— 客户团队名册 + 决策分级（decided_by: 老板（人类）/ CEO）
  kanban.db            —— 空板 + 欢迎任务（可选）
  init-state.json      —— 初始化标记（=initialized，31c 首启检测用）
  init-report.txt/json —— 初始化报告
  llm.env              —— LLM provider/key（compose 注入用）

双模式：
  交互问答：  python3 scripts/opc_init.py            （docker compose run --rm init）
  参数化：    python3 scripts/opc_init.py --template catering --name "老王烧烤" \
              --llm deepseek --key xxx [--out DIR] [--force] [--no-welcome]
  网关模式：  --llm gateway（或 --gateway）→ base_url 指向 llm-gateway（默认
              http://127.0.0.1:18080/v1，可 --gateway-url 覆盖）；熔断/月度预算由网关负责

红线：
  - 客户产物零 OPC 真实身份：zhuangzi/make/庄子/马克/「演示X」等全部不得进入产物
    （生成后自检扫描，命中即失败并列出位置）
  - 不碰收款/定价：产物里 billing=null，无任何定价/收费逻辑
  - 可重复运行：已有初始化产物时须确认覆盖（交互）/ --force（参数化），覆盖前备份到
    <out>/backups/<ts>/
"""
import argparse
import datetime
import json
import os
import re
import secrets
import shutil
import sqlite3
import sys
import uuid

def _read_version():
    """从仓根 VERSION 文件读取版本；文件缺失时 fallback 到硬编码常量（兼容旧部署包）。"""
    repo_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    vfile = os.path.join(repo_root, 'VERSION')
    try:
        with open(vfile, encoding='utf-8') as f:
            return f.read().strip()
    except OSError:
        return '0.3.5'  # fallback：旧部署包无 VERSION 文件

VERSION = _read_version()

# ---------------------------------------------------------------- 常量

TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'templates')

# LLM provider 默认模型（31c 接入 Hermes 运行时后由 llm.env / compose 注入）
PROVIDERS = {
    'deepseek':  {'model': 'deepseek-v4-flash',   'base_url': 'https://api.deepseek.com/v1'},
    'openai':    {'model': 'gpt-4o-mini',         'base_url': 'https://api.openai.com/v1'},
    'anthropic': {'model': 'claude-sonnet-4-5',   'base_url': 'https://api.anthropic.com'},
    'moonshot':  {'model': 'moonshot-v1-8k',      'base_url': 'https://api.moonshot.cn/v1'},
}

# 网关模式（0825-init-2）：统一模型名 hermes-opc-v1 = 网关统一入口，网关内部按
# priority 路由到 eyuai/kimi/deepseek/openrouter（熔断自动切换/月度预算由网关负责）。
# config.yaml 写 model.default=hermes-opc-v1 / model.provider=custom:hermes-opc（OPC
# 自己；0826-fix：必须带 custom: 前缀 + custom_providers[].name=hermes-opc 块才能被
# Hermes 解析器识别，裸 hermes-opc 报 Unknown provider），
# Hermes 侧 fallback_providers 保持空（红线：不依赖单点 fallback）。
GATEWAY_DEFAULT_URL = 'http://127.0.0.1:18080/v1'
GATEWAY_MODEL = 'hermes-opc-v1'       # 网关统一模型名（/v1/models 唯一暴露）
GATEWAY_PROVIDER = 'hermes-opc'       # 网关 provider 标识（OPC 自己的网关）
GATEWAY_CLIENT_TOKEN_ENV = 'GATEWAY_CLIENT_TOKEN'   # /v1/* Bearer 鉴权（llm.env 写入）

# 脱敏红线扫描表。命中即失败：
#   - 文本扫描（生成的全部文件，config.json 剔除 paths 段后扫描）
#   - 结构化身份字段另做精确比对（id == banned id / 中文名 == banned 名）
BANNED_TEXT = [
    '演示', 'Demo', 'demo',
    'zhuangzi', 'anran', 'linjing', 'wenwen', 'qianli', 'panming',
    '庄子', '马克', '安然', '林静', '温雯', '钱莉', '潘明', '蔡婉', '苏木',
    'Gavin', 'gavin',
]
BANNED_TEXT_RE = re.compile(
    '|'.join(re.escape(t) for t in BANNED_TEXT)
    + r'|\bmake\b|\bada\b|\biris\b|\bHermes\b|\bhermes\b', re.IGNORECASE)
# 结构化字段禁用的 profile id（zhuangzi/make/anran/... 官网 9 人）
BANNED_IDS = {'zhuangzi', 'make', 'anran', 'linjing', 'wenwen',
              'qianli', 'panming', 'ada', 'iris'}

# 决策分级域（与 OPC 治理口径一致：人财物归老板，事归 CEO）
DOMAINS_BOSS = ['人事', '财务', '物资资产', '花钱', '收款', '法务']
DOMAINS_CEO = ['运营', '执行', '产品迭代', '内容发布']

# kanban.db 空库 schema（与 Hermes kanban 内核 v1 一致，取 opc 板 DDL）
KANBAN_DDL = """
CREATE TABLE tasks (
    id                   TEXT PRIMARY KEY,
    title                TEXT NOT NULL,
    body                 TEXT,
    assignee             TEXT,
    status               TEXT NOT NULL,
    priority             INTEGER DEFAULT 0,
    created_by           TEXT,
    created_at           INTEGER NOT NULL,
    started_at           INTEGER,
    completed_at         INTEGER,
    workspace_kind       TEXT NOT NULL DEFAULT 'scratch',
    workspace_path       TEXT,
    branch_name          TEXT,
    project_id           TEXT,
    claim_lock           TEXT,
    claim_expires        INTEGER,
    tenant               TEXT,
    result               TEXT,
    idempotency_key      TEXT,
    consecutive_failures INTEGER NOT NULL DEFAULT 0,
    worker_pid           INTEGER,
    last_failure_error   TEXT,
    max_runtime_seconds  INTEGER,
    last_heartbeat_at    INTEGER,
    current_run_id       INTEGER,
    workflow_template_id TEXT,
    current_step_key     TEXT,
    skills               TEXT,
    model_override       TEXT,
    provider_override    TEXT,
    reasoning_effort     TEXT,
    max_retries          INTEGER,
    goal_mode            INTEGER NOT NULL DEFAULT 0,
    goal_max_turns       INTEGER,
    session_id           TEXT,
    block_kind           TEXT,
    block_recurrences    INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE task_links (
    parent_id  TEXT NOT NULL,
    child_id   TEXT NOT NULL,
    PRIMARY KEY (parent_id, child_id)
);
CREATE TABLE task_comments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id    TEXT NOT NULL,
    author     TEXT NOT NULL,
    body       TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE TABLE task_events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id    TEXT NOT NULL,
    run_id     INTEGER,
    kind       TEXT NOT NULL,
    payload    TEXT,
    created_at INTEGER NOT NULL
);
CREATE TABLE task_runs (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id             TEXT NOT NULL,
    profile             TEXT,
    step_key            TEXT,
    status              TEXT NOT NULL,
    claim_lock          TEXT,
    claim_expires       INTEGER,
    worker_pid          INTEGER,
    max_runtime_seconds INTEGER,
    last_heartbeat_at   INTEGER,
    started_at          INTEGER NOT NULL,
    ended_at            INTEGER,
    outcome             TEXT,
    summary             TEXT,
    metadata            TEXT,
    error               TEXT
);
CREATE TABLE task_attachments (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id      TEXT NOT NULL,
    filename     TEXT NOT NULL,
    stored_path  TEXT NOT NULL,
    content_type TEXT,
    size         INTEGER NOT NULL DEFAULT 0,
    uploaded_by  TEXT,
    created_at   INTEGER NOT NULL
);
CREATE TABLE kanban_notify_subs (
    task_id       TEXT NOT NULL,
    platform      TEXT NOT NULL,
    chat_id       TEXT NOT NULL,
    chat_type     TEXT,
    thread_id     TEXT NOT NULL DEFAULT '',
    user_id       TEXT,
    notifier_profile TEXT,
    delivery_metadata TEXT,
    created_at    INTEGER NOT NULL,
    last_event_id INTEGER NOT NULL DEFAULT 0,
    delivery_mode TEXT NOT NULL DEFAULT 'notify',
    user_id_alt   TEXT,
    PRIMARY KEY (task_id, platform, chat_id, thread_id)
);
CREATE INDEX idx_tasks_assignee_status ON tasks(assignee, status);
CREATE INDEX idx_tasks_status          ON tasks(status);
CREATE INDEX idx_links_child           ON task_links(child_id);
CREATE INDEX idx_links_parent          ON task_links(parent_id);
CREATE INDEX idx_comments_task         ON task_comments(task_id, created_at);
CREATE INDEX idx_events_task           ON task_events(task_id, created_at);
CREATE INDEX idx_runs_task             ON task_runs(task_id, started_at);
CREATE INDEX idx_runs_status           ON task_runs(status);
CREATE INDEX idx_attachments_task      ON task_attachments(task_id, created_at);
CREATE INDEX idx_notify_task           ON kanban_notify_subs(task_id);
CREATE INDEX idx_tasks_tenant          ON tasks(tenant);
CREATE INDEX idx_tasks_idempotency     ON tasks(idempotency_key);
CREATE INDEX idx_tasks_session_id      ON tasks(session_id);
CREATE INDEX idx_events_run            ON task_events(run_id, id);
"""


# ---------------------------------------------------------------- 小工具

class QuitError(Exception):
    pass


def now_iso():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y-%m-%dT%H:%M:%S+08:00')


def today_str():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y-%m-%d')


def ts_now():
    return int(datetime.datetime.now().timestamp())


def load_template(tid):
    path = os.path.join(TEMPLATES_DIR, f'{tid}.json')
    if not os.path.exists(path):
        raise SystemExit(f'[opc-init] 错误: 找不到模板 {tid}（{path}）。可选: {list_templates()}')
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def list_templates():
    ids = []
    for fn in sorted(os.listdir(TEMPLATES_DIR)):
        if fn.endswith('.json'):
            ids.append(fn[:-5])
    return ids


def load_all_templates():
    out = []
    for tid in list_templates():
        t = load_template(tid)
        out.append(t)
    return out


def default_out_dir():
    # 容器内（31c：opc_data 卷挂 /data）→ 直接写卷内；本机直跑 → 相对当前目录
    if os.path.isdir('/data') and os.access('/data', os.W_OK):
        return '/data'
    return os.path.join(os.getcwd(), 'opc-init-out')


def mask_key(key):
    if not key:
        return '(未设置)'
    if len(key) <= 8:
        return key[:2] + '*' * (len(key) - 2)
    return key[:4] + '*' * 8 + key[-4:]


def ask(prompt, default=None, validator=None, allow_quit=True):
    """交互一问。default 非空时显示 (默认 x)；空输入返回 default。
    'q'/'quit' 退出（allow_quit 时）。validator(value)->(ok, errmsg) 校验循环。"""
    while True:
        suffix = f'（默认 {default}）' if default not in (None, '') else ''
        try:
            raw = input(f'{prompt}{suffix}: ').strip()
        except EOFError:
            print()
            raise QuitError('输入结束')
        if allow_quit and raw.lower() in ('q', 'quit', 'exit'):
            raise QuitError('已退出')
        if raw == '' and default not in (None, ''):
            return default
        if raw == '' and default in (None, ''):
            if validator is None:
                return ''
            ok, err = validator('')
            if not ok:
                print(f'  ✗ {err}')
                continue
            return ''
        if validator is None:
            return raw
        ok, err = validator(raw)
        if not ok:
            print(f'  ✗ {err}')
            continue
        return raw


def ask_yesno(prompt, default=True):
    d = 'Y/n' if default else 'y/N'
    while True:
        try:
            raw = input(f'{prompt} [{d}] ').strip().lower()
        except EOFError:
            print()
            raise QuitError('输入结束')
        if raw in ('q', 'quit', 'exit'):
            raise QuitError('已退出')
        if raw == '':
            return default
        if raw in ('y', 'yes'):
            return True
        if raw in ('n', 'no'):
            return False
        print('  请输入 y / n')


# ---------------------------------------------------------------- 交互模式

def interactive_flow():
    print('=== OPC OS 初始化向导（opc-init） ===')
    print('为你的公司生成一套 AI 办公室（团队成员/配置/任务板）。随时输入 q 退出。\n')

    # 1) 行业模板
    all_tpl = load_all_templates()
    if not all_tpl:
        raise SystemExit('[opc-init] 错误: templates/ 目录为空')
    default_tid = next((t['id'] for t in all_tpl if t.get('is_default')), all_tpl[0]['id'])

    def val_tpl(raw):
        if raw in [str(i) for i in range(1, len(all_tpl) + 1)]:
            return True, ''
        if any(raw == t['id'] for t in all_tpl):
            return True, ''
        return False, f'请输入 1-{len(all_tpl)} 或模板 id'

    print('选择行业模板：')
    for i, t in enumerate(all_tpl, 1):
        mark = '（默认）' if t['id'] == default_tid else ''
        names = '、'.join(r['name_zh'] for r in t['roles'])
        print(f'  [{i}] {t["name"]} {mark} — {t.get("description", "")}')
        print(f'       角色: {names}')
    raw = ask('行业模板', default=default_tid, validator=val_tpl)
    if raw.isdigit():
        tpl = all_tpl[int(raw) - 1]
    else:
        tpl = load_template(raw)
    print(f'  已选: {tpl["name"]}（{tpl["id"]}）\n')

    # 2) 公司名
    def val_name(raw):
        if not raw:
            return False, '公司/门店名称不能为空'
        if len(raw) > 40:
            return False, '名称过长（≤40 字）'
        hit = [t for t in BANNED_TEXT if t in raw]
        if hit:
            return False, f'名称包含保留词 {hit}，请更换'
        return True, ''

    name = ask('公司/门店名称', validator=val_name)

    # 3) 成员数（默认模板全部角色）
    roles_base = [r for r in tpl['roles'] if not r.get('is_ceo')]
    full = len(tpl['roles'])
    non_ceo = len(roles_base)
    def val_members(raw):
        if raw == '':
            return True, ''
        if not raw.isdigit() or int(raw) < 1:
            return False, '请输入正整数'
        return True, ''
    members_raw = ask(f'团队角色数（默认全部 {full} 人）', default=str(full), validator=val_members)
    members = int(members_raw)

    # 4) 是否要 CEO
    ceo_roles = [r for r in tpl['roles'] if r.get('is_ceo')]
    want_ceo = True
    if ceo_roles:
        ceo_name = ceo_roles[0]['name_zh']
        want_ceo = ask_yesno(f'是否保留 AI CEO 角色（{ceo_name}）', default=True)
        if not want_ceo:
            print(f'  已移除 {ceo_name}（CEO），决策分级只剩「老板（人类）」一层\n')
    else:
        print('  （模板无 CEO 角色，团队直接向老板汇报）\n')

    # 5) LLM provider + key
    prov_names = list(PROVIDERS.keys())
    def val_prov(raw):
        if raw in [str(i) for i in range(1, len(prov_names) + 3)]:
            return True, ''
        if raw == 'custom' or raw in prov_names or raw == 'gateway':
            return True, ''
        return False, f'请输入 1-{len(prov_names) + 2} 或 provider 名'
    print('LLM 提供商（客户自带 key，BYOK）：')
    for i, p in enumerate(prov_names, 1):
        print(f'  [{i}] {p}（默认模型 {PROVIDERS[p]["model"]}）')
    print(f'  [{len(prov_names) + 1}] gateway（网关模式，推荐：熔断自动切换 + 月度预算保护）')
    print(f'  [{len(prov_names) + 2}] custom（自填 base_url + model）')
    raw = ask('LLM 提供商', default='deepseek', validator=val_prov)
    if raw.isdigit():
        idx = int(raw)
        if idx == len(prov_names) + 2:
            provider = 'custom'
        elif idx == len(prov_names) + 1:
            provider = 'gateway'
        else:
            provider = prov_names[idx - 1]
    else:
        provider = raw
    base_url, model = None, None
    gateway_url = GATEWAY_DEFAULT_URL
    if provider == 'custom':
        base_url = ask('自定义 base_url', validator=lambda v: (bool(v.strip()), '不能为空'))
        model = ask('自定义模型名', validator=lambda v: (bool(v.strip()), '不能为空'))
    elif provider == 'gateway':
        gateway_url = ask('网关地址', default=GATEWAY_DEFAULT_URL,
                          validator=lambda v: (v.startswith('http://') or v.startswith('https://'),
                                               '须 http(s):// 开头'))
        print(f'  → 网关模式：Hermes 请求走网关（{gateway_url}），统一模型名 hermes-opc-v1；'
              f'网关内部按 priority 路由 eyuai/kimi/deepseek/openrouter，熔断/降级由网关负责；'
              f'网关 client token 自动生成只进 llm.env（网关 GATEWAY_ENV_FILE 引用）')
    key = ask('API Key（可留空，仅写占位）', default='')

    # 6) 欢迎任务
    want_welcome = ask_yesno('是否创建欢迎任务（CEO 的首个任务卡）', default=True)

    # 7) 确认
    roles = select_roles(tpl, members, want_ceo)
    print('\n=== 确认 ===')
    print(f'  公司名称 : {name}')
    print(f'  行业模板 : {tpl["name"]}（{tpl["id"]}）')
    print(f'  团队成员 : {len(roles)} 人 → ' + '、'.join(r['name_zh'] for r in roles))
    print(f'  决策分级 : ' + ('老板（人类）+ ' + roles[0]['name_zh'] + '（CEO）' if want_ceo and ceo_roles else '老板（人类）'))
    print(f'  LLM      : {provider}' + (f'（{base_url} / {model}）' if provider == 'custom' else '') + (f'（网关模式 → {gateway_url}）' if provider == 'gateway' else ''))
    print(f'  欢迎任务 : {"是" if want_welcome else "否"}')
    if not ask_yesno('确认生成', default=True):
        print('已取消，未生成任何文件。')
        return None
    return {
        'template': tpl['id'], 'name': name, 'members': members,
        'ceo': want_ceo, 'llm': provider, 'key': key,
        'base_url': base_url, 'model': model, 'welcome': want_welcome,
        'gateway_url': gateway_url,
    }


# ---------------------------------------------------------------- 角色选择

def select_roles(tpl, members, want_ceo):
    """按模板顺序取前 members 个角色；want_ceo=False 时先剔除 CEO 角色。"""
    roles = list(tpl['roles'])
    if not want_ceo:
        roles = [r for r in roles if not r.get('is_ceo')]
    if not roles:
        raise SystemExit('[opc-init] 错误: 模板无可用角色（不要 CEO 后团队为空）')
    n = members if members else len(roles)
    n = max(1, min(n, len(roles)))
    return roles[:n]


# ---------------------------------------------------------------- 产物生成

def gen_config(tpl, roles, company):
    name_id, name_en, roles_map, role_en, roster = {}, {}, {}, {}, {}
    cron_member = {}
    for r in roles:
        rid, zh, en = r['id'], r['name_zh'], r['name_en']
        name_id[zh] = rid
        name_en[rid] = en
        roles_map[zh] = r['role_zh']
        role_en[r['role_zh']] = r['role_en']
        roster[rid] = {'name_zh': zh, 'name_en': en, 'role': r['role_zh']}
        for c in r.get('cron', []):
            cron_member[c['name']] = [zh, c['action'], c['desc']]
    # 通用角色别名（role 变体兜底）
    role_en.update({'CEO': 'CEO', '财务': 'Finance', '客服': 'Support',
                    '开发': 'Dev', '营销': 'Marketing', '运维': 'Ops'})
    cfg = {
        'collector': {
            'profiles': [r['id'] for r in roles],
            'cron_member': cron_member,
            'name_id': name_id,
            'name_en': name_en,
            'roles': roles_map,
            'role_en': role_en,
            'roster': roster,
            'paths': {
                'hermes_home': '/data/hermes-home',
                'opc_dir': '/data',
                'kanban_db': '/data/kanban.db',
                'demo_kanban_db': '',
                'out_status': '/data/status.json',
                'out_status_secondary': '',
                'state_db': '/data/hermes-home/state.db',
                'token_stats_out': '/data/token-stats.json',
                'publish_copy': '',
                'usage_audit_dir': '',
            },
            'running_since': today_str(),
        },
        'bus': {
            'poll_seconds': 1.0,
            'kanban_db': '/data/kanban.db',
            'status_out': '/data/status.json',
            'status_out_secondary': '',
            'bus_state_file': '/data/bus-state.json',
            'skip_kinds': ['heartbeat'],
        },
    }
    return cfg


def gen_soul(role, company, is_ceo):
    ceo_note = ''
    if is_ceo:
        ceo_note = (f'人财物（人事/财务/物资资产/花钱/收款/法务）由老板（人类）拍板；'
                    f'事（运营/执行/产品迭代/内容发布）由你（CEO）自主拍板。')
    else:
        ceo_note = '派活由 CEO 拍板并 Kanban 留痕；人财物事项升级老板（人类）拍板。'
    return f"""你是「{role['name_zh']}」（{role['name_en']}），{company} 的{role['role_zh']}。

## 思维框架
源自 {role.get('persona', {}).get('原型', '行业最佳实践')}。

## 职责
{role['duty']}

## 协作铁律
- 领活/干活/回报一律走 Kanban，不越俎代庖
- {ceo_note}
- 分工外阻塞 kanban_block 反馈{'老板' if not is_ceo else '老板/CEO'}

## 工作标准
{role.get('acceptance', '按角色职责交付，留痕可查')}。用中文，直截了当。
"""


def gen_role_md(role):
    return f"""# {role['name_zh']}（{role['name_en']}）— 角色定义

- 角色: {role['role_zh']}（{role['role_en']}）
- 职责: {role['duty']}
- 能力: {role.get('capability', '')}
- 验收标准: {role.get('acceptance', '')}
- 默认 cron: {'、'.join(c['name'] + '（' + c['desc'] + '）' for c in role.get('cron', [])) or '（无）'}
- 默认 skill 清单: {'、'.join(role.get('skills', [])) or '（无）'}
"""


def gen_persona_md(role):
    p = role.get('persona', {})
    soul = p.get('soul', [])
    lines = '\n'.join(f'{i}. {s}' for i, s in enumerate(soul, 1)) if soul else '（模板未定义，可自定义）'
    return f"""# {role['name_zh']}（{role['name_en']}）— Persona 要点

- 原型: {p.get('原型', '行业最佳实践')}
- 思维内核:
{lines}
"""


def gen_skills_md(role):
    sk = role.get('skills', [])
    body = '\n'.join(f'- {s}' for s in sk) if sk else '- （无默认 skill，按需安装）'
    return f"""# {role['name_zh']}（{role['name_en']}）— 默认 Skill 清单

{body}

说明: 此清单为初始化默认值；实际运行时可增删（skills/ 目录 + cron 引用）。
"""


def gen_cron_jobs(role, company, ts):
    jobs = []
    for c in role.get('cron', []):
        jobs.append({
            'id': uuid.uuid4().hex[:12],
            'name': c['name'],
            'prompt': (f"你是{role['name_zh']}（{role['name_en']}），{company}的{role['role_zh']}。"
                       f"例行任务：{c['desc']}。按角色职责执行，完成后留痕。"),
            'skills': role.get('skills', []) or None,
            'skill': (role.get('skills') or [None])[0],
            'schedule': {'kind': 'cron', 'expr': c['schedule'], 'display': c['schedule']},
            'enabled': True,
            'state': 'scheduled',
            'deliver': 'local',
            'created_at': ts,
        })
    return {'jobs': jobs, 'updated_at': ts}


def gen_profile_config_yaml(provider, model, base_url, gateway_mode=False):
    note = ('# 网关模式（0825-init-2）：请求走 llm-gateway（统一模型名 hermes-opc-v1，\n'
            '# 网关内部按 priority 路由 eyuai/kimi/deepseek/openrouter，熔断自动切换/月度预算\n'
            '# 由网关负责）；agent 侧 fallback_providers 保持空（红线：不依赖单点 fallback）\n'
            '# reasoning_echo=true（0826-fix）：网关上游 kimi thinking 要求多轮对话回传\n'
            '# assistant 消息的 reasoning_content，否则 HTTP 400\n'
            if gateway_mode else '')
    rc_line = '  reasoning_echo: true\n' if gateway_mode else ''
    if gateway_mode:
        # 0826-fix：provider 必须带 custom: 前缀 + custom_providers 块——裸
        # hermes-opc 会被解析器当内建 provider 找不到（Unknown provider 'hermes-opc'），
        # custom_providers 提供 name/base_url/key_env 让 custom:hermes-opc 可解析
        # （与 zhuangzi 线上配置同构：model.provider=custom:hermes-opc +
        # custom_providers[].name=hermes-opc + model.api_key=${GATEWAY_CLIENT_TOKEN}）。
        # token 经 llm.env 注入容器环境（compose env_file），config 用 ${...} 引用，
        # 无明文 key 落盘。
        provider = 'custom:' + provider
        api_line = f'  api_key: ${{{GATEWAY_CLIENT_TOKEN_ENV}}}\n'
        custom_block = (
            'custom_providers:\n'
            f'  - name: {GATEWAY_PROVIDER}\n'
            f'    base_url: {base_url}\n'
            f'    key_env: {GATEWAY_CLIENT_TOKEN_ENV}\n'
        )
    else:
        api_line = ''
        custom_block = ''
    return f"""{note}model:
  default: {model}
  provider: {provider}
  base_url: {base_url}
{api_line}{rc_line}fallback_providers: []
{custom_block}timezone: Asia/Shanghai
"""


def gen_state(tpl, roles, company, want_ceo, ts):
    ceo = next((r for r in roles if r.get('is_ceo')), None)
    team = []
    for r in roles:
        team.append({
            'id': r['id'],
            'role': r['role_zh'],
            'name_zh': r['name_zh'],
            'name_en': r['name_en'],
            'gender': None,
            'duty': r['duty'],
            'capability': r.get('capability', ''),
            'acceptance': r.get('acceptance', ''),
            'persona': {'原型': r.get('persona', {}).get('原型', '行业最佳实践'),
                        'soul': r.get('persona', {}).get('soul', [])},
        })
    if ceo:
        ceo_label = 'CEO' if ceo['name_zh'] == 'CEO' else f'{ceo["name_zh"]}（CEO）'
        decided_by = {'老板（人类）': DOMAINS_BOSS, ceo_label: DOMAINS_CEO}
        governance = (f'人财物（人事/财务/物资资产/花钱/收款/法务）由老板（人类）拍板；'
                      f'事（运营/执行/产品迭代/内容发布）由{ceo["name_zh"]}（CEO）自主拍板')
        ceo_obj = {'name_zh': ceo['name_zh'], 'name_en': ceo['name_en'],
                   'gender': None, 'role': ceo['role_zh'], 'id': ceo['id']}
    else:
        decided_by = {'老板（人类）': DOMAINS_BOSS + DOMAINS_CEO}
        governance = '全部事项（人财物 + 运营/执行/产品迭代/内容发布）由老板（人类）拍板'
        ceo_obj = None
    return {
        'company': {
            'name': company,
            'operator': 'AI（多 agent 运营）+ 老板（人）拍板',
            'ceo': ceo_obj,
            'template': tpl['id'],
            'template_name': tpl['name'],
            'initialized_at': ts,
            'governance': governance,
            'values': '阳光透明 / 顾客第一 / 现金流优先 / 本分经营',
            'legal_entity': None,
            'billing': None,
            'products': [],
            'operating_principle': '现金流优先 / 极简可维护 / 质量第一',
        },
        'team': team,
        'decided_by': decided_by,
        'decisions': [],
        'customers': [],
        'leads': [],
        'requirements': [],
        'revenue': [],
    }


def gen_kanban(out, roles, company, welcome, ts):
    db_path = os.path.join(out, 'kanban.db')
    # 覆盖流程：旧库已在备份里，直接重建全新空库（防 executescript 撞已存在表）
    if os.path.exists(db_path):
        os.remove(db_path)
    con = sqlite3.connect(db_path)
    con.executescript(KANBAN_DDL)
    if welcome and roles:
        ceo = next((r for r in roles if r.get('is_ceo')), roles[0])
        task_id = 't_' + uuid.uuid4().hex[:10]
        names = '、'.join(r['name_zh'] for r in roles)
        body = (f"你好，{ceo['name_zh']}（CEO）。「{company}」的 AI 办公室已就绪，"
                f"团队共 {len(roles)} 人：{names}。\n\n"
                f"建议第一步：\n"
                f"1. 打开透明办公室查看团队与状态\n"
                f"2. 阅读各成员角色定义（profiles/<id>/role.md）\n"
                f"3. 经 kanban 向成员派发第一个任务\n\n"
                f"决策分级：人财物（人事/财务/物资资产/花钱/收款/法务）由老板（人类）拍板；"
                f"事（运营/执行/产品迭代/内容发布）由你（CEO）自主拍板。")
        con.execute(
            'INSERT INTO tasks (id, title, body, assignee, status, priority, created_by, created_at, workspace_kind) '
            'VALUES (?,?,?,?,?,?,?,?,?)',
            (task_id, f'欢迎使用「{company}」的 AI 办公室', body,
             ceo['id'], 'ready', 99, 'opc-init', ts, 'scratch'))
    con.commit()
    con.close()


def gen_report(cfg, tpl, roles, company, provider, key, out, welcome, ts, gateway_mode=False, gateway_url=None):
    lines = []
    lines.append('OPC OS 初始化报告')
    lines.append('=' * 40)
    lines.append(f'公司名称 : {company}')
    lines.append(f'行业模板 : {tpl["name"]}（{tpl["id"]}）')
    lines.append(f'生成时间 : {ts}')
    lines.append(f'LLM      : {provider}' + ('（网关模式）' if gateway_mode else '') + f'（key 见 llm.env，勿外泄；当前 {mask_key(key)}）')
    if gateway_mode:
        lines.append(f'网关地址 : {gateway_url or GATEWAY_DEFAULT_URL}（统一模型名 hermes-opc-v1，网关内部按 priority 路由 eyuai/kimi/deepseek/openrouter；熔断自动切换/月度预算由网关负责，agent 侧不配 fallback）')
    lines.append(f'输出目录 : {out}')
    lines.append('')
    lines.append(f'生成团队（{len(roles)} 人）：')
    for i, r in enumerate(roles, 1):
        cron = '、'.join(c['name'] + '（' + c['desc'] + '）' for c in r.get('cron', []))
        ceo = '（CEO）' if r.get('is_ceo') else ''
        lines.append(f'  {i}. {r["name_zh"]}（{r["name_en"]}）— {r["role_zh"]}{ceo}')
        lines.append(f'     职责: {r["duty"]}')
        lines.append(f'     cron: {cron or "（无）"}')
    lines.append('')
    lines.append('产物清单:')
    lines.append('  config/config.json    配置（collector 零改动直接读，paths 全部指向卷内 /data）')
    lines.append('  hermes-home/profiles/<id>/  成员骨架（SOUL.md / persona.md / role.md / skills.md / cron/ / config.yaml）')
    lines.append('                      （= 客户 Hermes 实例 HOME 目录；collector 按 config paths.hermes_home 读取）')
    lines.append('  state.json            团队名册 + 决策分级（decided_by）')
    lines.append('  kanban.db             空板' + (' + 欢迎任务' if welcome else '') + '（' + (roles[0]['name_zh'] if roles else '-') + '）')
    lines.append('  init-state.json       初始化标记（=initialized，首启检测用）')
    lines.append('  llm.env               LLM key + 网关 client token（chmod 600；网关 GATEWAY_ENV_FILE 引用，不落 config.yaml/profiles）')
    lines.append('  init-report.txt/json  本报告')
    lines.append('')
    lines.append('下一步:')
    if gateway_mode:
        lines.append('  1. docker compose up -d --build   # 生效（含 llm-gateway 网关容器；宿主 Hermes 走 ' + (gateway_url or GATEWAY_DEFAULT_URL) + '）')
        lines.append('  2. 安装 Hermes 运行时（团队 Agent 底座）: 见 deploy-guide「安装 Hermes 运行时」章节（install-hermes-worker.sh）')
        lines.append('  3. 打开透明办公室查看团队/任务/活动流')
        lines.append('  4. 老板拍板「人财物」，CEO 自主「事」层面；全部决策留痕 state.json decisions[]')
    else:
        lines.append('  1. docker compose up -d --build   # 生效')
        lines.append('  2. 打开透明办公室查看团队/任务/活动流')
        lines.append('  3. 老板拍板「人财物」，CEO 自主「事」层面；全部决策留痕 state.json decisions[]')
    return '\n'.join(lines)


# ---------------------------------------------------------------- 脱敏自检

def _scan_text(text, where):
    hits = []
    for m in BANNED_TEXT_RE.finditer(text):
        hits.append((m.group(0), where))
    return hits


def scan_forbidden(out):
    """扫描全部生成产物：文本命中 + 结构化身份字段精确比对。返回命中列表。

    31c：跳过 collector 运行时产物（status.json/token-stats.json/bus-state.json/
    kanban-demo.db/demo 目录/llm.env）——它们是部署包运行时数据（欢迎态或采集输出，
    含 kanban_demo 等结构字段名），不是 opc-init 生成的客户产物，不参与脱敏自检。
    """
    hits = []
    out_abs = os.path.abspath(out)
    # 运行时产物（collector/web 输出或 init 的 key 文件）：不属于 init 生成的客户产物
    RUNTIME_FILES = {'status.json', 'token-stats.json', 'bus-state.json',
                     'kanban-demo.db', 'llm.env', 'init-report.txt', 'init-report.json'}
    for root, _dirs, files in os.walk(out):
        if 'backups' in root.split(os.sep):
            continue
        if 'demo' in root.split(os.sep):
            continue   # demo/ 目录（访客体验数据）
        for fn in files:
            if fn in RUNTIME_FILES:
                continue
            fp = os.path.join(root, fn)
            rel = os.path.relpath(fp, out)
            try:
                if fn == 'config.json' and 'config' in root.split(os.sep):
                    # 剔除 paths 段（hermes-home 等卷内路径为产品约定，非身份引用）
                    data = json.load(open(fp, encoding='utf-8'))
                    data.get('collector', {}).pop('paths', None)
                    data.pop('bus', None)
                    text = json.dumps(data, ensure_ascii=False)
                else:
                    text = open(fp, encoding='utf-8', errors='replace').read()
            except Exception as e:
                hits.append((f'<读取失败 {rel}: {e}>', rel))
                continue
            # 机器本地输出路径（如 /home/<user>/...）不是产物内容，扫描前打码
            text = text.replace(out_abs, '<OUT>')
            # 统一模型名/网关 provider 标识（0825-init-2）是产品约定（网关统一入口），
            # 非 OPC 真实身份引用，扫描前打码豁免（config.yaml 的
            # default: hermes-opc-v1 / provider: custom:hermes-opc / custom_providers
            # name: hermes-opc 属正常产物）
            text = (text.replace(GATEWAY_MODEL, 'GW-UNIFIED-MODEL')
                        .replace(GATEWAY_PROVIDER, 'GW-UNIFIED-PROVIDER'))
            hits += _scan_text(text, rel)
    # 结构化字段精确比对
    cfg_path = os.path.join(out, 'config', 'config.json')
    if os.path.exists(cfg_path):
        try:
            coll = json.load(open(cfg_path, encoding='utf-8')).get('collector', {})
            ids = list(coll.get('profiles', [])) + list(coll.get('name_id', {}).values())
            for i in ids:
                if i in BANNED_IDS:
                    hits.append((f'profile id "{i}"', 'config.json'))
            for zh in coll.get('name_id', {}).keys():
                if any(b in zh for b in BANNED_TEXT):
                    hits.append((f'成员中文名 "{zh}"', 'config.json'))
        except Exception:
            pass
    state_path = os.path.join(out, 'state.json')
    if os.path.exists(state_path):
        try:
            st = json.load(open(state_path, encoding='utf-8'))
            for m in st.get('team', []):
                if m.get('id') in BANNED_IDS:
                    hits.append((f'team id "{m["id"]}"', 'state.json'))
                for k in ('name_zh', 'name_en'):
                    v = m.get(k, '')
                    if any(b in v for b in BANNED_TEXT) or re.search(r'\b(?:make|ada|iris|hermes)\b', v, re.I):
                        hits.append((f'team {k} "{v}"', 'state.json'))
        except Exception:
            pass
    return hits


# ---------------------------------------------------------------- 主流程

def build(cfg):
    out = cfg['out']
    ts = now_iso()
    tpl = load_template(cfg['template'])
    roles = select_roles(tpl, cfg['members'], cfg['ceo'])
    company = cfg['name']
    provider = cfg['llm']
    gateway_mode = provider == 'gateway'
    if provider == 'custom':
        base_url, model = cfg['base_url'], cfg['model']
    elif gateway_mode:
        # 网关模式（0825-init-2）：统一模型名 hermes-opc-v1 / provider=hermes-opc，
        # base_url 指向 llm-gateway；熔断/降级由网关负责，agent 侧不配 fallback。
        base_url = cfg.get('gateway_url') or GATEWAY_DEFAULT_URL
        model = GATEWAY_MODEL
        provider = GATEWAY_PROVIDER
    else:
        base_url = PROVIDERS[provider]['base_url']
        model = cfg.get('model') or PROVIDERS[provider]['model']

    # 0) 覆盖确认 + 备份
    existing = [p for p in (
        os.path.join(out, 'init-state.json'),
        os.path.join(out, 'config', 'config.json'),
        os.path.join(out, 'state.json'),
        os.path.join(out, 'kanban.db')) if os.path.exists(p)]
    if existing and not cfg['force']:
        print('[opc-init] 检测到已有初始化产物:')
        for p in existing:
            print(f'  {p}')
        if cfg.get('interactive'):
            if not ask_yesno('覆盖？覆盖前将备份到 backups/<时间戳>/', default=False):
                print('已取消。')
                return 1
        else:
            print('[opc-init] 非交互模式检测到已有产物，请加 --force 覆盖（覆盖前自动备份）。')
            return 2
    if existing and cfg['force']:
        backup_to = os.path.join(out, 'backups', ts.replace(':', '').replace('+', '-'))
        os.makedirs(backup_to, exist_ok=True)
        for p in existing:
            if os.path.exists(p):
                dst = os.path.join(backup_to, os.path.relpath(p, out))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                if p.endswith('.db') and os.path.isfile(p):
                    try:
                        src = sqlite3.connect(p)
                        dstc = sqlite3.connect(dst)
                        src.backup(dstc)
                        dstc.close()
                        src.close()
                    except Exception:
                        shutil.copy2(p, dst)
                else:
                    shutil.copy2(p, dst)
        print(f'[opc-init] 已备份现有数据 → {backup_to}')

    # 0b) 匿名安装 ID（0826-os-2）：install.json 幂等——已存在则保留原 ID，
    #     --force 重跑初始化也不变（保证官网来源统计连续）。
    #     红线：install_id 只落客户数据卷（install.json），不落代码、不落 git、
    #     不进 stdout/聊天记录；仅含匿名随机 ID，无 IP/设备指纹。
    install_file = os.path.join(out, 'install.json')
    install_id = None
    install_created = now_iso()
    if os.path.exists(install_file):
        try:
            with open(install_file, encoding='utf-8') as f:
                _old = json.load(f)
            if re.fullmatch(r'[A-Za-z0-9_-]{8,64}', str(_old.get('install_id', ''))):
                install_id = _old['install_id']
                install_created = str(_old.get('created_at') or install_created)
        except Exception:
            install_id = None   # 文件损坏/格式非法 → 重新生成
    if not install_id:
        install_id = secrets.token_hex(16)   # 32 位 hex，无横线
    os.makedirs(out, exist_ok=True)
    with open(install_file, 'w', encoding='utf-8') as f:
        json.dump({'install_id': install_id, 'created_at': install_created,
                   'version': VERSION}, f, ensure_ascii=False, indent=2)
        f.write('\n')
    print('[opc-init] 匿名安装 ID 已就绪（install.json，仅落数据卷，不打印内容）')

    # 1) config/config.json
    cfg_json = gen_config(tpl, roles, company)
    os.makedirs(os.path.join(out, 'config'), exist_ok=True)
    with open(os.path.join(out, 'config', 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(cfg_json, f, ensure_ascii=False, indent=2)
        f.write('\n')

    # 2) profiles/<id>/ 骨架（31c：写 <out>/hermes-home/profiles/<id>/——config paths.hermes_home
    #    =/data/hermes-home，collector/token_stats 读 <hermes_home>/profiles/<p>/，客户 Hermes
    #    实例 HOME 也是 /data/hermes-home，骨架必须在此才能「直接加载运行」）
    for r in roles:
        pdir = os.path.join(out, 'hermes-home', 'profiles', r['id'])
        os.makedirs(os.path.join(pdir, 'cron'), exist_ok=True)
        with open(os.path.join(pdir, 'SOUL.md'), 'w', encoding='utf-8') as f:
            f.write(gen_soul(r, company, bool(r.get('is_ceo'))))
        with open(os.path.join(pdir, 'role.md'), 'w', encoding='utf-8') as f:
            f.write(gen_role_md(r))
        with open(os.path.join(pdir, 'persona.md'), 'w', encoding='utf-8') as f:
            f.write(gen_persona_md(r))
        with open(os.path.join(pdir, 'skills.md'), 'w', encoding='utf-8') as f:
            f.write(gen_skills_md(r))
        with open(os.path.join(pdir, 'profile.yaml'), 'w', encoding='utf-8') as f:
            f.write(f'description: {r["role_zh"]}岗，负责{r["duty"]}。\n'
                    f'description_auto: false\n')
        with open(os.path.join(pdir, 'config.yaml'), 'w', encoding='utf-8') as f:
            f.write(gen_profile_config_yaml(provider, model, base_url, gateway_mode=gateway_mode))
        with open(os.path.join(pdir, 'cron', 'jobs.json'), 'w', encoding='utf-8') as f:
            json.dump(gen_cron_jobs(r, company, ts), f, ensure_ascii=False, indent=2)

    # 3) state.json
    with open(os.path.join(out, 'state.json'), 'w', encoding='utf-8') as f:
        json.dump(gen_state(tpl, roles, company, cfg['ceo'], ts), f, ensure_ascii=False, indent=2)
        f.write('\n')

    # 4) kanban.db（空板 + 欢迎任务）
    gen_kanban(out, roles, company, cfg['welcome'], ts_now())

    # 5) init-state.json（31c 首启检测标记）
    with open(os.path.join(out, 'init-state.json'), 'w', encoding='utf-8') as f:
        json.dump({'status': 'initialized', 'initialized_at': ts,
                   'template': tpl['id'], 'company': company,
                   'generated_by': f'opc-init v{VERSION}'}, f, ensure_ascii=False, indent=2)

    # 6) llm.env
    #    OPC_LLM_* 供 compose/collector 注入；网关模式额外写：
    #    - GATEWAY_CLIENT_TOKEN=<随机>：/v1/* Bearer 鉴权，网关 GATEWAY_ENV_FILE 引用
    #      同一文件读到同值 → 客户 Hermes 与网关自洽（install-hermes-worker.sh 写入
    #      model.api_key 用此值）；
    #    - 客户自带 key（BYOK）：DEEPSEEK_API_KEY 等，与网关 provider 池对齐。
    #    红线：key/token 只进 llm.env（chmod 600），不落盘 config.yaml / profiles。
    env_lines = [
        f'OPC_LLM_PROVIDER={provider}\n',
        f'OPC_LLM_MODEL={model}\n',
        f'OPC_LLM_BASE_URL={base_url}\n',
        f'OPC_LLM_API_KEY={cfg["key"]}\n',
    ]
    if gateway_mode:
        # 网关自有 token（随机值，仅 llm.env + 网关 env 文件；不落聊天/代码/commit）
        env_lines.append(f'{GATEWAY_CLIENT_TOKEN_ENV}={uuid.uuid4().hex}\n')
        if cfg['key']:
            env_lines.append(f'DEEPSEEK_API_KEY={cfg["key"]}\n')   # 客户自带 key（BYOK）
    with open(os.path.join(out, 'llm.env'), 'w', encoding='utf-8') as f:
        f.writelines(env_lines)
    try:
        os.chmod(os.path.join(out, 'llm.env'), 0o600)
    except OSError:
        pass

    # 7) 报告
    report = gen_report(cfg_json, tpl, roles, company, provider, cfg['key'], out, cfg['welcome'], ts,
                        gateway_mode=gateway_mode, gateway_url=cfg.get('gateway_url'))
    with open(os.path.join(out, 'init-report.txt'), 'w', encoding='utf-8') as f:
        f.write(report + '\n')
    with open(os.path.join(out, 'init-report.json'), 'w', encoding='utf-8') as f:
        json.dump({
            'company': company, 'template': tpl['id'], 'template_name': tpl['name'],
            'generated_at': ts, 'llm_provider': provider, 'llm_model': model,
            'llm_mode': 'gateway' if gateway_mode else 'direct',
            'gateway_url': (cfg.get('gateway_url') or GATEWAY_DEFAULT_URL) if gateway_mode else None,
            'members': [{'id': r['id'], 'name_zh': r['name_zh'], 'role': r['role_zh'],
                         'is_ceo': bool(r.get('is_ceo'))} for r in roles],
            'welcome_task': cfg['welcome'], 'out': out, 'version': VERSION,
        }, f, ensure_ascii=False, indent=2)

    # 8) 脱敏自检（红线）
    hits = scan_forbidden(out)
    if hits:
        print('[opc-init] 错误: 脱敏自检未通过，产物已生成但包含以下保留词（请勿交付客户）:')
        for token, where in hits[:30]:
            print(f'  ✗ {token!r} @ {where}')
        print(f'  共 {len(hits)} 处命中。生成中止（已落盘文件请人工清理）。')
        return 3

    print()
    print(report)
    print()
    print('[opc-init] 初始化完成 ✅（脱敏自检通过：产物零 OPC 真实身份）')
    return 0


def main():
    ap = argparse.ArgumentParser(
        prog='opc-init',
        description='OPC OS 初始化引擎：按行业模板生成客户自己的 AI 办公室',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=('示例:\n'
                '  交互模式:   docker compose run --rm init\n'
                '  参数化模式: python3 scripts/opc_init.py --template manufacturing '
                '--name "精工制造" --llm deepseek --key xxx\n'))
    ap.add_argument('--template', '-t', help='行业模板 id（software/manufacturing/retail/aigc，缺省走交互）')
    ap.add_argument('--name', '-n', help='公司/门店名称（参数化模式必填）')
    ap.add_argument('--members', type=int, default=None, help='团队角色数（默认模板全部）')
    ap.add_argument('--no-ceo', action='store_true', help='不生成 AI CEO 角色（决策只留老板一层）')
    ap.add_argument('--llm', default='deepseek', help='LLM provider（deepseek/openai/anthropic/moonshot/gateway/custom，默认 deepseek；gateway=网关模式）')
    ap.add_argument('--key', default='', help='LLM API key（BYOK；建议经 env 或 .env 注入）')
    ap.add_argument('--gateway', action='store_true', help='网关模式（等价 --llm gateway）：base_url 指向 llm-gateway，熔断/月度预算由网关负责')
    ap.add_argument('--gateway-url', default=None, help=f'网关地址（网关模式默认 {GATEWAY_DEFAULT_URL}）')
    ap.add_argument('--base-url', default=None, help='custom provider 时必填')
    ap.add_argument('--model', default=None, help='custom provider 时必填')
    ap.add_argument('--out', default=None, help='输出目录（默认容器内 /data，本机 ./opc-init-out）')
    ap.add_argument('--force', action='store_true', help='已有产物时直接覆盖（覆盖前自动备份）')
    ap.add_argument('--no-welcome', action='store_true', help='不创建欢迎任务')
    ap.add_argument('--list-templates', action='store_true', help='列出可用模板后退出')
    ap.add_argument('--version', action='version', version=f'opc-init {VERSION}')
    args = ap.parse_args()

    if args.list_templates:
        for tid in list_templates():
            t = load_template(tid)
            names = '、'.join(r['name_zh'] for r in t['roles'])
            print(f'{tid}\t{t["name"]}\t{t.get("description", "")}\t角色: {names}')
        return 0

    # 参数化模式
    if args.template or args.name:
        if not args.template or not args.name:
            ap.error('参数化模式必须同时提供 --template 与 --name（或都不提供走交互模式）')
        llm = 'gateway' if (args.gateway or args.llm == 'gateway') else args.llm
        cfg = {
            'template': args.template,
            'name': args.name,
            'members': args.members,
            'ceo': not args.no_ceo,
            'llm': llm,
            'key': args.key,
            'base_url': args.base_url,
            'model': args.model,
            'welcome': not args.no_welcome,
            'out': args.out or default_out_dir(),
            'force': args.force,
            'gateway_url': args.gateway_url or GATEWAY_DEFAULT_URL,
        }
        if args.llm == 'custom' and (not args.base_url or not args.model):
            ap.error('--llm custom 必须同时提供 --base-url 与 --model')
        return build(cfg)

    # 交互模式
    out = args.out or default_out_dir()
    existing = [p for p in (
        os.path.join(out, 'init-state.json'),
        os.path.join(out, 'config', 'config.json'),
        os.path.join(out, 'state.json'),
        os.path.join(out, 'kanban.db')) if os.path.exists(p)]
    if existing and not args.force:
        print('[opc-init] 检测到已有初始化产物:')
        for p in existing:
            print(f'  {p}')
        if ask_yesno('继续将覆盖现有数据（覆盖前自动备份），是否继续？', default=False):
            args.force = True
        else:
            print('已取消。')
            return 0
    cfg = interactive_flow()
    if cfg is None:
        return 0
    cfg['out'] = out
    cfg['force'] = args.force
    cfg['interactive'] = True
    return build(cfg)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except QuitError as e:
        print(f'已退出: {e}')
        sys.exit(0)
    except KeyboardInterrupt:
        print('\n已取消。')
        sys.exit(130)
