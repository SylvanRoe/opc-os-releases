// opc-server pm2 守护配置固化（2026-08-26 SSE 风暴事故加固，t_58242ff9）
// 存档标注（2026-08-27 pm2→systemd 迁移，t_a66c2520）：守护已由 opcos-api.service 接管，
// 本文件仅作参数文档（kill_timeout/max_restarts/max_memory_restart 语义已映射到 systemd unit 加固段），不再用于启动。
// 用途：马克修复完成后，用以下命令启动 opc-server 即套用本配置：
//   pm2 start /home/gavin/hermes_space/opc-os/ecosystem.config.js --only opc-server
// 启动成功后执行 pm2 save 固化 dump（resurrect/开机自启用本配置）。
// 注意：本配置不覆盖 daemon 中已存在的 opc-server 条目配置；如 daemon 条目配置过旧，
//   可先 `pm2 delete opc-server` 再按上面命令启动。
module.exports = {
  apps: [
    {
      name: "opc-server",
      script: "./opc-api/index.cjs",
      cwd: "/home/gavin/hermes_space/opc-os",
      instances: 1,
      exec_mode: "fork",
      // —— 2026-08-26 事故加固参数 ——
      autorestart: true,        // 运维红线：常驻服务必须守护
      kill_timeout: 10000,      // SIGINT 后 10s 才 SIGKILL：风暴占满事件循环时给足优雅退出时间
                                // （事故根因之一：默认 1600ms 太短，stop 杀不死 → pm2 状态脱节）
      restart_delay: 3000,      // 崩溃后延迟 3s 再拉：防风暴瞬间 0 延迟狂拉放大（事故 ↺7）
      max_restarts: 5,          // 10s 窗口内崩溃重启超 5 次 → pm2 判 errored 停手，不再无限拉起
      min_uptime: 10000,        // 与 max_restarts 配合判重启循环；稳定运行超 10s 计数清零
      max_memory_restart: "900M", // RSS 超 900MB 自动重启（事故 RSS 涨至 1.1GB；风暴中由
                                  // max_restarts 兜底防循环）
      env: { NODE_ENV: "production" },
    },
  ],
};
