#!/bin/sh
# llm-gateway 容器入口（0825-init）
# 首次启动把镜像内置默认配置拷入数据卷 /app/data（管理面板改动热写卷内配置，重建不丢）；
# GATEWAY_CONFIG 由 compose 注入指向 /app/data/gateway.config.json，
# events/（config.events.dir 相对 config 文件解析）随之落卷 → 透明度数据持久化。
set -e

if [ ! -f /app/data/gateway.config.json ]; then
  mkdir -p /app/data
  cp /app/gateway.config.json /app/data/gateway.config.json
fi

exec node server.js
