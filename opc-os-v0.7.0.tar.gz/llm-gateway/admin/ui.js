/* ==========================================================================
   0821-c 公共头部按钮组件脚本（4 页统一引用，须在 <head> 同步加载）

   职责：
   ① 首帧主题/语言检测（防闪烁：data-theme + html lang/dir 必须在 body 渲染前就位）
   ② i18n 语言包缓存 bootstrap（.i18n-pending 门控，缓存命中同步应用零闪烁）
   ③ themeBtn 明暗切换（localStorage gavinlab-theme-v2，跟随系统偏好直至手动切换）
   ④ langBtn/langMenu 开合 + 7 语切换（localStorage site-lang-v2 + reload）

   页面挂钩（可选，须在本文件加载前定义）：
     window.__I18N_VER           —— 语言包版本号（缓存失效用；页面必设）
     window.__i18nValidateDict   —— 函数(dict)→bool，缓存命中附加校验
                                    （如 workbench 的 opc.workbench ≥70 键检查）
     window.__uiThemeText        —— 函数()→{light,dark}，主题按钮文案（走页面 i18n dict）
     window.__uiOnThemeToggle    —— 函数(theme)，主题切换后回调
                                    （如 governance drawBars / opc readPalette）
     window.__uiBeforeLangReload —— 函数(lang)，语言写入 localStorage 后、reload 前回调
                                    （如首页/透明办公室的 URL ?lang= 同步）

   页面调用点：applyI18n 应用语言包后调用 window.__uiSyncTheme() 重刷主题按钮文案。

   0822-a：esc() 提升为模块级公共函数（markdown-renderer 组件共用，全站唯一一份，
   见文件末尾 @gavin-ui component:markdown-renderer）。
   ========================================================================== */
// 站点版本（集中版本号，替代散落注释；语义见 /home/gavin/.hermes/opc/asset-versioning.md）
var SITE_VERSION = '1.0.291';
// 公共 HTML 转义（markdown 渲染器与主题按钮共用；& < > " ' 全转义）
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
(function () {
  'use strict';

  /* ===== ① 首帧主题/语言检测（防闪烁，同步执行） ===== */
  try {
    var k = 'gavinlab-theme-v2', s = localStorage.getItem(k);
    document.documentElement.setAttribute('data-theme',
      s || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
    var lk = 'site-lang-v2', sv = null;
    try { sv = localStorage.getItem(lk); } catch (e) {}
    var map = { zh: 1, en: 1, ja: 1, ko: 1, fr: 1, de: 1, ar: 1, ru: 1, es: 1, tr: 1, pl: 1, pt: 1 };
    var lang = null;
    var qm = location.search.match(/[?&]lang=([a-z]{2})/);
    if (qm && map[qm[1]]) lang = qm[1];
    if (!lang && sv && map[sv]) lang = sv;
    if (!lang) {
      var al = (navigator.languages || [navigator.language || 'zh']).map(function (x) {
        return String(x).toLowerCase().split('-')[0];
      });
      for (var i = 0; i < al.length; i++) {
        if (map[al[i]]) { lang = al[i]; break; }
      }
      if (!lang) lang = 'zh';
    }
    window.__i18nLang = lang;
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
  } catch (e) {
    window.__i18nLang = 'zh';
  }

  /* ===== ② i18n 语言包缓存 bootstrap（防闪烁门控） ===== */
  try {
    var VER = window.__I18N_VER || 1; window.__I18N_VER = VER;
    var LANG = window.__i18nLang || 'zh';
    var KEY = 'site-i18n-cache-v' + VER + '-' + LANG;
    var c = null; try { c = JSON.parse(localStorage.getItem(KEY)); } catch (e) { c = null; }
    var ok = c && typeof c === 'object' && c.dict && typeof c.dict === 'object' &&
             Object.keys(c.dict).length > 0 && c.lang === LANG && c.ver === VER;
    if (ok && typeof window.__i18nValidateDict === 'function') {
      try { ok = window.__i18nValidateDict(c.dict); } catch (e) { ok = false; }
    }
    if (ok) {
      window.__i18nCachedDict = c.dict;
      if (LANG !== 'zh') document.documentElement.classList.add('i18n-pending');
    } else {
      if (c) { try { localStorage.removeItem(KEY); } catch (e2) {} }
      if (LANG !== 'zh') document.documentElement.classList.add('i18n-pending');
    }
  } catch (e) {}

  /* ===== ③④ 主题/语言切换（DOM 就绪后挂接） ===== */
  var LANG_NAMES = { zh: '中文', en: 'English', ja: '日本語', ko: '한국어', fr: 'Français', de: 'Deutsch', ar: 'العربية', ru: 'Русский', es: 'Español', tr: 'Türkçe', pl: 'Polski', pt: 'Português' };
  var THEME_KEY = 'gavinlab-theme-v2';
  var LANG_KEY = 'site-lang-v2';
  var root = document.documentElement;
  var manual = false;
  try { manual = !!localStorage.getItem(THEME_KEY); } catch (e) {}
  var btn = null;

  function themeLabels() {
    if (typeof window.__uiThemeText === 'function') {
      try {
        var t = window.__uiThemeText();
        if (t && t.light && t.dark) return t;
      } catch (e) {}
    }
    return { light: '亮色', dark: '暗色' };
  }
  function themeIcon(isDark) {
    return isDark
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="width:14px;height:14px"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>'
      : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="width:14px;height:14px"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
  }
  function applyTheme(t) { root.setAttribute('data-theme', t); }

  function syncTheme() {
    if (!btn) return;
    var t = root.getAttribute('data-theme');
    var lb = themeLabels();
    // 暗色主题下显示「亮色」文案（点击回到亮色）
    var txt = t === 'dark' ? lb.light : lb.dark;
    btn.innerHTML = (t === 'dark' ? themeIcon(false) : themeIcon(true)) +
                    '<span class="theme-btn-txt">' + esc(txt) + '</span>';
  }
  window.__uiSyncTheme = syncTheme; // 页面 applyI18n 后调用重刷（dict 文案就绪）

  function init() {
    btn = document.getElementById('themeBtn');
    if (btn) {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      if (mq.addEventListener) {
        mq.addEventListener('change', function (e) {
          if (!manual) { applyTheme(e.matches ? 'dark' : 'light'); syncTheme(); }
        });
      }
      btn.addEventListener('click', function () {
        manual = true;
        var t = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        applyTheme(t);
        try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
        syncTheme();
        if (typeof window.__uiOnThemeToggle === 'function') {
          try { window.__uiOnThemeToggle(t); } catch (e) {}
        }
      });
    }

    var langBtn = document.getElementById('langBtn');
    var langMenu = document.getElementById('langMenu');
    if (langBtn && langMenu) {
      langBtn.addEventListener('click', function (e) { e.stopPropagation(); langMenu.classList.toggle('open'); });
      document.addEventListener('click', function () { langMenu.classList.remove('open'); });
      langMenu.addEventListener('click', function (e) { e.stopPropagation(); });
      var cur = document.getElementById('langCur');
      if (cur) cur.textContent = LANG_NAMES[window.__i18nLang] || window.__i18nLang;
      langMenu.querySelectorAll('.lang-opt').forEach(function (b) {
        b.classList.toggle('active', b.getAttribute('data-lang') === window.__i18nLang);
        b.addEventListener('click', function () {
          var l = b.getAttribute('data-lang');
          if (l === window.__i18nLang) { langMenu.classList.remove('open'); return; }
          try { localStorage.setItem(LANG_KEY, l); } catch (e) {}
          if (typeof window.__uiBeforeLangReload === 'function') {
            try { window.__uiBeforeLangReload(l); } catch (e) {}
          }
          location.reload();
        });
      });
    }

    syncTheme();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ==========================================================================
   @gavin-ui component:markdown-renderer
   公共 Markdown 渲染器 + 代码块一键复制（0822-a，规范 design-system.md §6）

   API：window.renderMarkdown(src, opts) → 安全 HTML 字符串
     opts = { imgBase: '' } —— 图片相对路径补全前缀（blog 传 '/blog/'；
     http(s):// 与 / 开头原样，img/ 开头拼 imgBase，其余相对路径配合 imgBase）。

   能力超集统一（三处页面一致，只增不减）：
     行内：`code`、**bold**、__bold__、*italic*、_italic_（边界约束防 foo_bar_baz）、
           [text](http(s)链接)、![alt](src)（loading=lazy + src 白名单）、裸 URL 自动链接
     块级：#/##/### 标题、-/* 无序、1. 有序、``` 代码围栏（含 .code-copy 复制按钮）、
           |表格|（tbl-wrap 横滑 + td>40 字符 .wrap）、> 引用、--- 或 *** 分隔线、段落
           （连续行合并 <p>，软换行 <br/>）

   安全红线（§6.2 六条，防线只强不弱）：
     ① esc 全转义在前（& < > " '），块级识别用原始行、转义在行内输出
     ② 行内码/代码块占位符保护（\u0001 / \u0002 类），代码内容绝不参与二次语法解释
     ③ 链接 href 仅 http/https，固定 target="_blank" rel="noopener noreferrer"
     ④ img src 白名单（http(s)://、/ 开头、img/ 开头、配合 imgBase 的相对路径），
        禁 javascript:/data:；alt 经 esc
     ⑤ 禁原始 HTML 直通（由 esc + 白名单保证）
     ⑥ 裸 URL 前导守卫 (^|[^"'>=\w]) 排除已生成属性内 URL；尾部剥离中英文标点并原样保留

   复制功能（§6.3）：document 级 click 委托捕获 .code-copy；navigator.clipboard.writeText
   优先 → execCommand('copy') + textarea 降级；成功 = .copied 换 CHECK_SVG 2s 还原 + toast；
   失败 = toast「复制失败」；禁 alert/confirm/prompt。toast 走页面 __uiToast 钩子
   （workbench/opc 接线到各自 #toast），未定义则自建 .ui-toast。

   包化预留（§6.6 D6）：本分区零页面耦合；对外接触面仅 window.renderMarkdown 与可选钩子
   （window.__uiToast、页面全局 T()——有则用、无则兜底）。样式全在 ui.css。
   ========================================================================== */
(function () {
  'use strict';

  // ---- lucide 线性图标常量（零 emoji 零箭头字符；固定 width/height 属性）----
  var COPY_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
  var CHECK_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>';
  var EXT_SVG = '<svg class="ext-link-ic" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>';

  var I18N_FALLBACK = {
    'common.copyCode': '复制代码',
    'common.copied': '已复制',
    'common.copyFailed': '复制失败'
  };

  // 文案解析：页面全局 T() 存在则走（workbench/opc/blog 均有），未命中/不存在兜底中文字面量。
  // 语言切换 = 整页 reload（site-lang-v2），渲染时解析一次即可。
  function uiText(key) {
    if (typeof window.T === 'function') {
      try {
        var v = window.T(key);
        if (v != null && v !== key) return v;
      } catch (e) {}
    }
    return I18N_FALLBACK[key] || '';
  }

  // toast：页面 __uiToast 钩子优先（workbench/opc 已接线到各自 #toast），未定义则
  // ui.js 自建 .ui-toast 轻提示（样式在 ui.css，反色 pill 底部居中，与 opc .toast 同族）。
  function notify(text, isErr) {
    if (typeof window.__uiToast === 'function') {
      try { window.__uiToast(text, !!isErr); return; } catch (e) {}
    }
    var el = document.querySelector('.ui-toast');
    if (!el) {
      el = document.createElement('div');
      el.className = 'ui-toast';
      document.body.appendChild(el);
    }
    el.textContent = text;
    el.classList.toggle('err', !!isErr);
    el.classList.add('show');
    clearTimeout(notify._t);
    notify._t = setTimeout(function () { el.classList.remove('show'); }, 2600);
  }

  function copyOk(btn) {
    btn.classList.add('copied');
    btn.innerHTML = CHECK_SVG;
    clearTimeout(copyOk._t);
    copyOk._t = setTimeout(function () {
      btn.classList.remove('copied');
      btn.innerHTML = COPY_SVG;
    }, 2000);
    notify(uiText('common.copied'));
  }
  function copyFail() { notify(uiText('common.copyFailed'), true); }

  // clipboard API 优先 → execCommand('copy') + textarea 降级（非安全上下文兼容）
  function copyText(btn, text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        function () { copyOk(btn); },
        function () { copyFallback(btn, text); }
      );
    } else {
      copyFallback(btn, text);
    }
  }
  function copyFallback(btn, text) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      ta.style.top = '0';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      var ok = document.execCommand('copy');
      document.body.removeChild(ta);
      if (ok) copyOk(btn); else copyFail();
    } catch (e) { copyFail(); }
  }

  // 复制事件委托（document 级捕获，动态插入的渲染内容也能命中，如 workbench 抽屉后开）
  document.addEventListener('click', function (e) {
    var t = e.target;
    while (t && t !== document) {
      if (t.classList && t.classList.contains('code-copy')) {
        var block = t.parentNode;
        var codeEl = block && block.querySelector ? block.querySelector('pre code') : null;
        if (codeEl) copyText(t, codeEl.textContent);
        e.preventDefault();
        return;
      }
      t = t.parentNode;
    }
  });

  // img src 白名单（§6.2#4）：http(s)://、/ 开头、img/ 开头、配合 imgBase 的相对路径；
  // 禁 javascript:/data: 等一切协议——非白名单一律返回 ''（按文本显示，不生成 img）
  function resolveImgSrc(p, imgBase) {
    if (!p) return '';
    if (/^(https?:)?\/\//i.test(p)) return p;
    if (/^\//.test(p)) return p;
    if (/^img\//.test(p)) return (imgBase || '') + p;
    if (imgBase) {
      // 其他相对路径配合 imgBase 补全；先排除任何显式协议（javascript:/data:/file: 等）
      if (/^[a-z][a-z0-9+.-]*:/i.test(p)) return '';
      return imgBase + p;
    }
    return '';
  }

  // ---- 行内渲染：入参必须已 esc（块级调用点统一 esc 后再 inline）----
  // 顺序：行内码占位 → 图片 → 链接 → 粗 → 斜 → 裸 URL → 还原行内码
  function inline(s) {
    var codes = [];
    s = s.replace(/`([^`\n]+)`/g, function (m, c) {
      codes.push(c);
      return '\u0001C' + (codes.length - 1) + '\u0001';
    });
    // 图片 ![alt](src)：loading=lazy；src 白名单校验；alt 已 esc
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, function (m, alt, src) {
      var r = resolveImgSrc(src, inline._imgBase);
      if (!r) return m; // 非白名单 src（javascript:/data: 等）→ 原文按文本显示
      return '<img src="' + r + '" alt="' + alt + '" loading="lazy" />';
    });
    // markdown 链接 [text](http(s)://...)：href 白名单仅 http/https；排除 " 防属性逃逸
    s = s.replace(/\[([^\[\]\n]+)\]\((https?:\/\/[^\s"')]+)\)/g, function (m, txt, url) {
      return '<a href="' + url + '" target="_blank" rel="noopener noreferrer">' + txt + EXT_SVG + '</a>';
    });
    // 粗体 **x** / __x__（先粗后斜，避免 * 与 ** 竞争）
    s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/__([^_\n]+)__/g, '<strong>$1</strong>');
    // 斜体 *x* / _x_（边界约束：* 前后非 *，_ 前后非字母数字下划线，防 foo_bar_baz 误伤）
    s = s.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>');
    s = s.replace(/(^|[^\w])_([^_\n]+)_(?!\w)/g, '$1<em>$2</em>');
    // 裸 URL 自动链接（§6.2#6）：前导守卫排除已生成标签属性内 URL；尾部剥离中英文标点
    // 并原样保留在链接外；展示文本 = host 去 www. 前缀 + 外链图标
    s = s.replace(/(^|[^"'>=\w])(https?:\/\/[^\s<>"')]+)/g, function (m, pre, u) {
      var tail = (u.match(/[.,;:!?，。、；：！？…）)】》"'一-鿿]+$/) || [''])[0];
      u = u.slice(0, u.length - tail.length);
      if (u.length < 4) return pre + u + tail; // 剥完过短 → 不链接，原样输出
      var host = (u.match(/^https?:\/\/([^\/?#]+)/) || ['', u])[1].replace(/^www\./, '');
      return pre + '<a href="' + u + '" target="_blank" rel="noopener noreferrer">' + host + EXT_SVG + '</a>' + tail;
    });
    // 还原行内码
    s = s.replace(/\u0001C(\d+)\u0001/g, function (m, i) { return '<code>' + codes[+i] + '</code>'; });
    return s;
  }

  // ---- 块级渲染（§6.2 架构铁律：块级识别用原始行，转义在行内输出）----
  function mdToHtml(src, imgBase) {
    var s = String(src == null ? '' : src);
    // ① 代码围栏优先提取 → 占位符（内容 esc 后入 blocks；代码内容绝不参与二次语法解释）
    var blocks = [];
    s = s.replace(/```([\s\S]*?)```/g, function (m, code) {
      code = code.replace(/^\n/, '').replace(/\n$/, '');
      blocks.push('<div class="code-block"><pre><code>' + esc(code) + '</code></pre>' +
        '<button type="button" class="code-copy" aria-label="' + esc(uiText('common.copyCode')) + '">' + COPY_SVG + '</button></div>');
      return '\u0002B' + (blocks.length - 1) + '\u0002';
    });
    // ② 按行切分，块级语法识别一律在原始行上做
    var lines = s.split('\n');
    var html = [], list = null, inP = false;
    inline._imgBase = imgBase || '';
    function isTblSep(l) {
      var cells = l.replace(/^\s*\|?/, '').replace(/\|?\s*$/, '').trim().split('|');
      return cells.length > 0 && cells.every(function (c) { return /^:?-{2,}:?$/.test(c.trim()); });
    }
    function closeP() { if (inP) { html.push('</p>'); inP = false; } }
    function closeList() { if (list) { html.push('</' + list + '>'); list = null; } }
    function flush() { closeP(); closeList(); }
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      var t = line.trim();
      // 代码块占位行
      var bm = t.match(/^\u0002B(\d+)\u0002$/);
      if (bm) { flush(); html.push(blocks[+bm[1]]); continue; }
      // 空行 → 段落/列表闭合
      if (!t) { flush(); continue; }
      // 表格：含 | 且下一行为分隔行 → 收集连续 | 行渲染 <table>（外包 tbl-wrap 横滑容器）
      if (t.indexOf('|') >= 0 && i + 1 < lines.length && isTblSep(lines[i + 1])) {
        flush();
        var tblLines = [t];
        i++;
        while (i < lines.length && lines[i].indexOf('|') >= 0) { tblLines.push(lines[i]); i++; }
        var rows = tblLines.map(function (l) {
          return l.replace(/^\s*\|?/, '').replace(/\|?\s*$/, '').trim().split('|').map(function (c) { return c.trim(); });
        });
        html.push('<div class="tbl-wrap"><table>');
        rows.forEach(function (cells, ri) {
          if (ri === 1 && cells.every(function (c) { return /^:?-{2,}:?$/.test(c); })) return; // 分隔行
          var tag = ri === 0 ? 'th' : 'td';
          var inner = cells.map(function (c) {
            return (tag === 'td' && c.length > 40) ? '<td class="wrap">' + inline(esc(c)) + '</td>'
                                                   : '<' + tag + '>' + inline(esc(c)) + '</' + tag + '>';
          }).join('');
          html.push('<tr>' + inner + '</tr>');
        });
        html.push('</table></div>');
        continue;
      }
      // 标题 #/##/###（h1-h3 全档）
      var hm = t.match(/^(#{1,3})\s+(.*)$/);
      if (hm) { flush(); var h = hm[1].length; html.push('<h' + h + '>' + inline(esc(hm[2])) + '</h' + h + '>'); continue; }
      // 引用 >
      var qm = t.match(/^>\s?(.*)$/);
      if (qm) { flush(); html.push('<blockquote>' + inline(esc(qm[1])) + '</blockquote>'); continue; }
      // 分隔线 --- 或 ***
      if (t === '---' || /^(\*\s*){3,}$/.test(t)) { flush(); html.push('<hr/>'); continue; }
      // 无序列表 - 或 *（行首）
      var um = t.match(/^[-*]\s+(.*)$/);
      if (um) {
        closeP();
        if (list !== 'ul') { closeList(); html.push('<ul>'); list = 'ul'; }
        html.push('<li>' + inline(esc(um[1])) + '</li>');
        continue;
      }
      // 有序列表 1.
      var om = t.match(/^\d+[.)]\s+(.*)$/);
      if (om) {
        closeP();
        if (list !== 'ol') { closeList(); html.push('<ol>'); list = 'ol'; }
        html.push('<li>' + inline(esc(om[1])) + '</li>');
        continue;
      }
      // 普通行 → 段落（连续行合并 <p>，行间软换行 <br/>；行为统一决议 §6.1）
      closeList();
      if (!inP) { html.push('<p>'); inP = true; }
      else html.push('<br/>');
      html.push(inline(esc(t)));
    }
    flush();
    // ③ 还原代码块占位符
    return html.join('').replace(/\u0002B(\d+)\u0002/g, function (m, i) { return blocks[+i]; });
  }

  function renderMarkdown(src, opts) {
    var o = opts || {};
    var s = String(src == null ? '' : src);
    if (!s) return ''; // 空输入返回空串，空态判断由调用方负责（如 opc 报告空态分支保留）
    return mdToHtml(s, o.imgBase || '');
  }
  window.renderMarkdown = renderMarkdown;
})();
