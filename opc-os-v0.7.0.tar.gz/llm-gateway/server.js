'use strict';
// llm-gateway server.js — BYOK transparent gateway v1 core.
//
// Local OpenAI-compatible reverse proxy with:
//   - multi-provider routing (priority + health + default_provider preference)
//   - circuit breaker + automatic failover (403/429/5xx × N → trip → next healthy)
//   - background health probes with cooldown-based recovery
//   - JSONL event log for the transparency page (0825-e) / monitoring (0825-c)
//   - management API + static admin shell (0825-i): /admin/*
//     (Bearer GATEWAY_ADMIN_TOKEN; config changes persist atomically to
//     gateway.config.json and hot-apply without a restart)
//
// Zero runtime dependencies (Node built-ins only). Secrets come from the
// environment / existing secrets file — never from gateway.config.json.
//
// Env:
//   GATEWAY_CONFIG        path to gateway.config.json (default: ./gateway.config.json)
//   GATEWAY_ENV_FILE      path to a KEY=VALUE secrets file to preload (optional;
//                         recommend a gateway-dedicated file, e.g.
//                         ~/.hermes/opc/llm-gateway/gateway.env, NOT the Hermes
//                         ~/.hermes/.env — 0825-init-2 decoupling; values never
//                         written back)
//   GATEWAY_ADMIN_TOKEN   Bearer token required by every /admin/* endpoint
//                         (loaded from the env file above if set there; empty → 401)
//   GATEWAY_CLIENT_TOKEN  Bearer token required by every /v1/* endpoint
//                         (loaded from the env file above if set there; when
//                         unset the /v1/* proxy is open — customer containers
//                         without a client token keep working unchanged)
//   GATEWAY_HOST          listen-address override (customer container form binds
//                         0.0.0.0 inside the compose network; host maps
//                         127.0.0.1:18080 so it stays loopback-only externally).
//                         Default: config host (127.0.0.1) — OPC local production
//                         runs without this env → zero behavior change.

const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const GATEWAY_DIR = __dirname;

// ---- env-file bootstrap (existing secrets mechanism, no new plaintext copies) ----
const envFile = process.env.GATEWAY_ENV_FILE;
if (envFile) {
  try {
    const raw = fs.readFileSync(envFile, 'utf8');
    for (const line of raw.split(/\r?\n/)) {
      const t = line.trim();
      if (!t || t.startsWith('#')) continue;
      const eq = t.indexOf('=');
      if (eq <= 0) continue;
      const k = t.slice(0, eq).trim();
      let v = t.slice(eq + 1).trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      if (k && !(k in process.env)) process.env[k] = v;
    }
  } catch (e) {
    console.error(`[llm-gateway] WARN cannot load env file ${envFile}: ${e.message}`);
  }
}

const cfgPath = process.env.GATEWAY_CONFIG || path.join(GATEWAY_DIR, 'gateway.config.json');
const config = require('./lib/config').load(cfgPath);
// GATEWAY_HOST env override (customer container form: bind 0.0.0.0 inside the
// compose network so the host 127.0.0.1:18080 mapping works and a future
// hermes-worker container can reach it via the gateway:18080 alias). When
// unset, the config value (default 127.0.0.1) is used unchanged — OPC local
// production runs without this env, zero behavior change.
if (process.env.GATEWAY_HOST) {
  config.host = process.env.GATEWAY_HOST;
}
const events = require('./lib/events').create(config);
const providers = require('./lib/providers').create(config, events);
const router = require('./lib/router').create(config, providers);
const VERSION = '1.7.0';
const startedAt = Date.now();
const statusRef = { lastProvider: null, startedAt };
const forward = require('./lib/forward').create(config, providers, router, events, statusRef);
const health = require('./lib/health').create(config, providers, events);

// 0826-gw-1: config memory↔disk sync tracking. disk_mtime_ms is the mtime of
// the config file at the last successful load/reload/admin-write; /admin/status
// compares it against the live file mtime to expose drift, and the fs.watch
// hot-reload below keeps the two in lockstep. watch flips to 'off' when
// fs.watch is unavailable (inotify limits etc.) — edits then need a restart.
const configSync = {
  watch: 'off',
  disk_mtime_ms: null,
  last_load_at: new Date().toISOString(),
  last_reload_at: null,
  last_error: null,
};
try { configSync.disk_mtime_ms = fs.statSync(cfgPath).mtimeMs; } catch (e) { /* config exists (just loaded above) */ }

const admin = require('./lib/admin').create({
  config,
  providers,
  events,
  statusRef,
  configPath: cfgPath,
  gatewayDir: GATEWAY_DIR,
  startedAt,
  version: VERSION,
  configSync,
});

function buildStatus() {
  const snap = providers.snapshot(config);
  // 0826-gw-3: 持久熔断（degraded）provider 摘要——per-provider degraded 字段在
  // snapshot 内，此处汇总便于监控/人一眼可见。
  const degradedProviders = Object.keys(snap).filter((n) => snap[n].degraded === true);
  return {
    gateway: 'llm-gateway',
    version: VERSION,
    ts: new Date().toISOString(),
    uptime_s: Math.round((Date.now() - startedAt) / 1000),
    current_provider: statusRef.lastProvider || null,
    default_provider: config.default_provider || null,
    degraded_providers: degradedProviders,
    providers: snap,
    events_file: events.file,
  };
}

function sendJson(res, status, obj) {
  const buf = Buffer.from(JSON.stringify(obj, null, 2), 'utf8');
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': buf.length });
  res.end(buf);
}

// --- admin panel static assets (0825-j): whitelisted extensions, traversal-safe ---
// The admin UI ships inside the deployment package (admin/index.html + ui.js +
// ui.css + locales/*.json) and is served by the gateway itself, so a customer
// deployment gets the whole panel at <host>:<port>/admin with zero extra setup.
const ADMIN_DIR = path.join(GATEWAY_DIR, 'admin');
const STATIC_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

// Map an /admin/* GET path to a file inside ADMIN_DIR, or null when it is not a
// static asset (admin API paths carry no extension and fall through to admin.js).
function adminStaticFile(reqPath) {
  const rel = reqPath === '/admin' || reqPath === '/admin/' ? 'index.html' : reqPath.slice('/admin/'.length);
  let dec;
  try { dec = decodeURIComponent(rel); } catch (e) { return null; }
  const segs = dec.split('/');
  for (const s of segs) {
    if (s === '' || s === '.' || s === '..') return null; // no empty/traversal segments
  }
  const file = path.join(ADMIN_DIR, ...segs);
  if (file !== ADMIN_DIR && !file.startsWith(ADMIN_DIR + path.sep)) return null;
  if (!STATIC_TYPES[path.extname(file).toLowerCase()]) return null;
  return file;
}

function serveStatic(res, filePath) {
  try {
    const buf = fs.readFileSync(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const type = STATIC_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, { 'content-type': type, 'content-length': buf.length });
    res.end(buf);
  } catch (e) {
    sendJson(res, 404, { error: { message: 'admin page not found', type: 'gateway_not_found' } });
  }
}

// --- request body collector with size cap ---
function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > maxBytes) {
        reject(Object.assign(new Error('request body too large'), { code: 413 }));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const reqPath = req.url.split('?')[0];
  const reqId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

  // --- local control endpoints (no upstream) ---
  if (req.method === 'GET' && (reqPath === '/healthz' || reqPath === '/health')) {
    res.writeHead(200, { 'content-type': 'text/plain' });
    res.end('ok');
    return;
  }
  if (req.method === 'GET' && (reqPath === '/v1/status' || reqPath === '/status')) {
    sendJson(res, 200, buildStatus());
    return;
  }

  // --- management panel (0825-i): static shell page + admin API (0825-j: +assets) ---
  if (req.method === 'GET' && (reqPath === '/admin' || reqPath === '/admin/' || reqPath === '/admin/index.html')) {
    serveStatic(res, path.join(ADMIN_DIR, 'index.html'));
    return;
  }
  if (reqPath.startsWith('/admin/')) {
    // static assets first (ui.js/ui.css/locales/*.json); admin API paths carry no
    // file extension and fall through to admin.handle
    const staticFile = req.method === 'GET' ? adminStaticFile(reqPath) : null;
    if (staticFile) {
      serveStatic(res, staticFile);
      return;
    }
    let adminBody = Buffer.alloc(0);
    if (req.method === 'POST' || req.method === 'PUT' || req.method === 'PATCH') {
      try {
        adminBody = await readBody(req, 64 * 1024);
      } catch (e) {
        sendJson(res, e && e.code === 413 ? 413 : 400, { error: { message: 'failed to read admin body', type: 'gateway_bad_request' } });
        return;
      }
    }
    admin.handle(req, res, reqPath, req.method, adminBody);
    return;
  }

  // --- OpenAI-compatible proxy paths ---
  const proxied =
    (reqPath === '/v1/chat/completions' && req.method === 'POST') ||
    (reqPath === '/v1/embeddings' && req.method === 'POST') ||
    (reqPath === '/v1/models' && req.method === 'GET');

  if (!proxied) {
    sendJson(res, 404, { error: { message: `not found: ${req.method} ${reqPath}`, type: 'gateway_not_found' } });
    return;
  }

  // --- /v1/* client auth (0825-init-2): GATEWAY_CLIENT_TOKEN 设置时校验 Bearer ---
  // 未配置 token → 放行（客户容器无 token 形态零行为变化）；配置后 /v1/* 全部
  // 要求 Bearer <GATEWAY_CLIENT_TOKEN>，Hermes 侧 model.api_key 用同一值。
  const clientToken = process.env.GATEWAY_CLIENT_TOKEN;
  if (clientToken) {
    const m = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '');
    const ok = m && m[1].length === clientToken.length
      && crypto.timingSafeEqual(Buffer.from(m[1]), Buffer.from(clientToken));
    if (!ok) {
      events.emit('error', { provider: 'client-auth', req_id: reqId, note: 'missing/invalid GATEWAY_CLIENT_TOKEN' });
      sendJson(res, 401, { error: { message: 'unauthorized: missing or invalid Bearer token', type: 'gateway_unauthorized' } });
      return;
    }
  }

  if (reqPath === '/v1/models') {
    // 统一模型名清单（0825-init-2）：静态暴露 cfg.unified_model（默认
    // hermes-opc-v1），不透传上游 provider 的模型列表。
    // 0827-gw-route: 额外暴露首选 provider 的 context_window（配置了才返回；
    // 未配置 → 无该字段，向后兼容）。首选 = router.candidates(unified)[0]
    // （health-aware：default_provider 熔断时它是 priority 兜底，值跟随实际落点）。
    const modelId = config.unified_model || 'hermes-opc-v1';
    const entry = {
      id: modelId,
      object: 'model',
      created: Math.floor(startedAt / 1000),
      owned_by: 'opc',
    };
    const candidates = router.candidates(modelId);
    if (candidates.length > 0 && candidates[0].context_window != null) {
      entry.context_window = candidates[0].context_window;
    }
    sendJson(res, 200, {
      object: 'list',
      data: [entry],
    });
    return;
  }

  // POST chat/embeddings
  let bodyBuf;
  try {
    bodyBuf = await readBody(req, config.max_body_bytes);
  } catch (e) {
    if (e && e.code === 413) {
      sendJson(res, 413, { error: { message: 'request body too large', type: 'gateway_body_too_large' } });
    } else {
      sendJson(res, 400, { error: { message: 'failed to read request body', type: 'gateway_bad_request' } });
    }
    return;
  }

  let model = null;
  let stream = false;
  try {
    const parsed = JSON.parse(bodyBuf.toString('utf8') || '{}');
    model = parsed.model || null;
    stream = parsed.stream === true;
  } catch (e) {
    sendJson(res, 400, { error: { message: 'invalid JSON body', type: 'gateway_bad_request' } });
    return;
  }

  forward.forward(reqPath, req.headers, bodyBuf, model, stream, req, res, reqId, 'POST');
});

server.on('clientError', (err, socket) => {
  if (socket.writable) {
    socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
  }
});

// ---- config file watch → hot reload (0826-gw-1) ----
// Watch the DIRECTORY, not the file: editors rename-replace config files and
// an inotify watch on the old inode would silently detach. Debounced so a
// burst of events (change/rename) or an in-place writer's transient truncation
// resolves to one reload of a complete file. A reload failure (invalid JSON /
// validation) keeps the previous in-memory config and only logs a WARN — a bad
// edit must never take the gateway down. When fs.watch itself is unavailable
// (inotify limits, etc.) we degrade to no watch + WARN: /admin/status then
// reports config_sync=false with watch:'off' so the drift stays visible.
let configReloadTimer = null;
let configWatcher = null;

function scheduleConfigReload(trigger) {
  if (configReloadTimer) clearTimeout(configReloadTimer);
  configReloadTimer = setTimeout(() => {
    configReloadTimer = null;
    try {
      admin.reloadFromDisk(trigger);
      console.log(`[llm-gateway] config hot-reloaded (${trigger})`);
    } catch (e) {
      configSync.last_error = e.message;
      configSync.last_error_at = new Date().toISOString();
      console.error(`[llm-gateway] WARN config reload failed, keeping previous config: ${e.message}`);
    }
  }, 250);
}

function startConfigWatch() {
  try {
    configWatcher = fs.watch(path.dirname(cfgPath), (eventType, filename) => {
      if (filename && filename !== path.basename(cfgPath)) return;
      scheduleConfigReload(`fs.watch ${eventType}${filename ? ' ' + filename : ''}`);
    });
  } catch (e) {
    configSync.watch = 'off';
    configSync.last_error = `config watch failed: ${e.message}`;
    console.error(`[llm-gateway] WARN config watch unavailable (${e.message}); edits to ${cfgPath} require a restart to take effect`);
    return;
  }
  configWatcher.on('error', (e) => {
    configSync.watch = 'off';
    configSync.last_error = `config watch error: ${e.message}`;
    console.error(`[llm-gateway] WARN config watch error (${e.message}); edits to ${cfgPath} require a restart to take effect`);
    try { configWatcher && configWatcher.close(); } catch (e2) { /* noop */ }
  });
  configSync.watch = 'on';
  console.log(`[llm-gateway] watching ${cfgPath} for changes (hot reload)`);
}

server.listen(config.port, config.host, () => {
  events.emit('startup', {
    version: VERSION,
    host: config.host,
    port: config.port,
    providers: config.providers.map((p) => `${p.name}@${p.priority}`),
    circuit: config.circuit,
    note: 'gateway started',
  });
  health.start();
  startConfigWatch();
  console.log(`[llm-gateway] v${VERSION} listening on http://${config.host}:${config.port}`);
  console.log(`[llm-gateway] providers: ${config.providers.map((p) => p.name).join(', ')}`);
  console.log(`[llm-gateway] events: ${events.file}`);
});

function shutdown(sig) {
  console.log(`[llm-gateway] ${sig} received, shutting down`);
  health.stop();
  if (configReloadTimer) clearTimeout(configReloadTimer);
  if (configWatcher) { try { configWatcher.close(); } catch (e) { /* noop */ } }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
