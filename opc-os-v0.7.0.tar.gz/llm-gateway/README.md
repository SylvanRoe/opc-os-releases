# llm-gateway — BYOK 透明 LLM 网关 v1（核心）

本地 OpenAI 兼容反向代理，解决 Hermes 单点 provider / fallback 在商用场景不可靠的问题（2026-08-25 实战：kimi 429/403 停摆）。
OPC 自建 BYOK fallback 透明网关：**一处熔断切换，全局生效**。零运行时依赖（Node 内置模块）。

## 架构

```
Hermes 各 profile (base_url → 网关, 0825-d 接入)
        │  POST /v1/chat/completions | /v1/embeddings | GET /v1/models
        ▼
┌─────────────────── llm-gateway (127.0.0.1:18080, pm2 常驻) ───────────────────┐
│  server.js  HTTP 入口                                                          │
│   ├─ router.js     按 model 匹配 + 优先级 + 健康状态 + default_provider 选候选  │
│   ├─ forward.js    转发到真实 provider，响应原样回传（SSE 流式逐字节透传）；    │
│   │                403/429/5xx/网络错 → 计数 → 自动切换下一个健康 provider      │
│   ├─ providers.js  每 provider 熔断状态机 healthy→open→(冷却后探测)→healthy     │
│   ├─ health.js     定时 ping 各 provider（GET /v1/models），冷却期后试探恢复     │
│   ├─ admin.js      管理 API（0825-i）：/admin/*，Bearer token，配置原子写+热生效 │
│   └─ events.js     JSONL 事件日志（trip/recover/failover/request/probe/admin_*）│
└──────────────────────────────────────────────────────────────────────────────┘
        │                                   │
        ▼                                   ▼
  真实 provider 池                     events/events.jsonl
  deepseek(主) / kimi(备)              供 0825-e 透明度 + 0825-c 监控消费
```

## 目录结构

```
llm-gateway/
├── server.js              入口：HTTP 服务、路由、密钥引导（GATEWAY_ENV_FILE）、/admin 挂载
├── gateway.config.json    provider 池 / 熔断阈值 / 端口 / 月度预算（不含任何密钥）
├── ecosystem.config.js    pm2 常驻定义（SOP=anran ops-service-protection，禁裸进程）
├── package.json
├── lib/
│   ├── config.js          配置加载 + 校验（normalize 供管理 API 复用）
│   ├── providers.js       熔断状态机（trip/recover/probe/reconcile）
│   ├── router.js          provider 候选排序（default_provider 优先、enabled 过滤）
│   ├── forward.js         上游转发 + SSE 透传 + 失败自动切换
│   ├── health.js          健康探测循环（跳过 disabled provider）
│   ├── admin.js           管理 API + 鉴权中间件 + 配置原子写/回滚 + 热生效（0825-i）
│   └── events.js          JSONL 事件日志（按大小轮转）
├── admin/                管理面板（0825-j 完整 UI）：index.html + ui.js/ui.css（官网设计系统
│   │                     公共组件副本）+ locales/*.json（i18n 12 语言包，nav + admin 命名空间）；
│   │                     静态资源由网关自身伺服（/admin/ui.js 等，白名单扩展名 + 路径穿越防护）
│   └── locales/           12 语言包：zh/en/ja/ko/fr/de/ar/ru/es/tr/pl/pt（键结构与 zh.json 一致）
├── events/                运行期事件日志（自动创建）
└── tests/                 node:test 集成测试（含 fake provider 熔断演练 + 管理端点测试）
```

## 配置（gateway.config.json）

> `GATEWAY_HOST` 环境变量可覆盖 `host`（0825-init）：容器部署（customer 形态
> docker-compose llm-gateway 服务）设 `GATEWAY_HOST=0.0.0.0`（容器内全接口监听，
> 端口映射 `127.0.0.1:18080:18080` 仅暴露宿主回环）；未设置时用 config 值
> （默认 `127.0.0.1`）——OPC 本机生产（pm2 直跑）零行为变化。

```jsonc
{
  "host": "127.0.0.1",
  "port": 18080,
  "max_body_bytes": 10485760,          // 请求体上限
  "upstream_timeout_ms": 120000,       // 单次上游超时
  "monthly_budget_usd": 300,           // 月度预算红线（0825-i；deepseek 定稿建议 300）
  "default_provider": null,            // 可选：指定默认 provider（管理 API 可切换；健康时置 unified 路径 healthy 组首位——0826-gw-2 自愈核心；熔断/未设/不在池 → 纯 priority 兜底）
  "unified_model": "hermes-opc-v1",    // 统一模型名（0825-init-2）：/v1/models 唯一暴露；该模型名的请求按 priority 路由（default_provider 健康时置首，0826-gw-2）
  "providers": [
    {
      "name": "deepseek",              // 唯一标识
      "priority": 1,                   // 数字越小越优先（default_provider 健康时置首；熔断/未设则按 priority）
      "base_url": "https://api.deepseek.com/v1",   // 兼容 OpenAI /v1 约定
      "api_key_env": "DEEPSEEK_API_KEY",           // ★ 只写环境变量名，不写密钥
      "models": ["deepseek-v4-flash", "deepseek-v4-flash-vision-exp"],  // 空=服务所有
      "enabled": true                  // 可选：false=停用（路由/健康探测均跳过）
    }
  ],
  "circuit": { "failure_threshold": 3, "cooldown_s": 60 },
  "health":  { "probe_interval_s": 30, "probe_timeout_ms": 10000 },
  "events":  { "dir": "events", "max_bytes": 52428800 },
  "monitor_config": "monitor/monitor.config.json"  // 可选：余额/用量数据源配置（相对本目录）
}
```

> 红线段（全卡遵守）：**config.yaml 一律不碰**；配置改动只走 gateway.config.json / monitor.config.json；
> 不依赖 Hermes 单点 fallback；任何层面不落明文 key（UI/API/日志）。

## 密钥管理（不落盘明文）

- `gateway.config.json` 只存 `api_key_env`（环境变量名）。
- 启动时通过 `GATEWAY_ENV_FILE` 预载独立 secrets 文件（**0825-init-2**：生产改为
  `/home/gavin/.hermes/opc/llm-gateway/gateway.env`，chmod 600，**不再引用**
  `~/.hermes/.env`——网关与 Hermes 主配置解耦；客户容器形态指向 `/data/llm.env`）。
- 网关自有 token（`GATEWAY_CLIENT_TOKEN` / `GATEWAY_ADMIN_TOKEN`）同样只在 env 文件
  与进程环境里，不落 gateway.config.json / 事件日志 / 管理 API 响应。
- 客户端 Authorization 头**不会**透传上游——网关用自己的 provider key 注入。
  （测试已验证：客户端传 `Bearer client-secret-key`，上游只看到网关自己的 key。）

## 统一模型名 hermes-opc-v1（0825-init-2）

- `/v1/models` **静态清单**：只返回 `{"id":"hermes-opc-v1"}`（+ `unified_model` 配置项
  可改名），**不再透传上游 provider 的模型列表**（kimi-k3 / deepseek-v4-flash 等不暴露）。
- **priority 路由 + default 自愈**：`model=hermes-opc-v1`（或 `model=null`）的请求走
  全启用池按 priority 候选（eyuai→kimi→deepseek→openrouter）；`default_provider`
  健康时置 healthy 组首位（0826-gw-2 自愈核心——运维可经 admin API 引流，default
  熔断/未设/不在池/被禁则按 priority 自然兜底），切换全在网关内部，不依赖客户端
  fallback。显式具体模型名（如 `kimi-k3`）走 serving 过滤 + 同一 default 置首语义。
- **上游 model 改写**：别名请求转发到实际 provider 时 body.model 改写为该 provider
  的 `models[0]`（上游不认识 hermes-opc-v1）；事件日志仍记原始请求模型。
- **客户端鉴权**：`GATEWAY_CLIENT_TOKEN` 设置后 `/v1/*` 全部要求
  `Authorization: Bearer <token>`；未设置 → 放行（客户容器无 token 形态零变化）。
  客户端（Hermes profile）`model.api_key` 用同一值。

## 启动 / 守护（pm2）

```bash
# 生产（OPC 本机，pm2 常驻，禁裸进程）
cd /home/gavin/.hermes/opc/llm-gateway
PM2_HOME=/home/gavin/.pm2 pm2 start ecosystem.config.js   # 已执行，pm2 list 可见 llm-gateway
PM2_HOME=/home/gavin/.pm2 pm2 save                         # 已执行，纳入开机恢复

# 前台调试
node server.js                                             # 或 GATEWAY_CONFIG=xx node server.js

# 测试
npm test                                                     # 50 项：熔断/切换/恢复/SSE/密钥隔离 + 管理端点 + 统一模型名路由/鉴权 + 模型健康 + config 同步
```

## 端点

| 端点 | 说明 |
|---|---|
| `POST /v1/chat/completions` | OpenAI 兼容，`stream:true` 时 SSE 逐字节透传；`model=hermes-opc-v1` 按 priority 路由（default 健康置首） |
| `POST /v1/embeddings` | 同路由逻辑 |
| `GET /v1/models` | **静态清单（0825-init-2）：仅 `hermes-opc-v1`**，不透传上游模型列表 |
| `GET /v1/status` | 网关状态：当前 provider、default_provider、各 provider 健康/熔断/探测时间戳/请求数 |
| `GET /healthz` | 存活探针（pm2/负载均衡用） |
| `GET /admin` | 管理面板静态页（**0825-j 完整 UI**：登录/仪表盘/provider 切换/阈值/CRUD/BYOK keys；页面公开，API 需 token） |
| `/admin/ui.js` `/admin/ui.css` `/admin/locales/*.json` | 管理面板静态资源（网关伺服，白名单扩展名，路径穿越拒绝） |
| `/admin/*` | 管理 API（见下节；**一律要求 `Authorization: Bearer <GATEW...`**） |

## 熔断与恢复语义

- **触发熔断**：某 provider 连续 `failure_threshold`（默认 3）次 403/429/5xx 或网络错误
  → 状态 `open`（熔断），事件日志写 `trip`。
- **自动切换**：请求在熔断 provider 失败后，自动重试下一个健康 provider，客户端仍然拿到
  成功响应（非流式全程可切；流式仅在首字节到达客户端前可切，一旦开始透传则原样放行）。
- **冷却与恢复**：熔断后等待 `cooldown_s`，之后健康探测（GET /v1/models）每
  `probe_interval_s` 试探一次；成功 → 恢复 `healthy`（事件日志写 `recover`），失败 → 冷却重置。
- **探测非惩罚性**：健康 provider 的探测失败只记录，不计数熔断（防 /models 权限差异误伤）；
  只有真实流量的 403/429/5xx 驱动熔断。
- **全熔断兜底**：所有 provider 都熔断时按优先级 fail-open 试最高优先级 provider，
  全部失败则回传最后一次上游错误（502 兜底）。

## 事件日志（events/events.jsonl）

每行一个 JSON，供 0825-e 透明度展示 / 0825-c 监控消费（口径以本文件路径为准）：

```jsonl
{"ts":"...","seq":1,"type":"startup","version":"1.0.0","port":18080,"providers":["deepseek@1","kimi@2"],"note":"gateway started"}
{"ts":"...","seq":2,"type":"request","provider":"deepseek","model":"deepseek-v4-flash","stream":false,"status":200,"latency_ms":852,"req_id":"..."}
{"ts":"...","seq":3,"type":"trip","provider":"kimi","status":403,"failures":3,"note":"consecutive failure threshold reached"}
{"ts":"...","seq":4,"type":"failover","from":"kimi","provider":"deepseek","model":"deepseek-v4-flash","status":403,"req_id":"..."}
{"ts":"...","seq":5,"type":"recover","provider":"kimi","note":"probe ok"}
{"ts":"...","seq":6,"type":"probe_fail","provider":"kimi","status":403,"note":"probe failed, cooldown restarted"}
```

type：`startup / request / trip / failover / recover / probe_fail / upstream_error / error / rotate / admin_*`

**probe_fail 为 edge-triggered（0827-gw-edge）**：仅当某 (provider, model) 的探测结果
从「非失败」翻转到「失败」时写一条（含重启后首次失败），连续失败期间静默，恢复翻转由
`recover` / `model_recover` 承担。完整探测明细以 `/admin/status` 的 `last_probe` 为准
（每次探测都记录），事件日志是翻转视图——稳态不再按探测周期刷盘。

管理变更事件（0825-i）示例——每次管理操作必留痕，`operator` 是 admin token 的 **env 变量名**（`GATEWAY_ADMIN_TOKEN`），绝不落 token 值：

```jsonl
{"ts":"...","seq":100,"type":"admin_set_default_provider","operator":"GATEWAY_ADMIN_TOKEN","action":"set_default_provider","target":"kimi","from":"deepseek","note":"default provider changed via admin API"}
{"ts":"...","seq":101,"type":"admin_update_thresholds","operator":"GATEWAY_ADMIN_TOKEN","action":"update_thresholds","target":"circuit/health/monthly_budget/balance","detail":{"circuit":{"failure_threshold":5,"cooldown_s":60},"monthly_budget_usd":300,"balance":null}}
{"ts":"...","seq":102,"type":"admin_provider_create","operator":"GATEWAY_ADMIN_TOKEN","action":"provider_create","target":"glm","detail":{"base_url":"https://...","api_key_env":"GLM_API_KEY","priority":9,"enabled":true}}
{"ts":"...","seq":103,"type":"admin_provider_update","operator":"GATEWAY_ADMIN_TOKEN","action":"provider_update","target":"glm","detail":{...}}
{"ts":"...","seq":104,"type":"admin_provider_delete","operator":"GATEWAY_ADMIN_TOKEN","action":"provider_delete","target":"glm"}
```

0825-e 透明展示只读消费原生命周期类型，`admin_*` 被自然忽略（回归已验证），互不影响。

## 管理面板与管理 API（0825-i）

客户级部署包内置部分：**一个进程 + 一个页面**。网关服务自带管理端点，管理面板静态页由
网关伺服（`GET /admin`），客户部署后访问 `<host>:<port>/admin`。

> 与透明办公室的关系：**不是透明办公室的一部分**。0825-e 的展示 tab 是 OPC 自用监控展示
> （`/api/opc/llm-gateway.json` 只读消费 events.jsonl + usage_state.json），保持现状不动。

### 鉴权

- 所有 `/admin/*` 端点一律要求 `Authorization: Bearer <GATEWAY_ADMIN_TOKEN>`；无 / 错 token → `401`。
- **GATEWAY_ADMIN_TOKEN 只从环境注入，不落任何配置文件**。两种注入方式：
  1. 在 `GATEWAY_ENV_FILE` 指向的 secrets 文件（生产：`/home/gavin/.hermes/opc/llm-gateway/gateway.env`，
     chmod 600；客户容器：`/data/llm.env`）加一行
     `GATEWAY_ADMIN_TOKEN=<值>`（推荐——pm2 的 shell env 不持久，env 文件随进程预载）；
  2. 手动 `export GATEWAY_ADMIN_TOKEN=<值>` 后启动。
- **env 变量未配置（空）→ 所有管理端点一律 401**（面板不可管理，但数据面不受影响）。
- UI 登录页：token 存 **sessionStorage**（会话级：刷新免重登，关浏览器失效；key 约定 `gateway_admin_token`）。

### 端点

| 端点 | 说明 |
|---|---|
| `GET /admin/status` | 池全量：各 provider 健康/余额/用量/阈值、熔断参数、月度预算、切换历史（复用 monitor usage_state.json + events.jsonl） |
| `PUT /admin/provider/default` | body `{name}` 切换/指定默认 provider（写 `gateway.config.json` 的 `default_provider`；不存在/已停用 → 400） |
| `PUT /admin/thresholds` | body `{circuit?, health?, monthly_budget_usd?, balance?}`：熔断（连续失败数/冷却秒/探测秒）+ 余额告警（`balance.<provider>.{warn,critical}`，写 monitor.config.json）+ 月度预算红线（`monthly_budget_usd`，deepseek 建议 300）；越界/类型错 → 400 且配置不变 |
| `POST /admin/providers` | 新增 provider `{name, base_url, model(s), api_key_env, priority, enabled?, thresholds?}`；重名 → 409 |
| `PUT /admin/providers/:name` | 更新 provider（部分字段）；不存在 → 404 |
| `DELETE /admin/providers/:name` | 删除 provider；最后一个 → 400；若删的是默认 provider 则 `default_provider` 一并清除 |
| `GET /admin/keys` | BYOK key 接入清单：只返回状态（env 变量名、是否已配置、健康/余额/用量、最近检查时间）——**永不返回 key 明文**；key 的新增/更新只接受 env 变量名引用（值仍走既有 secrets 文件） |

### 配置持久化与热生效（无重启）

- 每次管理变更**原子写** `gateway.config.json`（先备份 `gateway.config.json.bak` 再写，写失败从备份回滚，
  响应 500 且配置未变）；balance 阈值同步原子写 `monitor.config.json`。
- 变更后**立即热生效**：共享 config 对象原地更新 + provider 熔断状态表 reconcile，
  无需重启进程（已实测：改 `failure_threshold` 后 `/admin/status` 即时反映，进程 uptime 连续）。
- 每次管理变更写 `events.jsonl` 留痕（`type=admin_*`，含 operator token 名/动作/目标/ts/seq，
  见上节）。

### 管理面板 URL（0825-j 完整 UI）

- 本机生产：`http://127.0.0.1:18080/admin`（pm2 进程自带；静态页 + 静态资源均由网关伺服，客户零额外配置）
- 客户部署：`<host>:<port>/admin`（`port` 由 gateway.config.json 决定，默认 18080）

**登录**：输入 `GATEWAY_ADMIN_TOKEN` → `sessionStorage`（key `gateway_admin_token`）——
刷新免重登、关浏览器失效；任何 401 自动清 token 回登录页。**env 未配置（空）→ 所有管理端点 401**，
面板不可管理但数据面不受影响。

**功能**（与 /admin/* 端点一一对应）：
1. 登录页：token 输入（掩码）；401 = 回登录页
2. 仪表盘：当前 provider、默认 provider、运行时长、月度预算 KPI；池全量表（健康/余额/用量/阈值）；切换历史时间线（`/admin/status`，同 0825-e 口径）
3. 默认 provider 切换：下拉 → `PUT /admin/provider/default`，保存后仪表盘即时反映
4. 阈值设置：熔断（连续失败次数/冷却秒/探测秒）+ 余额告警（warn/critical，写 monitor.config.json）+ 月度预算红线（`monthly_budget_usd`）→ `PUT /admin/thresholds`，保存后展示「已生效」状态
5. provider 池 CRUD：表格增删改查（name/base_url/models/api_key_env/priority/enabled）→ POST/PUT/DELETE `/admin/providers`；删除走**页内自定义确认弹窗**（禁原生 confirm）
6. BYOK key 清单：只显示 env 变量名/已配置/健康/余额/用量/最近检查——**明文 key 永不显示、永不回显**；新增 key 只填 env 变量名（值写入 `GATEWAY_ENV_FILE` 指向的 secrets 文件）

**样式规范**：复用官网设计系统（`admin/ui.js` / `admin/ui.css` 为公共组件冻结副本，升级时从
company-site 复制覆盖）——明暗主题、i18n 12 语言包（`nav` + `admin` 命名空间，键结构同 zh.json）、
ar RTL、零硬编码中文（全部走 dict + 内联 zh 兜底）、零原生弹窗；localStorage 偏好 key 与官网同 key
（`site-lang-v2` / `gavinlab-theme-v2`），不新增偏好 key。

**与透明办公室的边界**：管理面板是网关部署包内置的独立页面（`/admin`），**不是透明办公室的一部分**。
0825-e 的透明展示 tab（`/api/opc/llm-gateway.json` 只读消费 events.jsonl + usage_state.json）保持现状，
不调用、不依赖、不被本面板影响；本面板也只调 0825-i 管理端点，不直连任何 provider API。

## 模型接入官网配置纪律（Gavin 0827 铁律）

**铁律**：网关接入的每一个模型，其上下文长度 / 最大输出 / 思考模式等参数，**一律以对应模型官网的官方数据为唯一事实源**。禁止凭记忆、凭口头、凭旧版（如 deepseek 128K）配置。配置留痕须注明来源（官网页 / 日期）。

**DeepSeek V4 系（官网 V4 API，2026-04-24 发布）**：

| 参数 | 官方值 |
|---|---|
| 上下文长度 | **1M tokens** |
| 最大输出 | **384K tokens** |
| 思考模式 | **默认开启**（可设 reasoning_effort high/max） |
| API 兼容 | OpenAI + Anthropic 两格式 |

**关键坑与落实（deepseek-v4-flash-vision-exp）**：
1. **思考模型必须 max_tokens 给足**：思考（reasoning）tokens 计入 max_tokens。max_tokens 太小 → 思考占满输出上限 → **空回复**（实测 max_tokens=20 即空）。给足在调用方（Hermes model 配置 `max_tokens`，参考 16384）。
2. **unified_model 选模型规则**：对 `hermes-opc-v1` 统一模型名请求，路由层用 `providers.selectModel` 挑该 provider **第一个健康**声明模型。**要让 OPC 成员走到 vision-exp，必须把 `deepseek-v4-flash-vision-exp` 排在 deepseek provider 的 `models[]` 首位**（否则落到 deepseek-v4-flash 文本版）。
3. **网关层不设容器上限**：llm-gateway 转发是 verbatim 透传（仅改写 model 字段），不覆写/不设 max_tokens、context。因此 context_length（1M）与 max_tokens 在**调用方**（Hermes 各 profile config.yaml 的 `model.context_length` / `model.max_tokens`）配置，网关透传给上游。
4. **1M 上下文**：Hermes model 配置 `context_length: 1000000`；否则未收录 catalog 的模型（如 hermes-opc-v1）探测不到上下文窗口，回退旧默认（128K）白白浪费能力。
5. **校验**：`curl /v1/status` 确认 default_provider 与目标 provider 健康；端到端 chat 确认响应 `model` 字段 == 目标模型 + 200 + 非空 + 长上下文不截断。

其它接入模型（kimi / openrouter 系 / MiniMax 系 / eyuai 系）**逐个查官网**，按上表方法校准，注明来源。

## 模型能力表（官网核验）

> **来源纪律（Gavin 0827 铁律）**：本表每一条目的数值一律取自对应模型**官网官方数据**（`source` 列即核验 URL），禁止凭记忆/凭口头/凭旧值/凭 OpenAI 兼容端点元数据。`verified` 表示「数值+source+核验日期已确认」；`pending` 表示「仅部分字段确认（如仅 context），未确认的字段**不填值**（不伪造），待官网核验后补」。

| 模型 id | context | max_output | 思考 | source（官网） | verified | 状态 |
|---|---|---|---|---|---|---|
| `MiniMax-M2.7` | 204800 | 196608 | always-on | platform.minimax.io | 2026-08-27 | verified |
| `MiniMax-M2.7-highspeed` | 204800 | 196608 | always-on | platform.minimax.io | 2026-08-27 | verified |
| `MiniMax-M3` | 1000000 | 524288 | adaptive | platform.minimax.io, minimax-ai.chat | 2026-08-27 | verified |
| `deepseek-v4-flash` | 1048576 | 393216 | enabled | api-docs.deepseek.com, huggingface.co | 2026-08-27 | verified |
| `deepseek-v4-flash-vision-exp` | 1048576 | 393216 | enabled | api-docs.deepseek.com | 2026-08-27 | verified |
| `deepseek-v4-pro` | 1048576 | 393216 | enabled | api-docs.deepseek.com, huggingface.co | 2026-08-27 | verified |
| `k3` | 1048576 | 1048576 | always-on | platform.kimi.ai, kimi.com | 2026-08-27 | verified |
| `kimi-for-coding` | 262144 | 262144 | always-on | kimi.com, platform.kimi.ai | 2026-08-27 | verified |
| `kimi-for-coding-highspeed` | 262144 | 262144 | always-on | kimi.com, platform.kimi.ai | 2026-08-27 | verified |
| `kimi-k3` | 1048576 | 1048576 | always-on | platform.kimi.ai, kimi.com | 2026-08-27 | verified |
| `cohere/north-mini-code:free` | 256000 | - | - | openrouter.ai | 2026-08-27 | pending |
| `dots-studio/dots-3-note-preview:free` | 512000 | - | - | openrouter.ai | 2026-08-27 | pending |
| `eyuai` | - | - | - | tks.eyuai.com | 2026-08-27 | pending |
| `google/gemma-4-26b-a4b-it:free` | 262144 | - | - | openrouter.ai | 2026-08-27 | pending |
| `google/gemma-4-31b-it:free` | 262144 | - | - | openrouter.ai | 2026-08-27 | pending |
| `gpt-5.5` | 1000000 | - | - | openai.com | 2026-08-27 | pending |
| `grok-4.3` | 1000000 | - | - | docs.x.ai | 2026-08-27 | pending |
| `grok-build-0.1` | 262144 | - | - | docs.x.ai | 2026-08-27 | pending |
| `grok-imagine-image-quality` | - | - | - | docs.x.ai, x.ai | 2026-08-27 | pending |
| `grok-imagine-video` | - | - | - | docs.x.ai | 2026-08-27 | pending |
| `k3-256k` | 262144 | - | always-on | kimi.com | 2026-08-27 | pending |
| `liquid/lfm-2.5-2.6b:free` | 65536 | - | - | openrouter.ai | 2026-08-27 | pending |
| `minimax/minimax-m2.7:free` | 196608 | - | - | openrouter.ai | 2026-08-27 | pending |
| `minimax/minimax-m3:free` | 1048576 | - | - | openrouter.ai | 2026-08-27 | pending |
| `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free` | 256000 | - | - | openrouter.ai | 2026-08-27 | pending |
| `nvidia/nemotron-3-super-120b-a12b:free` | 262144 | - | - | openrouter.ai | 2026-08-27 | pending |
| `nvidia/nemotron-3-ultra-550b-a55b:free` | 1000000 | - | - | openrouter.ai | 2026-08-27 | pending |
| `nvidia/nemotron-3.5-content-safety:free` | 128000 | - | - | openrouter.ai | 2026-08-27 | pending |
| `nvidia/nemotron-3.5-lightning:free` | 1000000 | - | - | openrouter.ai | 2026-08-27 | pending |
| `poolside/laguna-s-2.1:free` | 262144 | - | - | openrouter.ai | 2026-08-27 | pending |
| `poolside/laguna-xs-2.1:free` | 262144 | - | - | openrouter.ai | 2026-08-27 | pending |
| `thinkingmachines/inkling-small:free` | 1048576 | - | - | openrouter.ai | 2026-08-27 | pending |
| `thinkingmachines/inkling:free` | 1048576 | - | - | openrouter.ai | 2026-08-27 | pending |
| `z-ai/glm-5.2:free` | 256000 | - | - | openrouter.ai | 2026-08-27 | pending |

**红线约束**：`provider.models[].context_window` / `max_tokens`（运行时默认值，父卡 `t_e6b210b1` 做）**不得高于**本表 `model_capabilities` 的官方能力值（`context_length` / `max_output`）；`/v1/models` 暴露的 `context_window` = 官方值（deepseek-v4-flash-vision-exp=1000000，Gavin 0827 落点）。

**备注**：
- DeepSeek V4 系 `context=1,048,576`（官网标 1M）；`max_output=393,216`（官网标 384K，勿缩水）；思考默认开，`reasoning_effort` 属 low/high/max；API 兼容 OpenAI + Anthropic + Responses。
- MiniMax M2.x：`context=204,800`（输入+输出合并）；`max_output=196,608`；**思考不可关**（always-on）。M3：`context=1,000,000`；`max_output=524,288`（hard max，官方推荐 131,072）；思考 adaptive（enable_thinking 可关）。
- Kimi K3：`context=1,048,576`；`max_output=1,048,576`（默认 131,072，可调至 1M）；always-on 思考，`reasoning_effort` 属 low/high/max。K2.7 Code（kimi-for-coding / -highspeed）：`context=262,144`；always-on 思考。
- openrouter 系 :free 模型：context 取自 OpenRouter 官方 catalog（openrouter.ai/<org>/<model>），其 max_output / 思考模式官网未单独发布，标 pending。
- eyuai 为聚合别名（tks.eyuai.com），其能力=所代理模型的能力，按所代理模型核，标 pending。

## 变更 provider 池

- **推荐走管理 API**（上节 POST/PUT/DELETE /admin/providers）：校验 → 原子写 → 热生效 → 事件留痕，一步到位。
- 手动改 `gateway.config.json` 后 `pm2 restart llm-gateway --update-env`（仅当无法用 API 时）。
- 新增 provider：配置项里 `api_key_env` 对应的密钥放入既有 secrets 文件（`GATEWAY_ENV_FILE`）即可。

## 更新日志（CHANGELOG）

### 1.6.1 — 0827-gw-config：网关配置「唯一写者 + 拍板戳 CAS + 热重载方向校验」
- **R1 唯一写者**：新增对外入口 CLI `bin/opc-gw-config`（子命令 `set-direction` /
  `set-provider` / `show` / `switch-history`），一切 `gateway.config.json` /
  `monitor.config.json` 变更只能经它走 admin API（`127.0.0.1:18080`，Bearer
  `GATEWAY_ADMIN_TOKEN`）。网关单进程成为唯一文件写者（lib/admin.js 原子写
  tmp+rename+备份回滚），会话/人不再直接碰文件（`writeFileSync(cfgPath)` 库里已清零）。
- **R2 拍板戳 CAS**：配置新增 `directive` 段
  `{seq, direction:{provider,model}, decided_at, decided_by, card_id}`。
  `decided_at` = **拍板决策时刻**（非写入时刻）。`PUT /admin/direction` 写前 CAS：
  incoming `seq` ≤ 当前生效 `seq` → 拒绝（409「旧指令，已拒」+ 打印当前生效方向），
  杜绝「旧指令覆盖新拍板」。`seq` 由 CLI 写入时从当前 `directive.seq`+1 分配；
  首个权威写入作为 seq=1 基线。
- **R3 热重载方向校验（纵深防御）**：`server.js` reload 处理器（server.js fs.watch →
  `admin.reloadFromDisk`）在 apply 前校验「方向是否变化」（default_provider /
  priority / default_model）。方向变化必须带合法且非旧的 `directive`，缺失/非法/旧
  seq → 拒 reload、保留旧配置、WARN + 记 `events.jsonl` 审计
  （`config_reload_rejected`）。手改文件绕过 CLI 改方向会被拒，方向无法被静默翻转；
  只改 enabled/threshold 等非方向改动 → 无需 directive，向后兼容。
- 测试：`npm test` 71/71 全绿（基线 59/59 + 新增 12 项：CLI / directive CAS /
  reload 方向校验各分支）。
- 关联：arch 定审 `2026-08-27-llm-gateway-config-arbitration.md`（R1-R3 由马克 0827
  深夜实施，R4/R5 待 G 卡，0828）。

### 1.7.0 — 0827-gw-write-protect：网关配置并发写保护（W2 写锁 + W3 版本戳 CAS + W4 终态校验）
- 背景：Gavin 0827 P0 事故——多会话并发写生产 `gateway.config.json` 互相覆盖，unified
  请求漂移到错误模型（eyuai 文本版非 vision）。arch 评估卡 `t_bf2cfddd` 定结论并进包
  （报告 `2026-08-27-llm-gateway-concurrent-write-protection.md`），实现卡 `t_d24edd9e`。
- **W2 写锁（单写者判定红线）**：`lib/admin.js` 新增受管写唯一入口 `writeConfigGuarded`，
  一切 `gateway.config.json` 写路径（setDirection / setDefaultProvider / thresholds /
  provider CRUD）统一经它：**O_EXCL 原子创建 `<config>.lock`（写入 PID/时间戳）→
  kill(pid,0) 存活检测 + TTL（60s）陈旧锁回收 → finally 释放**。冲突 = 拒绝 + 409 明确
  报错（返回当前 holder / config_version / 生效方向），**绝不排队**（5ms 级写，争用是病理）。
  零依赖约束下禁原生 flock / shell flock。
- **W3 版本戳 CAS**：配置顶层新增 `version`（受管写 +1 单调）/ `updated_at` / `updated_by`
  （operator，永不写 token 值）；directive 扩展为
  `{seq, direction:{provider,model}, declared_state, decided_at, decided_by, card_id}`。
  写入前 CAS：磁盘 `version` ≠ 调用方 base version → 409「版本冲突」重读重试，绝不静默覆盖。
  `--decided-at`（拍板决策时刻，非写入时刻）从 CLI 必填，缺省拒绝（事故根因：两会话拿
  写文件时刻排序被反转）。`declared_state` = 本次目标终态
  `{default_provider, default_model, max_tokens, context_window}`（来自目标 provider +
  拍板声明，禁硬编码供应商/模型名）。
- **W4 终态校验**：受管写后**重读磁盘**断言 `default_provider` / `default_model` /
  `max_tokens` / `context_window` == `directive.declared_state`；不一致 → ① 从 `.bak`
  回滚 ② opc-alert-bus 告警（source=llm-gateway, type=config_terminal_check_failed,
  fingerprint=llm-gateway:config_terminal_check_failed:YYYY-MM-DD 幂等）③ `events.jsonl`
  审计 `config_terminal_check_failed`。目标终态来自 `declared_state`，代码只做
  「磁盘 == 声明」机械比对。
- **CLI**：`bin/opc-gw-config`（Node）`--decided-at` 改必填、`show` 增
  `config_version` + `declared_state`、写前自动带 `base_version`；新增运维层薄客户端
  `opc-os/scripts/opc-gw-config`（Python，env `GATEWAY_BASE_URL` + `GATEWAY_ADMIN_TOKEN`，
  与 `opc-alert-bus.py` 同层，不碰文件）。网关 `lib/config.js` 三处统一用
  `validateDirective` 校验 directive/version（boot load + admin 写入 + reload）。
- **W6 清理**：生产目录 8 个即兴 `.bak_*`（绕过网关的写者尸体）归档到
  `.backup-0827-gw-bak-archive/`，不留现场。
- 测试：`npm test` 75/75（基线 59 + gw-config 16 + 既有）+ model-capabilities 15 +
  circuit-isolation 12，共计 **102/102 全绿**；新增 W2（活锁 409 / 陈锁回收）、W3
  （decided_at 必填 400 / 版本冲突 409 / version 单调 +1）、W4（终态失败 500 + 回滚 +
  审计）用例。
- 关联：`2026-08-27-llm-gateway-concurrent-write-protection.md`（W1-W6 红线）。

## OPC 生产信息（本机）

- 落点：`/home/gavin/.hermes/opc/llm-gateway/`（0825-b 交付物，与 opc-os 部署包同步）
- 端口：`127.0.0.1:18080`；pm2 名：`llm-gateway`；版本：1.6.0（0825-init-2 + 0826-gw 系列）
- 密钥：独立 env 文件 `gateway.env`（chmod 600，`GATEWAY_ENV_FILE` 指向；含 4 个上游
  provider key + `GATEWAY_ADMIN_TOKEN` + `GATEWAY_CLIENT_TOKEN`）；**不再引用
  `~/.hermes/.env`**（0825-init-2 解耦）。客户端（各 profile）`model.api_key` =
  同一 `GATEWAY_CLIENT_TOKEN`。
- 统一模型名：`hermes-opc-v1`（`/v1/models` 静态清单唯一暴露；路由=全启用池按
  priority：eyuai→kimi→deepseek→openrouter，`default_provider` 健康时置首
  （0826-gw-2 自愈），熔断/未设 → priority 兜底）
- 生产 provider 池：eyuai（priority 1）/ kimi（priority 2，年费 Coding Plan 订阅制——
  Gavin 0825-gov 拍板保留订阅、先用到用完不充值；订阅额度周期性刷新，额度内 403 消失后
  健康探测自动 recover，期间真实请求 403 由既有熔断/探测定时处理，见 monitor/README.md「kimi」节）/
  deepseek（priority 3，充值制）/ openrouter（priority 4）
- 关联卡：0825-b（本卡=网关核心）/ 0825-c（用量/余额监控，消费本事件日志）/
  0825-d（全 profile base_url 接入）/ 0825-e（透明度展示，消费本事件日志 + 0825-c 状态 JSON）/
  0825-i（本卡=管理 API + 配置持久化）/ 0825-j（管理面板 UI，消费本管理 API）/
  0825-l（管理面板端到端验收）/ 0825-k（deepseek $300/月预算红线告警 + kimi 重入池）/
  0825-init-2（本卡=统一模型名 hermes-opc-v1 + 网关独立 env）
- 红线：不动 config.yaml（客户端配置只走官方 `hermes config set`）、不动已切 deepseek 的 cron、
  不依赖 Hermes fallback_providers、无外部付费服务
