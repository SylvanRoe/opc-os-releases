'use strict';
// test-config-sync.js — config memory↔disk sync (0826-gw-1).
//
// Covers the gateway defect where runtime `enabled` state drifted from
// gateway.config.json: config edits only took effect after a restart (or a
// 30-minute monitor read), so admin edits/status disagreed with the file.
//
// Spins up its own isolated instance (ports 18195/18196, temp dir config) so it
// can run in parallel with the other suites under `node --test tests/`.
//
// Coverage (acceptance for 0826-gw-1):
//   1. /admin/status carries config_sync (in_sync at boot) + config_sync_detail
//      with load times and watch state; no stale marks when in sync
//   2. editing gateway.config.json hot-reloads within seconds WITHOUT a restart
//      (enabled toggle round-trip: false → true), config_sync stays true
//   3. setDefaultProvider to an enabled=false provider → clear 400 naming the
//      condition, config file untouched, no admin event, default unchanged
//   4. an invalid config edit never crashes the gateway: old in-memory config
//      keeps serving, drift is visible (config_sync=false, status=invalid,
//      stale marks), and restoring the file auto-recovers to in_sync

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const NODE = process.execPath;
const ADMIN_TOKEN = 'test-config-sync-token-0123456789';

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-gw-cfgsync-'));
const GW_PORT = 18195;
const FAKE_PORT = 18196;
const GW_BASE = `http://127.0.0.1:${GW_PORT}`;
const FAKE_BASE = `http://127.0.0.1:${FAKE_PORT}`;
const CFG_PATH = path.join(TMP, 'gateway.config.json');
const EVENTS_FILE = path.join(TMP, 'events', 'events.jsonl');

const fakeKeyValue = 'dummy-fake-key-value';
const ENV_FILE = process.env.GATEWAY_ENV_FILE || path.join(ROOT, 'gateway.env');

let fakeProc;
let gwProc;
const children = [];

function spawnChild(args, env) {
  const p = spawn(NODE, args, {
    cwd: ROOT,
    env: Object.assign({}, process.env, env),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  children.push(p);
  p.stdout.on('data', (d) => process.stdout.write(`[child] ${d}`));
  p.stderr.on('data', (d) => process.stderr.write(`[child-err] ${d}`));
  return p;
}

async function waitFor(url, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(url);
      if (r.ok) return true;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`timeout waiting for ${url}`);
}

function reqJson(method, url, body, token) {
  return fetch(url, {
    method,
    headers: Object.assign(
      { 'content-type': 'application/json' },
      token ? { authorization: `Bearer ${token}` } : {}
    ),
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}
const get = (url, t) => reqJson('GET', url, undefined, t);
const put = (url, b, t) => reqJson('PUT', url, b, t);

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}
function readEvents() {
  try {
    return fs.readFileSync(EVENTS_FILE, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  } catch (e) {
    return [];
  }
}

async function adminStatus() {
  const r = await get(`${GW_BASE}/admin/status`, ADMIN_TOKEN);
  assert.equal(r.status, 200, 'admin/status reachable');
  return r.json();
}

// poll /admin/status until `pred` holds (the fs.watch hot-reload is debounced
// ~250ms; give the pipeline up to 8s) — throws with the last sync detail.
async function waitForReload(pred, label, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  let last;
  while (Date.now() < deadline) {
    last = await adminStatus();
    if (pred(last)) return last;
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error(`timeout waiting for ${label}; last config_sync_detail: ${JSON.stringify(last && last.config_sync_detail)}`);
}

function setEnabled(provider, enabled) {
  const cfg = readJson(CFG_PATH);
  cfg.providers.find((p) => p.name === provider).enabled = enabled;
  fs.writeFileSync(CFG_PATH, JSON.stringify(cfg, null, 2) + '\n');
  return cfg;
}

before(async () => {
  const cfg = {
    host: '127.0.0.1',
    port: GW_PORT,
    providers: [
      { name: 'fake', priority: 1, base_url: `http://127.0.0.1:${FAKE_PORT}/v1`, api_key_env: 'FAKE_API_KEY', models: ['test-model'] },
      { name: 'deepseek', priority: 2, base_url: `http://127.0.0.1:${FAKE_PORT}/v1`, api_key_env: 'DEEPSEEK_API_KEY', models: ['test-model'] },
    ],
    circuit: { failure_threshold: 3, cooldown_s: 60 },
    health: { probe_interval_s: 30, probe_timeout_ms: 10000 },
    events: { dir: 'events', max_bytes: 1048576 },
  };
  fs.writeFileSync(CFG_PATH, JSON.stringify(cfg, null, 2) + '\n');

  fakeProc = spawnChild(
    [path.join(__dirname, 'fixtures', 'fake-provider.js')],
    { FAKE_PORT: String(FAKE_PORT), FAKE_MODE: 'ok' }
  );
  await waitFor(`${FAKE_BASE}/__status`);

  gwProc = spawnChild(['server.js'], {
    GATEWAY_CONFIG: CFG_PATH,
    GATEWAY_ENV_FILE: ENV_FILE,
    GATEWAY_ADMIN_TOKEN: ADMIN_TOKEN,
    FAKE_API_KEY: fakeKeyValue,
  });
  await waitFor(`${GW_BASE}/healthz`);
});

after(async () => {
  for (const p of children) {
    try { p.kill('SIGKILL'); } catch (e) { /* noop */ }
  }
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) { /* noop */ }
});

// ---------- 1. boot state ----------
test('config_sync: in_sync at boot, watch on, detail carries load times, no stale marks', async () => {
  const st = await adminStatus();
  assert.equal(st.config_sync, true, 'config_sync boolean true at boot');
  const d = st.config_sync_detail;
  assert.equal(d.status, 'in_sync');
  assert.equal(d.watch, 'on', 'fs.watch active on this platform');
  assert.ok(d.last_load_at && typeof d.last_load_at === 'string', 'last_load_at present');
  assert.equal(d.last_reload_at, null, 'no reload yet before any edit');
  assert.ok(st.providers.fake.stale === undefined, 'no stale mark when in sync');
  assert.ok(st.providers.deepseek.stale === undefined, 'no stale mark when in sync');
});

// ---------- 2. hot reload without restart ----------
test('0826-gw-1: editing gateway.config.json hot-reloads within seconds (enabled toggle round-trip)', async () => {
  // disable deepseek directly on disk — NO restart, NO admin API
  setEnabled('deepseek', false);

  let st = await waitForReload(
    (s) => s.providers.deepseek && s.providers.deepseek.enabled === false && s.config_sync === true,
    'deepseek enabled=false reflected + in_sync'
  );
  assert.ok(st.config_sync_detail.last_reload_at, 'last_reload_at recorded after the file edit');
  assert.ok(st.providers.fake.stale === undefined, 'fake untouched and not stale');
  assert.ok(st.providers.deepseek.stale === undefined, 'no stale mark once reloaded (memory == disk)');

  // re-enable (round-trip back) — same path, must re-sync within seconds
  setEnabled('deepseek', true);
  st = await waitForReload(
    (s) => s.providers.deepseek.enabled === true && s.config_sync === true,
    'deepseek enabled=true restored + in_sync'
  );
  assert.equal(st.providers.deepseek.stale, undefined);
});

// ---------- 3. setDefaultProvider to disabled → clear error, no side effects ----------
test('0826-gw-1: setDefaultProvider to a disabled provider → clear 400, config untouched, no event', async () => {
  setEnabled('deepseek', false);
  await waitForReload((s) => s.providers.deepseek.enabled === false && s.config_sync === true, 'disabled for default test');

  const before = fs.readFileSync(CFG_PATH, 'utf8');
  const evBefore = readEvents().filter((e) => e.type === 'admin_set_default_provider').length;

  const r = await put(`${GW_BASE}/admin/provider/default`, { name: 'deepseek' }, ADMIN_TOKEN);
  assert.equal(r.status, 400, 'disabled provider rejected');
  const j = await r.json();
  assert.match(j.error.message, /disabled/, `error names the disabled condition: ${j.error.message}`);

  // no side effects: file untouched, no admin event, default unchanged
  assert.equal(fs.readFileSync(CFG_PATH, 'utf8'), before, 'config file untouched after failed default set');
  const evAfter = readEvents().filter((e) => e.type === 'admin_set_default_provider').length;
  assert.equal(evAfter, evBefore, 'no admin_set_default_provider event emitted');
  const st = await adminStatus();
  assert.equal(st.default_provider, null, 'default_provider unchanged');

  // restore
  setEnabled('deepseek', true);
  await waitForReload((s) => s.providers.deepseek.enabled === true && s.config_sync === true, 're-enabled after default test');
});

// ---------- 4. invalid edit → survive + recover ----------
test('0826-gw-1: invalid config edit → gateway survives on old config, drift visible, auto-recovers after fix', async () => {
  const original = readJson(CFG_PATH);

  fs.writeFileSync(CFG_PATH, '{ this is not valid json !!!\n');

  const st = await waitForReload(
    (s) => s.config_sync === false && s.config_sync_detail.status === 'invalid',
    'invalid config flagged as drift'
  );
  assert.equal(st.providers.deepseek.enabled, true, 'old in-memory config still served after bad edit');
  assert.equal(st.providers.deepseek.stale, true, 'stale marked while disk config unreadable');
  assert.ok(st.config_sync_detail.last_error, 'last_error recorded');

  // the gateway must still be alive (a bad edit never crashes the process)
  const hz = await fetch(`${GW_BASE}/healthz`);
  assert.equal(hz.status, 200, 'healthz still 200 after invalid config edit');

  // restore a valid config → watch picks it up and re-syncs
  fs.writeFileSync(CFG_PATH, JSON.stringify(original, null, 2) + '\n');
  const rec = await waitForReload(
    (s) => s.config_sync === true && s.providers.deepseek.enabled === true,
    'auto-recovery to in_sync after fix'
  );
  assert.equal(rec.config_sync_detail.last_error, null, 'last_error cleared after successful reload');
  assert.equal(rec.providers.deepseek.stale, undefined, 'stale marks cleared after re-sync');
});
