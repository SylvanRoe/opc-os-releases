'use strict';
// test-model-health.js — 0826-gw 探测升级验收：
//   1. 逐模型真实 chat 探测 + 业务错误（200+2056）熔断
//   2. 单模型废 → 单模型跳过（selectModel 选健康模型），provider 不拖垮
//   3. provider 全模型废 → provider open → 路由切其它 provider
//   4. 探测发现业务错误 → 无真实流量也熔断；恢复探测自动 recover
//   5. 显式模型请求跳过「该模型已废」的 provider（fail-open）
//
// 套件 A（probe_interval=3600，探测不干扰流量路径）：
//   fake-a(p1, m-a/m-b) + fake-b(p2, fake-b-model/shared-model) + fake-c(p3, shared-model)
//   默认 provider=fake-c（仅显式模型路径生效）
// 套件 B（probe_interval=3，验证探测熔断/恢复）：
//   fake-p(p1, m-p) + fake-q(p2, m-q)
//
// Run: node --test tests/test-model-health.js  (or `npm test`)

const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const NODE = process.execPath;

const FAKE_A_PORT = 18202;
const FAKE_B_PORT = 18203;
const FAKE_C_PORT = 18207;
const GW_A_PORT = 18201;
const GW_A_BASE = `http://127.0.0.1:${GW_A_PORT}`;
const EVENTS_A = path.join(__dirname, 'events-model-health-a', 'events.jsonl');

const FAKE_P_PORT = 18205;
const FAKE_Q_PORT = 18206;
const GW_P_PORT = 18204;
const GW_P_BASE = `http://127.0.0.1:${GW_P_PORT}`;
const EVENTS_P = path.join(__dirname, 'events-model-health-p', 'events.jsonl');

const children = [];

function spawnChild(args, env) {
  const p = spawn(NODE, args, {
    cwd: ROOT,
    env: Object.assign({}, process.env, env),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  children.push(p);
  p.stdout.on('data', (d) => process.stdout.write(`[child] ${d}`));
  p.stderr.on('data', (d) => process.stderr.write(`[child-err] ${d}`));
  return p;
}

async function waitFor(url, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(url);
      if (r.ok) return true;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`timeout waiting for ${url}`);
}

async function postJson(url, body, headers) {
  const r = await fetch(url, {
    method: 'POST',
    headers: Object.assign({ 'content-type': 'application/json' }, headers || {}),
    body: JSON.stringify(body),
  });
  return r;
}

async function gwStatus(base) {
  return (await (await fetch(`${base}/v1/status`)).json());
}

async function fakeStatus(base) {
  return (await (await fetch(`${base}/__status`)).json());
}

async function setFake(base, ctl) {
  const r = await fetch(`${base}/__control`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(ctl),
  });
  assert.equal(r.status, 200);
}

function waitUntil(fn, timeoutMs = 40000, intervalMs = 500) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeoutMs;
    const loop = async () => {
      try {
        if (await fn()) return resolve(true);
      } catch (e) { /* keep polling */ }
      if (Date.now() > deadline) return reject(new Error('waitUntil timeout'));
      setTimeout(loop, intervalMs);
    };
    loop();
  });
}

function readEvents(file) {
  try {
    return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  } catch (e) {
    return [];
  }
}

// ================================================================ 单元测试

describe('errors.businessFailure 分类', () => {
  const { businessFailure } = require('../lib/errors');

  test('MiniMax 2056 → quota', () => {
    const r = businessFailure({ error: { message: '额度不足，请充值', code: 2056, type: 'oneapi_error' } });
    assert.ok(r);
    assert.equal(r.reason, 'quota');
    assert.equal(r.code, '2056');
  });

  test('账号用量上限（kimi 403 body 文案）→ quota', () => {
    const r = businessFailure({ error: { message: "You've reached your usage limit for this billing cycle. Your quota will be refreshed in the next cycle.", type: 'quota_exceeded' } });
    assert.ok(r);
    assert.equal(r.reason, 'quota');
  });

  test('model disabled / not found → model_unavailable', () => {
    assert.equal(businessFailure({ error: { message: 'model not found: ghost-model' } }).reason, 'model_unavailable');
    assert.equal(businessFailure({ error: { code: 'model_disabled' } }).reason, 'model_unavailable');
    assert.equal(businessFailure({ error: { message: '模型已被禁用' } }).reason, 'model_unavailable');
  });

  test('普通客户端错误 / 正常响应 → null', () => {
    assert.equal(businessFailure({ error: { message: 'invalid request body' } }), null);
    assert.equal(businessFailure({ error: { message: 'messages must be an array' } }), null);
    assert.equal(businessFailure({ choices: [{ message: { content: 'ok' } }] }), null);
    assert.equal(businessFailure(null), null);
    assert.equal(businessFailure({ error: 'plain string error' }), null);
  });
});

describe('providers per-model 状态机', () => {
  const events = { emit: () => {} };
  const cfg = {
    providers: [
      { name: 'p', priority: 1, models: ['a', 'b'] },
      { name: 'q', priority: 2, models: ['q1'] },
    ],
    circuit: { failure_threshold: 3, cooldown_s: 60 },
    unified_model: 'hermes-opc-v1',
  };

  test('单模型业务错误达阈值 → 只熔该模型，provider 与其它模型仍健康', () => {
    const providers = require('../lib/providers').create(JSON.parse(JSON.stringify(cfg)), events);
    for (let i = 0; i < 3; i++) {
      providers.recordFailure('p', 200, 'quota', { model: 'a', code: '2056', business: true });
    }
    assert.equal(providers.isModelHealthy('p', 'a'), false, 'm-a 已熔');
    assert.equal(providers.isModelHealthy('p', 'b'), true, 'm-b 仍健康');
    assert.equal(providers.isHealthy('p'), true, 'provider 不因单模型熔断而 open');
    assert.equal(providers.selectModel(cfg.providers[0], 'hermes-opc-v1'), 'b', 'selectModel 跳过废模型选 b');
  });

  test('全部模型废 → provider open；任一模型恢复 → provider 恢复', () => {
    const providers = require('../lib/providers').create(JSON.parse(JSON.stringify(cfg)), events);
    for (let i = 0; i < 3; i++) {
      providers.recordFailure('p', 200, 'quota', { model: 'a', code: '2056', business: true });
      providers.recordFailure('p', 200, 'quota', { model: 'b', code: '2056', business: true });
    }
    assert.equal(providers.isHealthy('p'), false, '全部模型废 → provider open');
    assert.equal(providers.anyModelHealthy('p'), false);
    const snap = providers.snapshot(cfg);
    assert.equal(snap.p.models_status.a.state, 'open');
    assert.equal(snap.p.models_status.b.state, 'open');

    providers.recordSuccess('p', 'a');
    assert.equal(providers.isModelHealthy('p', 'a'), true, 'm-a 恢复');
    assert.equal(providers.isHealthy('p'), true, '有模型恢复 → provider 恢复');
  });

  test('显式模型路由跳过废模型 provider（fail-open）', () => {
    const cfg2 = {
      providers: [
        { name: 'p', priority: 1, models: ['a', 'b'] },
        { name: 'r', priority: 2, models: ['a'] },
      ],
      circuit: { failure_threshold: 3, cooldown_s: 60 },
      unified_model: 'hermes-opc-v1',
    };
    const providers = require('../lib/providers').create(JSON.parse(JSON.stringify(cfg2)), events);
    const router = require('../lib/router').create(cfg2, providers);
    for (let i = 0; i < 3; i++) {
      providers.recordFailure('p', 200, 'quota', { model: 'a', code: '2056', business: true });
    }
    // 显式模型 a：p 的 a 已废 → 只留 r
    assert.deepEqual(router.candidates('a').map((x) => x.name), ['r']);
    // 统一名：provider 级健康 → p 仍在（内部 selectModel 会选 b）
    assert.deepEqual(router.candidates('hermes-opc-v1').map((x) => x.name), ['p', 'r']);
    // 全部跳过 → fail-open 保留原池；gw-3：provider 级健康分组后 healthy=[p]
    // 非空 → 熔断的 r（其唯一模型 a 已废，provider 级 open）完全移出候选
    providers.recordFailure('r', 200, 'quota', { model: 'a', code: '2056', business: true });
    providers.recordFailure('r', 200, 'quota', { model: 'a', code: '2056', business: true });
    providers.recordFailure('r', 200, 'quota', { model: 'a', code: '2056', business: true });
    assert.deepEqual(router.candidates('a').map((x) => x.name), ['p'], '全废 fail-open → 仅健康 p；r 隔离');
  });
});

// ================================================================ 套件 A：业务错误流量路径

describe('套件A：200+业务错误 → 熔断/单模型跳过/自动切换', () => {
  let fakeA, fakeB, fakeC, gwProc;

  before(async () => {
    try { fs.rmSync(path.dirname(EVENTS_A), { recursive: true, force: true }); } catch (e) { /* noop */ }

    fakeA = spawnChild([path.join(__dirname, 'fixtures', 'fake-provider.js')], { FAKE_PORT: String(FAKE_A_PORT), FAKE_MODE: 'ok' });
    await waitFor(`${`http://127.0.0.1:${FAKE_A_PORT}`}/__status`);
    fakeB = spawnChild([path.join(__dirname, 'fixtures', 'fake-provider.js')], { FAKE_PORT: String(FAKE_B_PORT), FAKE_MODE: 'ok' });
    await waitFor(`${`http://127.0.0.1:${FAKE_B_PORT}`}/__status`);
    fakeC = spawnChild([path.join(__dirname, 'fixtures', 'fake-provider.js')], { FAKE_PORT: String(FAKE_C_PORT), FAKE_MODE: 'ok' });
    await waitFor(`${`http://127.0.0.1:${FAKE_C_PORT}`}/__status`);

    gwProc = spawnChild(['server.js'], {
      GATEWAY_CONFIG: path.join(__dirname, 'gateway.modelhealth.test.json'),
      FAKE_API_KEY: 'dummy',
      // 显式清空继承的 GATEWAY_CLIENT_TOKEN，本套件不走客户端鉴权
      GATEWAY_CLIENT_TOKEN: '',
    });
    await waitFor(`${GW_A_BASE}/healthz`);
  });

  after(async () => {
    for (const p of children) {
      try { p.kill('SIGKILL'); } catch (e) { /* noop */ }
    }
  });

  test('单模型业务错误：当前请求立即 failover 到下一 provider（软降级）', async () => {
    await setFake(`http://127.0.0.1:${FAKE_A_PORT}`, { mode: 'ok', bizModel: 'm-a' });
    const body = { model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }] };
    const r = await postJson(`${GW_A_BASE}/v1/chat/completions`, body);
    assert.equal(r.status, 200);
    const j = await r.json();
    assert.equal(j.choices[0].message.content, 'fake-ok-reply');
    // fake-a 收到的是改写后的 m-a（第一个健康模型），返回业务错误后被跳过
    const stA = await fakeStatus(`http://127.0.0.1:${FAKE_A_PORT}`);
    assert.equal(stA.lastModel, 'm-a', '统一模型改写为 m-a');
    assert.ok(stA.chatRequests >= 1);
    const stB = await fakeStatus(`http://127.0.0.1:${FAKE_B_PORT}`);
    assert.ok(stB.chatRequests >= 1, 'failover 到了 fake-b');
  });

  test('3 次业务错误 → 仅 m-a 熔断（model_trip 事件），m-b 与 provider 仍健康', async () => {
    for (let i = 0; i < 2; i++) {
      const r = await postJson(`${GW_A_BASE}/v1/chat/completions`, { model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }] });
      assert.equal(r.status, 200);
    }
    const st = await gwStatus(GW_A_BASE);
    const ms = st.providers['fake-a'].models_status;
    assert.equal(ms['m-a'].state, 'open', 'm-a 熔断');
    assert.equal(ms['m-a'].consecutive_failures, 3);
    assert.equal(ms['m-b'].state, 'healthy', 'm-b 不受影响');
    assert.equal(st.providers['fake-a'].state, 'healthy', 'provider 不整体熔断');
    const events = readEvents(EVENTS_A);
    assert.ok(events.some((e) => e.type === 'model_trip' && e.provider === 'fake-a' && e.model === 'm-a' && e.status === 200), 'model_trip 事件存在');
    assert.ok(events.some((e) => e.type === 'upstream_error' && e.provider === 'fake-a' && e.note && e.note.includes('business')), '业务错误 upstream_error 事件存在');
  });

  test('m-a 废后 selectModel 自动选 m-b，流量不再碰 m-a（单模型跳过）', async () => {
    const stB0 = (await fakeStatus(`http://127.0.0.1:${FAKE_B_PORT}`)).chatRequests;
    const r = await postJson(`${GW_A_BASE}/v1/chat/completions`, { model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }] });
    assert.equal(r.status, 200);
    const stA = await fakeStatus(`http://127.0.0.1:${FAKE_A_PORT}`);
    assert.equal(stA.lastModel, 'm-b', 'selectModel 改写为 m-b');
    const stB = await fakeStatus(`http://127.0.0.1:${FAKE_B_PORT}`);
    assert.equal(stB.chatRequests, stB0, '不再 failover 到 fake-b（fake-a 直接成功）');
  });

  test('显式模型请求：跳过该模型已废的 provider，直接由其它 provider 服务', async () => {
    // serving shared-model 的是 fake-b(2)/fake-c(3)；default(fake-a) 不服务该模型 →
    // 显式模型路径 default 无操作，按 priority 先打 fake-b（0826-gw-2 语义）
    await setFake(`http://127.0.0.1:${FAKE_B_PORT}`, { mode: 'ok', bizModel: 'shared-model' });
    const body = { model: 'shared-model', messages: [{ role: 'user', content: 'hi' }] };
    for (let i = 0; i < 3; i++) {
      const r = await postJson(`${GW_A_BASE}/v1/chat/completions`, body);
      assert.equal(r.status, 200, `第 ${i + 1} 次仍经 failover 200`);
    }
    const st = await gwStatus(GW_A_BASE);
    assert.equal(st.providers['fake-b'].models_status['shared-model'].state, 'open', 'fake-b 的 shared-model 熔断');
    // fake-b 还声明了 fake-b-model（健康）→ 单模型废不拖垮 provider
    assert.equal(st.providers['fake-b'].state, 'healthy', 'fake-b 有其它健康模型，provider 不整体熔断');

    const stB = await fakeStatus(`http://127.0.0.1:${FAKE_B_PORT}`);
    const b0 = stB.chatRequests;
    const r = await postJson(`${GW_A_BASE}/v1/chat/completions`, body);
    assert.equal(r.status, 200);
    const stB2 = await fakeStatus(`http://127.0.0.1:${FAKE_B_PORT}`);
    assert.equal(stB2.chatRequests, b0, '路由跳过 fake-b（其 shared-model 已废），直接 fake-c');
  });
});

// ================================================================ 套件 B：探测熔断 / 恢复

describe('套件B：逐模型探测 → 业务错误自动熔断 → 恢复', () => {
  let fakeP, fakeQ, gwProc;

  before(async () => {
    try { fs.rmSync(path.dirname(EVENTS_P), { recursive: true, force: true }); } catch (e) { /* noop */ }

    fakeP = spawnChild([path.join(__dirname, 'fixtures', 'fake-provider.js')], { FAKE_PORT: String(FAKE_P_PORT), FAKE_MODE: 'bizfail' });
    await waitFor(`${`http://127.0.0.1:${FAKE_P_PORT}`}/__status`);
    fakeQ = spawnChild([path.join(__dirname, 'fixtures', 'fake-provider.js')], { FAKE_PORT: String(FAKE_Q_PORT), FAKE_MODE: 'ok' });
    await waitFor(`${`http://127.0.0.1:${FAKE_Q_PORT}`}/__status`);

    gwProc = spawnChild(['server.js'], {
      GATEWAY_CONFIG: path.join(__dirname, 'gateway.modelhealth-probe.test.json'),
      FAKE_API_KEY: 'dummy',
      // 显式清空继承的 GATEWAY_CLIENT_TOKEN，本套件不走客户端鉴权
      GATEWAY_CLIENT_TOKEN: '',
    });
    await waitFor(`${GW_P_BASE}/healthz`);
  });

  after(async () => {
    for (const p of children) {
      try { p.kill('SIGKILL'); } catch (e) { /* noop */ }
    }
  });

  test('探测发现业务错误（无真实流量）→ per-model + provider 自动 open', async () => {
    await waitUntil(async () => {
      const st = await gwStatus(GW_P_BASE);
      return st.providers['fake-p'] && st.providers['fake-p'].state === 'open';
    }, 30000, 1000);
    const st = await gwStatus(GW_P_BASE);
    assert.equal(st.providers['fake-p'].models_status['m-p'].state, 'open', 'm-p 探测熔断');
    assert.equal(st.providers['fake-p'].state, 'open', 'provider 全模型废 → open');
    // 探测事件留痕
    const events = readEvents(EVENTS_P);
    assert.ok(events.some((e) => e.type === 'probe_fail' && e.provider === 'fake-p' && e.model === 'm-p'), 'probe_fail 事件存在');
    assert.ok(events.some((e) => e.type === 'model_trip' && e.provider === 'fake-p' && e.model === 'm-p'), 'model_trip（探测触发）事件存在');
  });

  test('open 期间真实流量自动切到 fake-q（真实流量不再命中已废 provider）', async () => {
    const stQ0 = (await fakeStatus(`http://127.0.0.1:${FAKE_Q_PORT}`)).chatRequests;
    const r = await postJson(`${GW_P_BASE}/v1/chat/completions`, { model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }] });
    assert.equal(r.status, 200);
    const stQ = await fakeStatus(`http://127.0.0.1:${FAKE_Q_PORT}`);
    assert.ok(stQ.chatRequests > stQ0, '流量走 fake-q');
    const st = await gwStatus(GW_P_BASE);
    assert.equal(st.current_provider, 'fake-q');
  });

  test('上游恢复 → 探测成功 → provider 自动 recover → 流量回归 priority 1', async () => {
    await setFake(`http://127.0.0.1:${FAKE_P_PORT}`, { mode: 'ok', bizModel: null });
    await waitUntil(async () => {
      const st = await gwStatus(GW_P_BASE);
      return st.providers['fake-p'] && st.providers['fake-p'].state === 'healthy';
    }, 40000, 1000);
    const stP0 = (await fakeStatus(`http://127.0.0.1:${FAKE_P_PORT}`)).chatRequests;
    const r = await postJson(`${GW_P_BASE}/v1/chat/completions`, { model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }] });
    assert.equal(r.status, 200);
    const stP = await fakeStatus(`http://127.0.0.1:${FAKE_P_PORT}`);
    assert.ok(stP.chatRequests > stP0, 'recover 后流量回 fake-p');
    const st = await gwStatus(GW_P_BASE);
    assert.equal(st.providers['fake-p'].models_status['m-p'].state, 'healthy');
    assert.equal(st.providers['fake-p'].models_status['m-p'].last_probe.ok, true, 'm-p last_probe 可见');
  });
});
