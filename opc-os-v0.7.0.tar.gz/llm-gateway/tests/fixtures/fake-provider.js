'use strict';
// fake-provider.js — configurable fake upstream for gateway tests.
// Modes: fail (403), 429, 500, ok, model404, bizfail (200+business error for
// all chat), no_models. Control via POST /__control {"mode": ...}.
// Additional controls:
//   bizModel: with mode=ok, chat requests for THIS model return a 200 +
//             business error body (MiniMax-style 2056) — simulates a single
//             dead model on an otherwise healthy provider.
// Exposes request counters, last Authorization header and last chat body
// model via GET /__status.
//
// Env: FAKE_PORT (default 18081), FAKE_MODE (default "fail").

const http = require('http');

const port = Number(process.env.FAKE_PORT || 18081);
let mode = process.env.FAKE_MODE || 'fail';
let bizModel = null;
let chatRequests = 0;
let modelsRequests = 0;
let lastAuth = null;
let lastModel = null;
let lastMaxTokens = null;

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];

  if (url === '/__control' && req.method === 'POST') {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      try {
        const ctl = JSON.parse(body);
        if (ctl.mode) mode = ctl.mode;
        if (ctl.bizModel !== undefined) bizModel = ctl.bizModel;
      } catch (e) { /* keep */ }
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ mode, bizModel }));
    });
    return;
  }

  if (url === '/__status') {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ mode, bizModel, chatRequests, modelsRequests, lastAuth, lastModel, lastMaxTokens }));
    return;
  }

  const auth = req.headers['authorization'] || null;
  if (auth) lastAuth = auth;

  if (url === '/v1/models') {
    modelsRequests += 1;
    if (mode === 'ok') {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ object: 'list', data: [{ id: 'deepseek-v4-flash', object: 'model' }] }));
    } else if (mode === 'no_models') {
      res.writeHead(404, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'no /v1/models endpoint here', type: 'fake' } }));
    } else {
      fail(res, mode);
    }
    return;
  }

  if (url === '/v1/chat/completions' || url === '/v1/embeddings') {
    chatRequests += 1;
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      let reqModel = null;
      let stream = false;
      let reqMaxTokens = null;
      try {
        const parsed = JSON.parse(body);
        reqModel = parsed.model || null;
        stream = parsed.stream === true;
        reqMaxTokens = parsed.max_tokens != null ? parsed.max_tokens : null;
      } catch (e) { /* keep */ }
      if (reqModel) lastModel = reqModel;
      if (reqMaxTokens != null) lastMaxTokens = reqMaxTokens;
      else lastMaxTokens = null;

      // per-model business failure: this model is dead on an ok provider
      if (mode === 'ok' && bizModel && reqModel === bizModel) {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({
          error: { message: 'usage limit reached for this model (quota exhausted)', code: 2056, type: 'fake_business' },
        }));
        return;
      }
      if (mode === 'bizfail') {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({
          error: { message: "You've reached your usage limit for this billing cycle", code: 2056, type: 'fake_business' },
        }));
        return;
      }
      if (mode === 'model404') {
        res.writeHead(404, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ error: { message: 'model not found: ghost-model', type: 'invalid_request_error' } }));
        return;
      }
      if (mode !== 'ok') { fail(res, mode); return; }
      if (stream) {
        res.writeHead(200, {
          'content-type': 'text/event-stream',
          'cache-control': 'no-cache',
          connection: 'keep-alive',
        });
        res.write(`data: ${JSON.stringify({ id: 'fake-1', object: 'chat.completion.chunk', model: 'deepseek-v4-flash', choices: [{ index: 0, delta: { role: 'assistant', content: 'fake' }, finish_reason: null }] })}\n\n`);
        res.write(`data: ${JSON.stringify({ id: 'fake-2', object: 'chat.completion.chunk', model: 'deepseek-v4-flash', choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] })}\n\n`);
        res.end('data: [DONE]\n\n');
      } else {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({
          id: 'fake-ok-1', object: 'chat.completion', model: reqModel || 'deepseek-v4-flash',
          choices: [{ index: 0, message: { role: 'assistant', content: 'fake-ok-reply' }, finish_reason: 'stop' }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
        }));
      }
    });
    return;
  }

  res.writeHead(404, { 'content-type': 'application/json' });
  res.end(JSON.stringify({ error: { message: 'fake not found', type: 'fake' } }));
});

function fail(res, m) {
  const status = m === '429' ? 429 : m === '500' ? 500 : 403;
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify({ error: { message: `simulated ${status}`, type: 'fake' } }));
}

server.listen(port, '127.0.0.1', () => {
  console.log(`[fake-provider] listening on 127.0.0.1:${port}, mode=${mode}`);
});
