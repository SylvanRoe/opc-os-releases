'use strict';
// test.js — integration tests for the BYOK gateway core.
//
// Spins up:
//   fake-provider  (127.0.0.1:18081, mode=fail) — simulates a dead upstream
//   gateway        (127.0.0.1:18082, tests/gateway.config.test.json)
//     providers: fake (priority 1, always 403 in fail mode), deepseek (priority 2, real)
//
// Covers acceptance: breaker (3× → trip → failover → still 200), event log
// trip/failover/recover records, recovery probe after cooldown, SSE passthrough,
// client key never forwarded upstream.
//
// Run: node --test tests/
// Env: GATEWAY_ENV_FILE must point at the secrets file with DEEPSEEK_API_KEY
//      (the runner below defaults to the gateway's own gateway.env; override with GATEWAY_ENV_FILE).

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const FAKE_PORT = 18181;
const GW_PORT = 18182;
const GW_BASE = `http://127.0.0.1:${GW_PORT}`;
const FAKE_BASE = `http://127.0.0.1:${FAKE_PORT}`;
const EVENTS_FILE = path.join(__dirname, 'events-test', 'events.jsonl');

const NODE = process.execPath;

let fakeProc;
let gwProc;
const children = [];

function spawnChild(args, env) {
  const p = spawn(NODE, args, {
    cwd: ROOT,
    env: Object.assign({}, process.env, env),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  children.push(p);
  p.stdout.on('data', (d) => process.stdout.write(`[child] ${d}`));
  p.stderr.on('data', (d) => process.stderr.write(`[child-err] ${d}`));
  return p;
}

async function waitFor(url, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(url);
      if (r.ok) return true;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`timeout waiting for ${url}`);
}

async function postJson(url, body, headers) {
  const r = await fetch(url, {
    method: 'POST',
    headers: Object.assign({ 'content-type': 'application/json' }, headers || {}),
    body: JSON.stringify(body),
  });
  return r;
}

async function gwStatus() {
  const r = await fetch(`${GW_BASE}/v1/status`);
  return r.json();
}

function readEvents() {
  try {
    return fs.readFileSync(EVENTS_FILE, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  } catch (e) {
    return [];
  }
}

function waitUntil(fn, timeoutMs = 40000, intervalMs = 500) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeoutMs;
    const loop = async () => {
      try {
        if (await fn()) return resolve(true);
      } catch (e) { /* keep polling */ }
      if (Date.now() > deadline) return reject(new Error('waitUntil timeout'));
      setTimeout(loop, intervalMs);
    };
    loop();
  });
}

before(async () => {
  // wipe previous test events
  try { fs.rmSync(path.dirname(EVENTS_FILE), { recursive: true, force: true }); } catch (e) { /* noop */ }

  fakeProc = spawnChild(
    [path.join(__dirname, 'fixtures', 'fake-provider.js')],
    { FAKE_PORT: String(FAKE_PORT), FAKE_MODE: 'fail' }
  );
  await waitFor(`${FAKE_BASE}/__status`);

  gwProc = spawnChild(
    ['server.js'],
    {
      GATEWAY_CONFIG: path.join(__dirname, 'gateway.config.test.json'),
      GATEWAY_ENV_FILE: process.env.GATEWAY_ENV_FILE || path.join(ROOT, 'gateway.env'),
      FAKE_API_KEY: 'dummy',
      // 显式清空继承的 GATEWAY_CLIENT_TOKEN：本套件验证的是网关不校验客户端 token
      GATEWAY_CLIENT_TOKEN: '',
    }
  );
  await waitFor(`${GW_BASE}/healthz`);
});

after(async () => {
  for (const p of children) {
    try { p.kill('SIGKILL'); } catch (e) { /* noop */ }
  }
});

test('healthz + status endpoint shape', async () => {
  const r = await fetch(`${GW_BASE}/healthz`);
  assert.equal(r.status, 200);
  const st = await gwStatus();
  assert.equal(st.gateway, 'llm-gateway');
  assert.ok(st.providers.fake, 'fake provider present in status');
  assert.ok(st.providers.deepseek, 'deepseek provider present in status');
  assert.equal(st.providers.fake.state, 'healthy');
  assert.equal(st.providers.deepseek.state, 'healthy');
  assert.ok(st.ts, 'status has fresh timestamp');
});

test('breaker: 3 consecutive 403s trip fake, requests still 200 via deepseek failover', async () => {
  const body = { model: 'deepseek-v4-flash', messages: [{ role: 'user', content: 'ping' }] };
  for (let i = 0; i < 3; i++) {
    const r = await postJson(`${GW_BASE}/v1/chat/completions`, body, { authorization: 'Bearer client-secret-key' });
    assert.equal(r.status, 200, `request ${i + 1} still 200 through failover`);
    const j = await r.json();
    assert.ok(j.choices && j.choices[0] && j.choices[0].message, 'valid OpenAI response shape');
  }

  // fake must be tripped now
  const st = await gwStatus();
  assert.equal(st.providers.fake.state, 'open', 'fake tripped after 3 failures');
  assert.equal(st.providers.fake.consecutive_failures, 3);

  const events = readEvents();
  assert.ok(events.some((e) => e.type === 'trip' && e.provider === 'fake' && e.status === 403), 'event log has trip record');
  assert.ok(events.some((e) => e.type === 'failover' && e.from === 'fake' && e.provider === 'deepseek'), 'event log has failover record');
  assert.ok(events.some((e) => e.type === 'request' && e.provider === 'deepseek' && e.status === 200), 'event log has served-by-deepseek request');
});

test('after trip: fake is skipped, deepseek serves directly, client key NOT forwarded upstream', async () => {
  const beforeFake = (await (await fetch(`${FAKE_BASE}/__status`)).json()).chatRequests;
  const body = { model: 'deepseek-v4-flash', messages: [{ role: 'user', content: 'ping again' }] };
  const r = await postJson(`${GW_BASE}/v1/chat/completions`, body, { authorization: 'Bearer client-secret-key' });
  assert.equal(r.status, 200);
  const afterFake = (await (await fetch(`${FAKE_BASE}/__status`)).json()).chatRequests;
  assert.equal(afterFake, beforeFake, 'tripped fake received no new traffic');

  const st = await gwStatus();
  assert.equal(st.current_provider, 'deepseek');

  const fakeStatus = await (await fetch(`${FAKE_BASE}/__status`)).json();
  assert.notEqual(fakeStatus.lastAuth, 'Bearer client-secret-key', 'client key never forwarded');
  assert.equal(fakeStatus.lastAuth, 'Bearer dummy', 'gateway injects its own provider key');
});

test('recovery: fake flips to ok, cooldown + probe auto-recovers it', async () => {
  await postJson(`${FAKE_BASE}/__control`, { mode: 'ok' });
  await waitUntil(async () => {
    const st = await gwStatus();
    return st.providers.fake.state === 'healthy';
  }, 40000, 1000);
  const events = readEvents();
  assert.ok(events.some((e) => e.type === 'recover' && e.provider === 'fake'), 'event log has recover record');
});

test('after recovery: traffic routes back to fake (priority 1), SSE passthrough intact', async () => {
  // non-stream
  const body = { model: 'deepseek-v4-flash', messages: [{ role: 'user', content: 'hello' }] };
  const r = await postJson(`${GW_BASE}/v1/chat/completions`, body);
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.choices[0].message.content, 'fake-ok-reply', 'served by recovered fake');

  // SSE stream
  const r2 = await fetch(`${GW_BASE}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(Object.assign({}, body, { stream: true })),
  });
  assert.equal(r2.status, 200);
  assert.equal(r2.headers.get('content-type'), 'text/event-stream');
  const text = await r2.text();
  assert.ok(text.includes('data: [DONE]'), 'SSE terminator present');
  assert.ok(text.split('\n').filter((l) => l.startsWith('data: ')).length >= 2, 'multiple SSE chunks');

  const st = await gwStatus();
  assert.equal(st.current_provider, 'fake');
});

test('models passthrough + bad request handling', async () => {
  const r = await fetch(`${GW_BASE}/v1/models`);
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.object, 'list');

  const bad = await postJson(`${GW_BASE}/v1/chat/completions`, { not: 'valid' });
  assert.ok([200, 400].includes(bad.status), 'malformed body: gateway must not crash');
  const bad2 = await fetch(`${GW_BASE}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: '{broken json',
  });
  assert.equal(bad2.status, 400);

  const nf = await fetch(`${GW_BASE}/nope`);
  assert.equal(nf.status, 404);
});
