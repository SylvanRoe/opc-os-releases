'use strict';
// test-gw-config.js — opc-gw-config CLI + 拍板戳 directive + reload 方向校验
// (0827-gw-config, R1/R2/R3).
//
// Spin-up: isolated gateway (ports 18211/18212, temp dir config) + opc-gw-config CLI.
//
// Coverage (acceptance for 0827-gw-config):
//   R1  1. CLI --help 可跑；CLI show 读当前方向+directive
//   R2  2. PUT /admin/direction 落 directive（seq=1 基线）→ config 文件带 directive
//       3. 写前 CAS：旧指令（seq ≤ 当前）被拒（409, "旧指令，已拒"），方向不变
//       4. CLI set-direction 自动分配 seq+1；CLI set-provider；switch-history 含 admin_set_direction
//   R3  5. 手改文件改方向但无 directive → reload 被拒（last_error 非空、内存配置未变、审计事件）
//       6. 手改文件改方向且带合法 directive → reload 放行
//       7. 手改文件改方向但 directive 旧（seq ≤ 当前）→ reload 被拒
//       8. 手改文件只改 enabled（方向不变）→ reload 放行（向后兼容）
//       9. /admin/status 暴露 directive + config_sync_detail.last_error 保留

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn, execFile } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const NODE = process.execPath;
const ADMIN_TOKEN = 'test-gw-config-token-0123456789';

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-gw-gwconfig-'));
const GW_PORT = 18211;
const FAKE_PORT = 18212;
const GW_BASE = `http://127.0.0.1:${GW_PORT}`;
const FAKE_BASE = `http://127.0.0.1:${FAKE_PORT}`;
const CFG_PATH = path.join(TMP, 'gateway.config.json');
const EVENTS_FILE = path.join(TMP, 'events', 'events.jsonl');

const fakeKeyValue = 'dummy-fake-key-value';
const ENV_FILE = process.env.GATEWAY_ENV_FILE || path.join(ROOT, 'gateway.env');

let fakeProc;
let gwProc;
const children = [];

function spawnChild(args, env) {
  const p = spawn(NODE, args, {
    cwd: ROOT,
    env: Object.assign({}, process.env, env),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  children.push(p);
  p.stdout.on('data', (d) => process.stdout.write(`[child] ${d}`));
  p.stderr.on('data', (d) => process.stderr.write(`[child-err] ${d}`));
  return p;
}

async function waitFor(url, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(url);
      if (r.ok) return true;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`timeout waiting for ${url}`);
}

function reqJson(method, url, body, token) {
  return fetch(url, {
    method,
    headers: Object.assign(
      { 'content-type': 'application/json' },
      token ? { authorization: `Bearer ${token}` } : {}
    ),
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}
const get = (url, t) => reqJson('GET', url, undefined, t);
const put = (url, b, t) => reqJson('PUT', url, b, t);

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}
function readEvents() {
  try {
    return fs.readFileSync(EVENTS_FILE, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  } catch (e) {
    return [];
  }
}

async function adminStatus() {
  const r = await get(`${GW_BASE}/admin/status`, ADMIN_TOKEN);
  assert.equal(r.status, 200, 'admin/status reachable');
  return r.json();
}
async function gwStatus() {
  const r = await fetch(`${GW_BASE}/v1/status`);
  return r.json();
}

async function waitForReload(pred, label, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  let last;
  while (Date.now() < deadline) {
    last = await adminStatus();
    if (pred(last)) return last;
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error(`timeout waiting for ${label}; last: ${JSON.stringify(last && last.config_sync_detail)}`);
}

// 手改磁盘配置（只改当前分片的字段），绕过 CLI —— 模拟即兴写者。
function editDisk(mutator) {
  const cfg = readJson(CFG_PATH);
  mutator(cfg);
  fs.writeFileSync(CFG_PATH, JSON.stringify(cfg, null, 2) + '\n');
  return cfg;
}

// 把磁盘配置重写回「当前内存状态」（读 /admin/status → 重建完整配置再写盘），并等
// reload 回 in_sync。被拒 reload 后的磁盘与内存会分歧，每个 R3 用例先对齐再施改，
// 才能让「方向变化/无变化」的判定只由本次改动触发。
async function syncDiskToMemory() {
  const ast = await adminStatus();
  const cfg = buildConfig();
  for (const p of cfg.providers) {
    const sp = ast.providers[p.name];
    if (sp) {
      p.priority = sp.priority;
      p.enabled = sp.enabled !== false;
      p.default_model = sp.default_model;
    }
  }
  cfg.default_provider = ast.default_provider || 'fake';
  if (ast.directive) cfg.directive = ast.directive;
  fs.writeFileSync(CFG_PATH, JSON.stringify(cfg, null, 2) + '\n');
  await waitForReload(
    (s) => s.config_sync === true && s.config_sync_detail.last_error === null,
    'disk synced to memory'
  );
}

// 把磁盘/内存重写回干净的 buildConfig 基线（default=fake、deepseek 启用、无 directive），
// 供独立用例从已知态开始（R3 用例会把 provider enabled / directive 搅乱，需先复位）。
async function resetConfig() {
  fs.writeFileSync(CFG_PATH, JSON.stringify(buildConfig(), null, 2) + '\n');
  return waitForReload(
    (s) => s.default_provider === 'fake' && s.directive == null && s.config_sync === true,
    'config reset to baseline'
  );
}

// ---- CLI 助手：spawn bin/opc-gw-config，捕获 stdout/stderr/exit ----
const CLI = path.join(ROOT, 'bin', 'opc-gw-config');
function cli(args) {
  return new Promise((resolve) => {
    execFile(NODE, [CLI].concat(args), {
      env: Object.assign({}, process.env, {
        GATEWAY_ADMIN_URL: GW_BASE,
        GATEWAY_ADMIN_TOKEN: ADMIN_TOKEN,
      }),
      cwd: ROOT,
    }, (err, stdout, stderr) => {
      resolve({ code: err ? err.code || 1 : 0, stdout: stdout || '', stderr: stderr || '' });
    });
  });
}

// ---- 构造测试配置 ----
function buildConfig() {
  return {
    host: '127.0.0.1',
    port: GW_PORT,
    providers: [
      { name: 'fake', priority: 1, base_url: `http://127.0.0.1:${FAKE_PORT}/v1`, api_key_env: 'FAKE_API_KEY', models: ['deepseek-v4-flash'], default_model: 'deepseek-v4-flash' },
      { name: 'deepseek', priority: 2, base_url: `http://127.0.0.1:${FAKE_PORT}/v1`, api_key_env: 'DEEPSEEK_API_KEY', models: ['deepseek-v4-flash', 'deepseek-v4-flash-vision-exp'], default_model: 'deepseek-v4-flash-vision-exp' },
    ],
    circuit: { failure_threshold: 3, cooldown_s: 60 },
    health: { probe_interval_s: 30, probe_timeout_ms: 10000 },
    events: { dir: 'events', max_bytes: 1048576 },
    default_provider: 'fake',
  };
}

before(async () => {
  fs.writeFileSync(CFG_PATH, JSON.stringify(buildConfig(), null, 2) + '\n');

  fakeProc = spawnChild(
    [path.join(__dirname, 'fixtures', 'fake-provider.js')],
    { FAKE_PORT: String(FAKE_PORT), FAKE_MODE: 'ok' }
  );
  await waitFor(`${FAKE_BASE}/__status`);

  gwProc = spawnChild(['server.js'], {
    GATEWAY_CONFIG: CFG_PATH,
    GATEWAY_ENV_FILE: ENV_FILE,
    GATEWAY_ADMIN_TOKEN: ADMIN_TOKEN,
    FAKE_API_KEY: fakeKeyValue,
    DEEPSEEK_API_KEY: 'dummy-deepseek-key-value',
    // 测试隔离：终态校验告警写入临时目录，不污染真实 opc-alert-bus（W4）
    OPC_ALERT_DIR: path.join(TMP, 'alerts'),
  });
  await waitFor(`${GW_BASE}/healthz`);
});

after(async () => {
  for (const p of children) {
    try { p.kill('SIGKILL'); } catch (e) { /* noop */ }
  }
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) { /* noop */ }
});

// ---------- R1: CLI --help / show ----------
test('R1: CLI --help 可跑（exit 0, 含子命令清单）', async () => {
  const r = await cli(['--help']);
  assert.equal(r.code, 0, '--help exits 0');
  assert.match(r.stdout, /set-direction/, 'usage carries set-direction');
  assert.match(r.stdout, /set-provider/, 'usage carries set-provider');
  assert.match(r.stdout, /switch-history/, 'usage carries switch-history');
});

test('R1: CLI show 读当前生效方向 + directive（初始无拍板戳）', async () => {
  const r = await cli(['show']);
  assert.equal(r.code, 0, 'show exits 0');
  assert.match(r.stdout, /当前生效方向: fake/, 'active direction = fake');
  assert.match(r.stdout, /default_provider: fake/, 'default_provider = fake');
  assert.match(r.stdout, /拍板戳 directive: \(无\)/, 'no directive yet');
});

// ---------- R2: PUT /admin/direction 落 directive（seq=1 基线）----------
test('R2: PUT /admin/direction 落 directive（seq=1 基线）→ 文件带 directive、方向生效', async () => {
  const body = {
    direction: { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' },
    decided_by: 'zhuangzi',
    card_id: 'G-2026-08-27-001',
    decided_at: '2026-08-27T15:00:00.000Z',
    seq: 1,
  };
  const r = await put(`${GW_BASE}/admin/direction`, body, ADMIN_TOKEN);
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.directive.seq, 1);
  assert.equal(j.default_provider, 'deepseek');

  // 落盘：config 文件带 directive
  const onDisk = readJson(CFG_PATH);
  assert.equal(onDisk.directive.seq, 1);
  assert.deepEqual(onDisk.directive.direction, { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' });
  assert.equal(onDisk.default_provider, 'deepseek');
  assert.equal(onDisk.providers.find((p) => p.name === 'deepseek').priority, 1);

  // 生效：/v1/status + /admin/status
  const st = await gwStatus();
  assert.equal(st.default_provider, 'deepseek', 'v1/status reflects new direction');
  const ast = await adminStatus();
  assert.equal(ast.directive.seq, 1);
  assert.deepEqual(ast.active_direction, { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' });
  assert.equal(ast.providers.deepseek.priority, 1, 'deepseek promoted to p1');
  assert.equal(ast.providers.fake.priority, 2, 'old primary fake downgraded to p2');
});

// ---------- R2: CAS 旧指令被拒 ----------
test('R2: CAS — 旧指令（seq ≤ 当前）被拒（409 "旧指令，已拒"），方向不变', async () => {
  // 当前生效 seq=1；发 seq=1（≤1）→ 拒
  const body = {
    direction: { provider: 'fake', model: 'deepseek-v4-flash' },
    decided_by: 'zhuangzi',
    card_id: 'G-2026-08-27-002',
    decided_at: '2026-08-27T16:00:00.000Z',
    seq: 1,
  };
  const r = await put(`${GW_BASE}/admin/direction`, body, ADMIN_TOKEN);
  assert.equal(r.status, 409, 'stale seq rejected with 409');
  const j = await r.json();
  assert.match(j.error.message, /旧指令，已拒/, 'message names old-instruction rejection');

  // 方向未被翻转：仍 deepseek / seq=1
  const ast = await adminStatus();
  assert.equal(ast.default_provider, 'deepseek', 'direction unchanged after CAS reject');
  assert.equal(ast.directive.seq, 1, 'directive.seq still 1');
});

// ---------- R1/R2: CLI set-direction 自动分配 seq ----------
test('R1: CLI set-direction 自动分配 seq+1 并落拍板戳', async () => {
  const r = await cli([
    'set-direction', '--provider', 'fake', '--model', 'deepseek-v4-flash',
    '--decided-by', 'zhuangzi', '--card-id', 'G-2026-08-27-003',
    '--decided-at', '2026-08-27T17:00:00.000Z',
  ]);
  assert.equal(r.code, 0, `set-direction exits 0: ${r.stderr}`);
  assert.match(r.stdout, /seq=2/, 'seq auto = 2 (prev 1 + 1)');

  const ast = await adminStatus();
  assert.equal(ast.directive.seq, 2);
  assert.equal(ast.default_provider, 'fake');
  assert.deepEqual(ast.active_direction, { provider: 'fake', model: 'deepseek-v4-flash' });
});

test('R1: CLI set-provider 设默认 provider（model 取其 default_model）', async () => {
  const r = await cli([
    'set-provider', '--provider', 'deepseek',
    '--decided-by', 'zhuangzi', '--card-id', 'G-2026-08-27-004',
    '--decided-at', '2026-08-27T18:00:00.000Z',
  ]);
  assert.equal(r.code, 0, `set-provider exits 0: ${r.stderr}`);
  const ast = await adminStatus();
  assert.equal(ast.default_provider, 'deepseek');
  assert.equal(ast.directive.seq, 3);
  assert.deepEqual(ast.active_direction, { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' });
});

test('R2: switch-history 含 admin_set_direction 事件', async () => {
  const ast = await adminStatus();
  const dirEvents = ast.switch_history.filter((e) => e.type === 'admin_set_direction');
  assert.ok(dirEvents.length >= 3, `at least 3 admin_set_direction events (got ${dirEvents.length})`);
  // 最新一条 seq=3
  assert.equal(dirEvents[dirEvents.length - 1].directive.seq, 3);
});

// ---------- R3: reload 方向校验 ----------
test('R3: 手改文件改方向但无 directive → reload 被拒（last_error 非空、内存未变、审计事件）', async () => {
  await syncDiskToMemory();
  const beforeDir = (await adminStatus()).directive.seq; // 3
  // 改 default_provider=fake（方向变化）+ 删除 directive → 无拍板戳
  editDisk((cfg) => {
    cfg.default_provider = 'fake';
    cfg.providers.find((p) => p.name === 'fake').priority = 1;
    cfg.providers.find((p) => p.name === 'deepseek').priority = 2;
    delete cfg.directive;
  });

  const st = await waitForReload(
    (s) => s.config_sync_detail.last_error != null && s.config_sync_detail.last_error.trim() !== '',
    'reload rejected (no directive)'
  );
  // 内存配置未变：仍 deepseek / seq=3
  assert.equal(st.default_provider, 'deepseek', 'memory direction unchanged after rejected reload');
  assert.equal(st.directive.seq, beforeDir, 'directive.seq unchanged');
  // 审计事件
  const evs = readEvents();
  assert.ok(evs.some((e) => e.type === 'config_reload_rejected'), 'config_reload_rejected audit event emitted');
});

test('R3: 手改文件改方向且带合法 directive → reload 放行', async () => {
  await syncDiskToMemory();
  // 当前 memory: default=deepseek, seq=3。改 default=fake + 合法 directive seq=4
  editDisk((cfg) => {
    cfg.default_provider = 'fake';
    cfg.providers.find((p) => p.name === 'fake').priority = 1;
    cfg.providers.find((p) => p.name === 'deepseek').priority = 2;
    cfg.directive = {
      seq: 4,
      direction: { provider: 'fake', model: 'deepseek-v4-flash' },
      declared_state: { default_provider: 'fake', default_model: 'deepseek-v4-flash', max_tokens: null, context_window: null },
      decided_at: '2026-08-27T19:00:00.000Z',
      decided_by: 'zhuangzi',
      card_id: 'G-2026-08-27-005',
    };
  });

  const st = await waitForReload(
    (s) => s.default_provider === 'fake' && s.directive && s.directive.seq === 4,
    'reload allowed (valid directive)'
  );
  assert.equal(st.config_sync_detail.last_error, null, 'last_error cleared after successful allowed reload');
});

test('R3: 手改文件改方向但 directive 旧（seq ≤ 当前）→ reload 被拒', async () => {
  await syncDiskToMemory();
  // 当前 memory: default=fake, seq=4。改 default=deepseek + 旧 directive seq=3（≤4）→ 拒
  editDisk((cfg) => {
    cfg.default_provider = 'deepseek';
    cfg.providers.find((p) => p.name === 'deepseek').priority = 1;
    cfg.providers.find((p) => p.name === 'fake').priority = 2;
    cfg.directive.seq = 3; // stale
  });

  const st = await waitForReload(
    (s) => s.config_sync_detail.last_error != null && /旧指令/.test(s.config_sync_detail.last_error),
    'reload rejected (stale directive seq)'
  );
  assert.equal(st.default_provider, 'fake', 'memory direction unchanged after stale-directive reject');
  assert.equal(st.directive.seq, 4, 'directive.seq still 4 in memory');
});

test('R3: 手改文件只改 enabled（方向不变）→ reload 放行（向后兼容）', async () => {
  await syncDiskToMemory();
  // 当前 memory: default=fake, seq=4, deepseek p2 enabled true。只关 deepseek enabled
  editDisk((cfg) => {
    cfg.providers.find((p) => p.name === 'deepseek').enabled = false;
  });

  const st = await waitForReload(
    (s) => s.providers.deepseek && s.providers.deepseek.enabled === false && s.config_sync === true,
    'enabled toggle reloaded (no directive needed)'
  );
  assert.equal(st.default_provider, 'fake', 'direction untouched');
  assert.equal(st.directive.seq, 4, 'directive preserved');
  assert.equal(st.config_sync_detail.last_error, null, 'no error for non-direction change');
});

test('R3: /admin/status 暴露 directive + 保留 config_sync_detail.last_error', async () => {
  await syncDiskToMemory();
  // 制造一次被拒 reload（改方向无 directive），确认 last_error 暴露在 /admin/status
  editDisk((cfg) => {
    cfg.default_provider = 'deepseek';
    cfg.providers.find((p) => p.name === 'fake').priority = 2;
    cfg.providers.find((p) => p.name === 'deepseek').priority = 1;
    cfg.providers.find((p) => p.name === 'deepseek').enabled = true; // 配置保持合法，拒因=无 directive
    delete cfg.directive; // 方向变化 + 无拍板戳 → 拒
  });
  const st = await waitForReload(
    (s) => s.config_sync_detail.last_error != null && s.config_sync_detail.last_error.trim() !== '',
    'last_error exposed in status after rejected reload'
  );
  assert.ok(st.directive && st.directive.seq === 4, 'directive still exposed');
  assert.equal(st.default_provider, 'fake', 'memory unchanged (deepseek rejected)');
  assert.equal(st.config_sync, false, 'config_sync=false while disk drifts');
});

// ---------- W3: decided_at 必填 ----------
test('W3: decided_at 缺失 → PUT /admin/direction 400 拒绝（拍板时刻必填，禁用写入时刻冒充）', async () => {
  await syncDiskToMemory();
  const body = {
    direction: { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' },
    decided_by: 'zhuangzi', card_id: 'G-w3-nodate',
  }; // 无 decided_at
  const r = await put(`${GW_BASE}/admin/direction`, body, ADMIN_TOKEN);
  assert.equal(r.status, 400, 'missing decided_at → 400');
  assert.match((await r.json()).error.message, /decided_at is required/);
});

// ---------- W3: 版本戳 CAS ----------
test('W3: 版本戳 CAS — 旧 base_version 写 → 409 版本冲突；重读再写 → version 单调 +1', async () => {
  await resetConfig();
  // 先落一个带版本戳的方向（确立 config_version）
  const r0 = await put(`${GW_BASE}/admin/direction`, {
    direction: { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' },
    decided_by: 'zhuangzi', card_id: 'G-w3-base', decided_at: '2026-08-27T21:00:00.000Z',
  }, ADMIN_TOKEN);
  assert.equal(r0.status, 200, 'baseline direction write ok');
  const base = await adminStatus();
  const curVer = base.config_version;
  assert.ok(Number.isInteger(curVer), 'config_version stamped after write');

  // 基于旧版写 → 409 版本冲突
  const r = await put(`${GW_BASE}/admin/direction`, {
    direction: { provider: 'fake', model: 'deepseek-v4-flash' },
    decided_by: 'zhuangzi', card_id: 'G-w3-stale', decided_at: '2026-08-27T22:00:00.000Z',
    seq: base.directive.seq + 1,
    base_version: curVer + 99,
  }, ADMIN_TOKEN);
  assert.equal(r.status, 409, 'stale base_version → 409');
  assert.match((await r.json()).error.message, /版本冲突/);
  const after = await adminStatus();
  assert.equal(after.default_provider, 'deepseek', 'direction unchanged after version-conflict reject');

  // 重读最新 version 再写 → 成功且 version 单调 +1
  const r2 = await put(`${GW_BASE}/admin/direction`, {
    direction: { provider: 'fake', model: 'deepseek-v4-flash' },
    decided_by: 'zhuangzi', card_id: 'G-w3-fresh', decided_at: '2026-08-27T23:00:00.000Z',
    seq: base.directive.seq + 1,
    base_version: curVer,
  }, ADMIN_TOKEN);
  assert.equal(r2.status, 200, 'fresh base_version accepted');
  const j2 = await r2.json();
  assert.equal(j2.version, curVer + 1, 'version monotonic +1');
});

// ---------- W2: 写锁（O_EXCL + 陈旧回收）----------
test('W2: 写锁 — 活锁冲突 → 409；陈旧锁 → 自动回收后写入成功并释放', async () => {
  await resetConfig();
  const lockP = CFG_PATH + '.lock';
  // ① 活锁冲突：预置持活 pid（本测试进程）→ 受管写被拒 409
  fs.writeFileSync(lockP, JSON.stringify({ pid: process.pid, ts: Date.now(), host: 'test' }));
  const r = await put(`${GW_BASE}/admin/direction`, {
    direction: { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' },
    decided_by: 'zhuangzi', card_id: 'G-w2-live', decided_at: '2026-08-27T23:10:00.000Z',
  }, ADMIN_TOKEN);
  assert.equal(r.status, 409, 'live lock held → write rejected 409');
  assert.match((await r.json()).error.message, /锁/, 'error names lock contention');
  fs.unlinkSync(lockP);
  // ② 陈旧锁：预置死 pid（远超 pid_max）→ 受管写自动回收陈锁并成功
  fs.writeFileSync(lockP, JSON.stringify({ pid: 99999999, ts: Date.now() - 100000, host: 'test' }));
  const r2 = await put(`${GW_BASE}/admin/direction`, {
    direction: { provider: 'fake', model: 'deepseek-v4-flash' },
    decided_by: 'zhuangzi', card_id: 'G-w2-stale', decided_at: '2026-08-27T23:20:00.000Z',
  }, ADMIN_TOKEN);
  assert.equal(r2.status, 200, 'stale lock recovered → write succeeds');
  assert.ok(!fs.existsSync(lockP), 'lock released after write');
});

// ---------- W4: 终态校验失败 → 回滚 + 审计 ----------
test('W4: 终态校验失败 → 500 + 磁盘回滚 + config_terminal_check_failed 审计', async () => {
  await resetConfig();
  const onDiskBefore = readJson(CFG_PATH);
  const before = await adminStatus();
  // direction 指 deepseek-vision，但 declared_state.default_model 故意不一致 → 终态校验失败
  const body = {
    direction: { provider: 'deepseek', model: 'deepseek-v4-flash-vision-exp' },
    decided_by: 'zhuangzi', card_id: 'G-w4-fail', decided_at: '2026-08-27T23:50:00.000Z',
    seq: (before.directive ? before.directive.seq : 0) + 1,
    declared_state: { default_provider: 'deepseek', default_model: 'deepseek-v4-flash', max_tokens: null, context_window: null },
  };
  const r = await put(`${GW_BASE}/admin/direction`, body, ADMIN_TOKEN);
  assert.equal(r.status, 500, 'terminal check failure → 500');
  assert.match((await r.json()).error.message, /终态校验失败/);
  // 磁盘回滚到写入前（.bak 恢复）
  const onDiskAfter = readJson(CFG_PATH);
  assert.deepEqual(onDiskAfter.directive, onDiskBefore.directive, 'directive rolled back');
  assert.equal(onDiskAfter.default_provider, onDiskBefore.default_provider, 'default_provider rolled back');
  // 审计事件
  const evs = readEvents();
  assert.ok(evs.some((e) => e.type === 'config_terminal_check_failed'), 'config_terminal_check_failed audit emitted');
});
