'use strict';
// test-host-env.js — GATEWAY_HOST env override (0825-init).
//
// The gateway must listen on the GATEWAY_HOST value when set, overriding the
// host in gateway.config.json (default 127.0.0.1). OPC local production runs
// without GATEWAY_HOST → config host is used unchanged (zero behavior change,
// covered implicitly by every other test spawning without the env).
//
// Run: node --test tests/test-host-env.js  (or `npm test`)

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const PORT = 18085;
const EVENTS_DIR = path.join(ROOT, 'events-host-env');  // config events.dir "../events-host-env" resolves against tests/ → repo root
const EVENTS_FILE = path.join(EVENTS_DIR, 'events.jsonl');
const NODE = process.execPath;

let proc;
let childOut = '';

before(async () => {
  try { fs.rmSync(EVENTS_DIR, { recursive: true, force: true }); } catch (e) { /* noop */ }
  proc = spawn(NODE, [path.join(ROOT, 'server.js')], {
    cwd: ROOT,
    env: Object.assign({}, process.env, {
      GATEWAY_CONFIG: path.join(__dirname, 'gateway.hostenv.test.json'),
      GATEWAY_HOST: '0.0.0.0',
      FAKE_API_KEY: 'dummy',
    }),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  proc.stdout.on('data', (d) => { childOut += d; });
  proc.stderr.on('data', (d) => { childOut += d; });
  const deadline = Date.now() + 15000;
  while (!childOut.includes('listening on http://') && Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 200));
  }
});

after(() => {
  if (proc) { try { proc.kill('SIGKILL'); } catch (e) { /* noop */ } }
  try { fs.rmSync(EVENTS_DIR, { recursive: true, force: true }); } catch (e) { /* noop */ }
});

test('GATEWAY_HOST env overrides config host; startup event records it', async () => {
  assert.match(childOut, /listening on http:\/\/0\.0\.0\.0:18085/,
    `server must listen on GATEWAY_HOST (log: ${childOut.slice(-500)})`);
  const r = await fetch(`http://127.0.0.1:${PORT}/healthz`);
  assert.equal(r.status, 200);
  assert.equal(await r.text(), 'ok');
  const events = fs.readFileSync(EVENTS_FILE, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  const startup = events.find((e) => e.type === 'startup');
  assert.ok(startup, 'startup event recorded');
  assert.equal(startup.host, '0.0.0.0', 'startup event host must reflect GATEWAY_HOST');
});
