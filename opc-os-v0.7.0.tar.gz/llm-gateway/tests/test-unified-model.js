'use strict';
// test-unified-model.js — 统一模型名 hermes-opc-v1（0825-init-2 / 0826-gw-2）路由与鉴权。
//
// 单测：router.candidates 别名分支 —— hermes-opc-v1 / null 与显式具体模型名统一语义
//       （0826-gw-2）：default_provider 健康时排 healthy 组首位；default 熔断→priority
//       兜底；default 未设/不在池/被禁→纯 priority（向后兼容）。
// 集成：起 fake-a(18184,p1) + fake-b(18185,p2,default) + gateway(18183)，
//       GATEWAY_CLIENT_TOKEN 生效：
//         - /v1/models 静态清单只含 hermes-opc-v1；无 token 401
//         - chat model=hermes-opc-v1 → 200，走 fake-b（default_provider 生效）
//         - fake-b（default）熔断（3×403）→ 自动切 fake-a（自愈，不依赖人为改 default）
//         - fake-b 恢复（冷却+探测）→ 流量自动回到 default fake-b
//
// Run: node --test tests/test-unified-model.js  (or `npm test`)

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const GW_PORT = 18186;
const FAKE_A_PORT = 18187;
const FAKE_B_PORT = 18188;
const GW_BASE = `http://127.0.0.1:${GW_PORT}`;
const FAKE_A_BASE = `http://127.0.0.1:${FAKE_A_PORT}`;
const FAKE_B_BASE = `http://127.0.0.1:${FAKE_B_PORT}`;
const EVENTS_DIR = path.join(__dirname, 'events-unified-test');
const NODE = process.execPath;
const CLIENT_TOKEN = 'test-client-token';

let fakeA;
let fakeB;
let gwProc;
const children = [];

function spawnChild(args, env) {
  const p = spawn(NODE, args, {
    cwd: ROOT,
    env: Object.assign({}, process.env, env),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  children.push(p);
  p.stdout.on('data', (d) => process.stdout.write(`[child] ${d}`));
  p.stderr.on('data', (d) => process.stderr.write(`[child-err] ${d}`));
  return p;
}

async function waitFor(url, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(url);
      if (r.ok) return true;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`timeout waiting for ${url}`);
}

async function fakeStatus(base) {
  return (await (await fetch(`${base}/__status`)).json());
}

async function setFakeMode(base, mode) {
  const r = await fetch(`${base}/__control`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ mode }),
  });
  assert.equal(r.status, 200);
}

function waitUntil(fn, timeoutMs = 40000, intervalMs = 500) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeoutMs;
    const loop = async () => {
      try {
        if (await fn()) return resolve(true);
      } catch (e) { /* keep polling */ }
      if (Date.now() > deadline) return reject(new Error('waitUntil timeout'));
      setTimeout(loop, intervalMs);
    };
    loop();
  });
}

// ---------------------------------------------------------------- router 单测

function mkRouter(cfgOverrides, healthOverrides) {
  const cfg = Object.assign({
    providers: [
      { name: 'fakeA', priority: 1, models: ['fake-a-model'] },
      { name: 'fakeB', priority: 2, models: ['fake-b-model'] },
      { name: 'kimi', priority: 3, models: ['kimi-k3'] },
    ],
    default_provider: 'kimi',
    unified_model: 'hermes-opc-v1',
  }, cfgOverrides || {});
  const providers = {
    isHealthy: (name) => (healthOverrides ? healthOverrides[name] !== false : true),
  };
  return require('../lib/router').create(cfg, providers).candidates;
}

test('router: hermes-opc-v1 → default_provider 健康时排首位（0826-gw-2 规则 5 生效）', () => {
  const c = mkRouter();
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['kimi', 'fakeA', 'fakeB']);
});

test('router: model=null / undefined → 同 unified 语义（default 健康置首）', () => {
  const c = mkRouter();
  assert.deepEqual(c(null).map((p) => p.name), ['kimi', 'fakeA', 'fakeB']);
  assert.deepEqual(c(undefined).map((p) => p.name), ['kimi', 'fakeA', 'fakeB']);
});

test('router: default 熔断 → healthy 组按 priority 兜底（自愈，不依赖改 default）', () => {
  const c = mkRouter({}, { kimi: false });
  // gw-3：健康池非空 → 熔断的 default 完全移出候选（不进 rest 组尾部）
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['fakeA', 'fakeB']);
});

test('router: default 未设 → 纯 priority（向后兼容）', () => {
  const c = mkRouter({ default_provider: undefined });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['fakeA', 'fakeB', 'kimi']);
});

test('router: default 不在池 → 纯 priority（moveToFront 无操作）', () => {
  const c = mkRouter({ default_provider: 'ghost-provider' });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['fakeA', 'fakeB', 'kimi']);
});

test('router: default 被禁（enabled:false）→ 不在候选池，剩余按 priority', () => {
  const c = mkRouter({
    providers: [
      { name: 'fakeA', priority: 1, models: ['fake-a-model'] },
      { name: 'fakeB', priority: 2, models: ['fake-b-model'] },
      { name: 'kimi', priority: 3, models: ['kimi-k3'], enabled: false },
    ],
  });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['fakeA', 'fakeB']);
});

test('router: 全池熔断 → fail-open 仍按 priority 尝试（rest 组逻辑保留）', () => {
  const c = mkRouter({}, { fakeA: false, fakeB: false, kimi: false });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['fakeA', 'fakeB', 'kimi']);
});

test('router: 显式具体模型名 → serving 过滤 + default_provider 优先（原语义保留）', () => {
  const c = mkRouter();
  // 只有 kimi 声明服务 kimi-k3
  assert.deepEqual(c('kimi-k3').map((p) => p.name), ['kimi']);
  // models 全空（serves all）时 default_provider 置首
  const c2 = mkRouter({
    providers: [
      { name: 'fakeA', priority: 1, models: [] },
      { name: 'fakeB', priority: 2, models: [] },
      { name: 'kimi', priority: 3, models: [] },
    ],
  });
  assert.deepEqual(c2('kimi-k3').map((p) => p.name), ['kimi', 'fakeA', 'fakeB']);
});

test('router: 别名下熔断排序照旧（healthy 先于 tripped；default 健康置首；gw-3 隔离）', () => {
  const c = mkRouter({}, { fakeA: false });
  // gw-3：healthy=[kimi,fakeB] 非空 → 熔断 fakeA 完全移出
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['kimi', 'fakeB']);
});

// ---------------------------------------------------------------- 集成测试

before(async () => {
  try { fs.rmSync(EVENTS_DIR, { recursive: true, force: true }); } catch (e) { /* noop */ }

  fakeA = spawnChild(
    [path.join(__dirname, 'fixtures', 'fake-provider.js')],
    { FAKE_PORT: String(FAKE_A_PORT), FAKE_MODE: 'ok' }
  );
  await waitFor(`${FAKE_A_BASE}/__status`);
  fakeB = spawnChild(
    [path.join(__dirname, 'fixtures', 'fake-provider.js')],
    { FAKE_PORT: String(FAKE_B_PORT), FAKE_MODE: 'ok' }
  );
  await waitFor(`${FAKE_B_BASE}/__status`);

  gwProc = spawnChild(
    ['server.js'],
    {
      GATEWAY_CONFIG: path.join(__dirname, 'gateway.unified.test.json'),
      FAKE_API_KEY: 'dummy',
      GATEWAY_CLIENT_TOKEN: CLIENT_TOKEN,
    }
  );
  await waitFor(`${GW_BASE}/healthz`);
});

after(async () => {
  for (const p of children) {
    try { p.kill('SIGKILL'); } catch (e) { /* noop */ }
  }
});

test('integration: /v1/models 静态清单只含 hermes-opc-v1；无 token → 401', async () => {
  const noAuth = await fetch(`${GW_BASE}/v1/models`);
  assert.equal(noAuth.status, 401);

  const r = await fetch(`${GW_BASE}/v1/models`, {
    headers: { authorization: `Bearer ${CLIENT_TOKEN}` },
  });
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.object, 'list');
  assert.equal(j.data.length, 1, '静态清单只有一个模型');
  assert.equal(j.data[0].id, 'hermes-opc-v1', '唯一暴露统一模型名');
  assert.ok(!JSON.stringify(j).includes('kimi-k3'), '不透传上游模型');
  assert.ok(!JSON.stringify(j).includes('fake-a-model'), '不透传上游模型');
});

test('integration: chat 无 token → 401；带 token + hermes-opc-v1 → 200 走 fake-b（default_provider 生效）', async () => {
  const body = { model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'ping' }] };

  const noAuth = await fetch(`${GW_BASE}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  assert.equal(noAuth.status, 401);

  const stBeforeA = (await fakeStatus(FAKE_A_BASE)).chatRequests;
  const stBeforeB = (await fakeStatus(FAKE_B_BASE)).chatRequests;

  const r = await fetch(`${GW_BASE}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${CLIENT_TOKEN}` },
    body: JSON.stringify(body),
  });
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.choices[0].message.content, 'fake-ok-reply');

  const afterA = (await fakeStatus(FAKE_A_BASE)).chatRequests;
  const afterB = (await fakeStatus(FAKE_B_BASE)).chatRequests;
  assert.ok(afterB > stBeforeB, 'default_provider=fake-b 收到请求（unified 路径 default 生效）');
  assert.equal(afterA, stBeforeA, 'priority 1 的 fake-a 未被选中');
});

test('integration: default(fake-b) 熔断（3×403）→ 自动切 fake-a（自愈，不依赖改 default）', async () => {
  await setFakeMode(FAKE_B_BASE, 'fail');
  const body = { model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'ping failover' }] };

  const stA0 = (await fakeStatus(FAKE_A_BASE)).chatRequests;
  for (let i = 0; i < 3; i++) {
    const r = await fetch(`${GW_BASE}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${CLIENT_TOKEN}` },
      body: JSON.stringify(body),
    });
    assert.equal(r.status, 200, `第 ${i + 1} 次经自愈仍 200`);
  }
  const stA1 = (await fakeStatus(FAKE_A_BASE)).chatRequests;
  assert.ok(stA1 > stA0, 'default(fake-b) 熔断后请求自动切到 fake-a（网关内部自愈，default 未改）');

  // 熔断状态在 status 里可见
  const st = await (await fetch(`${GW_BASE}/v1/status`)).json();
  assert.equal(st.providers['fake-b'].state, 'open', 'default fake-b tripped');
  assert.equal(st.providers['fake-a'].state, 'healthy');

  // 恢复：fake-b 回 ok → 冷却+探测后自动 recover → 流量回到 default fake-b
  await setFakeMode(FAKE_B_BASE, 'ok');
  await waitUntil(async () => {
    const s = await (await fetch(`${GW_BASE}/v1/status`)).json();
    return s.providers['fake-b'].state === 'healthy';
  }, 40000, 1000);
  const stB2 = (await fakeStatus(FAKE_B_BASE)).chatRequests;
  const r = await fetch(`${GW_BASE}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${CLIENT_TOKEN}` },
    body: JSON.stringify(body),
  });
  assert.equal(r.status, 200);
  assert.ok((await fakeStatus(FAKE_B_BASE)).chatRequests > stB2, 'recover 后流量回到 default fake-b');
});

test('integration: 推理型模型 unified 请求 max_tokens 给足注入（0827-gw-route，缺失/过小<配置值→配置值，≥配置值不覆盖）', async () => {
  // 确保 default(fake-b) healthy，unified 请求落到 fake-b（fake-b 配置 max_tokens=800）
  await setFakeMode(FAKE_B_BASE, 'ok');
  await setFakeMode(FAKE_A_BASE, 'ok');
  await waitUntil(async () => {
    const s = await (await fetch(`${GW_BASE}/v1/status`)).json();
    return s.providers['fake-b'].state === 'healthy';
  }, 40000, 1000);

  const call = async (body) => {
    const r = await fetch(`${GW_BASE}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${CLIENT_TOKEN}` },
      body: JSON.stringify(body),
    });
    assert.equal(r.status, 200);
    return (await fakeStatus(FAKE_B_BASE)).lastMaxTokens;
  };

  // 未传 max_tokens → 注入 provider.max_tokens(800)
  assert.equal(await call({ model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }] }), 800,
    '缺失 max_tokens 注入 800');
  // 传过小(20) < 800 → 提升到 800（红线：推理占满会空回复）
  assert.equal(await call({ model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }], max_tokens: 20 }), 800,
    '过小 max_tokens(20) 被提升到 800');
  // 传中等值(300) < 800 → 提升到 800
  assert.equal(await call({ model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }], max_tokens: 300 }), 800,
    'max_tokens(300) 提升到 800');
  // 传大值(8000) ≥ 800 → 不覆盖，原样透传
  assert.equal(await call({ model: 'hermes-opc-v1', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8000 }), 8000,
    '大 max_tokens(8000) 不被覆盖');
});
