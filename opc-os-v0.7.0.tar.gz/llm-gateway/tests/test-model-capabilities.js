'use strict';
// test-model-capabilities.js — model_capabilities 官网能力注册表校验（0827-gw-calib, t_d83d13e1）。
//
// Gavin 0827 铁律：网关接入的每一个模型，配置参数一律以官网为唯一事实源，禁止拍脑袋/凭旧值。
// model_capabilities 是权威能力表（官网值 + source 留痕），/v1/models / 路由的运行时默认值
// 不得高于它的官方能力值。本套件单测 lib/config.normalize() 对 model_capabilities 的校验：
//   - 生产 config（含 model_capabilities）正常通过
//   - 未配置 model_capabilities → 行为不变（向后兼容）
//   - 非法值必须明确报错不静默丢弃：context_length<=0 / max_output<=0 / reasoning 非法枚举 /
//     source 空 / verified 条目缺 max_output / status 非法 / api_format 非法枚举 /
//     model_capabilities 非对象
//   - pending-官网核验 条目允许只确认部分字段（不伪造数值）
//
// Run: node --test tests/test-model-capabilities.js  (or `npm test`, 全量)

const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { normalize } = require('../lib/config');

const ROOT = path.resolve(__dirname, '..');
const PROD = JSON.parse(fs.readFileSync(path.join(ROOT, 'gateway.config.json'), 'utf8'));

function fresh() {
  return JSON.parse(JSON.stringify(PROD));
}

test('model_capabilities: production config passes normalize', () => {
  const cfg = normalize(fresh());
  assert.ok(cfg.model_capabilities, 'model_capabilities present');
  const vals = Object.values(cfg.model_capabilities);
  assert.ok(vals.some((e) => e.status === 'verified'), 'has verified entries');
  assert.ok(vals.some((e) => e.status === 'pending-官网核验'), 'has pending entries');
});

test('model_capabilities: absent → no behavior change (backward compat)', () => {
  const cfg = fresh();
  delete cfg.model_capabilities;
  // must not throw
  const out = normalize(cfg);
  assert.equal(out.model_capabilities, undefined);
});

test('model_capabilities: context_length=0 rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities['deepseek-v4-flash'].context_length = 0;
  assert.throws(() => normalize(cfg), /context_length must be a positive integer/);
});

test('model_capabilities: max_output<=0 on verified rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities['deepseek-v4-flash'].max_output = -1;
  assert.throws(() => normalize(cfg), /max_output must be a positive integer/);
});

test('model_capabilities: source empty rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities['deepseek-v4-flash'].source = '';
  assert.throws(() => normalize(cfg), /source is required/);
});

test('model_capabilities: reasoning not in enum rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities['MiniMax-M3'].reasoning = 'sometimes';
  assert.throws(() => normalize(cfg), /reasoning must be/);
});

test('model_capabilities: verified entry missing max_output rejected', () => {
  const cfg = fresh();
  delete cfg.model_capabilities['kimi-k3'].max_output;
  assert.throws(() => normalize(cfg), /status=verified requires max_output>0/);
});

test('model_capabilities: verified entry missing context_length rejected', () => {
  const cfg = fresh();
  delete cfg.model_capabilities['deepseek-v4-flash'].context_length;
  assert.throws(() => normalize(cfg), /status=verified requires context_length>0/);
});

test('model_capabilities: pending entry with only context_length accepted (no fabrication)', () => {
  const cfg = fresh();
  cfg.model_capabilities['grok-4.3'] = {
    source: 'https://docs.x.ai/developers/models',
    status: 'pending-官网核验',
    context_length: 1000000,
  };
  assert.doesNotThrow(() => normalize(cfg));
});

test('model_capabilities: pending entry missing source rejected', () => {
  const cfg = fresh();
  delete cfg.model_capabilities['eyuai'].source;
  assert.throws(() => normalize(cfg), /source is required/);
});

test('model_capabilities: invalid status rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities['kimi-k3'].status = 'confirmed';
  assert.throws(() => normalize(cfg), /status must be/);
});

test('model_capabilities: api_format bad value rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities['deepseek-v4-flash'].api_format = ['openai', 'xai'];
  assert.throws(() => normalize(cfg), /api_format must be/);
});

test('model_capabilities: reasoning_effort bad value rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities['kimi-k3'].reasoning_effort = ['low', 'turbo'];
  assert.throws(() => normalize(cfg), /reasoning_effort must be/);
});

test('model_capabilities: non-object (array) rejected', () => {
  const cfg = fresh();
  cfg.model_capabilities = [1, 2, 3];
  assert.throws(() => normalize(cfg), /must be an object keyed by model id/);
});

test('model_capabilities: every provider-declared model is covered (DoD coverage)', () => {
  const cfg = normalize(fresh());
  const declared = new Set();
  for (const p of cfg.providers) {
    for (const m of p.models) declared.add(m);
  }
  for (const mid of declared) {
    assert.ok(cfg.model_capabilities[mid], `model_capabilities missing for provider model ${mid}`);
  }
});
