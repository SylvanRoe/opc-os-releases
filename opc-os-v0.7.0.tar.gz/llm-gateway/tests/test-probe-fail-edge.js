'use strict';
// test-probe-fail-edge.js — 0827-gw-edge probe_fail 降噪验收（edge-triggered 写盘）。
//
// 语义：probe_fail 仅在 (provider, model) 探测结果从「非失败」翻转到「失败」时 emit，
//   连续失败期间静默（稳态不刷盘）；恢复翻转由 model_recover / recover 承担；
//   trip / model_trip 等其它事件不受影响；provider 级探测（model=null）独立键；
//   reconcile 移除 provider 时清理边缘键。
//
// Run: node --test tests/test-probe-fail-edge.js

const { test, describe } = require('node:test');
const assert = require('node:assert/strict');

function makeHarness(cfgOverrides) {
  const seen = [];
  const events = { emit: (type, fields) => seen.push(Object.assign({ type }, fields)) };
  const cfg = Object.assign({
    providers: [
      { name: 'p1', priority: 1, models: ['m-a', 'm-b'] },
      { name: 'p2', priority: 2, models: ['m-a'] }, // 同名模型，不同 provider
      { name: 'p3', priority: 3 },                  // 无声明模型 → provider 级 ping（model=null）
    ],
    circuit: { failure_threshold: 3, cooldown_s: 60 },
    unified_model: 'hermes-opc-v1',
  }, cfgOverrides);
  const providers = require('../lib/providers').create(JSON.parse(JSON.stringify(cfg)), events);
  return { providers, seen, cfg };
}

function probeFails(seen, provider, model) {
  return seen.filter((e) => e.type === 'probe_fail' && e.provider === provider && e.model === model);
}

function failDetail(status, extra) {
  return Object.assign({ status, error: `HTTP ${status}` }, extra || {});
}

describe('probe_fail edge-triggered（0827-gw-edge）', () => {
  test('连续失败静默：同一 provider+model 连续 5 次失败只 emit 1 条', () => {
    const { providers, seen } = makeHarness();
    for (let i = 0; i < 5; i++) {
      providers.applyProbe('p1', 'm-a', false, failDetail(429));
    }
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 1, '稳态不重复刷盘');
  });

  test('恢复后再次失败 → 再次翻转 emit（诊断链闭环）', () => {
    const { providers, seen } = makeHarness();
    providers.applyProbe('p1', 'm-a', false, failDetail(429)); // 翻转 #1
    providers.applyProbe('p1', 'm-a', false, failDetail(429)); // 静默
    providers.applyProbe('p1', 'm-a', true);                    // 恢复（非熔断场景：仅清零计数）
    providers.applyProbe('p1', 'm-a', false, failDetail(500)); // 翻转 #2
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 2, '恢复后首次失败是新的翻转');
  });

  test('不同 provider 的同名模型各自独立翻转', () => {
    const { providers, seen } = makeHarness();
    providers.applyProbe('p1', 'm-a', false, failDetail(429)); // 翻转
    providers.applyProbe('p2', 'm-a', false, failDetail(429)); // 翻转
    providers.applyProbe('p1', 'm-a', false, failDetail(429)); // p1 静默
    providers.applyProbe('p2', 'm-a', false, failDetail(429)); // p2 静默
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 1);
    assert.equal(probeFails(seen, 'p2', 'm-a').length, 1);
  });

  test('同 provider 不同 model 独立翻转：m-a 静默不影响 m-b 首次 emit', () => {
    const { providers, seen } = makeHarness();
    providers.applyProbe('p1', 'm-a', false, failDetail(429));
    providers.applyProbe('p1', 'm-a', false, failDetail(429));
    providers.applyProbe('p1', 'm-b', false, failDetail(429)); // m-b 首次 → emit
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 1);
    assert.equal(probeFails(seen, 'p1', 'm-b').length, 1);
  });

  test('provider 级探测（model=null）独立键：连续失败只 emit 1 条', () => {
    const { providers, seen } = makeHarness();
    for (let i = 0; i < 3; i++) {
      providers.applyProbe('p3', null, false, failDetail(502));
    }
    const p3Fails = seen.filter((e) => e.type === 'probe_fail' && e.provider === 'p3');
    assert.equal(p3Fails.length, 1, 'provider 级 ping 同样降噪');
    assert.equal(p3Fails[0].model, null, '事件携带 model=null');
  });

  test('非惩罚失败与惩罚期失败都降噪；trip/model_trip 不受影响', () => {
    const { providers, seen } = makeHarness();
    // m-a 业务失败 ×3（healthy 态惩罚性失败）→ 第 1 条 emit，后 2 条静默；第 3 次触发 model_trip
    for (let i = 0; i < 3; i++) {
      providers.applyProbe('p1', 'm-a', false, failDetail(200, { business: true, code: '2056', error: '[quota] x' }));
    }
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 1, '达阈值前只有翻转 1 条');
    assert.equal(seen.filter((e) => e.type === 'model_trip' && e.model === 'm-a').length, 1, 'model_trip 照常');
    // m-b 业务失败 ×3 → provider 全模型废 → trip
    for (let i = 0; i < 3; i++) {
      providers.applyProbe('p1', 'm-b', false, failDetail(200, { business: true, code: '2056', error: '[quota] x' }));
    }
    assert.equal(seen.filter((e) => e.type === 'trip' && e.provider === 'p1').length, 1, 'trip 照常');
    // open 惩罚期（providerOpen）重复失败 → 静默（L305 路径）
    providers.applyProbe('p1', 'm-a', false, failDetail(500));
    providers.applyProbe('p1', 'm-a', false, failDetail(500));
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 1, '惩罚期重复失败静默');
    // 恢复后再次失败 → 新翻转
    providers.applyProbe('p1', 'm-a', true);
    providers.applyProbe('p1', 'm-a', false, failDetail(500));
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 2, '恢复后首次失败翻转');
    // 诊断链完整：trip / model_trip / recover / model_recover 均在
    assert.ok(seen.some((e) => e.type === 'recover' && e.provider === 'p1'), 'recover 照常');
    assert.ok(seen.some((e) => e.type === 'model_recover' && e.provider === 'p1' && e.model === 'm-a'), 'model_recover 照常');
  });

  test('last_probe 仍记录每次探测（唯一事实源不丢，snapshot 可见）', () => {
    const { providers, seen, cfg } = makeHarness();
    for (let i = 0; i < 4; i++) {
      providers.applyProbe('p1', 'm-a', false, failDetail(429));
    }
    providers.applyProbe('p1', 'm-a', true);
    const snap = providers.snapshot(cfg);
    assert.equal(snap.p1.models_status['m-a'].last_probe.ok, true, '最后一次探测是成功');
    assert.equal(snap.p1.last_probe.ok, true, 'provider 级 last_probe 同样最新');
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 1, '写盘 1 条 vs 探测 5 次：降噪比 5:1');
  });

  test('reconcile 移除 provider 时清理边缘键：重加后首次失败重新翻转', () => {
    const { providers, seen } = makeHarness();
    providers.applyProbe('p1', 'm-a', false, failDetail(429)); // prevOk=false
    // 移除 p1（p1 不在列表）
    providers.reconcile([
      { name: 'p2', priority: 2, models: ['m-a'] },
      { name: 'p3', priority: 3 },
    ]);
    // 重新加入 p1
    providers.reconcile([
      { name: 'p1', priority: 1, models: ['m-a', 'm-b'] },
      { name: 'p2', priority: 2, models: ['m-a'] },
      { name: 'p3', priority: 3 },
    ]);
    providers.applyProbe('p1', 'm-a', false, failDetail(429));
    assert.equal(probeFails(seen, 'p1', 'm-a').length, 2, '边缘键被清 → 首次失败重新翻转');
  });
});
