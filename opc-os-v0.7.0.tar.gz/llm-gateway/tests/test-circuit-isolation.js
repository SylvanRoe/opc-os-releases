'use strict';
// test-circuit-isolation.js — 0826-gw-3 缺陷3修复单测：
//   熔断 provider 从候选池隔离（健康池非空完全移出，不进 rest 组尾部）
//   + 全池熔断 fail-open 保底（不回 502 黑洞）+ 持久熔断 degraded 标记/排序
//   + probe 恢复自动清除 degraded 回归候选池。
//
// 对应验收标准：
//   1. 健康池非空时熔断 provider 不在候选（unified 路径 + 显式模型路径）
//   2. 全池熔断 fail-open：候选仍含最高优先级 provider，不回 502 黑洞
//   3. degraded 标记：providers.isDegraded + snapshot().degraded 可见
//   4. degraded 排在所有候选之后（即使 fail-open 场景也最后尝试）
//   5. probe 恢复 → degraded 自动清除 + provider 自动回归候选池
//   （isModelHealthy 乐观默认 L79 保持不变，此处顺带回归验证）
//
// Run: node --test tests/test-circuit-isolation.js

const { test } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

const routerMod = require('../lib/router');
const providersMod = require('../lib/providers');

// ---- 内存事件总线（providers 依赖 events.emit）----
function mkEvents() {
  const log = [];
  return { log, emit: (type, payload) => log.push({ type, payload }) };
}

function mkCfg(overrides) {
  return Object.assign({
    providers: [
      { name: 'p1', priority: 1, models: ['m1'] },
      { name: 'p2', priority: 2, models: ['m2'] },
      { name: 'p3', priority: 3, models: ['m3'] },
    ],
    default_provider: 'p2',
    unified_model: 'hermes-opc-v1',
    circuit: { failure_threshold: 3, cooldown_s: 12 },
    health: { probe_interval_s: 3, probe_timeout_ms: 5000 },
    events: { dir: '/tmp/no-events', max_bytes: 1024 },
  }, overrides || {});
}

// ---- router 单测（mock providers：isHealthy + isDegraded）----
function mkRouter(cfg, healthyMap, degradedMap) {
  const providers = {
    isHealthy: (name) => (healthyMap ? healthyMap[name] !== false : true),
    isDegraded: (name) => !!(degradedMap && degradedMap[name]),
  };
  return routerMod.create(cfg, providers).candidates;
}

test('gw3: 健康池非空 → 熔断 provider 完全移出候选（unified 路径）', () => {
  const c = mkRouter(mkCfg(), { p1: true, p2: false, p3: false });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['p1'], 'tripped p2/p3 不在候选');
});

test('gw3: default 熔断 + 健康池非空 → default 移出，healthy 按 priority（自愈）', () => {
  const c = mkRouter(mkCfg(), { p1: true, p2: false, p3: true });
  // default=p2 tripped → healthy=[p1,p3] 按 priority；p2 完全不在候选
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['p1', 'p3']);
});

test('gw3: 显式模型路径同样隔离（serving 池内 healthy 非空时 tripped 移出）', () => {
  const cfg = mkCfg({
    providers: [
      { name: 'p1', priority: 1, models: [] },      // serves all
      { name: 'p2', priority: 2, models: ['m2'] },
    ],
    default_provider: 'p2',
  });
  const c = mkRouter(cfg, { p1: true, p2: false });
  // 请求 m2：serving=[p1,p2]；p2 tripped → healthy=[p1] 非空 → 候选只有 p1
  assert.deepEqual(c('m2').map((p) => p.name), ['p1']);
});

test('gw3: 全池熔断 → fail-open 保底（候选非空，最高优先级被尝试，不回 502 黑洞）', () => {
  const c = mkRouter(mkCfg(), { p1: false, p2: false, p3: false });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['p1', 'p2', 'p3'], '全部 tripped 仍尝试（纯 priority，与 gw-2 rest 组语义一致）');
  assert.ok(c('hermes-opc-v1').length > 0, '候选非空');
});

test('gw3: 全池熔断 + degraded → degraded 排最后（fail-open 也最后尝试）', () => {
  const c = mkRouter(mkCfg(), { p1: false, p2: false, p3: false }, { p3: true });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['p1', 'p2', 'p3'], 'degraded p3 最后（非 degraded 按 priority）');
});

test('gw3: 健康池非空时 degraded 同样被移出（不占候选位）', () => {
  const c = mkRouter(mkCfg(), { p1: true, p2: false, p3: false }, { p3: true });
  assert.deepEqual(c('hermes-opc-v1').map((p) => p.name), ['p1'], 'p3 degraded 也隔离');
});

test('gw3: 显式模型路径 fail-open（serving 池全熔断 → 仍尝试，degraded 最后）', () => {
  const cfg = mkCfg({
    providers: [
      { name: 'p1', priority: 1, models: ['m2'] },
      { name: 'p2', priority: 2, models: ['m2'] },
    ],
    default_provider: 'p2',
  });
  const c = mkRouter(cfg, { p1: false, p2: false }, { p2: true });
  assert.deepEqual(c('m2').map((p) => p.name), ['p1', 'p2'], 'serving 池全熔断 fail-open，degraded p2 最后');
});

// ---- providers 状态机单测（真实 providers + 注入时钟）----
test('gw3-fix: 持续探针失败（cooldown 重启）不再阻止 degraded 标记（时钟永归零回归）', () => {
  let fakeNow = 1_000_000_000_000;
  const events = mkEvents();
  const providers = providersMod.create(mkCfg(), events, { now: () => fakeNow });

  // 3× provider 级失败 → open（opened_at 记首次 open 时间）
  for (let i = 0; i < 3; i++) providers.recordFailure('p1', 429, 'daily limit');
  const s = providers.get('p1');
  assert.equal(s.state, 'open');
  const firstOpenedAt = s.opened_at;
  assert.equal(firstOpenedAt, fakeNow, 'opened_at = 首次 open 时间');
  assert.equal(s.tripped_at, fakeNow);
  assert.equal(providers.isDegraded('p1'), false, '刚熔断不算 degraded');
  assert.equal(providers.snapshot(mkCfg())['p1'].degraded, false);

  // 每轮 cooldown 探针都失败 → tripped_at 不断刷新（cooldown 重启语义保留），
  // 但 opened_at 保持不变 → 40min 后 degraded 必须成立（原 BUG：恒 false）
  let degradedSeen = false;
  for (let i = 0; i < 40; i++) {
    fakeNow += 60 * 1000; // 一个 cooldown 周期过去
    providers.applyProbe('p1', 'm1', false, { status: 429, error: 'HTTP 429' });
    assert.equal(providers.get('p1').opened_at, firstOpenedAt, 'opened_at 不被探针失败刷新');
    if (providers.isDegraded('p1')) { degradedSeen = true; break; }
  }
  assert.ok(degradedSeen, '40min 持续探针失败后 degraded 成立（时钟不再归零）');
  assert.equal(providers.isDegraded('p1'), true);
  assert.equal(providers.snapshot(mkCfg())['p1'].degraded, true, 'snapshot 可见');
  assert.ok(providers.get('p1').tripped_at > firstOpenedAt, 'tripped_at 已随探针失败前进（cooldown 重启保留）');
  assert.ok(providers.get('p1').opened_at <= firstOpenedAt, 'opened_at 停在首次 open');

  // probe 成功恢复 → opened_at 清除 + degraded 自动清除 + 回归候选池
  providers.applyProbe('p1', 'm1', true, { status: 200 });
  assert.equal(providers.get('p1').state, 'healthy');
  assert.equal(providers.get('p1').opened_at, null, '恢复后 opened_at 清除');
  assert.equal(providers.get('p1').tripped_at, null);
  assert.equal(providers.isDegraded('p1'), false, '恢复后 degraded 自动清除');
});

test('gw3-fix: opened_at 在重新熔断时重新计时（恢复→再熔断→再 degraded）', () => {
  let fakeNow = 1_000_000_000_000;
  const events = mkEvents();
  const providers = providersMod.create(mkCfg(), events, { now: () => fakeNow });

  for (let i = 0; i < 3; i++) providers.recordFailure('p1', 429, 'daily limit');
  const firstOpenedAt = providers.get('p1').opened_at;

  // 恢复（模拟探针成功）
  providers.applyProbe('p1', 'm1', true, { status: 200 });
  assert.equal(providers.get('p1').state, 'healthy');
  assert.equal(providers.get('p1').opened_at, null);

  // 再次熔断 → opened_at 重新计时，且不被探针失败刷新
  fakeNow += 10 * 60 * 1000;
  for (let i = 0; i < 3; i++) providers.recordFailure('p1', 429, 'daily limit');
  const secondOpenedAt = providers.get('p1').opened_at;
  assert.ok(secondOpenedAt > firstOpenedAt, '二次熔断 opened_at 重新计时');
  for (let i = 0; i < 35; i++) {
    fakeNow += 60 * 1000;
    providers.applyProbe('p1', 'm1', false, { status: 429, error: 'HTTP 429' });
    assert.equal(providers.get('p1').opened_at, secondOpenedAt, '二次熔断的 opened_at 同样不被刷新');
  }
  assert.equal(providers.isDegraded('p1'), true, '二次熔断超阈值后同样 degraded');
});

test('gw3: degraded 生命周期 —— 熔断→超阈值→标记；恢复→自动清除', () => {
  let fakeNow = 1_000_000_000_000;
  const events = mkEvents();
  const providers = providersMod.create(mkCfg(), events, { now: () => fakeNow });

  // 3× provider 级失败 → open
  for (let i = 0; i < 3; i++) providers.recordFailure('p1', 429, 'daily limit');
  const s1 = providers.get('p1');
  assert.equal(s1.state, 'open');
  assert.equal(s1.tripped_at, fakeNow);
  assert.equal(providers.isDegraded('p1'), false, '刚熔断不算 degraded');
  assert.equal(providers.snapshot(mkCfg())['p1'].degraded, false);

  // 超过阈值时长（max(30min, 10×cooldown)=30min）→ degraded
  fakeNow += 30 * 60 * 1000 + 1000;
  assert.equal(providers.isDegraded('p1'), true, '超阈值后 degraded');
  assert.equal(providers.snapshot(mkCfg())['p1'].degraded, true, 'snapshot 可见');

  // probe 恢复（traffic ok / applyProbe ok 同路径）→ 自动清除 degraded
  providers.recordSuccess('p1', 'm1');
  assert.equal(providers.get('p1').state, 'healthy');
  assert.equal(providers.isDegraded('p1'), false, '恢复后 degraded 自动清除');
  assert.equal(providers.snapshot(mkCfg())['p1'].degraded, false);
});

test('gw3: probe 恢复 → provider 自动回归候选池（路由层闭环）', () => {
  let fakeNow = 1_000_000_000_000;
  const events = mkEvents();
  const cfg = mkCfg();
  const providers = providersMod.create(cfg, events, { now: () => fakeNow });
  const candidates = routerMod.create(cfg, providers).candidates;

  // p1 全模型熔断（3×失败）→ unified 候选不含 p1（p2/p3 healthy）
  for (let i = 0; i < 3; i++) providers.recordFailure('p1', 429, 'daily limit');
  assert.deepEqual(candidates('hermes-opc-v1').map((p) => p.name), ['p2', 'p3'], '熔断 p1 隔离');

  // 模拟 probe 成功恢复 p1（applyProbe ok 走 recordSuccess → recomputeProviderState）
  providers.applyProbe('p1', 'm1', true, { status: 200 });
  assert.equal(providers.isHealthy('p1'), true);
  assert.deepEqual(candidates('hermes-opc-v1').map((p) => p.name), ['p2', 'p1', 'p3'], 'p1 回归候选（default p2 仍置首）');
});

test('gw3: 单模型熔断不拖垮 provider（isModelHealthy 乐观默认保留）', () => {
  const cfg = mkCfg({
    providers: [{ name: 'p1', priority: 1, models: ['m1', 'm2'] }],
    default_provider: 'p1',
  });
  const events = mkEvents();
  const providers = providersMod.create(cfg, events);
  const candidates = routerMod.create(cfg, providers).candidates;

  // 仅 m1 熔断（声明模型内）→ provider 级仍 healthy，unified 候选保留 p1
  for (let i = 0; i < 3; i++) providers.recordFailure('p1', 429, 'quota', { model: 'm1' });
  assert.equal(providers.isModelHealthy('p1', 'm1'), false, 'm1 熔断');
  assert.equal(providers.isModelHealthy('p1', 'm2'), true, 'm2 未熔断');
  assert.equal(providers.isHealthy('p1'), true, 'provider 级不 trip（anyModelHealthy）');
  assert.deepEqual(candidates('hermes-opc-v1').map((p) => p.name), ['p1'], 'p1 仍在候选');
  assert.equal(candidates('m1').length, 1, '显式 m1 请求 fail-open 保留原池');
});
