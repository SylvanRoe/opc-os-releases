# llm-gateway monitor（0825-c：BYOK 用量监控 + 余额告警 + 切换事件数据源）

透明网关（0825-b，`~/.hermes/opc/llm-gateway/`）的监控配套。周期采集各 BYOK provider
余额/用量/健康，做阈值告警（去重、不轰炸），并把「当前 provider + 切换历史 + 余额」汇总成
单一数据文件，供透明度展示（0825-e）直接消费。

## 文件

| 文件 | 作用 |
|---|---|
| `monitor.js` | 主程序（Node 零依赖，采集→评估→持久化→stdout 契约） |
| `monitor.config.json` | 配置：阈值 / 汇率 / 路径 / 告警去重 / 通知渠道 |
| `usage_state.json` | **输出**：单一数据文件（0825-e 直接消费） |
| `alerts.jsonl` | **输出**：告警事件日志（与网关 events.jsonl 同构：`{ts,seq,type,...}`） |
| `run.sh` | cron 包装（bash 执行 node，供 hermes cron script 模式使用） |

## 数据流

```
gateway.config.json providers ─┐  （唯一事实源：provider 基线，admin/配置加即自动带出）
monitor.config.json providers ─┤→ monitor.js（每 30 分钟，cron llm-gateway-monitor）
   （仅 per-provider 补充字段：balance_endpoint/pricing/thresholds 等，按名映射）
deepseek /user/balance ────────┤   → usage_state.json（单一数据文件）
usage_audit.jsonl ─────────────┤   → alerts.jsonl（事件日志）
gateway /v1/status ────────────┘        └→ 新告警/恢复时 stdout 输出 → cron 投递 Telegram
gateway events.jsonl ──────────────────────┘
```

### provider 基线（0825-gw3，弃手工双份静态基线）

- **基线 = `gateway.config.json` 的 `providers` 数组**（`paths.gateway_config` 指向），
  monitor 每轮采集实时读取；admin 面板加 provider → 下一轮采集自动带出，**无需手改基线**。
- `monitor.config.json` 的 `providers` 只保留**按名映射的补充字段**：
  `balance_endpoint` / `api_key_env` / `currency` / `quota_tokens_month` /
  `monthly_budget_usd` / `model_pricing_usd_per_m` / `thresholds` / `disabled_reason`；
  缺失的补充字段降级默认值（阈值默认 `balance_usd_min=5 / critical=1`、
  `usage_pct_max=0.8 / critical=0.95`、`budget_pct_max=0.8 / critical=1`）。
- `enabled` / `priority` 以网关为准（输出里的 priority 与网关 `/v1/status` 一致）。
- **降级**：`gateway.config.json` 不可读时回退 `monitor.config.json` 的 providers 为基线
  （stderr 打 WARN，`monitor.providers_source` 标明实际来源）。
- ⚠️ `monitor.js` 与 `monitor.config.json` **必须同版本部署**（新代码 + 旧配置 = kimi
  无 `enabled` 会被当禁用；回滚也须两文件一起回滚）。

## 状态文件字段（usage_state.json）

- `generated_at` / `monitor.gateway_online`：采集时间与网关在线态
- `current_provider`：当前生效 provider（优先网关 `/v1/status`，离线时由事件日志派生）+ `since`
- `providers.<name>`：每 provider 的
  - `balance`：余额（CNY 总额 / 充值 / 赠送 / USD 估算，汇率 `usd_cny_rate` 可配）
  - `usage`：24h / 本月 token 用量 + 月度花费估算（源 `~/.hermes/cron/usage_audit.jsonl`，
    `cost_usd_24h`/`cost_usd_month`/`cost_by_model` 见「月度预算口径」）。
    0825-gw3b 起按 provider 归因（P2-2）：usage_audit 条目只有 model，monitor 依
    gateway.config.json providers[].models 做 model→provider 映射（同模型多 provider
    时按 priority 升序归属，即网关路由偏好）逐条过滤；无法归因（降级基线无网关配置）
    时回退全局聚合并在 `usage.scope` 标注 `provider`/`global`
  - `healthy`：网关熔断态（healthy / open / unknown）
  - `thresholds`：该 provider 阈值（告警触发线）
  - `alerts`：各规则状态（active / level / first_active_at / notified_at）
- `switches`：切换历史（派生自网关 `events/events.jsonl`，startup/trip/failover/recover/upstream_error）
- `alerts.active`：当前活跃告警（warn/critical 级）
- `red_lines`：红线声明（config.yaml 未动、文件无密钥、密钥只走 .env 运行时读取）

## 告警规则与走向

| 规则 | 触发 | 级别 |
|---|---|---|
| `balance_low` | 余额 < `balance_usd_min`（默认 $5） | warn；< `balance_usd_critical`（$1）→ critical |
| `balance_unavailable` | provider 官方余额接口 `is_available=false` | warn |
| `balance_query_failed` | 余额接口连续 3 次查询失败（防瞬时抖动） | warn |
| `usage_high` | 月配额用量 > `usage_pct_max`（80%）；> critical（95%） | warn / critical |
| `monthly_budget` | 月度估算花费 ≥ `monthly_budget_usd` × `budget_pct_max`（80%）；≥ × `budget_pct_critical`（100%）→ critical（0825-k：deepseek $300/月红线） | warn / critical |
| `circuit_open` | 网关熔断（healthy→open） | warn |

**告警走向**：
1. 事件日志：`alerts.jsonl` 全量记录每次 raised / cleared / level_change（含 dedup 抑制标记）
2. 触发渠道：cron `llm-gateway-monitor`（每 30 分钟）no_agent 模式——**stdout 非空才投递**到
   Telegram（`deliver=telegram:8126814736`），正常采集 stdout 为空、完全静默
3. 去重：同一 provider+rule 在 `dedup_h`（24h）窗口内只通知一次；恢复通知同样受窗口约束；
   状态文件 `alerts.active` 始终如实展示当前告警（展示层不轰炸）

**kimi**：`enabled=true`（0825-k 起，Gavin 拍板保留年费 Coding Plan 订阅、先用到用完、不充值）。
订阅制（`balance_endpoint=null`、无月度预算）：订阅额度周期性刷新，额度内 403 消失后网关健康探测
自动 `recover`；若订阅额度用尽（chat 仍 403），由网关既有非惩罚性探测定时处理——探测只测 `/v1/models`
（不消耗额度），真实请求 403 才计数熔断。`api_key_env=KIMI_API_KEY` 订阅身份不变，不充值不改配额。

## 月度预算口径（0825-k，验收标准 2）

- **估算公式**：`cost_usd = Σ (prompt_tokens × input_price + completion_tokens × output_price) / 1e6`，
  单价取自 `monitor.config.json` 的 `providers.<name>.model_pricing_usd_per_m`（USD / 每百万 token，
  当前 deepseek-v4-flash = 输入 $0.14 / 输出 $0.28，来源 mrd 全模型定价库
  `marketingdashboard/server/data/model-prices.json` 快照；`default` 键兜底未知模型）。
- **月度窗口**：本地时区（Asia/Shanghai）自然月——`月初 1 日 00:00 归零`，与 `tokens_month` 同口径。
- **字段**：`usage.cost_usd_24h` / `usage.cost_usd_month` / `usage.cost_by_model.<model>.cost_usd`，
  与现有 usage 聚合（`tokens_24h`/`tokens_month`/`by_model`）同源同窗口。
- **触发**：`cost_usd_month ≥ monthly_budget_usd × budget_pct_max`（80%）→ warn；
  `≥ budget_pct_critical`（100%）→ critical。告警写 `alerts.jsonl`（rule=`monthly_budget`），
  与其它规则共用 24h 去重 + cron 静默投递链路。
- **实测记录（0825-k）**：测试阈值（预算 $0.01，估算花费 $0.043）→ raised critical；
  恢复大预算 → cleared；24h 窗口内再触发 → raised `suppressed:dedup`（stdout 空）。与 0825-c 先例同法。

## 运行与验证

```bash
# 手动跑一次（幂等；正常态 stdout 空，只有 stderr 一行 ok 日志）
bash /home/gavin/.hermes/opc/llm-gateway/monitor/run.sh

# 验收 2 实测（改阈值 → 跑 → 恢复阈值 → 跑）：
#   balance_usd_min 临时调高 → stdout 出现 raised 行 + alerts.jsonl 记录 alert
#   （0825-08-25 实测通过：$100 测试阈值触发 raised warn，恢复 5.0 触发 cleared，24h 窗口内再触发 suppressed）

# 状态文件（0825-e 消费）
cat /home/gavin/.hermes/opc/llm-gateway/monitor/usage_state.json

# 线上一致性（网关事件同源）
tail /home/gavin/.hermes/opc/llm-gateway/events/events.jsonl
```

## 红线（与 0825-b 一致）

- 不写 config.yaml（本模块零接触）
- 密钥零落盘：只在运行时从 `GATEWAY_ENV_FILE` 指向的 secrets 文件读取（生产：
  `gateway.env`，chmod 600；`api_key_env` 存变量名），状态/日志文件不含任何密钥
- 告警不轰炸：阈值 + 24h 去重 + cron 静默投递契约

## 部署（同步到 opc-os 产品化轨道）

monitor 目录整体同步到 opc-os 仓（`/home/gavin/hermes_space/opc-os/llm-gateway/monitor/`），
随 0825-b 网关一起分发。cron 由本机 make profile 持有（`hermes -p make cron edit llm-gateway-monitor`）。
