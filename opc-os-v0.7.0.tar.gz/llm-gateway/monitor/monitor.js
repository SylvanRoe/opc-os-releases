'use strict';
// monitor.js — llm-gateway usage/balance monitor (0825-c).
//
// Periodic collector that produces a single data file for the transparency page
// (0825-e): current provider + switch history + per-provider balance/usage/health,
// plus threshold alerts (balance < $X, usage > 80%) with dedup so alerts don't
// spam.
//
// Run modes:
//   node monitor.js                 normal run (collect → evaluate → persist)
//   node monitor.js --notify-test   force-evaluate and print alert text even if
//                                   dedup would suppress it (acceptance test)
//
// Output contract (cron no_agent pattern):
//   stdout empty   → nothing new to notify (silent tick)
//   stdout non-emp → alert text(s), one per line; cron delivers to the channel
//
// Red lines: never writes config.yaml; never writes API keys anywhere (keys are
// read from the GATEWAY_ENV_FILE secrets file — production gateway.env, chmod
// 600 — at runtime only); alerts are deduped by
// provider+rule with a configurable window (alerts.dedup_h).

const fs = require('fs');
const path = require('path');

const MONITOR_DIR = __dirname;
const CFG_PATH = process.env.MONITOR_CONFIG || path.join(MONITOR_DIR, 'monitor.config.json');

const config = JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'));
const P = config.paths;

// ---- env bootstrap (existing secrets mechanism, values never written back) ----
function loadEnv(file) {
  const env = {};
  try {
    const raw = fs.readFileSync(file, 'utf8');
    for (const line of raw.split(/\r?\n/)) {
      const t = line.trim();
      if (!t || t.startsWith('#')) continue;
      const eq = t.indexOf('=');
      if (eq <= 0) continue;
      const k = t.slice(0, eq).trim();
      let v = t.slice(eq + 1).trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      if (k) env[k] = v;
    }
  } catch (e) {
    console.error(`[monitor] WARN cannot load env file ${file}: ${e.message}`);
  }
  return env;
}
const env = loadEnv(P.env_file);

// ---- provider baseline (0825-gw3) ----
// gateway.config.json is the single source of truth for WHICH providers exist
// (added via the gateway admin panel / direct config). monitor.config.json
// keeps only per-provider supplements (balance_endpoint / pricing / thresholds
// / disabled_reason), merged by name. Missing supplements degrade to defaults,
// so adding a provider to the gateway config shows up on the next collection
// with no manual baseline edit. If the gateway config is unreadable we fall
// back to monitor.config.json providers (legacy behavior).
const GW_CONFIG_PATH = P.gateway_config || path.join(MONITOR_DIR, '..', 'gateway.config.json');
const DEFAULT_THRESHOLDS = {
  balance_usd_min: 5,
  balance_usd_critical: 1,
  usage_pct_max: 0.8,
  usage_pct_critical: 0.95,
  budget_pct_max: 0.8,
  budget_pct_critical: 1,
};
// fields monitor.config.json may supplement per provider (by name)
const SUPPLEMENT_KEYS = [
  'balance_endpoint', 'api_key_env', 'currency', 'quota_tokens_month',
  'monthly_budget_usd', 'model_pricing_usd_per_m', 'thresholds', 'disabled_reason',
];

function loadBaselineProviders() {
  let gwCfg = null;
  let source = GW_CONFIG_PATH;
  try {
    gwCfg = JSON.parse(fs.readFileSync(GW_CONFIG_PATH, 'utf8'));
  } catch (e) {
    console.error(`[monitor] WARN cannot read gateway config ${GW_CONFIG_PATH}: ${e.message}; falling back to monitor.config.json providers`);
    gwCfg = null;
  }
  const supplements = config.providers || {};
  const map = {};
  if (gwCfg && Array.isArray(gwCfg.providers)) {
    for (const p of gwCfg.providers) {
      if (!p || !p.name) continue;
      const sup = supplements[p.name] || {};
      const merged = {
        name: p.name,
        enabled: p.enabled !== false,
        priority: (p.priority != null) ? p.priority : 99,
        base_url: p.base_url || null,
        api_key_env: p.api_key_env || sup.api_key_env || null,
        models: Array.isArray(p.models) ? p.models : [],
        quota_tokens_month: null, // explicit null → key always present in output (schema compat)
      };
      for (const k of SUPPLEMENT_KEYS) {
        if (k === 'api_key_env') continue; // baseline (gateway) wins
        if (sup[k] !== undefined) merged[k] = sup[k];
      }
      if (!merged.thresholds) merged.thresholds = Object.assign({}, DEFAULT_THRESHOLDS);
      map[p.name] = merged;
    }
  } else {
    // degraded: no gateway config → legacy behavior (monitor.config.json as baseline)
    source = CFG_PATH;
    for (const [name, sup] of Object.entries(supplements)) {
      map[name] = Object.assign({ name, enabled: sup.enabled !== false, priority: (sup.priority != null) ? sup.priority : 99, quota_tokens_month: null }, sup);
      if (!map[name].thresholds) map[name].thresholds = Object.assign({}, DEFAULT_THRESHOLDS);
    }
  }
  return { providers: map, source };
}

// ---- tiny JSONL helpers ----
function readJsonl(file, limit) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    const lines = text.split('\n').filter(Boolean);
    const slice = limit ? lines.slice(-limit) : lines;
    return slice
      .map((l) => { try { return JSON.parse(l); } catch (e) { return null; } })
      .filter(Boolean);
  } catch (e) {
    return []; // ENOENT etc → empty
  }
}
function appendJsonl(file, obj) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.appendFileSync(file, JSON.stringify(obj) + '\n');
}

// ---- 1. provider balance ----
async function fetchBalance(provider) {
  if (!provider.enabled || !provider.balance_endpoint) {
    return { ok: null, reason: 'disabled' };
  }
  const key = env[provider.api_key_env];
  if (!key) return { ok: false, error: `env ${provider.api_key_env} missing` };
  try {
    const res = await fetch(provider.balance_endpoint, {
      headers: { Authorization: `Bearer ${key}`, Accept: 'application/json' },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return { ok: false, status: res.status, error: `HTTP ${res.status}` };
    const data = await res.json();
    return { ok: true, data };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ---- 2. usage from cron usage_audit.jsonl ----
// Cost estimation (0825-k): spend = Σ (prompt_tokens × input_price + completion_tokens ×
// output_price), prices from provider.model_pricing_usd_per_m (USD per 1M tokens).
// Month window = local-time month start (Asia/Shanghai) → resets to zero on the 1st
// of each month at 00:00, matching tokens_month. Unknown models cost nothing.
//
// 0825-gw3b P2-2: usage_audit entries carry model (not provider), so per-provider
// usage must be attributed via the gateway config model list. buildModelOwner maps
// model → provider deterministically (lowest priority number wins for shared
// models — the gateway's own routing preference). When attribution is impossible
// (degraded baseline without gateway config), scope='global' keeps the legacy
// aggregate so no provider row shows a misleading copy of the global number.
function buildModelOwner(cfgProviders) {
  const owner = {};
  const sorted = Object.values(cfgProviders)
    .filter((p) => p.enabled)
    .sort((a, b) => a.priority - b.priority);
  for (const p of sorted) {
    for (const m of p.models || []) {
      if (owner[m] === undefined) owner[m] = p.name;
    }
  }
  return owner;
}

function aggregateUsage(auditPath, now, pricing, ownerFilter, modelOwner) {
  const entries = readJsonl(auditPath, 20000);
  const day = 24 * 3600 * 1000;
  let tokens24h = 0;
  let tokensMonth = 0;
  let costUsd24h = 0;
  let costUsdMonth = 0;
  const byModel = {};
  const costByModel = {};
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0); // local tz
  const prices = pricing || {};
  for (const e of entries) {
    const ts = new Date(e.ts).getTime();
    if (isNaN(ts)) continue;
    if (ownerFilter) {
      const owner = modelOwner ? modelOwner[e.model || ''] : null;
      if (owner !== ownerFilter) continue;
    }
    const pt = e.prompt_tokens || 0;
    const ct = e.completion_tokens || 0;
    const tok = e.total_tokens || (pt + ct);
    const model = e.model || 'unknown';
    byModel[model] = (byModel[model] || 0) + tok;
    const price = prices[model] || prices.default || null;
    if (price) {
      const cost = (pt / 1e6) * (price.input || 0) + (ct / 1e6) * (price.output || 0);
      costByModel[model] = costByModel[model] || { tokens: 0, cost_usd: 0 };
      costByModel[model].tokens += tok;
      costByModel[model].cost_usd += cost;
      if (ts >= now.getTime() - day) costUsd24h += cost;
      if (ts >= monthStart.getTime()) costUsdMonth += cost;
    }
    if (ts >= now.getTime() - day) tokens24h += tok;
    if (ts >= monthStart.getTime()) tokensMonth += tok;
  }
  return {
    tokens_24h: tokens24h,
    tokens_month: tokensMonth,
    by_model: byModel,
    cost_usd_24h: costUsd24h,
    cost_usd_month: costUsdMonth,
    cost_by_model: costByModel,
    scope: ownerFilter ? 'provider' : 'global',
  };
}

// ---- 3. gateway status (live probe + event-log derived current provider) ----
async function probeGatewayStatus() {
  try {
    const res = await fetch('http://127.0.0.1:18080/v1/status', { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      const data = await res.json();
      return { online: true, status: data };
    }
    return { online: false, error: `HTTP ${res.status}` };
  } catch (e) {
    return { online: false, error: e.message };
  }
}

const SWITCH_TYPES = new Set(['trip', 'recover', 'failover', 'startup', 'upstream_error']);

function deriveSwitches(gatewayEvents, cfgProviders) {
  const history = [];
  let cur = null;
  const fallback = cfgProviders.filter((p) => p.enabled).sort((a, b) => a.priority - b.priority)[0];
  for (const e of gatewayEvents) {
    if (e.type === 'startup') {
      if (Array.isArray(e.providers) && e.providers.length) {
        cur = e.providers[0].split('@')[0];
      }
      history.push({ ts: e.ts, type: 'startup', provider: cur, note: e.note || 'gateway started' });
    } else if (e.type === 'failover') {
      cur = e.provider || cur;
      history.push({ ts: e.ts, type: 'failover', from: e.from, provider: cur, status: e.status, req_id: e.req_id });
    } else if (e.type === 'trip') {
      history.push({ ts: e.ts, type: 'trip', provider: e.provider, status: e.status, failures: e.failures, note: e.note });
    } else if (e.type === 'recover') {
      history.push({ ts: e.ts, type: 'recover', provider: e.provider, note: e.note });
    } else if (e.type === 'upstream_error') {
      history.push({ ts: e.ts, type: 'upstream_error', provider: e.provider, status: e.status, error: e.error });
    }
  }
  // last event that actually changed (or established) the current provider
  let sinceTs = null;
  for (let i = history.length - 1; i >= 0; i--) {
    const t = history[i].type;
    if (t === 'failover' || t === 'startup' || t === 'trip' || t === 'recover') { sinceTs = history[i].ts; break; }
  }
  return {
    history,
    current_provider: cur || (fallback ? fallback.name : null),
    since: sinceTs,
    source: P.gateway_events,
  };
}

// ---- 4. alert evaluation ----
function evaluateAlerts(cfgProviders, collected, prevState) {
  // returns { perProvider: {name: {rule: {active, level, message}}}, events: [...] }
  const perProvider = {};
  const events = [];
  const notifyList = []; // {provider, rule, level, message}

  for (const [name, pcfg] of Object.entries(cfgProviders)) {
    const c = collected[name] || {};
    const prev = (prevState && prevState.providers && prevState.providers[name]) || {};
    const prevAlerts = prev.alerts || {};
    const alerts = {};
    const rules = [];

    if (!pcfg.enabled) {
      // static config fact → shown in state, never notified (not an event)
      alerts.disabled = { active: true, level: 'info', message: `disabled: ${pcfg.disabled_reason || 'n/a'}` };
      perProvider[name] = { alerts, consecutive_balance_failures: 0 };
      continue;
    }
      // balance rules (deepseek)
      if (pcfg.balance_endpoint) {
        if (c.balance && c.balance.ok === true && c.balance.usd_est != null) {
          const usd = c.balance.usd_est;
          if (c.balance.is_available === false) {
            alerts.balance_unavailable = { active: true, level: 'warn', message: `${name} balance API reports is_available=false` };
          } else {
            const th = pcfg.thresholds;
            if (usd < th.balance_usd_critical) {
              alerts.balance_low = { active: true, level: 'critical', message: `${name} balance ${c.balance.currency} ${c.balance.total} (~$${usd.toFixed(2)}) < critical $${th.balance_usd_critical}` };
            } else if (usd < th.balance_usd_min) {
              alerts.balance_low = { active: true, level: 'warn', message: `${name} balance ${c.balance.currency} ${c.balance.total} (~$${usd.toFixed(2)}) < $${th.balance_usd_min}` };
            }
          }
        } else if (c.balance && c.balance.ok === false) {
          // query failure: warn only after 3 consecutive failures (transient-safe)
          const prevFail = prev.consecutive_balance_failures || 0;
          const fails = prevFail + 1;
          c.consecutive_balance_failures = fails;
          if (fails >= 3) {
            alerts.balance_query_failed = { active: true, level: 'warn', message: `${name} balance query failed ${fails}x (last: ${c.balance.error})` };
          } else {
            alerts.balance_query_failed = { active: false, level: 'warn', message: `transient (${fails}/3)` };
          }
        }
      }
      // usage rules (quota-based providers)
      if (pcfg.quota_tokens_month && c.usage && c.usage.tokens_month != null) {
        const pct = c.usage.tokens_month / pcfg.quota_tokens_month;
        c.usage.usage_pct = pct;
        const th = pcfg.thresholds;
        if (pct >= th.usage_pct_critical) {
          alerts.usage_high = { active: true, level: 'critical', message: `${name} month usage ${(pct * 100).toFixed(1)}% >= ${(th.usage_pct_critical * 100).toFixed(0)}%` };
        } else if (pct >= th.usage_pct_max) {
          alerts.usage_high = { active: true, level: 'warn', message: `${name} month usage ${(pct * 100).toFixed(1)}% >= ${(th.usage_pct_max * 100).toFixed(0)}%` };
        }
      }
      // monthly budget rules (cost-estimated, 0825-k: deepseek $300/月红线)
      if (pcfg.monthly_budget_usd && c.usage && c.usage.cost_usd_month != null) {
        const pct = c.usage.cost_usd_month / pcfg.monthly_budget_usd;
        c.usage.budget_pct = pct;
        const th = pcfg.thresholds;
        if (pct >= th.budget_pct_critical) {
          alerts.monthly_budget = { active: true, level: 'critical', message: `${name} month spend ~$${c.usage.cost_usd_month.toFixed(2)} (${(pct * 100).toFixed(1)}%) >= ${(th.budget_pct_critical * 100).toFixed(0)}% of $${pcfg.monthly_budget_usd} monthly budget` };
        } else if (pct >= th.budget_pct_max) {
          alerts.monthly_budget = { active: true, level: 'warn', message: `${name} month spend ~$${c.usage.cost_usd_month.toFixed(2)} (${(pct * 100).toFixed(1)}%) >= ${(th.budget_pct_max * 100).toFixed(0)}% of $${pcfg.monthly_budget_usd} monthly budget` };
        }
      }
      // circuit health from gateway snapshot
      const gwState = (c.gateway && c.gateway.state) || 'unknown';
      if (gwState === 'open') {
        alerts.circuit_open = { active: true, level: 'warn', message: `${name} circuit OPEN (tripped at ${c.gateway.tripped_at || 'n/a'})` };
      }

    // diff vs previous → events + notifications (with dedup)
    const dedupMs = config.alerts.dedup_h * 3600 * 1000;
    for (const [rule, a] of Object.entries(alerts)) {
      const prevA = prevAlerts[rule];
      const prevActive = prevA ? prevA.active : false;
      const prevLevel = prevA ? prevA.level : null;
      const wasNotified = prevA ? !!prevA.notified_at : false;
      const now = new Date().toISOString();
      const nowMs = Date.now();
      // dedup: suppress a repeat notification for the same provider+rule if any
      // notification was sent within the window (prevents alert bombing)
      const lastNotifiedMs = prevA && prevA.notified_at ? new Date(prevA.notified_at).getTime() : 0;
      const recentlyNotified = lastNotifiedMs > 0 && (nowMs - lastNotifiedMs) < dedupMs;
      const entry = {
        rule, active: a.active, level: a.level, message: a.message,
        first_active_at: (a.active && !prevActive) ? now : (prevA ? prevA.first_active_at : null),
        notified_at: wasNotified ? prevA.notified_at : null,
      };
      if (!prevActive && a.active) {
        // new trigger
        entry.first_active_at = now;
        if (!recentlyNotified) {
          events.push({ ts: now, type: 'alert', provider: name, rule, level: a.level, message: a.message, action: 'raised' });
          notifyList.push({ provider: name, rule, level: a.level, message: a.message, action: 'raised' });
          entry.notified_at = now;
        } else {
          events.push({ ts: now, type: 'alert', provider: name, rule, level: a.level, message: a.message, action: 'raised', suppressed: 'dedup' });
          entry.notified_at = prevA.notified_at;
        }
      } else if (prevActive && !a.active) {
        // cleared
        const clearedMsg = a.message;
        if (!recentlyNotified) {
          events.push({ ts: now, type: 'alert_clear', provider: name, rule, level: a.level || prevLevel, message: clearedMsg, action: 'cleared' });
          notifyList.push({ provider: name, rule, level: 'info', message: `${name} alert cleared: ${rule}`, action: 'cleared' });
          entry.notified_at = now;
        } else {
          events.push({ ts: now, type: 'alert_clear', provider: name, rule, level: a.level || prevLevel, message: clearedMsg, action: 'cleared', suppressed: 'dedup' });
          entry.notified_at = prevA.notified_at;
        }
      } else if (a.active && prevActive && prevLevel !== a.level) {
        // escalation/de-escalation while active
        events.push({ ts: now, type: 'alert', provider: name, rule, level: a.level, message: a.message, action: 'level_change', from_level: prevLevel });
        notifyList.push({ provider: name, rule, level: a.level, message: a.message, action: 'level_change' });
        entry.notified_at = now;
      }
      alerts[rule] = entry;
    }
    // rules that were active before but are no longer evaluated (e.g. balance
    // recovered above threshold) → explicit clear, not silent disappearance
    for (const [rule, prevA] of Object.entries(prevAlerts)) {
      if (prevA && prevA.active && !(rule in alerts)) {
        const now = new Date().toISOString();
        const nowMs = Date.now();
        const lastNotifiedMs = prevA.notified_at ? new Date(prevA.notified_at).getTime() : 0;
        const recentlyNotified = lastNotifiedMs > 0 && (nowMs - lastNotifiedMs) < dedupMs;
        const clearMsg = `${name} alert cleared: ${rule}`;
        if (!recentlyNotified) {
          events.push({ ts: now, type: 'alert_clear', provider: name, rule, level: prevA.level, message: clearMsg, action: 'cleared' });
          notifyList.push({ provider: name, rule, level: 'info', message: clearMsg, action: 'cleared' });
        } else {
          events.push({ ts: now, type: 'alert_clear', provider: name, rule, level: prevA.level, message: clearMsg, action: 'cleared', suppressed: 'dedup' });
        }
        alerts[rule] = { rule, active: false, level: prevA.level, message: clearMsg, first_active_at: prevA.first_active_at, notified_at: recentlyNotified ? prevA.notified_at : now };
      }
    }
    // keep previously-active alerts that are no longer evaluated (e.g. provider enabled→disabled) — handled by disabled rule above
    perProvider[name] = { alerts, consecutive_balance_failures: c.consecutive_balance_failures || 0 };
  }
  return { perProvider, events, notifyList };
}

// ---- 5. main ----
async function main() {
  const now = new Date();
  const notifyTest = process.argv.includes('--notify-test');

  // previous state (persisted) for diffing
  let prevState = null;
  try { prevState = JSON.parse(fs.readFileSync(P.usage_state, 'utf8')); } catch (e) { /* first run */ }

  const baseline = loadBaselineProviders();
  const cfgProviders = baseline.providers;
  // per-provider usage attribution (0825-gw3b P2-2): only when the gateway config
  // yields a non-empty model→provider map; degraded baseline keeps legacy global.
  const modelOwner = buildModelOwner(cfgProviders);
  const usageAttributable = Object.keys(modelOwner).length > 0;

  // gather per-provider data
  const collected = {};
  for (const [name, pcfg] of Object.entries(cfgProviders)) {
    const item = { name, enabled: pcfg.enabled, checked_at: now.toISOString() };
    if (pcfg.enabled) {
      const bal = await fetchBalance(pcfg);
      if (bal.ok && bal.data) {
        const infos = bal.data.balance_infos || [];
        const totalCny = infos.reduce((s, b) => s + parseFloat(b.total_balance || 0), 0);
        item.balance = {
          ok: true, is_available: bal.data.is_available,
          currency: (infos[0] && infos[0].currency) || pcfg.currency || null,
          total: totalCny,
          granted: infos.reduce((s, b) => s + parseFloat(b.granted_balance || 0), 0),
          topped_up: infos.reduce((s, b) => s + parseFloat(b.topped_up_balance || 0), 0),
          usd_est: totalCny / config.usd_cny_rate,
        };
      } else {
        item.balance = { ok: false, error: bal.error || (bal.reason || 'unknown') };
      }
      item.usage = aggregateUsage(P.usage_audit, now, pcfg.model_pricing_usd_per_m || {}, usageAttributable ? pcfg.name : null, modelOwner);
      item.gateway = null;
    }
    collected[name] = item;
  }

  // gateway live status + event-derived switches
  const gw = await probeGatewayStatus();
  let gwProviders = null;
  let currentProvider = null;
  let currentProviderSource = 'gateway-events';
  if (gw.online && gw.status) {
    gwProviders = gw.status.providers || null;
    currentProvider = gw.status.current_provider || null;
    if (currentProvider) currentProviderSource = 'gateway:/v1/status';
  }
  for (const [name, item] of Object.entries(collected)) {
    if (gwProviders && gwProviders[name]) {
      item.gateway = {
        state: gwProviders[name].state,
        priority: gwProviders[name].priority,
        tripped_at: gwProviders[name].tripped_at,
        last_probe: gwProviders[name].last_probe,
        requests_total: gwProviders[name].requests_total,
      };
    } else {
      item.gateway = { state: 'unknown', note: gw.online ? 'not in gateway pool' : 'gateway offline' };
    }
  }

  const gatewayEvents = readJsonl(P.gateway_events, 5000);
  const switches = deriveSwitches(gatewayEvents, Object.values(cfgProviders));
  if (!currentProvider) currentProvider = switches.current_provider;

  // evaluate alerts
  const { perProvider, events, notifyList } = evaluateAlerts(cfgProviders, collected, prevState);

  // write alerts log (same {ts,seq,type,...} line shape as gateway events.js)
  let seq = 0;
  try {
    const last = readJsonl(P.alerts_log, 1)[0];
    seq = (last && last.seq) || 0;
  } catch (e) { /* ignore */ }
  for (const ev of events) {
    seq += 1;
    appendJsonl(P.alerts_log, Object.assign({ ts: ev.ts, seq, type: ev.type }, ev));
  }

  // build the single data file for 0825-e
  const state = {
    schema: 'llm-gateway-monitor/usage-state v1',
    generated_at: now.toISOString(),
    monitor: {
      version: '1.3.0',
      interval_s: config.interval_s,
      config: CFG_PATH,
      usd_cny_rate: config.usd_cny_rate,
      gateway_online: gw.online,
      providers_source: baseline.source,
    },
    current_provider: {
      name: currentProvider,
      source: currentProviderSource,
      since: switches.since,
    },
    providers: {},
    switches: {
      source: P.gateway_events,
      last_switch_at: switches.history.length ? switches.history[switches.history.length - 1].ts : null,
      history: switches.history.slice(-50),
    },
    alerts: {
      log: P.alerts_log,
      active: [],
      dedup_h: config.alerts.dedup_h,
      notify: { channel: config.alerts.notify.channel, chat_id: config.alerts.notify.chat_id },
    },
    red_lines: {
      config_yaml_untouched: true,
      no_api_keys_in_file: true,
      keys_source: (P.env_file || 'env file') + ' (runtime only)',
    },
  };
  for (const [name, pcfg] of Object.entries(cfgProviders)) {
    const c = collected[name] || {};
    const al = perProvider[name] ? perProvider[name].alerts : {};
    const activeAlerts = Object.values(al).filter((a) => a.active);
    state.providers[name] = {
      enabled: pcfg.enabled,
      healthy: c.gateway ? c.gateway.state : 'unknown',
      priority: pcfg.priority,
      balance: c.balance || null,
      usage: c.usage || null,
      thresholds: pcfg.thresholds,
      quota_tokens_month: pcfg.quota_tokens_month,
      monthly_budget_usd: pcfg.monthly_budget_usd || null,
      model_pricing_usd_per_m: pcfg.model_pricing_usd_per_m || null,
      disabled_reason: pcfg.enabled ? null : (pcfg.disabled_reason || null),
      alerts: al,
      consecutive_balance_failures: perProvider[name] ? perProvider[name].consecutive_balance_failures : 0,
      last_check: c.checked_at,
    };
    for (const a of activeAlerts) {
      if (a.level === 'warn' || a.level === 'critical') {
        state.alerts.active.push({ provider: name, rule: a.rule, level: a.level, message: a.message });
      }
    }
  }
  fs.mkdirSync(path.dirname(P.usage_state), { recursive: true });
  fs.writeFileSync(P.usage_state, JSON.stringify(state, null, 2) + '\n');

  // ---- stdout contract: only real notifications ----
  // Channel: cron no_agent job delivers non-empty stdout to the configured
  // channel (telegram:8126814736). No in-process telegram push here — a second
  // direct push would double-deliver the same alert. Dedup happens in the
  // evaluate step (notified_at per provider+rule, dedup_h window).
  if (notifyList.length) {
    const lines = notifyList.map((n) => `[llm-gateway-monitor] ${n.action} ${n.level} ${n.provider}/${n.rule}: ${n.message}`);
    console.log(lines.join('\n'));
  }

  console.error(`[monitor] ok: ${Object.keys(cfgProviders).join(',')} checked; state -> ${P.usage_state}; gateway ${gw.online ? 'online' : 'offline'}; alerts_active=${state.alerts.active.length}`);
}

main().catch((e) => {
  console.error(`[monitor] FATAL ${e.stack || e.message}`);
  process.exit(1);
});
