#!/bin/bash
# run.sh — cron wrapper for monitor.js (cron script mode runs .sh via bash).
# stdout contract: empty when nothing to notify; alert lines when something did.
# stderr carries the one-line ok log and is never delivered.
exec /home/gavin/.nvm/versions/node/v24.14.0/bin/node /home/gavin/.hermes/opc/llm-gateway/monitor/monitor.js
