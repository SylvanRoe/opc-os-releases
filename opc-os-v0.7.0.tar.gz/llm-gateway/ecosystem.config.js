// ecosystem.config.js — pm2 常驻定义（SOP=anran ops-service-protection，禁裸进程）
// 启动：PM2_HOME=/home/gavin/.pm2 pm2 start ecosystem.config.js
// 密钥来自网关独立 env 文件：GATEWAY_ENV_FILE 指向 gateway.env（0825-init-2 解耦，
// 不再引用 ~/.hermes/.env；KEY=VALUE 预载，仅读入进程环境，不写回、不落新明文）。
// gateway.config.json 只存 api_key_env 变量名。
'use strict';

module.exports = {
  apps: [
    {
      name: 'llm-gateway',
      script: 'server.js',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 20,
      restart_delay: 3000,
      max_memory_restart: '256M',
      time: true,
      env: {
        NODE_ENV: 'production',
        GATEWAY_ENV_FILE: '/home/gavin/.hermes/opc/llm-gateway/gateway.env',
      },
    },
  ],
};
